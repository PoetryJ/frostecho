/**
 * 福音雪镇 - Electron 主进程 (0.6B 精简版 · 无Steam)
 * 
 * 与 electron-main-06b.js 的区别：
 * - 移除所有 Steam SDK 相关代码（不依赖 steamworks.js）
 * - 不打包 steam_api64.dll 和 steam_appid.txt
 * - 不注册 Steam IPC handlers
 * - 默认启动 0.6B 模型（startLlamaServer('fast')）
 * - 窗口标题标注"精简版(免Steam)"
 * 
 * 使用方式：package.json 中 "main" 指向此文件，或通过 electron-builder -c 指定
 */

const { app, BrowserWindow, shell, dialog, ipcMain } = require('electron');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn, execSync } = require('child_process');
const net = require('net');

// 🧊 无Steam版本 — 不加载 steamworks.js

// ============ 配置 ============
const isDev = process.env.NODE_ENV === 'development' || !app.isPackaged;
const PORT = 18923;
let mainWindow = null;
let embeddedServer = null;

// ============ llama-server 配置 ============
const LLAMA_PORT = 18924;
let llamaProcess = null;
let llamaReady = false;
let llamaLastLogs = [];
let llamaStartAttempt = '';

// 🧊 精简版标记：默认使用 0.6B 小模型
const DEFAULT_MODEL_TYPE = 'fast';

function getLlamaServerPath() {
    if (process.platform === 'win32') {
        const unpackedRoot = isDev ? __dirname : path.join(path.dirname(app.getPath('exe')));
        return {
            serverBin: path.join(unpackedRoot, 'llm', 'llama-server.exe'),
            mainModel: path.join(unpackedRoot, 'llm', 'models', 'Qwen3-8B-Q8_0.gguf'),
            fastModel: path.join(unpackedRoot, 'llm', 'models', 'Qwen3-0.6B-Q8_0.gguf'),
        };
    } else {
        return {
            serverBin: path.join(__dirname, 'asset', 'LLM', 'llama.cpp', 'build', 'bin', 'llama-server'),
            mainModel: path.join(__dirname, 'asset', 'LLM', 'checkpoints', 'Qwen3-8B-Q8_0.gguf'),
            fastModel: path.join(__dirname, 'asset', 'LLM', 'checkpoints', 'Qwen3-0.6B-Q8_0.gguf'),
        };
    }
}

function isPortInUse(port) {
    return new Promise((resolve) => {
        const server = net.createServer();
        server.once('error', (err) => {
            if (err.code === 'EADDRINUSE') resolve(true);
            else resolve(false);
        });
        server.once('listening', () => {
            server.close();
            resolve(false);
        });
        server.listen(port, '127.0.0.1');
    });
}

function waitForLlamaReady(port, maxRetries = 60, interval = 1000) {
    return new Promise((resolve) => {
        let retries = 0;
        const check = () => {
            const req = http.get(`http://127.0.0.1:${port}/health`, (res) => {
                if (res.statusCode === 200) {
                    llamaReady = true;
                    console.log(`🧠 llama-server 就绪 (端口 ${port})`);
                    resolve(true);
                } else {
                    retry();
                }
                res.resume();
            });
            req.on('error', () => retry());
            req.setTimeout(2000, () => { req.destroy(); retry(); });
        };
        const retry = () => {
            retries++;
            if (retries >= maxRetries) {
                console.error(`❌ llama-server 启动超时 (${maxRetries}秒)`);
                resolve(false);
            } else {
                setTimeout(check, interval);
            }
        };
        check();
    });
}

let currentModelType = DEFAULT_MODEL_TYPE;

async function startLlamaServer(modelType = DEFAULT_MODEL_TYPE) {
    currentModelType = modelType;
    const paths = getLlamaServerPath();
    console.log(`🧠 [llama-server] 🧊精简版(免Steam) 路径检测:`);
    console.log(`   可执行文件: ${paths.serverBin} (存在: ${fs.existsSync(paths.serverBin)})`);
    console.log(`   主模型: ${paths.mainModel} (存在: ${fs.existsSync(paths.mainModel)})`);
    console.log(`   快速模型: ${paths.fastModel} (存在: ${fs.existsSync(paths.fastModel)})`);
    console.log(`   🧊 默认启动模型类型: ${modelType}`);
    console.log(`   app.getPath('exe'): ${app.getPath('exe')}`);
    console.log(`   isDev: ${isDev}`);

    if (!fs.existsSync(paths.serverBin)) {
        console.error(`❌ llama-server 不存在: ${paths.serverBin}`);
        return false;
    }
    
    if (!fs.existsSync(paths.fastModel)) {
        console.warn(`⚠️ 快速模型不存在: ${paths.fastModel}`);
        const modelsDir = path.dirname(paths.fastModel);
        if (fs.existsSync(modelsDir)) {
            try {
                const files = fs.readdirSync(modelsDir);
                const ggufFiles = files.filter(f => f.endsWith('.gguf'));
                if (ggufFiles.length > 0) {
                    const fastGguf = ggufFiles.find(f => /0[\.\-_]?6[bB]|small|fast|mini/i.test(f)) || ggufFiles[0];
                    paths.fastModel = path.join(modelsDir, fastGguf);
                    console.log(`🔄 自动选择模型: ${paths.fastModel}`);
                    const mainGguf = ggufFiles.find(f => /8[bB]/i.test(f)) || ggufFiles[0];
                    paths.mainModel = path.join(modelsDir, mainGguf);
                } else {
                    console.error('❌ models 目录中没有 .gguf 文件！');
                    return false;
                }
            } catch (e) {
                console.error(`❌ 无法读取 models 目录: ${e.message}`);
                return false;
            }
        } else {
            console.error(`❌ models 目录不存在: ${modelsDir}`);
            return false;
        }
    }

    const portInUse = await isPortInUse(LLAMA_PORT);
    if (portInUse) {
        console.warn(`⚠️ 端口 ${LLAMA_PORT} 已被占用，尝试复用...`);
        const alreadyRunning = await waitForLlamaReady(LLAMA_PORT, 3, 500);
        if (alreadyRunning) {
            console.log('🧠 复用已有的 llama-server 实例');
            return true;
        }
        try {
            if (process.platform === 'win32') {
                execSync(`netstat -ano | findstr :${LLAMA_PORT} | findstr LISTENING`, { encoding: 'utf-8' });
            } else {
                execSync(`fuser -k ${LLAMA_PORT}/tcp 2>/dev/null`, { encoding: 'utf-8' });
            }
        } catch (e) { /* ignore */ }
    }

    // 🧊 精简版：优先使用 0.6B 小模型
    const activeModel = (modelType === 'fast' && fs.existsSync(paths.fastModel)) ? paths.fastModel : paths.mainModel;
    const modelLabel = modelType === 'fast' ? 'qwen3:0.6b 🧊精简版' : 'qwen3:8b';
    console.log(`🧊 启动 llama-server... [${modelLabel}]`);
    console.log(`   模型: ${activeModel}`);
    console.log(`   端口: ${LLAMA_PORT}`);

    const llamaEnv = { ...process.env };
    const llmDir = path.dirname(paths.serverBin);
    const pathSep = process.platform === 'win32' ? ';' : ':';
    llamaEnv.PATH = llmDir + pathSep + (llamaEnv.PATH || '');
    llamaEnv.GGML_BACKEND_PATH = llmDir;
    console.log(`🧠 llm 目录已加入 PATH: ${llmDir}`);
    console.log(`🧠 GGML_BACKEND_PATH 已设置: ${llmDir}`);

    try {
        const dllFiles = fs.readdirSync(llmDir).filter(f => /\.(dll|so|dylib)$/i.test(f));
        console.log(`🧠 llm 目录中的库文件: [${dllFiles.join(', ')}]`);
    } catch (e) { /* ignore */ }

    const argSets = [
        {
            label: `🧊 GPU 完整参数 (flash-attn + jinja + ctx8192) [${modelLabel}]`,
            isGpu: true,
            args: [
                '--model', activeModel,
                '--host', '127.0.0.1',
                '--port', String(LLAMA_PORT),
                '--ctx-size', '8192',
                '--n-gpu-layers', '99',
                '--flash-attn',
                '--jinja',
            ],
        },
        {
            label: `🧊 GPU 模式 (无 flash-attn, ctx8192) [${modelLabel}]`,
            isGpu: true,
            args: [
                '--model', activeModel,
                '--host', '127.0.0.1',
                '--port', String(LLAMA_PORT),
                '--ctx-size', '8192',
                '--n-gpu-layers', '99',
            ],
        },
        {
            label: `🧊 GPU 模式 (小上下文 ctx4096) [${modelLabel}]`,
            isGpu: true,
            args: [
                '--model', activeModel,
                '--host', '127.0.0.1',
                '--port', String(LLAMA_PORT),
                '--ctx-size', '4096',
                '--n-gpu-layers', '99',
            ],
        },
    ];

    for (let i = 0; i < argSets.length; i++) {
        const { label, args, isGpu } = argSets[i];
        console.log(`🧊 [尝试 ${i + 1}/${argSets.length}] ${label}`);
        console.log(`🧊 启动参数: ${paths.serverBin} ${args.join(' ')}`);
        llamaStartAttempt = `[${i + 1}/${argSets.length}] ${label}`;
        llamaLastLogs = [];

        const result = await tryStartLlama(paths.serverBin, args, llmDir, llamaEnv);
        if (result === true) {
            const gpuTag = isGpu ? '🎮 GPU加速' : '🐢 CPU推理';
            console.log(`✅ 🧊 llama-server 启动成功！使用: ${label} [${gpuTag}]`);
            llamaStartAttempt = `${label} [${gpuTag}]`;
            global.llamaGpuMode = isGpu;
            return true;
        }
        console.warn(`⚠️ [尝试 ${i + 1}] ${label} 失败: ${result}`);
        if (llamaProcess) {
            try { llamaProcess.kill('SIGKILL'); } catch (e) {}
            llamaProcess = null;
        }
        llamaReady = false;
        if (i < argSets.length - 1) {
            console.log('🔄 2秒后尝试下一组参数...');
            await new Promise(r => setTimeout(r, 2000));
        }
    }

    console.error('❌ 🧊 所有 GPU 启动参数组合均失败');
    return false;
}

async function tryStartLlama(serverBin, args, cwd, env) {
    return new Promise(async (resolve) => {
        let resolved = false;
        let earlyExitReason = '';

        llamaProcess = spawn(serverBin, args, {
            stdio: ['ignore', 'pipe', 'pipe'],
            detached: false,
            cwd: cwd,
            env: env,
        });

        llamaProcess.stdout.on('data', (data) => {
            const msg = data.toString().trim();
            if (msg) {
                console.log(`[llama] ${msg}`);
                llamaLastLogs.push(`[out] ${msg}`);
                if (llamaLastLogs.length > 30) llamaLastLogs.shift();
            }
        });
        llamaProcess.stderr.on('data', (data) => {
            const msg = data.toString().trim();
            if (msg) {
                console.log(`[llama-err] ${msg}`);
                llamaLastLogs.push(`[err] ${msg}`);
                if (llamaLastLogs.length > 30) llamaLastLogs.shift();
            }
        });

        llamaProcess.on('exit', (code, signal) => {
            const reason = `exit code=${code}, signal=${signal}`;
            console.error(`🧠 llama-server 退出 (${reason})`);
            earlyExitReason = reason;
            llamaProcess = null;
            llamaReady = false;
            if (!resolved) { resolved = true; resolve(reason); }
        });
        llamaProcess.on('error', (err) => {
            const reason = `spawn error: ${err.message}`;
            console.error(`❌ llama-server 启动失败:`, err.message);
            llamaProcess = null;
            llamaReady = false;
            if (!resolved) { resolved = true; resolve(reason); }
        });

        const ready = await waitForLlamaReady(LLAMA_PORT, 60, 1000);
        if (!resolved) {
            resolved = true;
            resolve(ready ? true : (earlyExitReason || '等待超时(60秒)'));
        }
    });
}

function stopLlamaServer() {
    if (llamaProcess) {
        console.log('🧠 正在关闭 llama-server...');
        try {
            llamaProcess.kill('SIGTERM');
            setTimeout(() => {
                if (llamaProcess) { try { llamaProcess.kill('SIGKILL'); } catch (e) {} }
            }, 3000);
        } catch (e) {
            console.error('关闭 llama-server 异常:', e.message);
        }
    }
}

// ============ 路径解析 ============
function getAppRoot() {
    if (isDev) return __dirname;
    return app.getAppPath();
}

const APP_ROOT = getAppRoot();

function getLogDir() {
    if (isDev) return path.join(__dirname, 'log');
    return path.join(app.getPath('userData'), 'log');
}

const LOG_BASE = getLogDir();
const LOG_DIR = path.join(LOG_BASE, 'debug_log');
const AIMODE_LOG_DIR = path.join(LOG_BASE, 'aimode_log');
const BUG_REPORT_DIR = path.join(LOG_BASE, 'bug_reports');

function ensureLogDirs() {
    [LOG_DIR, AIMODE_LOG_DIR, BUG_REPORT_DIR].forEach(dir => {
        if (!fs.existsSync(dir)) { fs.mkdirSync(dir, { recursive: true }); }
    });
}

// ============ MIME 类型 ============
const MIME_TYPES = {
    '.html': 'text/html; charset=utf-8',
    '.js':   'application/javascript; charset=utf-8',
    '.css':  'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png':  'image/png',
    '.jpg':  'image/jpeg',
    '.gif':  'image/gif',
    '.svg':  'image/svg+xml',
    '.ico':  'image/x-icon',
    '.wav':  'audio/wav',
    '.mp3':  'audio/mpeg',
    '.woff': 'font/woff',
    '.woff2':'font/woff2',
    '.ttf':  'font/ttf',
};

// ============ 内嵌 HTTP 服务器 ============
function startEmbeddedServer() {
    return new Promise((resolve, reject) => {
        embeddedServer = http.createServer((req, res) => {
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
            res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-External-API-URL, X-External-API-Key');

            if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

            // ---- API: 保存 Debug Log ----
            if (req.method === 'POST' && req.url === '/api/save-debug-log') {
                handleJsonPost(req, res, (data) => {
                    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
                    const filename = data.filename || `debug_${timestamp}.log`;
                    const filepath = path.join(LOG_DIR, filename);
                    if (!filepath.startsWith(LOG_DIR)) return sendError(res, 400, '非法文件路径');
                    fs.writeFileSync(filepath, data.content || '', 'utf-8');
                    sendJson(res, { success: true, filename, path: filepath });
                });
                return;
            }

            if (req.method === 'POST' && req.url === '/api/append-debug-log') {
                handleJsonPost(req, res, (data) => {
                    const filename = data.filename || 'current_session.log';
                    const filepath = path.join(LOG_DIR, filename);
                    if (!filepath.startsWith(LOG_DIR)) return sendError(res, 400, '非法文件路径');
                    fs.appendFileSync(filepath, (data.content || '') + '\n', 'utf-8');
                    sendJson(res, { success: true, filename });
                });
                return;
            }

            if (req.method === 'POST' && req.url === '/api/save-aimode-log') {
                handleJsonPost(req, res, (data) => {
                    const filename = data.filename || `aimode_${new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)}.log`;
                    const filepath = path.join(AIMODE_LOG_DIR, filename);
                    if (!filepath.startsWith(AIMODE_LOG_DIR)) return sendError(res, 400, '非法文件路径');
                    fs.writeFileSync(filepath, data.content || '', 'utf-8');
                    sendJson(res, { success: true, filename, path: filepath });
                });
                return;
            }

            if (req.method === 'POST' && req.url === '/api/append-aimode-log') {
                handleJsonPost(req, res, (data) => {
                    const filename = data.filename || 'current_aimode_session.log';
                    const filepath = path.join(AIMODE_LOG_DIR, filename);
                    if (!filepath.startsWith(AIMODE_LOG_DIR)) return sendError(res, 400, '非法文件路径');
                    fs.appendFileSync(filepath, (data.content || '') + '\n', 'utf-8');
                    sendJson(res, { success: true, filename });
                });
                return;
            }

            if (req.method === 'POST' && req.url === '/api/save-bug-report') {
                handleJsonPost(req, res, (data) => {
                    const today = new Date().toISOString().slice(0, 10);
                    if (data.content) {
                        const textFile = path.join(BUG_REPORT_DIR, `bug_report_${today}.log`);
                        if (textFile.startsWith(BUG_REPORT_DIR)) fs.appendFileSync(textFile, data.content + '\n', 'utf-8');
                    }
                    if (data.jsonReport) {
                        const jsonFile = path.join(BUG_REPORT_DIR, `${data.jsonReport.id || 'bug_' + Date.now()}.json`);
                        if (jsonFile.startsWith(BUG_REPORT_DIR)) fs.writeFileSync(jsonFile, JSON.stringify(data.jsonReport, null, 2), 'utf-8');
                    }
                    sendJson(res, { success: true, reportId: data.jsonReport?.id || 'unknown' });
                });
                return;
            }

            if (req.method === 'GET' && req.url === '/api/list-debug-logs') {
                try {
                    const files = fs.readdirSync(LOG_DIR).filter(f => f.endsWith('.log')).map(f => {
                        const stat = fs.statSync(path.join(LOG_DIR, f));
                        return { name: f, size: stat.size, modified: stat.mtime };
                    }).sort((a, b) => b.modified - a.modified);
                    sendJson(res, { files });
                } catch (err) { sendError(res, 500, err.message); }
                return;
            }

            // ---- API: 外部 LLM 代理 ----
            if (req.method === 'POST' && req.url === '/api/external-llm') {
                let body = '';
                req.on('data', chunk => { body += chunk; });
                req.on('end', () => {
                    try {
                        const externalUrl = req.headers['x-external-api-url'];
                        const externalKey = req.headers['x-external-api-key'] || '';
                        if (!externalUrl) return sendError(res, 400, '缺少 X-External-API-URL 头');
                        const parsedUrl = new URL(externalUrl);
                        const isHttps = parsedUrl.protocol === 'https:';
                        const httpModule = isHttps ? require('https') : http;
                        const proxyHeaders = { 'Content-Type': 'application/json', 'Host': parsedUrl.host, 'Content-Length': Buffer.byteLength(body) };
                        if (externalKey) proxyHeaders['Authorization'] = `Bearer ${externalKey}`;
                        const proxyReq = httpModule.request({
                            hostname: parsedUrl.hostname, port: parsedUrl.port || (isHttps ? 443 : 80),
                            path: parsedUrl.pathname + parsedUrl.search, method: 'POST', headers: proxyHeaders,
                        }, (proxyRes) => {
                            const resHeaders = { ...proxyRes.headers };
                            delete resHeaders['access-control-allow-origin'];
                            res.writeHead(proxyRes.statusCode, resHeaders);
                            proxyRes.pipe(res, { end: true });
                        });
                        proxyReq.on('error', (err) => sendError(res, 502, `外部API连接失败: ${err.message}`));
                        proxyReq.setTimeout(120000, () => { proxyReq.destroy(); sendError(res, 504, '外部API请求超时(120秒)'); });
                        proxyReq.write(body);
                        proxyReq.end();
                    } catch (err) { sendError(res, 500, err.message); }
                });
                return;
            }

            // ---- Ollama API 代理 ----
            if (req.url.startsWith('/ollama/')) {
                const ollamaPath = req.url.replace('/ollama', '');
                if (llamaReady) {
                    if (ollamaPath === '/api/ps') {
                        sendJson(res, { models: [{ name: 'qwen3:0.6b', model: 'qwen3:0.6b', size: 0, digest: 'llama-server', details: { format: 'gguf' } }] });
                        return;
                    }
                    if (ollamaPath === '/api/tags') {
                        const models = [{ name: 'qwen3:0.6b', model: 'qwen3:0.6b', size: 0, digest: 'llama-server-06b' }];
                        sendJson(res, { models });
                        return;
                    }
                    if (ollamaPath === '/api/generate' && req.method === 'POST') {
                        let body = '';
                        req.on('data', chunk => body += chunk);
                        req.on('end', () => {
                            try {
                                const ollamaReq = JSON.parse(body);
                                if (ollamaReq.keep_alive === 0) { sendJson(res, { model: ollamaReq.model, response: '', done: true }); return; }
                                const openaiBody = JSON.stringify({ model: 'qwen3:0.6b', prompt: ollamaReq.prompt || 'hi', max_tokens: (ollamaReq.options && ollamaReq.options.num_predict) || 1, stream: false });
                                const proxyReq = http.request({
                                    hostname: '127.0.0.1', port: LLAMA_PORT, path: '/v1/completions', method: 'POST',
                                    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(openaiBody) },
                                }, (proxyRes) => {
                                    let respBody = '';
                                    proxyRes.on('data', chunk => respBody += chunk);
                                    proxyRes.on('end', () => {
                                        try { const o = JSON.parse(respBody); sendJson(res, { model: ollamaReq.model, response: (o.choices && o.choices[0] && o.choices[0].text) || '', done: true }); }
                                        catch (e) { sendJson(res, { model: ollamaReq.model, response: '', done: true }); }
                                    });
                                });
                                proxyReq.on('error', (err) => sendError(res, 502, `llama-server 连接失败: ${err.message}`));
                                proxyReq.setTimeout(30000, () => { proxyReq.destroy(); sendError(res, 504, 'llama-server 预热超时(30秒)'); });
                                proxyReq.write(openaiBody);
                                proxyReq.end();
                            } catch (err) { sendError(res, 500, err.message); }
                        });
                        return;
                    }
                    sendError(res, 404, `llama-server 模式不支持此 Ollama API: ${ollamaPath}`);
                    return;
                }
                const proxyReq = http.request({ hostname: '127.0.0.1', port: 11434, path: ollamaPath, method: req.method, headers: { ...req.headers, host: '127.0.0.1:11434' } }, (proxyRes) => {
                    res.writeHead(proxyRes.statusCode, proxyRes.headers);
                    proxyRes.pipe(res, { end: true });
                });
                proxyReq.on('error', (err) => sendError(res, 502, `Ollama连接失败: ${err.message}`));
                req.pipe(proxyReq, { end: true });
                return;
            }

            // ---- llama-server API 代理 ----
            if (req.url.startsWith('/llm/')) {
                if (!llamaReady) { sendError(res, 503, 'LLM 引擎尚未就绪，请稍候...'); return; }
                const llmPath = req.url.replace('/llm', '');
                const proxyReq = http.request({
                    hostname: '127.0.0.1', port: LLAMA_PORT, path: llmPath, method: req.method,
                    headers: { ...req.headers, host: `127.0.0.1:${LLAMA_PORT}` },
                }, (proxyRes) => {
                    res.writeHead(proxyRes.statusCode, proxyRes.headers);
                    proxyRes.pipe(res, { end: true });
                });
                proxyReq.on('error', (err) => sendError(res, 502, `llama-server连接失败: ${err.message}`));
                proxyReq.setTimeout(120000, () => { proxyReq.destroy(); sendError(res, 504, 'LLM推理超时(120秒)'); });
                req.pipe(proxyReq, { end: true });
                return;
            }

            // ---- API: 切换模型 ----
            if (req.method === 'GET' && req.url.startsWith('/api/llm-switch-model')) {
                const urlObj = new URL(req.url, `http://127.0.0.1`);
                const targetType = urlObj.searchParams.get('type') || DEFAULT_MODEL_TYPE;
                console.log(`🔄 [API] 🧊 收到模型切换请求: ${targetType} (当前: ${currentModelType})`);
                if (targetType === currentModelType && llamaReady) {
                    sendJson(res, { success: true, switched: false, model: currentModelType, message: '已是目标模型' });
                    return;
                }
                (async () => {
                    try {
                        if (llamaProcess) {
                            try { llamaProcess.kill('SIGKILL'); } catch (e) {}
                            llamaProcess = null;
                            llamaReady = false;
                        }
                        await new Promise(r => setTimeout(r, 1000));
                        const success = await startLlamaServer(targetType);
                        sendJson(res, { success, switched: true, model: targetType, message: success ? `已切换到 ${targetType === 'fast' ? '0.6B 🧊精简' : '8B 性能'}模型` : '模型切换失败' });
                    } catch (err) {
                        sendJson(res, { success: false, switched: false, model: currentModelType, message: err.message });
                    }
                })();
                return;
            }

            // ---- API: 等待 LLM 就绪 ----
            if (req.method === 'GET' && req.url === '/api/llm-wait') {
                const maxWait = 90000; const interval = 1000; const startTime = Date.now();
                const pollReady = () => {
                    if (llamaReady) { sendJson(res, { ready: true, backend: 'llama-server', waited: Date.now() - startTime }); }
                    else if (llamaProcess === null && Date.now() - startTime > 15000) { sendJson(res, { ready: false, error: 'llama-server 进程已退出', backend: 'none' }); }
                    else if (Date.now() - startTime >= maxWait) { sendJson(res, { ready: false, error: '等待超时(90秒)', backend: 'none' }); }
                    else { setTimeout(pollReady, interval); }
                };
                pollReady();
                return;
            }

            // ---- API: LLM 一键测试 ----
            if (req.method === 'GET' && req.url === '/api/llm-test') {
                const testResult = { timestamp: new Date().toISOString(), steps: [], success: false };
                const addStep = (name, ok, detail) => testResult.steps.push({ name, ok, detail });
                const paths = getLlamaServerPath();
                const llmDir = path.dirname(paths.serverBin);
                addStep('llama-server.exe 存在', fs.existsSync(paths.serverBin), paths.serverBin);
                addStep('🧊 快速模型文件存在', fs.existsSync(paths.fastModel), paths.fastModel);
                let dllFiles = [];
                try { dllFiles = fs.readdirSync(llmDir).filter(f => /\.(dll|so|dylib)$/i.test(f)); } catch (e) {}
                addStep('CPU 后端 DLL', dllFiles.some(f => /^ggml-cpu/i.test(f)), dllFiles.filter(f => /^ggml-cpu/i.test(f)).join(', ') || '缺失！');
                addStep('CUDA 后端 DLL', dllFiles.some(f => /^ggml-cuda/i.test(f)), dllFiles.some(f => /^ggml-cuda/i.test(f)) ? 'ggml-cuda.dll' : '缺失');
                addStep('llama-server 进程运行中', llamaProcess !== null, llamaProcess ? `PID=${llamaProcess.pid}` : '未运行');
                addStep('llama-server 就绪', llamaReady, llamaReady ? '🧊模型已加载' : '未就绪');
                addStep('🧊 当前模型类型', true, currentModelType);
                addStep('🚫 Steam SDK', true, '无Steam版');
                if (llamaLastLogs.length > 0) addStep('最近日志', true, llamaLastLogs.slice(-5).join('\n'));
                if (llamaReady) {
                    const hReq = http.get(`http://127.0.0.1:${LLAMA_PORT}/health`, (hRes) => {
                        let body = ''; hRes.on('data', d => body += d);
                        hRes.on('end', () => { addStep('健康检查', hRes.statusCode === 200, `HTTP ${hRes.statusCode}: ${body}`); testResult.success = hRes.statusCode === 200; sendJson(res, testResult); });
                    });
                    hReq.on('error', (e) => { addStep('健康检查', false, e.message); sendJson(res, testResult); });
                    hReq.setTimeout(3000, () => { hReq.destroy(); addStep('健康检查', false, '超时(3秒)'); sendJson(res, testResult); });
                } else { sendJson(res, testResult); }
                return;
            }

            // ---- API: LLM 状态查询 ----
            if (req.method === 'GET' && req.url === '/api/llm-status') {
                const paths = getLlamaServerPath();
                const modelsDir = path.dirname(paths.fastModel);
                let modelFiles = [];
                try { if (fs.existsSync(modelsDir)) modelFiles = fs.readdirSync(modelsDir); } catch (e) { /* ignore */ }
                sendJson(res, {
                    llamaReady, llamaPort: LLAMA_PORT, llamaRunning: llamaProcess !== null,
                    gpuMode: global.llamaGpuMode != null ? global.llamaGpuMode : null,
                    currentModelType, backend: llamaReady ? 'llama-server' : 'none',
                    startAttempt: llamaStartAttempt, lastLogs: llamaLastLogs.slice(-10),
                    steamEnabled: false,
                    paths: {
                        serverBin: paths.serverBin, serverBinExists: fs.existsSync(paths.serverBin),
                        mainModel: paths.mainModel, mainModelExists: fs.existsSync(paths.mainModel),
                        fastModel: paths.fastModel, fastModelExists: fs.existsSync(paths.fastModel),
                        modelsDir, modelFiles,
                    },
                });
                return;
            }

            // ---- 静态文件服务 ----
            let filePath = path.join(APP_ROOT, decodeURIComponent(req.url.split('?')[0]));
            if (filePath === APP_ROOT + '/' || filePath === APP_ROOT) filePath = path.join(APP_ROOT, 'index.html');
            if (!filePath.startsWith(APP_ROOT)) { res.writeHead(403); res.end('Forbidden'); return; }
            try {
                const stat = fs.statSync(filePath);
                if (!stat.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end(`404 Not Found: ${req.url}`); return; }
                const ext = path.extname(filePath).toLowerCase();
                const mime = MIME_TYPES[ext] || 'application/octet-stream';
                const headers = { 'Content-Type': mime };
                if (['.js', '.css', '.json', '.html'].includes(ext)) headers['Cache-Control'] = 'no-cache, no-store, must-revalidate';
                res.writeHead(200, headers);
                fs.createReadStream(filePath).pipe(res);
            } catch (err) {
                res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
                res.end(`404 Not Found: ${req.url}`);
            }
        });

        embeddedServer.listen(PORT, '127.0.0.1', () => {
            console.log(`🎮 🧊内嵌服务器已启动(免Steam): http://127.0.0.1:${PORT}`);
            resolve();
        });
        embeddedServer.on('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                console.error(`❌ 端口 ${PORT} 被占用，尝试随机端口...`);
                embeddedServer.listen(0, '127.0.0.1', () => {
                    console.log(`🎮 🧊内嵌服务器已启动（随机端口）: http://127.0.0.1:${embeddedServer.address().port}`);
                    resolve();
                });
            } else { reject(err); }
        });
    });
}

function handleJsonPost(req, res, callback) {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => { try { callback(JSON.parse(body)); } catch (err) { sendError(res, 500, err.message); } });
}
function sendJson(res, data) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(data)); }
function sendError(res, code, message) { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: message })); }

// ============ 创建窗口 ============
function createWindow() {
    const actualPort = embeddedServer.address().port;
    mainWindow = new BrowserWindow({
        width: 1920, height: 900, minWidth: 1200, minHeight: 700,
        title: '🥶 福音雪镇 — 末日生存（0.6B精简版·免Steam）',
        backgroundColor: '#0a0a1a',
        show: false,
        webPreferences: {
            nodeIntegration: false, contextIsolation: true,
            preload: path.join(__dirname, 'preload.js'),
            autoplayPolicy: 'no-user-gesture-required',
        },
    });
    mainWindow.loadURL(`http://127.0.0.1:${actualPort}/index.html?build=06b`);
    mainWindow.once('ready-to-show', () => { mainWindow.show(); mainWindow.focus(); });
    if (isDev) mainWindow.webContents.openDevTools({ mode: 'detach' });
    mainWindow.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
    mainWindow.on('closed', () => { mainWindow = null; });
    mainWindow.setMenuBarVisibility(false);
}

// ============ App 生命周期 ============
app.whenReady().then(async () => {
    ensureLogDirs();

    // 🚫 无Steam版 — 不初始化 Steam SDK
    console.log('🚫 [Steam] 免Steam版本，跳过 Steam SDK 初始化');

    // 注册空的 Steam IPC handlers（前端代码可能调用，返回未初始化状态）
    ipcMain.handle('steam:getStatus', () => ({ inited: false, appId: null, noSteam: true }));
    ipcMain.handle('steam:getPlayerInfo', () => null);
    ipcMain.handle('steam:activateAchievement', () => false);
    ipcMain.handle('steam:isAchievementActivated', () => false);
    ipcMain.handle('steam:setRichPresence', () => {});
    ipcMain.handle('steam:openOverlayToWebPage', () => {});
    ipcMain.handle('steam:openOverlayToStore', () => {});
    ipcMain.handle('steam:cloudSave', () => false);
    ipcMain.handle('steam:cloudLoad', () => null);
    ipcMain.handle('steam:cloudList', () => []);

    // 🧊 精简版：默认启动 0.6B 小模型
    const llamaStartPromise = startLlamaServer('fast').then((ok) => {
        if (ok) console.log('✅ 🧊 llama-server 启动成功，使用 0.6B 小模型 (免Steam版)');
        else console.error('❌ llama-server 启动失败！');
    });
    
    await startEmbeddedServer();
    createWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

app.on('window-all-closed', () => {
    stopLlamaServer();
    if (embeddedServer) embeddedServer.close();
    if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
    stopLlamaServer();
    if (embeddedServer) embeddedServer.close();
});

const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
    app.quit();
} else {
    app.on('second-instance', () => {
        if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); }
    });
}
