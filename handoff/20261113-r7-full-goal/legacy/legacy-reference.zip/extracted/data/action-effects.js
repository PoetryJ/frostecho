/**
 * 福音镇 - 行动效果数据
 * 行为锁优先级定义 + 行动实效性映射表
 * 挂载到 GST.BEHAVIOR_PRIORITY, GST.ACTION_EFFECT_MAP
 */
(function() {
    'use strict';
    const GST = window.GST;

    GST.BEHAVIOR_PRIORITY = {
    FREE: 0,        // 自由行动：闲逛、社交、LLM低优先级决策
    WORK: 1,        // 任务/工作：taskOverride、资源采集、日程工作
    RECOVERY: 2,    // 恢复行为：休息、看病途中
    BASIC_NEED: 3,  // 基本需求：吃饭、睡觉、治疗中
    SURVIVAL: 4,    // 生存紧急：第4天室内锁定、严重失温(体温<35°C)
    FATAL: 5,       // 致命紧急：体温<33°C、健康<10
};


    GST.ACTION_EFFECT_MAP = [
    // 砍柴/伐木 → 产出木柴 【v4.24增强】增加LLM常用同义词
    { keywords: ['砍柴', '伐木', '搬运木柴', '砍树', '收集木柴', '木柴采集', '伐木场工作', '采集木材', '劈柴', '搬木头'], requiredScene: 'village', effectType: 'produce_resource', resourceType: 'woodFuel', ratePerHour: 10, bubbleText: '🪓 砍柴中' },
    // 采集食物/捕鱼 → 产出食物 【v4.24增强】增加LLM常用同义词
    { keywords: ['采集食物', '捕鱼', '搜索罐头', '钓鱼', '打鱼', '食物采集', '收集食物', '寻找食物', '冰湖捕鱼', '采集'], requiredScene: 'village', effectType: 'produce_resource', resourceType: 'food', ratePerHour: 8, bubbleText: '🎣 采集食物中' },
    // 户外采矿 → 产出电力（矿渣堆）【v4.24增强】增加LLM常用同义词
    { keywords: ['采矿', '挖矿', '矿渣', '挖掘', '采集矿石', '矿渣堆'], requiredScene: 'village', effectType: 'produce_resource', resourceType: 'power', ratePerHour: 12, bubbleText: '⛏️ 采矿中（⚡+12/h）' },
    // 探索废墟 → 随机物资（每天限3次）【v4.24增强】增加LLM常用同义词
    { keywords: ['探索废墟', '废墟探索', '废墟', '搜索废墟', '探索遗迹', '探索', '搜索物资', '搜刮'], requiredScene: 'village', effectType: 'explore_ruins', ratePerHour: 1, bubbleText: '🔍 探索废墟中…' },
    // 人工发电/维修发电机/维护电力 → 产出电力（室内工坊）【v4.24增强】增加LLM常用同义词
    { effectKey: 'maintain_power', keywords: ['人工发电', '手摇发电', '手动发电', '维修发电机', '检查发电机', '技术工作', '制造工具', '维护电力', '正在维护电力', '发电', '电力维护', '维修电力', '工坊工作'], requiredScene: 'workshop', effectType: 'produce_resource', resourceType: 'power', ratePerHour: 8, bubbleText: '⚡ 人工发电中（⚡+8/h）' },
    // 暖炉修复/暖炉扩建 已移除（v4.13: 暖炉是被动系统，自动燃烧消耗木柴，不需要人工修复/扩建）
    // 制作急救包/草药制剂 → 制作急救包
    { keywords: ['制作草药', '急救包', '草药制剂', '制药', '整理药品'], requiredScene: 'medical', effectType: 'craft_medkit', ratePerHour: 0.5, bubbleText: '💊 制作急救包中' },
    // 修理无线电已移除（v4.5）
    // 管理仓库/盘点物资/整理库存 → 减少食物浪费 【v4.24增强】增加LLM常用同义词
    { keywords: ['盘点物资', '整理库存', '管理物资', '物资分配', '搬运', '整理物资', '仓库管理', '清点物资', '管理仓库'], requiredScene: 'warehouse', effectType: 'reduce_waste', bubbleText: '📦 管理仓库中（浪费-20%）' },
    // 做饭/准备早餐/晚餐 → 减少食物浪费 【v4.24增强】增加LLM常用同义词
    { keywords: ['做早餐', '准备早餐', '准备晚餐', '分配食物', '准备午餐', '准备明日食材', '做饭', '烹饪', '做菜', '煮饭', '炊事'], requiredScene: 'kitchen', effectType: 'reduce_waste', bubbleText: '🍳 烹饪中（浪费-20%）' },
    // 坐诊/治疗冻伤/心理疏导 → 医疗效果 【v4.24增强】增加LLM常用同义词
    { keywords: ['坐诊', '治疗冻伤', '心理疏导', '巡查伤员', '医疗救治', '处理伤员', '治疗', '看病', '诊治', '医疗工作', '救治伤员'], requiredScene: 'medical', effectType: 'medical_heal', ratePerHour: 1, bubbleText: '🏥 医疗救治中' },
    // 巡查健康状况（限医疗站或暖炉广场）→ 医疗效果
    { keywords: ['巡查', '巡查健康', '巡查伤员'], requiredScene: 'medical', effectType: 'medical_heal', ratePerHour: 1, bubbleText: '🏥 巡查健康中' },
    // 维护暖炉 已移除（v4.13: 暖炉是被动系统，自动燃烧消耗木柴，不需要专人维护）
    // 巡逻/警戒 → 全队San恢复加成
    { keywords: ['巡逻', '警戒', '安全巡查', '巡视', '陷阱', '警报'], requiredScene: 'village', effectType: 'patrol_bonus', bubbleText: '🛡️ 巡逻警戒中' },
    // 安抚/调解/统筹/鼓舞 → San恢复 【v4.24增强】增加LLM常用同义词
    { keywords: ['安抚', '调解冲突', '统筹', '鼓舞', '讲故事', '安慰', '心理支持', '协调', '谈心', '陪伴', '开导', '聊天安慰', '鼓励', '打气', '疏导情绪'], requiredScene: null, effectType: 'morale_boost', ratePerHour: 2, bubbleText: '💬 安抚鼓舞中' },
    // 修理工具 → 产出少量电力
    { keywords: ['修理工具'], requiredScene: 'workshop', effectType: 'produce_resource', resourceType: 'power', ratePerHour: 4, bubbleText: '🔧 修理工具中' },
    // 建造自动发电机 → 推进发电机建造进度
    { effectKey: 'build_machine_generator', keywords: ['建造发电机', '组装发电机', '制造发电机', '建造自动发电机'], requiredScene: 'workshop', effectType: 'build_machine', machineType: 'generator', bubbleText: '🏗️ 建造发电机中' },
    // 建造自动伐木机 → 推进伐木机建造进度
    { effectKey: 'build_machine_lumber', keywords: ['建造伐木机', '组装伐木机', '制造伐木机', '建造自动伐木机'], requiredScene: 'workshop', effectType: 'build_machine', machineType: 'lumberMill', bubbleText: '🏗️ 建造伐木机中' },
    // 建造自动捕猎机 → 推进捕猎机建造进度
    { effectKey: 'build_machine_food', keywords: ['建造捕猎机', '组装捕猎机', '制造捕猎机', '建造自动捕猎机', '建造捕猎机'], requiredScene: 'workshop', effectType: 'build_machine', machineType: 'foodCollector', bubbleText: '🏗️ 建造捕猎机中' },
    // 【v4.22新增】维修自动发电机 → 推进发电机维修进度
    { effectKey: 'repair_machine_generator', keywords: ['维修发电机', '修理发电机', '修发电机', '维修自动发电机'], requiredScene: 'workshop', effectType: 'repair_machine', machineType: 'generator', bubbleText: '🔧 维修发电机中' },
    // 【v4.22新增】维修自动伐木机 → 推进伐木机维修进度
    { effectKey: 'repair_machine_lumber', keywords: ['维修伐木机', '修理伐木机', '修伐木机', '维修自动伐木机'], requiredScene: 'workshop', effectType: 'repair_machine', machineType: 'lumberMill', bubbleText: '🔧 维修伐木机中' },
    // 维修自动捕猎机 → 推进捕猎机维修进度
    { effectKey: 'repair_machine_food', keywords: ['维修捕猎机', '修理捕猎机', '修捕猎机', '维修自动捕猎机', '维修捕猎机'], requiredScene: 'workshop', effectType: 'repair_machine', machineType: 'foodCollector', bubbleText: '🔧 维修捕猎机中' },
];


})();
