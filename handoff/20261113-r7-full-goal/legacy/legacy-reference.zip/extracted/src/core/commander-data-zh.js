/**
 * 福音镇 - 指挥官系统 中文数据层
 * 
 * 架构说明：
 * - 本文件只包含中文相关的数据：别名、正则、任务标签、LLM prompt 模板、回复模板
 * - 路由层在 commander.js 中，通过 GST._commanderDataZh 引用
 * - 英文数据层在 commander-data-en.js 中
 * - 切换语言时自动切换数据源，彻底解耦
 */
(function() {
    'use strict';
    const GST = window.GST;

    // ============ NPC 别名映射（中文输入匹配用） ============
    const ALIAS_MAP = {
        zhao_chef: ['赵铁柱', '赵大厨', '老赵'],
        lu_chen: ['陆沉', '阿沉'],
        li_shen: ['李婶'],
        wang_teacher: ['王策', '王老师', '老师'],
        old_qian: ['老钱', '钱叔'],
        su_doctor: ['苏医生', '老苏'],
        ling_yue: ['凌月', '小凌'],
        qing_xuan: ['清漩', '青玄', '小青'],
    };

    // ============ NPC 显示名映射 ============
    const NAME_MAP = {
        zhao_chef: '赵铁柱',
        lu_chen: '陆辰',
        li_shen: '李婶',
        wang_teacher: '王策',
        old_qian: '老钱',
        su_doctor: '苏岩',
        ling_yue: '歆玥',
        qing_xuan: '清璇',
    };

    // ============ NPC 角色 Emoji ============
    const ROLE_EMOJI = {
        zhao_chef: '👨‍🍳',
        lu_chen: '💪',
        li_shen: '👩‍🍳',
        wang_teacher: '👨‍🏫',
        old_qian: '👴',
        su_doctor: '👨‍⚕️',
        ling_yue: '🔍',
        qing_xuan: '🧪',
    };

    // ============ 任务标签 ============
    const TASK_LABELS = {
        BUILD_LUMBER_MILL: '建造伐木机',
        BUILD_GENERATOR: '建造发电机',
        BUILD_FOOD_COLLECTOR: '建造捕猎机',
        REPAIR_LUMBER_MILL: '维修伐木机',
        REPAIR_GENERATOR: '维修发电机',
        REPAIR_FOOD_COLLECTOR: '维修捕猎机',
        DISTRIBUTE_FOOD: '做饭',
        PREPARE_MEDICAL: '医疗救治',
        MAINTAIN_POWER: '维护电力',
        COLLECT_WOOD: '收集木柴',
        COLLECT_FOOD: '收集食物',
        COLLECT_MATERIAL: '探索废墟',
        BOOST_MORALE: '安抚众人',
        MAINTAIN_ORDER: '巡逻警戒',
        TREATMENT: '接受治疗',
    };

    // ============ 任务默认参数 ============
    const TASK_DEFAULTS = {
        BUILD_LUMBER_MILL: {
            targetLocation: 'workshop_door',
            stateDesc: '建造伐木机',
            reason: '去工坊建造伐木机',
            effectKey: 'build_machine_lumber',
            targetValue: 1,
            priority: 'urgent',
        },
        BUILD_GENERATOR: {
            targetLocation: 'workshop_door',
            stateDesc: '建造发电机',
            reason: '去工坊建造发电机',
            effectKey: 'build_machine_generator',
            targetValue: 1,
            priority: 'urgent',
        },
        BUILD_FOOD_COLLECTOR: {
            targetLocation: 'workshop_door',
            stateDesc: '建造捕猎机',
            reason: '去工坊建造捕猎机',
            effectKey: 'build_machine_food',
            targetValue: 1,
            priority: 'urgent',
        },
        REPAIR_LUMBER_MILL: {
            targetLocation: 'workshop_door',
            stateDesc: '维修伐木机',
            reason: '去工坊维修伐木机',
            effectKey: 'repair_machine_lumber',
            targetValue: 1,
            priority: 'urgent',
        },
        REPAIR_GENERATOR: {
            targetLocation: 'workshop_door',
            stateDesc: '维修发电机',
            reason: '去工坊维修发电机',
            effectKey: 'repair_machine_generator',
            targetValue: 1,
            priority: 'urgent',
        },
        REPAIR_FOOD_COLLECTOR: {
            targetLocation: 'workshop_door',
            stateDesc: '维修捕猎机',
            reason: '去工坊维修捕猎机',
            effectKey: 'repair_machine_food',
            targetValue: 1,
            priority: 'urgent',
        },
        DISTRIBUTE_FOOD: {
            targetLocation: 'kitchen_door',
            stateDesc: '做饭',
            reason: '去炊事房做饭',
            targetValue: 1,
            priority: 'high',
        },
        PREPARE_MEDICAL: {
            targetLocation: 'medical_door',
            stateDesc: '医疗救治',
            reason: '去医疗站治疗',
            targetValue: 1,
            priority: 'urgent',
        },
        MAINTAIN_POWER: {
            targetLocation: 'workshop_door',
            stateDesc: '人工发电',
            reason: '去工坊人工发电',
            effectKey: 'maintain_power',
            targetValue: 20,
            priority: 'urgent',
        },
        COLLECT_WOOD: {
            targetLocation: 'lumber_camp',
            stateDesc: '砍柴',
            reason: '去伐木场砍柴',
            targetValue: 30,
            priority: 'high',
        },
        COLLECT_FOOD: {
            targetLocation: 'frozen_lake',
            stateDesc: '采集食物',
            reason: '去冰湖采集食物',
            targetValue: 20,
            priority: 'high',
        },
        COLLECT_MATERIAL: {
            targetLocation: 'ruins_site',
            stateDesc: '探索废墟',
            reason: '去废墟探索物资',
            targetValue: 1,
            priority: 'high',
        },
        BOOST_MORALE: {
            targetLocation: 'dorm_a_door',
            stateDesc: '安抚',
            reason: '去宿舍安抚大家',
            targetValue: 1,
            priority: 'high',
        },
        MAINTAIN_ORDER: {
            targetLocation: 'dorm_a_door',
            stateDesc: '巡逻',
            reason: '去宿舍巡逻',
            targetValue: 1,
            priority: 'high',
        },
    };

    // ============ 命令预设（正则匹配 → 动作） ============
    const ACTION_PRESETS = [
        {
            match: text => /修.*伐木机|维修.*伐木机|修理.*伐木机/.test(text),
            action: { mode: 'task_system', taskType: 'REPAIR_LUMBER_MILL', ...TASK_DEFAULTS.REPAIR_LUMBER_MILL }
        },
        {
            match: text => /修.*发电机|维修.*发电机|修理.*发电机/.test(text),
            action: { mode: 'task_system', taskType: 'REPAIR_GENERATOR', ...TASK_DEFAULTS.REPAIR_GENERATOR }
        },
        {
            match: text => /建.*伐木机|自动伐木/.test(text),
            action: { mode: 'task_system', taskType: 'BUILD_LUMBER_MILL', ...TASK_DEFAULTS.BUILD_LUMBER_MILL }
        },
        {
            match: text => /建.*发电机|发电机|自动发电/.test(text),
            action: { mode: 'task_system', taskType: 'BUILD_GENERATOR', ...TASK_DEFAULTS.BUILD_GENERATOR }
        },
        { match: text => /休息|睡觉|睡一会|太累|累了|歇会/.test(text), action: { type: 'rest', reason: '回宿舍休息' } },
        { match: text => /吃饭|吃点东西|进食|开饭|去吃/.test(text), action: { type: 'eat', target: 'kitchen_door', reason: '去吃饭' } },
        {
            match: text => /做饭|烹饪|炊事|煮饭|烧饭|准备晚餐|准备早餐/.test(text),
            action: { mode: 'task_system', taskType: 'DISTRIBUTE_FOOD', targetLocation: 'kitchen_door', stateDesc: '准备早餐', reason: '去炊事房做饭', targetValue: 1, priority: 'high' }
        },
        {
            match: text => /医疗|治疗|看病|救人|包扎|制药|草药/.test(text),
            action: { mode: 'task_system', taskType: 'PREPARE_MEDICAL', ...TASK_DEFAULTS.PREPARE_MEDICAL }
        },
        {
            match: text => /人工发电|手摇发电|手动发电|维护电力|修电|发电|电力/.test(text),
            action: { mode: 'task_system', taskType: 'MAINTAIN_POWER', ...TASK_DEFAULTS.MAINTAIN_POWER }
        },
        {
            match: text => /砍柴|伐木|搬木|柴火|木柴|木头/.test(text),
            action: { mode: 'task_system', taskType: 'COLLECT_WOOD', ...TASK_DEFAULTS.COLLECT_WOOD }
        },
        {
            match: text => /捕鱼|抓鱼|钓鱼|采集食物|找吃的|食物/.test(text),
            action: { mode: 'task_system', taskType: 'COLLECT_FOOD', ...TASK_DEFAULTS.COLLECT_FOOD }
        },
        { match: text => /采矿|挖矿|矿石|矿渣/.test(text), action: { type: 'go_to', target: 'ore_pile', reason: '去矿渣堆采矿' } },
        {
            match: text => /探索|废墟|搜寻|侦察/.test(text),
            action: { mode: 'task_system', taskType: 'COLLECT_MATERIAL', ...TASK_DEFAULTS.COLLECT_MATERIAL }
        },
        {
            match: text => /安抚|鼓舞|打气|安慰|谈心|稳定士气/.test(text),
            action: { mode: 'task_system', taskType: 'BOOST_MORALE', ...TASK_DEFAULTS.BOOST_MORALE }
        },
        {
            match: text => /巡逻|守夜|警戒|看守/.test(text),
            action: { mode: 'task_system', taskType: 'MAINTAIN_ORDER', ...TASK_DEFAULTS.MAINTAIN_ORDER }
        },
        { match: text => /仓库|整理物资|盘点|清点库存/.test(text), action: { type: 'go_to', target: 'warehouse_door', reason: '去仓库整理物资' } },
        { match: text => /待命|原地|别动|守在这/.test(text), action: { type: 'go_to', target: 'dorm_a_door', reason: '去宿舍原地待命' } },
        { match: text => /巡视|逛逛|转转|随便走走/.test(text), action: { type: 'go_to', target: 'dorm_a_door', reason: '去宿舍巡视' } },
        { match: text => /工作|干活|忙起来|去干活/.test(text), action: { type: 'go_to', target: 'workshop_door', reason: '去工坊工作' } },
    ];

    // ============ LLM 意图库 ============
    const LLM_INTENT_LIBRARY = {
        BUILD_LUMBER_MILL: { mode: 'task_system', taskType: 'BUILD_LUMBER_MILL', resourceType: null, desc: '去工坊建造自动伐木机，建成后可自动产柴', ...TASK_DEFAULTS.BUILD_LUMBER_MILL },
        BUILD_GENERATOR: { mode: 'task_system', taskType: 'BUILD_GENERATOR', resourceType: null, desc: '去工坊建造自动发电机，建成后可自动产电', ...TASK_DEFAULTS.BUILD_GENERATOR },
        REPAIR_LUMBER_MILL: { mode: 'task_system', taskType: 'REPAIR_LUMBER_MILL', resourceType: null, desc: '去工坊维修故障的自动伐木机', ...TASK_DEFAULTS.REPAIR_LUMBER_MILL },
        REPAIR_GENERATOR: { mode: 'task_system', taskType: 'REPAIR_GENERATOR', resourceType: null, desc: '去工坊维修故障的自动发电机', ...TASK_DEFAULTS.REPAIR_GENERATOR },
        BUILD_FOOD_COLLECTOR: { mode: 'task_system', taskType: 'BUILD_FOOD_COLLECTOR', resourceType: null, desc: '去工坊建造自动捕猎机，建成后可自动产食物', ...TASK_DEFAULTS.BUILD_FOOD_COLLECTOR },
        REPAIR_FOOD_COLLECTOR: { mode: 'task_system', taskType: 'REPAIR_FOOD_COLLECTOR', resourceType: null, desc: '去工坊维修故障的自动捕猎机', ...TASK_DEFAULTS.REPAIR_FOOD_COLLECTOR },
        DISTRIBUTE_FOOD: { mode: 'task_system', taskType: 'DISTRIBUTE_FOOD', resourceType: null, desc: '去炊事房做饭，减少食物浪费', ...TASK_DEFAULTS.DISTRIBUTE_FOOD },
        PREPARE_MEDICAL: { mode: 'task_system', taskType: 'PREPARE_MEDICAL', resourceType: null, desc: '去医疗站治疗伤员或处理医疗事务', ...TASK_DEFAULTS.PREPARE_MEDICAL },
        MAINTAIN_POWER: { mode: 'task_system', taskType: 'MAINTAIN_POWER', resourceType: 'power', desc: '去工坊人工发电，紧急补电', ...TASK_DEFAULTS.MAINTAIN_POWER },
        COLLECT_WOOD: { mode: 'task_system', taskType: 'COLLECT_WOOD', resourceType: 'woodFuel', desc: '去伐木场砍柴补充木柴', ...TASK_DEFAULTS.COLLECT_WOOD },
        COLLECT_FOOD: { mode: 'task_system', taskType: 'COLLECT_FOOD', resourceType: 'food', desc: '去冰湖采集食物', ...TASK_DEFAULTS.COLLECT_FOOD },
        COLLECT_MATERIAL: { mode: 'task_system', taskType: 'COLLECT_MATERIAL', resourceType: null, desc: '去废墟探索物资', ...TASK_DEFAULTS.COLLECT_MATERIAL },
        BOOST_MORALE: { mode: 'task_system', taskType: 'BOOST_MORALE', resourceType: null, desc: '去安抚和鼓舞大家，恢复士气', ...TASK_DEFAULTS.BOOST_MORALE },
        MAINTAIN_ORDER: { mode: 'task_system', taskType: 'MAINTAIN_ORDER', resourceType: null, desc: '去宿舍巡逻警戒', ...TASK_DEFAULTS.MAINTAIN_ORDER },
        MINE_POWER: { mode: 'task_system', taskType: 'MINE_POWER', targetLocation: 'ore_pile', stateDesc: '采矿', reason: '去矿渣堆采矿', targetValue: 20, priority: 'high', resourceType: 'power', desc: '去矿渣堆采矿发电' },
        PSYCHOLOGY: { mode: 'task_system', taskType: 'PSYCHOLOGY', targetLocation: 'medical_door', stateDesc: '心理疏导', reason: '去医疗站心理疏导', targetValue: 1, priority: 'high', resourceType: null, desc: '去医疗站做心理疏导' },
        WAREHOUSE: { mode: 'task_system', taskType: 'WAREHOUSE', targetLocation: 'warehouse_door', stateDesc: '盘点物资', reason: '去仓库盘点物资', targetValue: 1, priority: 'high', resourceType: null, desc: '去仓库盘点物资，减少浪费' },
        REST: { type: 'rest', reason: '回宿舍休息', priority: 'urgent', desc: '回宿舍休息恢复体力' },
        EAT: { type: 'eat', target: 'kitchen_door', reason: '去吃饭', priority: 'urgent', desc: '去炊事房吃饭' },
        WORK: { type: 'go_to', target: 'workshop_door', reason: '去工坊工作', priority: 'normal', desc: '去工坊工作' },
        STAY: { type: 'go_to', target: 'dorm_a_door', reason: '去宿舍待命', priority: 'normal', desc: '去宿舍待命' },
        WANDER: { type: 'go_to', target: 'dorm_a_door', reason: '去宿舍巡视', priority: 'low', desc: '去宿舍巡视' },
    };

    // ============ "全员"别名 ============
    const ALL_ALIASES = ['全员', '所有人', '大家', '全部人'];

    // ============ 问题分析正则 ============
    const QUESTION_PATTERNS = {
        aboutGenerator: /发电机|自动发电/,
        aboutLumberMill: /伐木机|自动伐木/,
        aboutFoodCollector: /捕猎机|自动捕猎/,
        asksResources: /资源|物资|库存|木柴|食物|电力/,
        asksConditions: /条件|需要什么|缺什么|还差什么|门槛|解锁|怎么建|可建|能建/,
        asksProgress: /进度|进展|做到哪|进行到哪|完成了没|完成没有|什么情况|怎么样了/,
        asksTeamStatus: /全员|大家|所有人|全部人|队伍|分工|安排|都在干什么|都在忙什么/,
        asksSelfStatus: /(你现在|你在干什么|你干什么|你忙什么|你的任务|你负责|你那边)/,
        asksSelfStatusFallback: /在干什么|干什么|忙什么|进度|进展|怎么样了|完成了没|完成没有/,
        isQuestion: /我问你|问你|问下|问问|请问|回答我|告诉我|说说|汇报|报告一下|什么条件|需要什么|缺什么|还差什么|进度|进展|做到哪|进行到哪|怎么样了|什么情况|在干什么|干什么|忙什么|完成了没|完成没有|资源怎么样|物资怎么样|解锁|可建|能建|现在怎么样/,
    };

    // ============ 采集描述映射 ============
    const GATHER_NAMES = {
        wood: '砍柴',
        woodFuel: '砍柴',
        food: '采集食物',
        power: '采矿',
        explore: '探索废墟',
    };
    const GATHER_DEFAULT = '采集物资';

    // ============ LLM Prompt 模板 ============

    function buildPlannerSystemPrompt() {
        return `你是末日生存游戏中的"玩家指挥解析器"。你的任务是把一条中文指挥语句解析成结构化JSON，并在需要时生成一句自然、简短、贴合当前局势的NPC回复。
只输出JSON，不要Markdown，不要解释。
必须只使用提供的存活NPC id；不要让死人执行任务。
如果是提问，kind 必须是 question，并写出给指挥官的回复文本。
如果是命令，kind 必须是 directive，并且 intentKey 只能从允许列表中选择。
如果指令不合理、危险、违反生存本能、荒谬、或者不在允许列表中（如自杀、互相伤害、放弃生存等），kind 必须是 refuse，reply 中写出角色拒绝的理由和反应（要有情感、有性格，可以愤怒、恐惧、质疑、劝说等）。
targets 是 NPC id 数组；如果明确是全员就填 ["all"]。
replyMode 只能是 single 或 all。refuse 时 replyMode 建议用 all，让多个角色各自表达态度。
question 的 reply 要用幸存者口吻，简洁自然，可以以"指挥官，"开头。
directive 的 reply 是收到命令后的简短回应，可以留空。
refuse 的 reply 要用角色自己的口吻，表达拒绝、质疑或劝说，要有个性和情感。
优先理解真实意图，不要机械照抄原句。`;
    }

    function buildPlannerUserPrompt(worldSummary, npcCatalog, intentCatalog, statement, fallbackHint) {
        return `【世界状态】
${worldSummary}

【存活NPC】
${npcCatalog}

【可选命令意图键】
${intentCatalog}

【解析要求】
- 如果语句是在询问现状、进度、资源、条件、谁在做什么，用 question。
- 如果语句是在安排工作、命令人行动，用 directive。
- 如果是问"大家/全员/队伍"情况，replyMode 通常用 single，让最合适的一个人代表回答。
- 不要发明新的 intentKey。
- 回复内容要贴合当前世界状态。
- 如果指令危险、不合理、违反生存本能（如自杀、互相伤害、放弃求生），用 refuse，并让角色表达真实反应。
- 如果明显无法理解，就返回 {"kind":"unknown"}。
- ${fallbackHint}

【待解析语句】
${statement}

【输出JSON示例】
{"kind":"directive","targets":["lu_chen"],"replyMode":"all","reply":"指挥官，收到，我这就去补木柴。","intentKey":"COLLECT_WOOD","reason":"去伐木场砍柴"}
{"kind":"question","targets":["old_qian"],"replyMode":"single","reply":"指挥官，发电机还没开工，现在还差木柴和电力。"}
{"kind":"refuse","targets":["all"],"replyMode":"all","reply":"指挥官，你疯了吗？！我们好不容易活到现在，怎么能自杀！"}
{"kind":"unknown"}`;
    }

    function buildFallbackHint(allowFallbackSingle) {
        return allowFallbackSingle
            ? '这是一条单独语句。如果没有明确点名，你可以自行选择最合适的幸存者，或在明显是群体命令时使用 ["all"]。'
            : '如果语句已明确点名或上下文限定，请优先使用被点名的幸存者。';
    }

    function buildFallbackSystemPrompt(npc) {
        return `你是末日生存游戏中的幸存者"${npc.name}"（${npc.occupation || '幸存者'}，${npc.age || '?'}岁，${npc.gender || ''}）。
现在是末日雪灾，你们一群人在雪镇艰难求生。指挥官（玩家）刚刚对你下达了一个命令。
请用你自己的口吻、性格和情感，直接回复指挥官。不需要JSON格式，直接说话就行。
回复要简短自然（一两句话），要有你这个角色的个性。
如果命令荒谬或危险，你可以拒绝、质疑、愤怒、恐惧、劝说——表达你真实的反应。`;
    }

    function buildFallbackUserPrompt(npc, statement) {
        return `指挥官说："${statement}"\n\n请以${npc.name}的身份直接回复：`;
    }

    // ============ 世界摘要模板 ============

    function buildWorldSummaryLabels() {
        return {
            timeHeader: (dayCount, timeStr, period) => `当前时间：第${dayCount}天 ${timeStr} ${period}`,
            weather: w => `天气：${w}`,
            survival: s => `生存状况：${s}`,
            resources: r => `资源：${r}`,
            taskSummary: t => `任务汇总：${t}`,
            facilities: f => `设施：${f}`,
            death: d => `死亡情况：${d}`,
            aliveHeader: '存活成员：',
            npcStatus: (id, name, scene, task, stamina, health, sanity, hunger, bodyTemp) =>
                `${id}/${name}：场景${scene}，状态${task}，体力${Math.round(stamina)}，健康${Math.round(health)}，San${Math.round(sanity)}，饱腹${Math.round(hunger)}，体温${bodyTemp}°C`,
        };
    }

    // ============ 意图目录格式化 ============

    function formatIntentCatalogEntry(key, action) {
        if (action.mode === 'task_system') {
            return `${key}: ${action.desc || action.reason}（目标:${action.targetLocation}，持续状态:${action.stateDesc}，优先级:${action.priority || 'normal'}）`;
        }
        const targetLabel = action.target && GST.NPC.ACTION_TARGETS
            ? (GST.NPC.ACTION_TARGETS[action.target] || action.target)
            : '无固定目标';
        return `${key}: ${action.desc || action.reason}（动作:${action.type}，目标:${targetLabel}，优先级:${action.priority || 'normal'}）`;
    }

    // ============ 回复模板 ============

    const REPLY_TEMPLATES = {
        // 指挥官前缀
        commanderPrefix: '指挥官，',
        // 前往任务
        goingTo: desc => `前往${desc}`,
        // 资源回复
        resourceReply: (wood, woodHours, food, foodMeals, power, powerHours) =>
            `现在仓库里木柴${wood}（大概还能撑${woodHours}小时），食物${food}（够${foodMeals}餐），电力${power}（还能用${powerHours}小时）`,
        crisisWarning: crisisList => `，眼下最危险的是${crisisList}`,
        crisisLabels: { noFood: '食物见底', noPower: '电力告急', noWoodFuel: '木柴见底' },
        noResourceAccess: '我这边暂时拿不到仓库账本。',
        // NPC 任务回复
        noTaskAccess: '我这边暂时汇报不了。',
        myTask: label => `我现在负责${label}`,
        alreadyBuilt: '，已经建好了',
        buildProgress: pct => `，现场建造进度${pct}%`,
        buildPaused: '，不过现在暂时停工了',
        notStarted: '，还没正式开工',
        taskCompleted: '，已经完成了',
        taskPaused: reason => `，目前暂停着，原因是${reason || '条件不足'}`,
        taskProgress: pct => `，进度大约${pct}%`,
        currentlyDoing: desc => `，眼下在${desc}`,
        currentState: desc => `我现在在${desc}。`,
        // 团队摘要
        noSurvivors: '现在没有还能行动的人手了。',
        teamSummary: summaryList => `我看了一圈，目前${summaryList}。`,
        npcDoing: (name, task) => `${name}在${task}`,
        // 机器回复
        machineBuilt: (name, running) => `${name}已经建成${running ? '，现在在运行' : '，但现在停机了'}`,
        machineOutput: (outputLabel, outputPerHour, consumeLabel, consumePerHour) =>
            `，每小时产出${outputLabel}${outputPerHour}，消耗${consumeLabel}${consumePerHour}`,
        machineRunReq: (label, current) => `，当前${label}${current}`,
        machineBuildReq: (woodCost, materialCost, minWorkers, timeHours) =>
            `开建前要木柴${woodCost}、电力${materialCost}，至少${minWorkers}人，大约${timeHours}小时`,
        machineTotalOutput: (produced, outputLabel, consumed, consumeLabel) =>
            `累计产出${Math.round(produced)}${outputLabel}，累计消耗${Math.round(consumed)}${consumeLabel}`,
        machineBuilding: (name, pct) => `${name}正在建造，当前进度${pct}%`,
        machineWorkers: workers => `，施工人手有${workers}`,
        machineBuildPausedNote: '，不过现在因为木柴储备过低暂停了',
        machineNotStarted: (name, unmetText) => `${name}还没开工，${unmetText}`,
        machineUnlockMissing: missing => `解锁还差${missing}`,
        machineUnlockReady: '解锁条件已经满足',
        machineBuildCost: (woodCost, materialCost, minWorkers, timeHours) =>
            `正式建造要木柴${woodCost}、电力${materialCost}，至少${minWorkers}人，大约${timeHours}小时`,
        // 指令回复
        directiveAlreadyBuilt: (name) => `指挥官，收到，${name}已经建好了，我先去检查运行情况。`,
        directiveJoinBuild: (name, pct) => `指挥官，收到，我会去支援${name}建设，现场进度${pct}%`,
        directiveCurrentWorkers: workers => `，现在施工的是${workers}`,
        directiveBuildPaused: '，不过现在暂时停工了',
        directiveUnlockMissing: (reason, missing) => `指挥官，收到，我会${reason}，不过现在还差${missing}。`,
        directiveUnlockReady: reason => `指挥官，收到，我会${reason}，建造条件已经满足。`,
        directiveAck: reason => `指挥官，收到，我会${reason}。`,
        // 拒绝回复
        refuseDefault: '指挥官，这个命令我没法执行。',
        // 默认任务标签
        defaultTaskLabel: '任务',
        defaultAction: '执行命令',
        defaultStandby: '待命',
        unknownScene: '未知场景',
        // 指挥官名称
        commanderName: '指挥官',
        // 指挥官前缀正则
        commanderPrefixRegex: /^指挥官[，,:：]?/,
        commanderPrefixNormalize: '指挥官，',
    };

    // ============ NPC 目录格式化 ============

    function formatNpcCatalogEntry(npc, displayName, aliases) {
        return `${npc.id}（显示名:${displayName}，别名:${aliases || npc.name}）`;
    }

    // ============ 暴露到全局 ============
    GST._commanderDataZh = {
        ALIAS_MAP,
        NAME_MAP,
        ROLE_EMOJI,
        TASK_LABELS,
        TASK_DEFAULTS,
        ACTION_PRESETS,
        LLM_INTENT_LIBRARY,
        ALL_ALIASES,
        QUESTION_PATTERNS,
        GATHER_NAMES,
        GATHER_DEFAULT,
        REPLY_TEMPLATES,
        buildPlannerSystemPrompt,
        buildPlannerUserPrompt,
        buildFallbackHint,
        buildFallbackSystemPrompt,
        buildFallbackUserPrompt,
        buildWorldSummaryLabels,
        formatIntentCatalogEntry,
        formatNpcCatalogEntry,
    };
})();
