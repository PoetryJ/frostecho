/**
 * 福音镇 - Camera 摄像机
 * 跟随目标、视口计算、缩放、边界限制
 * 挂载到 GST.Camera
 */
(function() {
    'use strict';
    const GST = window.GST;

class Camera {
    constructor(w, h) {
        this.x = 0;
        this.y = 0;
        this.width = w;
        this.height = h;
        // 平滑跟随
        this.targetX = 0;
        this.targetY = 0;
        this.smoothSpeed = 3; // 值越大跟随越快
    }

    /** 【v4.40】边界限制：地图比视口小时居中显示，大时正常限制 */
    _clampX(val, mapW) {
        if (mapW <= this.width) {
            // 地图比视口小 → 居中显示
            return (mapW - this.width) / 2;
        }
        return Math.max(0, Math.min(val, mapW - this.width));
    }

    _clampY(val, mapH) {
        if (mapH <= this.height) {
            // 地图比视口小 → 居中显示
            return (mapH - this.height) / 2;
        }
        return Math.max(0, Math.min(val, mapH - this.height));
    }

    /** 立即跳到目标 */
    jumpTo(tx, ty, mapW, mapH) {
        this.targetX = tx - this.width / 2;
        this.targetY = ty - this.height / 2;
        this.targetX = this._clampX(this.targetX, mapW);
        this.targetY = this._clampY(this.targetY, mapH);
        this.x = this.targetX;
        this.y = this.targetY;
    }

    /** 平滑跟随 */
    followSmooth(tx, ty, mapW, mapH, dt) {
        this.targetX = tx - this.width / 2;
        this.targetY = ty - this.height / 2;
        this.targetX = this._clampX(this.targetX, mapW);
        this.targetY = this._clampY(this.targetY, mapH);
        const lerp = 1 - Math.exp(-this.smoothSpeed * dt);
        this.x += (this.targetX - this.x) * lerp;
        this.y += (this.targetY - this.y) * lerp;
    }

    /** Debug 模式: WASD 直接移动 */
    moveBy(dx, dy, mapW, mapH) {
        this.x += dx;
        this.y += dy;
        this.x = this._clampX(this.x, mapW);
        this.y = this._clampY(this.y, mapH);
        this.targetX = this.x;
        this.targetY = this.y;
    }
}


// ============ Game 主类 ============


    GST.Camera = Camera;
})();
