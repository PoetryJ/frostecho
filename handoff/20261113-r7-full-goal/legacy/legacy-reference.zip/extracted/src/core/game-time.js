/**
 * 福音镇 - 游戏时间与结算
 * 从 game.js 拆分，遵循SRP原则
 * 挂载到 GST.Game.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.Game.prototype;


    proto._onHourChange = function(hour) {
        // 【修复】废掉旧的随机天气系统，统一使用 WeatherSystem 的预设天气
        // 每小时同步 WeatherSystem 的天气到 this.weather，确保全局一致
        if (this.weatherSystem) {
            this.weather = this.weatherSystem.currentWeather;
            this._updateRainIntensity();
        }

        // 【v4.42】游戏内21:00触发日结算（检查任务完成+人生目标完成）
        if (hour === 21) {
            this._performDailySettlement();
        }

        // 【v4.8】资源危机检测 → 自动触发投票决策会议
        if (this.councilSystem && !this.paused) {
            this.councilSystem.checkResourceCrisisTrigger();
        }

        // 【v4.17】NPC危机状态检测 → 有人发疯/濒死时自动触发紧急决策会议
        if (this.councilSystem && !this.paused) {
            this.councilSystem.checkNpcCrisisTrigger();
        }

        // 【v4.8】清理过期的投票决策分工
        if (GST.CouncilSystem && GST.CouncilSystem.cleanExpiredCouncilTasks) {
            GST.CouncilSystem.cleanExpiredCouncilTasks(this.npcs);
        }
    };


    // ============ 【v4.42】每日21:00结算 ============
    // 检查每个角色的任务完成情况和人生目标完成情况
    proto._performDailySettlement = function() {
        // 防止同一天重复结算
        if (this._lastSettlementDay === this.dayCount) return;
        this._lastSettlementDay = this.dayCount;

        const day = this.dayCount;
        const aliveNpcs = this.npcs.filter(n => !n.isDead);

        console.log(`[结算] ===== 第${day}天 21:00 日结算开始 =====`);
        this.addEvent(GST.t('event.settlement_header', { n: day }));

        // ============ 1. 任务完成情况 ============
        if (this.taskSystem && this.taskSystem.dailyTasks) {
            const tasks = this.taskSystem.dailyTasks;
            const completedTasks = tasks.filter(t => t.status === 'completed');
            const totalTasks = tasks.length;

            this.addEvent(GST.t('event.task_complete', { done: completedTasks.length, total: totalTasks }));

            for (const task of tasks) {
                const progressPct = task.target > 0 ? Math.round((task.progress / task.target) * 100) : 0;
                const npc = this.npcs.find(n => n.id === task.assignedNpcId);
                const npcName = npc ? (npc.displayName || npc.name) : 'N/A';
                if (task.status === 'completed') {
                    this.addEvent(GST.t('day_summary.task_done', { task: task.name, npc: npcName }));
                } else {
                    this.addEvent(GST.t('day_summary.task_progress', { task: task.name, npc: npcName, pct: progressPct }));
                }
            }
        }

        // ============ 2. 人生目标完成情况 ============
        this.addEvent(GST.t('event.goal_progress'));
        for (const npc of aliveNpcs) {
            if (!npc.goals || npc.goals.length === 0) continue;

            const completedGoals = npc.goals.filter(g => g.completed);
            const totalGoals = npc.goals.length;
            const dailyGoals = npc.goals.filter(g => g.type === 'daily');
            const lifeGoals = npc.goals.filter(g => g.type !== 'daily');

            let goalSummary = `  ${npc.displayName || npc.name}: `;
            const parts = [];

            // 每日目标
            for (const g of dailyGoals) {
                const pct = g.targetValue > 0 ? Math.min(100, Math.round((g.progress / g.targetValue) * 100)) : 0;
                parts.push(`${g.completed ? '✅' : '⬜'}${g.desc}(${pct}%)`);
            }
            // 人生目标
            for (const g of lifeGoals) {
                const pct = g.targetValue > 0 ? Math.min(100, Math.round((g.progress / g.targetValue) * 100)) : 0;
                parts.push(`${g.completed ? '🏆' : '⬜'}${g.desc}(${pct}%)`);
            }

            goalSummary += parts.join(' | ');
            this.addEvent(goalSummary);
        }

        // ============ 3. 存活状态总结 ============
        const deadNpcs = this.npcs.filter(n => n.isDead);
        this.addEvent(GST.t('event.alive_status', { alive: aliveNpcs.length }) + (deadNpcs.length > 0 ? ` | ${GST.t('event.dead_list', { names: deadNpcs.map(n => n.displayName || n.name).join(', ') })}` : ''));

        // ============ 4. AI模式日志 ============
        if (this.aiModeLogger) {
            const lines = [];
            lines.push(`第${day}天21:00日结算:`);

            // 任务
            if (this.taskSystem && this.taskSystem.dailyTasks) {
                const tasks = this.taskSystem.dailyTasks;
                const completed = tasks.filter(t => t.status === 'completed').length;
                lines.push(`  任务: ${completed}/${tasks.length}完成`);
                for (const t of tasks) {
                    const pct = t.target > 0 ? Math.round((t.progress / t.target) * 100) : 0;
                    lines.push(`    ${t.status === 'completed' ? '✅' : '❌'} ${t.name}: ${pct}% (${t.assignedNpcId})`);
                }
            }

            // 目标
            for (const npc of aliveNpcs) {
                if (!npc.goals || npc.goals.length === 0) continue;
                const goalStr = npc.goals.map(g => {
                    const pct = g.targetValue > 0 ? Math.min(100, Math.round((g.progress / g.targetValue) * 100)) : 0;
                    return `${g.completed ? '✅' : '❌'}${g.desc}(${pct}%)`;
                }).join(', ');
                lines.push(`  ${npc.name}目标: ${goalStr}`);
            }

            this.aiModeLogger.log('DAILY_SETTLEMENT', lines.join('\n'));
        }

        this.addEvent(GST.t('event.settlement_footer'));
        console.log(`[结算] ===== 第${day}天 日结算完毕 =====`);
    };


    /**
    * 全员入睡跳夜机制：所有存活NPC都在睡觉时，直接跳到早6点
    * - 仅在深夜时段（22:00~05:59）生效
    * - 每天只触发一次，防止反复跳
    * - 跳过期间补算NPC的体力/San值/体温恢复
    * - 正确处理跨午夜日切换
    */

    proto._checkNightSkip = function() {
        // 已经跳过了今晚，不再重复
        if (this._nightSkipDone) return;

        // 【v4.22修复】第4天也允许跳夜到06:00，然后正常走到18:00触发结局
        // 之前禁止第4天跳夜导致全员睡着后玩家干等4.5小时游戏时间流逝
        // if (this.dayCount >= 4) return;  // 已移除

        const hour = this.getHour();
        // 放宽检测时段：20:00~05:59（NPC可能因体力不支在20点就开始强制入睡）
        const isNightTime = hour >= 20 || hour < 6;
        if (!isNightTime) {
            this._allSleepingFrames = 0; // 非夜间重置计数
            return;
        }

        // 检测所有存活NPC是否都在睡觉
        const aliveNpcs = this.npcs.filter(n => !n.isDead);
        if (aliveNpcs.length === 0) return; // 无存活NPC不跳
        
        // 允许 isSleeping=true 或者 state==='SLEEPING' 都算在睡觉
        const allSleeping = aliveNpcs.every(n => n.isSleeping || n.state === 'SLEEPING');
        
        // 调试日志：每5秒打印一次跳夜检测状态
        if (!this._lastNightSkipLog || Date.now() - this._lastNightSkipLog > 5000) {
            this._lastNightSkipLog = Date.now();
            const statusList = aliveNpcs.map(n => `${n.name}:sleeping=${n.isSleeping},state=${n.state},scene=${n.currentScene}`).join(' | ');
            console.log(`[跳夜检测] hour=${hour} allSleeping=${allSleeping} frames=${this._allSleepingFrames} alive=${aliveNpcs.length} | ${statusList}`);
        }
        
        if (!allSleeping) {
            this._allSleepingFrames = 0; // 有人醒着，重置计数
            return;
        }

        // 防抖动：需要连续多帧（约0.5秒，30帧@60fps）全员在睡才触发跳夜
        // 这样即使有NPC被短暂饿醒又重新入睡，也不会阻止跳夜
        this._allSleepingFrames = (this._allSleepingFrames || 0) + 1;
        if (this._allSleepingFrames < 30) return; // 等待约0.5秒稳定

        // ✅ 全员入睡持续稳定 → 执行跳夜
        this._nightSkipDone = true;
        this._allSleepingFrames = 0;

        // 计算需要跳过的游戏秒数（跳到早6点=21600秒）
        const targetSeconds = 6 * 3600; // 06:00
        const currentSeconds = this.gameTimeSeconds;
        let skipSeconds;
        if (currentSeconds >= 20 * 3600) {
            // 20:00~23:59 → 需要跨午夜：先到24:00再到06:00
            skipSeconds = (24 * 3600 - currentSeconds) + targetSeconds;
        } else {
            // 00:00~05:59 → 直接跳到06:00
            skipSeconds = targetSeconds - currentSeconds;
        }

        if (skipSeconds <= 0) return; // 安全保护

        const skipHours = skipSeconds / 3600;
        console.log(`[跳夜] 全员入睡！从 ${this.getTimeStr()} 跳到 06:00（跳过 ${skipHours.toFixed(1)} 小时）`);

        // 1. 补算NPC睡眠恢复（按跳过的时间量）
        for (const npc of aliveNpcs) {
            // 体力恢复：睡眠中每游戏小时恢复约8点（正常tick中是 0.002*dt*60≈0.12/s → 7.2/h）
            const staminaGain = skipHours * 8;
            npc.stamina = Math.min(100, npc.stamina + staminaGain);

            // San值恢复：睡眠中每游戏小时恢复约6点（v4.6增强：3→6）
            const sanityGain = skipHours * 6;
            npc.sanity = Math.min(100, npc.sanity + sanityGain);

            // 健康恢复：睡眠中每游戏小时恢复约1点
            const healthGain = skipHours * 1;
            npc.health = Math.min(100, npc.health + healthGain);

            // 体温：如果在室内睡觉，体温缓慢回升到36度
            if (npc.bodyTemp !== undefined && npc.bodyTemp < 36) {
                npc.bodyTemp = Math.min(36, npc.bodyTemp + skipHours * 0.5);
            }

            // 清除强制睡眠标记（跳夜后相当于睡够了）
            if (npc._forcedSleep) {
                npc._forcedSleep = false;
                npc._forcedSleepTimer = 0;
            }
        }

        // 2. 处理跨午夜日切换
        const needDayChange = currentSeconds >= 20 * 3600; // 20点以后需要跨日
        if (needDayChange) {
            // 【兜底保护】第4天不允许跳夜到第5天，直接触发结局
            if (this.dayCount >= 4) {
                console.log('[跳夜] 第4天禁止跳夜到第5天，触发结局检测');
                if (this.deathSystem) this.deathSystem._checkEndingCondition();
                return;
            }
            // 先推进到午夜，触发日切换
            this.gameTimeSeconds = 24 * 3600; // 会在下一帧的时间流逝中触发日切换
            // 手动触发日切换逻辑（因为我们直接设置时间，不经过正常tick）
            this.gameTimeSeconds = 0; // 重置为0:00
            this.dayCount++;
            this._nightSkipDone = false; // 新的一天，但立刻会再设为true
            this._nightSkipDone = true;  // 防止新的一天0:00再次触发跳夜检测

            // 触发跨过的每个小时的天气变化
            for (let h = hour + 1; h <= 23; h++) {
                this._onHourChange(h);
            }
            for (let h = 0; h <= 6; h++) {
                this._onHourChange(h);
            }

            // 日切换时的NPC属性处理（简化版，避免重复完整日切换逻辑）
            for (const npc of this.npcs) {
                npc._dayChangeWhileSleeping = true;
                npc.shopVisitorCount = 0;
                npc.shopLastVisitorTime = null;
                npc.shopAloneMinutes = 0;
                npc.hunger = Math.max(npc.hunger, 80);
                npc.isEating = false;
                npc._hungerOverride = false;
                npc._hungerTarget = null;
                // 【v4.29致命修复】跳夜到D4时，立刻为所有NPC设置day4_lockdown
                // 消除竞态窗口：_updateActionOverride在_updateSchedule之前执行，
                // 如果不在这里预设day4_lockdown，NPC醒来后_pendingAction会在day4_lockdown设置之前
                // 驱动NPC出门到village，然后被day4_lockdown困在户外致死
                // 陆辰D4就是这样死的：醒来→_pendingAction(warehouse_door)→出门→day4_lockdown→困死
                if (this.dayCount === 4) {
                    npc._priorityOverride = 'day4_lockdown';
                    // 清除可能导致出门的pending行动
                    npc._pendingAction = null;
                    npc._pendingIntent = null;
                    console.log(`[跳夜→D4] ${npc.name} 预设day4_lockdown，清除pendingAction`);
                }
            }

            // 通知各子系统
            if (this.weatherSystem && this.weatherSystem.onDayChange) {
                this.weatherSystem.onDayChange(this.dayCount);
            }
            if (this.resourceSystem && this.resourceSystem.generateDayReport) {
                const report = this.resourceSystem.generateDayReport(this.dayCount - 1);
                if (report) {
                    console.log('[Game] 跳夜日结算报告:', this.resourceSystem.formatDayReport(report));
                }
            }
            if (this.furnaceSystem && this.furnaceSystem.onDayChange) {
                this.furnaceSystem.onDayChange(this.dayCount);
            }
            if (this.taskSystem && this.taskSystem.onDayChange) {
                this.taskSystem.onDayChange(this.dayCount);
            }
            if (this.deathSystem && this.deathSystem.addMilestone) {
                this.deathSystem.addMilestone(`🌅 第${this.dayCount}天开始（跳夜）`);
            }
            if (this.bgmSystem && this.bgmSystem.onDayChange) {
                this.bgmSystem.onDayChange(this.dayCount);
            }

            // 【v4.33修复】跳夜后也触发晨会
            this._openingCouncilDone = false;
            this._openingCouncilScheduled = false;
            this._scheduleOpeningCouncil();

this.addEvent(GST.t('event.new_day', { n: this.dayCount }));
        } else {
            // 不跨日（0~5点），只需补触发跳过的小时
            for (let h = hour + 1; h <= 6; h++) {
                this._onHourChange(h);
            }
        }

        // 3. 补算资源消耗（木柴+电力在跳过期间仍然需要持续消耗）
        if (this.resourceSystem) {
            const rs = this.resourceSystem;
            // 模拟跳过时段的资源消耗（传入跳过的总秒数）
            rs._tickConsumption(skipSeconds);
            console.log(`[跳夜] 资源补算: 木柴=${rs.woodFuel.toFixed(1)} 电力=${rs.power.toFixed(1)} (消耗${skipHours.toFixed(1)}小时)`);
        }

        // 3.5 补算自动化机器产出（发电机/伐木机在跳夜期间也持续运行）
        if (this.machineSystem) {
            const ms = this.machineSystem;
            // 模拟跳过时段的机器运行（传入跳过的总秒数）
            if (ms.generator.built) ms._updateMachineRunning('generator', skipSeconds);
            if (ms.lumberMill.built) ms._updateMachineRunning('lumberMill', skipSeconds);
            console.log(`[跳夜] 机器补算: 发电机=${ms.generator.running ? '运行' : '停机'} 伐木机=${ms.lumberMill.running ? '运行' : '停机'}`);
        }

        // 4. 设置最终时间为06:00
        this.gameTimeSeconds = targetSeconds;

        // 5. 添加UI事件通知
        this.addEvent(GST.t('event.night_skip'));

        // AI模式日志
        if (this.aiModeLogger) {
            this.aiModeLogger.log('NIGHT_SKIP', `全员入睡跳夜 → 06:00 | 跳过${skipHours.toFixed(1)}小时 | 第${this.dayCount}天`);
        }

        console.log(`[跳夜] 完成！当前时间: ${this.getTimeStr()} 第${this.dayCount}天`);
    };


    proto._updateRainIntensity = function() {
        switch (this.weather) {
            case '小雨': this.rainIntensity = 0.4; break;
            case '大雨': this.rainIntensity = 1.0; break;
            default:     this.rainIntensity = 0; break;
        }
    };


    proto.isRaining = function() {
        return this.weather === '小雨' || this.weather === '大雨';
    };


    proto.getTimeStr = function() {
        const h = Math.floor((this.gameTimeSeconds / 3600) % 24);
        const m = Math.floor((this.gameTimeSeconds / 60) % 60);
        return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
    };


    proto.getHour = function() {
        return Math.floor((this.gameTimeSeconds / 3600) % 24);
    };


    proto.getTimePeriod = function() {
        const h = this.getHour();
        const t = GST.t;
        if (h >= 5 && h < 8) return t('time_period.dawn');
        if (h >= 8 && h < 11) return t('time_period.morning');
        if (h >= 11 && h < 14) return t('time_period.noon');
        if (h >= 14 && h < 17) return t('time_period.afternoon');
        if (h >= 17 && h < 20) return t('time_period.evening');
        if (h >= 20 && h < 23) return t('time_period.night');
        return t('time_period.midnight');
    };


    proto.cycleSpeed = function() {
        this.speedIdx = (this.speedIdx + 1) % this.speedOptions.length;
        const btn = document.getElementById('btn-speed');
        btn.textContent = `${this.speedOptions[this.speedIdx]}×`;
        this.addEvent(GST.t('event.speed_change', { n: this.speedOptions[this.speedIdx] }));
    };


    proto.togglePause = function() {
        // 【v4.34修复】会议期间按暂停键 → 关闭会议（而不是直接取消暂停导致会议还在但游戏已恢复）
        if (this.councilSystem && this.councilSystem.isActive) {
            this.councilSystem.close();
            return;
        }
        this.paused = !this.paused;
        const btn = document.getElementById('btn-pause');
        btn.textContent = this.paused ? '▶️' : '⏸️';
        if (this.paused) {
            this.addEvent(GST.t('event.paused'));
            // 弹出营地讨论弹窗
            if (this.councilSystem) {
                this.councilSystem.open();
            }
        }
    };

})();
