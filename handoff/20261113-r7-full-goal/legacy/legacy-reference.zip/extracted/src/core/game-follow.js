/**
 * 福音镇 - 镜头跟随与场景切换
 * 从 game.js 拆分，遵循SRP原则
 * 挂载到 GST.Game.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.Game.prototype;


    // ---- 输入系统 ----

    proto.setFollowTarget = function(npc) {
        this.followTarget = npc;
        this.autoFollow = false;
        this.followSwitchTimer = 0;
        // 清除事件驱动锁定
        this._cameraLockTimer = 0;
        this._cameraLockPriority = 0;

        // 更新 UI — 切到跟随模式（锁定该角色）
        const btnFollow = document.getElementById('btn-follow');
        if (btnFollow) {
            btnFollow.classList.add('active');
            btnFollow.textContent = GST.t('hud.follow_lock');
        }
        const sel = document.getElementById('sel-follow-target');
        if (sel) sel.value = npc.id;

        // 如果 NPC 在不同场景，切换过去
        if (npc.currentScene !== this.currentScene) {
            this._switchScene(npc.currentScene, npc);
        }

        this.addEvent(GST.t('camera.switch_to', { name: npc.name }));
    };


    /**
    * 智能切换跟随目标：
    * - 自由模式下：只切换目标但保持自由模式，用事件锁定临时观看10秒后恢复自动切换
    * - 跟随模式下：直接调用 setFollowTarget 锁定
    */

    proto.switchFollowTarget = function(npc) {
        if (!npc) return;
        if (this.autoFollow) {
            // 自由模式下：切换目标但不退出自由模式
            this.followTarget = npc;
            this.followSwitchTimer = 0;
            // 设置事件锁定，临时观看10秒后恢复自动切换
            this._cameraLockTimer = 10;
            this._cameraLockPriority = 0;

            // 同步下拉选择器
            const sel = document.getElementById('sel-follow-target');
            if (sel) sel.value = npc.id;

            // 如果 NPC 在不同场景，切换过去
            if (npc.currentScene !== this.currentScene) {
                this._switchScene(npc.currentScene, npc);
            }

            this.addEvent(GST.t('camera.view_switch', { name: npc.name }));
        } else {
            // 跟随模式下：直接锁定
            this.setFollowTarget(npc);
        }
    };

    // [已拆分到 game-collision.js / game-save.js] _resolveGroupCollisions
    // [已拆分到 game-collision.js / game-save.js] _forceCrazyEscape
    // [已拆分到 game-collision.js / game-save.js] _computeBubbleOffsets
    proto._autoSwitchFollow = function() {
        if (!this.autoFollow || this.npcs.length === 0) return;

        // 过滤掉已死亡的 NPC
        const alive = this.npcs.filter(n => !n.isDead);
        if (alive.length === 0) return; // 所有NPC都死了，保持当前镜头

        // 优先级1：正在对话的 NPC（排除当前目标）
        const chatting = alive.filter(n => n.state === 'CHATTING' && n !== this.followTarget);
        if (chatting.length > 0) {
            const pick = chatting[Math.floor(Math.random() * chatting.length)];
            this._doAutoSwitch(pick, '正在对话');
            return;
        }

        // 优先级2：正在移动的 NPC（排除当前目标）
        const walking = alive.filter(n => n.isMoving && n !== this.followTarget);
        if (walking.length > 0) {
            const pick = walking[Math.floor(Math.random() * walking.length)];
            this._doAutoSwitch(pick, '正在移动');
            return;
        }

        // 优先级3：任意存活的其他 NPC
        const others = alive.filter(n => n !== this.followTarget);
        if (others.length > 0) {
            const pick = others[Math.floor(Math.random() * others.length)];
            this._doAutoSwitch(pick);
        }
        // 如果只剩当前跟随的NPC存活，则保持不动
    };


    /** 自动切换辅助：执行切换并同步UI */

    proto._doAutoSwitch = function(npc, reason) {
        this.followTarget = npc;
        if (npc.currentScene !== this.currentScene) {
            this._switchScene(npc.currentScene, npc);
        }
        const label = reason ? `（${reason}）` : '';
        this.addEvent(GST.t('camera.auto_switch', { name: npc.name, label }));
        // 同步下拉选择器显示当前NPC
        const sel = document.getElementById('sel-follow-target');
        if (sel) sel.value = npc.id;
    };


    /**
    * NPC 重大事件通知 —— 由外部（dialogue.js / npc.js / death-system.js）调用
    * @param {NPC} npc - 触发事件的 NPC
    * @param {'chat_start'|'crazy'|'death'} eventType - 事件类型
    */

    proto.onNPCEvent = function(npc, eventType) {
        // 仅在自由模式下生效
        if (!this.autoFollow) return;
        if (!npc) return;

        const priority = Game.CAMERA_EVENT_PRIORITY[eventType] || 0;

        // 如果当前有锁定且新事件优先级不高于当前锁定，忽略
        if (this._cameraLockTimer > 0 && priority <= this._cameraLockPriority) return;

        // 执行事件驱动切换
        this._eventDrivenSwitch(npc, eventType);

        // 设置锁定
        this._cameraLockTimer = this._cameraLockDuration;
        this._cameraLockPriority = priority;

        // 重置兜底轮询计时器，避免刚切过去又被轮询切走
        this.followSwitchTimer = 0;
    };


    /**
    * 事件驱动切换：立即将镜头切到指定 NPC
    * @param {NPC} npc - 目标 NPC
    * @param {string} eventType - 事件类型
    */

    proto._eventDrivenSwitch = function(npc, eventType) {
        this.followTarget = npc;

        // 跨场景切换
        if (npc.currentScene !== this.currentScene) {
            this._switchScene(npc.currentScene, npc);
        }

        // 事件日志（区分类型）
        const eventLabels = {
            chat_start: GST.t('camera.event_chat_start'),
            crazy: GST.t('camera.event_crazy'),
            death: GST.t('camera.event_death')
        };
        const label = eventLabels[eventType] || eventType;
        this.addEvent(GST.t('camera.urgent_switch', { name: npc.name, label }));

        // 同步下拉选择器
        const sel = document.getElementById('sel-follow-target');
        if (sel) sel.value = npc.id;
    };


    proto._switchScene = function(scene, npc) {
        if (!this.maps[scene]) return;
        if (this.fadeDirection !== 0) return;
        this.nextScene = scene;
        this.pendingFollowTarget = npc;
        this.fadeDirection = 1;
    };

})();
