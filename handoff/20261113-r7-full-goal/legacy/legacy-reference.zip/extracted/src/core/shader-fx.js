/**
 * 福音镇 - WebGL 雪花效果系统 v3
 * 
 * 仅负责：程序化雪花渲染（透明叠加层）
 * 昼夜光照、暗角等由原有 Canvas 系统处理，不在此重复。
 * 
 * 架构：透明 WebGL canvas 覆盖在游戏 canvas 上方，
 *       只绘制白色雪花，背景完全透明。
 * 
 * 性能：零粒子循环，GPU 程序化生成，无纹理采样。
 */
(function () {
    'use strict';
    const GST = window.GST;

    // ============ Shader 源码 ============

    const VS_SOURCE = `#version 300 es
in vec2 aPosition;
out vec2 vUV;
void main() {
    vUV = aPosition * 0.5 + 0.5;
    gl_Position = vec4(aPosition, 0.0, 1.0);
}`;

    // 纯雪花 shader —— 输出带 alpha 的白色雪花，背景透明
    const FS_SOURCE = `#version 300 es
precision mediump float;

in vec2 vUV;
out vec4 fragColor;

uniform vec2 uResolution;
uniform float uTime;
uniform float uWindOffset;
uniform float uBlizzardAlpha;
uniform float uSnowIntensity;

// ---- 哈希函数 ----
float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

vec2 hash22(vec2 p) {
    float n = hash21(p);
    return vec2(n, hash21(p + n));
}

// ---- 六角雪花 SDF ----
float hexStar(vec2 p, float r) {
    const float k = 0.8660254; // sqrt(3)/2
    p = abs(p);
    p -= 2.0 * min(dot(vec2(k, 0.5), p), 0.0) * vec2(k, 0.5);
    p -= 2.0 * min(dot(vec2(-k, 0.5), p), 0.0) * vec2(-k, 0.5);
    p -= vec2(clamp(p.x, -r, r), r);
    return length(p);
}

// ---- 程序化雪花层 ----
float snowLayer(vec2 uv, float scale, float speed, float windStr, float t) {
    uv.y += t * speed;
    uv.x += t * speed * windStr * 0.4;
    uv *= scale;

    vec2 gid = floor(uv);
    vec2 guv = fract(uv) - 0.5;

    float snow = 0.0;

    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 offset = vec2(float(x), float(y));
            vec2 cellId = gid + offset;
            vec2 rnd = hash22(cellId);

            if (rnd.x > 0.65) continue;

            vec2 snowPos = offset + vec2(rnd.x, rnd.y) - 0.5;
            float wobble = sin(t * 2.0 + rnd.x * 6.28) * 0.08;
            snowPos.x += wobble;

            vec2 diff = guv - snowPos;
            float size = 0.12 + rnd.y * 0.16;
            float d = hexStar(diff * 8.0 / size, 0.5);
            float flake = smoothstep(0.6, 0.0, d);
            flake *= 0.5 + rnd.x * 0.5;
            snow += flake;
        }
    }
    return snow;
}

void main() {
    vec2 uv = vUV;
    float t = uTime;
    float aspect = uResolution.x / uResolution.y;

    if (uSnowIntensity < 0.01) {
        fragColor = vec4(0.0);
        return;
    }

    float wind = uWindOffset;
    vec2 snowUV = vec2(uv.x * aspect, uv.y);

    float snow = 0.0;
    // 近景层：大雪花，慢速
    snow += snowLayer(snowUV, 4.0, 0.12, wind, t) * 0.8;
    // 中景层
    snow += snowLayer(snowUV + 7.3, 8.0, 0.20, wind * 0.8, t) * 0.55;
    // 远景层：小雪花，快速
    snow += snowLayer(snowUV + 13.7, 14.0, 0.30, wind * 0.6, t) * 0.35;

    // 暴风雪额外密集层
    if (uBlizzardAlpha > 0.1) {
        snow += snowLayer(snowUV + 23.1, 30.0, 0.5, wind * 1.2, t) * 0.3 * uBlizzardAlpha;
        snow += snowLayer(snowUV + 37.9, 18.0, 0.4, wind * 1.5, t) * 0.35 * uBlizzardAlpha;
    }

    snow *= uSnowIntensity;

    // 暴风雪白雾
    float fog = 0.0;
    if (uBlizzardAlpha > 0.3) {
        float whiteout = (uBlizzardAlpha - 0.3) * 1.4;
        float pulse = 0.9 + 0.1 * sin(t * 0.5);
        fog = whiteout * pulse * 0.25;
    }

    // 雪花颜色：白色偏蓝
    vec3 snowColor = vec3(0.92, 0.95, 1.0);
    float alpha = clamp(snow * 1.1 + fog, 0.0, 0.9);

    fragColor = vec4(snowColor * alpha, alpha);
}`;

    // ============ ShaderFX 类 ============

    class ShaderFX {
        constructor(game) {
            this.game = game;
            this.enabled = true;
            this.gl = null;
            this.program = null;
            this.uniforms = {};
            this._startTime = performance.now() / 1000;

            this.params = {
                windOffset: 0,
                blizzardAlpha: 0,
                snowIntensity: 0,
            };

            this._init();
        }

        _init() {
            try {
                this._createCanvas();
                this._initWebGL();
                if (this.gl) {
                    this._compileShaders();
                    this._setupGeometry();
                    this._resize();
                    console.log('[ShaderFX] ✅ WebGL 雪花系统 v3 初始化成功（纯透明叠加）');
                }
            } catch (e) {
                console.warn('[ShaderFX] ⚠️ 初始化失败，降级到 Canvas 渲染:', e.message);
                this.enabled = false;
                if (this.canvas && this.canvas.parentNode) {
                    this.canvas.parentNode.removeChild(this.canvas);
                }
            }
        }

        _createCanvas() {
            const container = document.getElementById('game-container');
            if (!container) throw new Error('game-container 不存在');

            // 确保容器有定位上下文
            if (getComputedStyle(container).position === 'static') {
                container.style.position = 'relative';
            }

            this.canvas = document.createElement('canvas');
            this.canvas.id = 'shaderFXCanvas';
            this.canvas.style.cssText = `
                position: absolute;
                top: 0; left: 0;
                pointer-events: none;
                z-index: 1;
            `;
            container.appendChild(this.canvas);
        }

        _initWebGL() {
            this.gl = this.canvas.getContext('webgl2', {
                alpha: true,              // 关键：透明背景！
                premultipliedAlpha: true,
                antialias: false,
                preserveDrawingBuffer: false,
            });
            if (!this.gl) throw new Error('WebGL2 不可用');
        }

        _compileShaders() {
            const gl = this.gl;
            const vs = this._createShader(gl.VERTEX_SHADER, VS_SOURCE);
            const fs = this._createShader(gl.FRAGMENT_SHADER, FS_SOURCE);

            this.program = gl.createProgram();
            gl.attachShader(this.program, vs);
            gl.attachShader(this.program, fs);
            gl.linkProgram(this.program);

            if (!gl.getProgramParameter(this.program, gl.LINK_STATUS)) {
                throw new Error('Shader 链接失败: ' + gl.getProgramInfoLog(this.program));
            }

            gl.useProgram(this.program);

            const uniformNames = [
                'uResolution', 'uTime', 'uWindOffset',
                'uBlizzardAlpha', 'uSnowIntensity'
            ];
            for (const name of uniformNames) {
                this.uniforms[name] = gl.getUniformLocation(this.program, name);
            }
        }

        _createShader(type, source) {
            const gl = this.gl;
            const shader = gl.createShader(type);
            gl.shaderSource(shader, source);
            gl.compileShader(shader);
            if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
                const info = gl.getShaderInfoLog(shader);
                gl.deleteShader(shader);
                throw new Error('Shader 编译失败: ' + info);
            }
            return shader;
        }

        _setupGeometry() {
            const gl = this.gl;
            const vao = gl.createVertexArray();
            gl.bindVertexArray(vao);

            const buf = gl.createBuffer();
            gl.bindBuffer(gl.ARRAY_BUFFER, buf);
            gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
                -1, -1, 1, -1, -1, 1, 1, 1
            ]), gl.STATIC_DRAW);

            const posLoc = gl.getAttribLocation(this.program, 'aPosition');
            gl.enableVertexAttribArray(posLoc);
            gl.vertexAttribPointer(posLoc, 2, gl.FLOAT, false, 0, 0);
        }

        /** 从游戏状态同步参数 */
        syncFromGame() {
            const ws = this.game.weatherSystem;
            if (ws) {
                this.params.windOffset = ws.windOffset || 0;
                this.params.blizzardAlpha = ws.blizzardAlpha || 0;
                this.params.snowIntensity = Math.min(1.0, (ws.maxSnowParticles || 0) / 500);
            }
        }

        /** 调整 canvas 尺寸和位置，与游戏 canvas 完全对齐 */
        _resize() {
            const gameCanvas = this.game.canvas;
            if (!gameCanvas) return;

            const w = gameCanvas.width;
            const h = gameCanvas.height;

            if (this.canvas.width !== w || this.canvas.height !== h) {
                this.canvas.width = w;
                this.canvas.height = h;
            }
            // 【v4.23】精确对齐：使用 gameCanvas 的实际 CSS 尺寸和位置
            this.canvas.style.width = gameCanvas.offsetWidth + 'px';
            this.canvas.style.height = gameCanvas.offsetHeight + 'px';
            this.canvas.style.left = gameCanvas.offsetLeft + 'px';
            this.canvas.style.top = gameCanvas.offsetTop + 'px';
        }

        /** 主渲染 —— 只画透明雪花 */
        render() {
            if (!this.enabled || !this.gl) return;

            try {
                const gl = this.gl;

                // 【v4.23】检测 WebGL context 是否丢失
                if (gl.isContextLost()) {
                    console.warn('[ShaderFX] WebGL context 丢失，降级到 Canvas 渲染');
                    this.enabled = false;
                    return;
                }

                // 【v4.24】性能计时 — CPU 侧计时（含 gl.finish 强制同步）
                const perfStart = performance.now();

                this._resize();
                this.syncFromGame();

                // 没有雪就跳过渲染，清空画面
                if (this.params.snowIntensity < 0.01) {
                    gl.clearColor(0, 0, 0, 0);
                    gl.clear(gl.COLOR_BUFFER_BIT);
                    this._recordPerf(0, true); // 无雪跳过
                    return;
                }

                gl.viewport(0, 0, this.canvas.width, this.canvas.height);

                // 透明背景
                gl.clearColor(0, 0, 0, 0);
                gl.clear(gl.COLOR_BUFFER_BIT);

                // 启用混合
                gl.enable(gl.BLEND);
                gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);

                gl.useProgram(this.program);
                gl.uniform2f(this.uniforms.uResolution, this.canvas.width, this.canvas.height);
                gl.uniform1f(this.uniforms.uTime, performance.now() / 1000 - this._startTime);
                gl.uniform1f(this.uniforms.uWindOffset, this.params.windOffset);
                gl.uniform1f(this.uniforms.uBlizzardAlpha, this.params.blizzardAlpha);
                gl.uniform1f(this.uniforms.uSnowIntensity, this.params.snowIntensity);

                gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);

                gl.disable(gl.BLEND);

                // 【v4.24】gl.finish() 强制GPU完成，得到真实耗时（仅采样，不是每帧都finish）
                this._perfSampleCounter = (this._perfSampleCounter || 0) + 1;
                if (this._perfSampleCounter % 60 === 0) { // 每60帧采样一次真实GPU时间
                    gl.finish();
                    const perfEnd = performance.now();
                    this._recordPerf(perfEnd - perfStart, false);
                }
            } catch (e) {
                console.warn('[ShaderFX] 渲染出错，降级到 Canvas 渲染:', e.message);
                this.enabled = false;
            }
        }

        /** 【v4.24】性能记录 — 每10秒输出一次统计 */
        _recordPerf(ms, skipped) {
            if (!this._perfStats) {
                this._perfStats = { samples: [], skippedCount: 0, lastReport: performance.now() };
            }
            const stats = this._perfStats;
            if (skipped) {
                stats.skippedCount++;
            } else {
                stats.samples.push(ms);
            }
            const now = performance.now();
            if (now - stats.lastReport > 10000 && stats.samples.length > 0) {
                const avg = stats.samples.reduce((a, b) => a + b, 0) / stats.samples.length;
                const max = Math.max(...stats.samples);
                const min = Math.min(...stats.samples);
                const res = `${this.canvas.width}×${this.canvas.height}`;
                const blizzard = this.params.blizzardAlpha > 0.1 ? '🌨️暴风雪' : '❄️普通雪';
                console.log(
                    `[ShaderFX ⏱️ 性能] ${blizzard} | 分辨率:${res} | ` +
                    `GPU耗时: avg=${avg.toFixed(2)}ms, min=${min.toFixed(2)}ms, max=${max.toFixed(2)}ms | ` +
                    `采样${stats.samples.length}次, 跳过${stats.skippedCount}帧(无雪) | ` +
                    `snowIntensity=${this.params.snowIntensity.toFixed(2)}`
                );
                stats.samples = [];
                stats.skippedCount = 0;
                stats.lastReport = now;
            }
        }

        /** 销毁 */
        destroy() {
            if (this.canvas && this.canvas.parentNode) {
                this.canvas.parentNode.removeChild(this.canvas);
            }
            this.gl = null;
            this.enabled = false;
        }
    }

    GST.ShaderFX = ShaderFX;
})();
