/**
 * 福音镇 - 输入处理
 * 键盘/鼠标输入、WASD移动、点击交互、快捷键
 * 通过 mixin 模式挂载到 Game.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.Game.prototype;

    // ============ 数据定义已迁移 ============
    // COMMANDER_ALIAS_MAP, COMMANDER_NAME_MAP, COMMANDER_ROLE_EMOJI,
    // COMMANDER_TASK_LABELS, COMMANDER_TASK_DEFAULTS, COMMANDER_ACTION_PRESETS,
    // COMMANDER_LLM_INTENT_LIBRARY
    // → 已迁移到 commander-data-zh.js / commander-data-en.js
    // → 通过 commander.js 的 _getLang() 动态获取
    // → 外部可通过 GST._COMMANDER_ALIAS_MAP 等 getter 访问

    proto._nearestNPCToCamera = function(maxDist) {
        const camCenterGX = Math.floor((this.camera.x + this.camera.width / 2) / GST.TILE);
        const camCenterGY = Math.floor((this.camera.y + this.camera.height / 2) / GST.TILE);
        let best = null, bestDist = Infinity;
        for (const npc of this.npcs) {
            if (npc.currentScene !== this.currentScene) continue;
            const np = npc.getGridPos();
            const d = Math.abs(camCenterGX - np.x) + Math.abs(camCenterGY - np.y);
            if (d <= maxDist && d < bestDist) {
                bestDist = d;
                best = npc;
            }
        }
        return best;
    }
    // [已拆分到 commander.js] _escapeCommanderHtml
    // [已拆分到 commander.js] _planCommanderStatementWithLLM
    // [已拆分到 commander.js] _executeCommanderText
    // [已拆分到 commander.js] _generateLocalCommanderFallbackReply

    proto._submitCommanderCommand = async function(options) {
        this._ensureCommanderState();
        const opts = options || {};
        const rawText = this._commanderUI.input.value.trim();
        if (!rawText) {
            this._commanderUI.feedback.textContent = GST.t('commander.empty_input');
            return;
        }

        this._setCommanderBusy(true, '指挥解析中……');
        try {
            const result = await this._executeCommanderText(rawText);
            this._commanderUI.feedback.textContent = result.summary;
            this._renderCommanderHistory();
            this._renderCommanderStatus();

            if (!result.ok) return;

            this._commanderUI.input.value = '';
            if (opts.keepPaused) {
                this.paused = true;
                this._syncPauseButtonState();
                return;
            }
            this._closeCommandMode({ restorePreviousPause: false });
        } catch (err) {
            console.error('[Commander] 提交命令失败:', err);
            this._commanderUI.feedback.textContent = GST.t('commander.parse_fail');
        } finally {
            this._setCommanderBusy(false);
        }
    }

    // ---- 渲染 ----;

    proto._setupControls = function() {
        this._ensureCommanderState();

        const btnPause = document.getElementById('btn-pause');
        const btnSpeed = document.getElementById('btn-speed');
        const btnFollow = document.getElementById('btn-follow');
        const selTarget = document.getElementById('sel-follow-target');

        btnPause.addEventListener('click', () => this.togglePause());
        btnSpeed.addEventListener('click', () => this.cycleSpeed());
        btnFollow.addEventListener('click', () => {
            this.autoFollow = !this.autoFollow;
            btnFollow.classList.toggle('active', !this.autoFollow);
            btnFollow.textContent = this.autoFollow ? GST.t('hud.follow_free') : GST.t('hud.follow_lock');
            // 无论切到哪个模式，都清除事件锁定状态
            this._cameraLockTimer = 0;
            this._cameraLockPriority = 0;
            if (this.autoFollow) {
                // 切到自由模式：立即触发一次自动切换，避免镜头卡住不动
                this.followSwitchTimer = 0;
                this._autoSwitchFollow();
            }
        });

        // BGM 静音按钮（延迟获取bgmSystem，避免初始化时序问题）
        const btnBgmMute = document.getElementById('btn-bgm-mute');
        if (btnBgmMute) {
            const self = this;
            btnBgmMute.addEventListener('click', () => {
                const bgm = self.bgmSystem;
                if (!bgm) { console.warn('[Input] bgmSystem 未初始化'); return; }
                const muted = bgm.toggleMute();
btnBgmMute.textContent = muted ? GST.t('hud.bgm_off') : GST.t('hud.bgm_on');
                btnBgmMute.title = muted ? GST.t('hud.bgm_tip_muted') : GST.t('hud.bgm_tip_playing');
                // 同步会议面板的静音按钮
                const councilMuteBtn = document.getElementById('council-mute');
                if (councilMuteBtn) {
councilMuteBtn.textContent = muted ? GST.t('hud.bgm_council_off') : GST.t('hud.bgm_council_on');
                    councilMuteBtn.title = muted ? GST.t('hud.bgm_tip_muted') : GST.t('hud.bgm_tip_playing');
                }
            });
        }

        // 【v5.8.17→v5.8.19】节能模式按钮（只读显示，不可在游戏内切换，需回主界面更改）
        const btnPowerSave = document.getElementById('btn-power-save');
        if (btnPowerSave) {
            // 从 localStorage 恢复节能模式状态（只读显示）
            try {
                const saved = localStorage.getItem('gospel_power_save_mode');
                if (saved === 'true') {
                    GST.LLM.powerSaveMode = true;
                    btnPowerSave.classList.add('active');
                    btnPowerSave.textContent = GST.t('hud.power_save_on');
                    btnPowerSave.title = GST.t('hud.power_save_tip_on');
                } else {
                    btnPowerSave.title = GST.t('hud.power_save_tip_off');
                }
            } catch (e) { /* ignore */ }

            // 游戏内不可切换，点击提示需回主界面更改
            btnPowerSave.addEventListener('click', () => {
                btnPowerSave.title = GST.t('hud.power_save_locked');
                // 短暂闪烁提示
                btnPowerSave.style.animation = 'none';
                btnPowerSave.offsetHeight; // 触发reflow
                btnPowerSave.style.animation = 'shake 0.3s ease';
            });
        }

        // 填充 NPC 选择
        for (const npc of this.npcs) {
            const opt = document.createElement('option');
            opt.value = npc.id;
            opt.textContent = npc.name;
            selTarget.appendChild(opt);
        }
        selTarget.addEventListener('change', () => {
            const val = selTarget.value;
            if (val === 'auto') {
                this.autoFollow = true;
                btnFollow.classList.remove('active');
                btnFollow.textContent = GST.t('hud.follow_free');
                // 立即触发一次自动切换
                this.followSwitchTimer = 0;
                this._autoSwitchFollow();
            } else {
                const npc = this.npcs.find(n => n.id === val);
                if (npc) this.switchFollowTarget(npc);
            }
        });

        // Debug 模式: 显示额外 UI
        if (this.mode === 'debug') {
            document.getElementById('instructions').style.display = 'block';
        }

        // 📦 顶部物资栏（始终可见，无需折叠逻辑）

        // 💾 Debug Log 保存按钮
        const btnSaveLog = document.getElementById('btn-save-debug-log');
        if (btnSaveLog) {
            btnSaveLog.addEventListener('click', () => {
                this._debugLogFailCount = 0; // 手动触发时重置失败计数，恢复自动保存
                this._saveDebugLogToServer();
            });
        }

        // 【自动保存】每5分钟自动保存一次debug log到服务器
        this._debugLogAutoSaveInterval = setInterval(() => {
            this._saveDebugLogToServer(true); // quiet模式，不弹提示
        }, 5 * 60 * 1000);
    }

    // ---- 侧边栏 Agent 卡片 ----;

    proto._setupInput = function() {
        this._ensureCommanderState();

        window.addEventListener('keydown', e => {
            if (e.metaKey || e.ctrlKey) {
                if (e.key === 's' || e.key === 'S') {
                    e.preventDefault();
                    this.save();
                }
                return;
            }

            const active = document.activeElement;
            const isEditable = active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.tagName === 'SELECT');

            if (!isEditable && (e.key === 'q' || e.key === 'Q')) {
                e.preventDefault();
                this._toggleCommandMode();
                return;
            }

            if (isEditable) return;

            if (this.commandModeActive) {
                if (e.key === 'Escape') {
                    e.preventDefault();
                    this._closeCommandMode({ restorePreviousPause: true });
                }
                return;
            }

            this.keys[e.key] = true;

            // 通用快捷键
            if (e.key === ' ') { e.preventDefault(); this.togglePause(); }
            if (e.key === '+' || e.key === '=') this.cycleSpeed();

            // Debug 模式快捷键
            if (this.mode === 'debug') {
                if (e.key === 'g' || e.key === 'G') this.showGrid = !this.showGrid;
                if (e.key === 'e' || e.key === 'E') this._tryInteract();
                if (e.key === 't' || e.key === 'T') {
                    e.preventDefault();
                    const chatUI = document.getElementById('chat-container');
                    chatUI.style.display = 'flex';
                    document.getElementById('chat-input').focus();
                }
            }

            // 数字键 1-8 跟随对应 NPC
            const num = parseInt(e.key);
            if (num >= 1 && num <= 8 && num <= this.npcs.length) {
                this.switchFollowTarget(this.npcs[num - 1]);
            }
        });
        window.addEventListener('keyup', e => this.keys[e.key] = false);
        window.addEventListener('blur', () => { this.keys = {}; });

        // Debug 模式聊天
        if (this.mode === 'debug') {
            const chatInput = document.getElementById('chat-input');
            const btnSend = document.getElementById('btn-send-chat');
            const sendChat = () => {
                const msg = chatInput.value.trim();
                if (!msg) return;
                chatInput.value = '';
                chatInput.blur();
                const nearest = this._nearestNPCToCamera(5);
                if (nearest) {
                    this.dialogueManager.startPlayerChat(nearest, msg);
                }
            };
            if (btnSend) btnSend.addEventListener('click', sendChat);
            if (chatInput) chatInput.addEventListener('keydown', e => {
                if (e.key === 'Enter') sendChat();
                if (e.key === 'Escape') { chatInput.blur(); document.getElementById('chat-container').style.display = 'none'; }
            });
        }
    }

    // ---- 顶部控制栏 ----;

    proto._tryInteract = function() {
        if (this.mode !== 'debug') return;
        const nearest = this._nearestNPCToCamera(3);
        if (nearest) {
            this.dialogueManager.startPlayerChat(nearest);
        }
    };

})();
