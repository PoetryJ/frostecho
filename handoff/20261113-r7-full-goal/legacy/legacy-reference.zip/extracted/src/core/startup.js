/**
 * 福音镇 - 启动逻辑
 * 模型选择、模式选择、游戏启动初始化
 * 挂载到 GST.startup
 */
(function() {
    'use strict';
    const GST = window.GST;
    // 引用 LLM 配置代理对象（变量定义在 llm-client.js IIFE 中，通过 GST.LLM getter/setter 访问）
    const LLM = GST.LLM;

// ============ 混合模式：固定使用 qwen3:8b(主) + qwen3:0.6b(快速) ============
// 主模型用于深度对话、紧急决策、团队讨论
// 快速模型用于常规行动决策、think心情、打招呼等简单任务

// 快速小模型（用于简单任务，启动时自动检测并预热）
const FAST_MODEL = 'qwen3:0.6b';

// ============ 带超时的 fetch 工具函数 ============
function fetchWithTimeout(url, options = {}, timeoutMs = 5000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    return fetch(url, { ...options, signal: controller.signal }).finally(() => clearTimeout(timer));
}

// ============ 模型切换：加载指定模型并卸载其他模型 ============
async function switchModel(targetModel) {
    const statusEl = document.getElementById('model-status');
    // 同步更新加载页面上的 LLM 状态
    const _llmText = document.getElementById('llm-status-text');
    const t = GST.t; // i18n 快捷引用
    function updateLlmHint(msg) {
        if (_llmText) _llmText.textContent = msg;
    }

    // --- 外部 API 模式：跳过 Ollama 模型管理，直接配置 ---
    if (LLM.source === 'external') {
        if (statusEl) {
            statusEl.textContent = t('llm.status_external_checking');
            statusEl.className = 'model-status loading';
        }
        updateLlmHint(t('llm.status_external_verifying'));
        try {
            // 配置全局变量为外部API模式
            LLM.apiKey = LLM.externalKey;
            LLM.apiUrl = '/api/external-llm';  // 通过服务器代理转发
            LLM.useOllamaNative = false;
            LLM.model = LLM.externalModel || targetModel;

            // 发送测试请求验证外部API可用
            const testResp = await fetch('/api/external-llm', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-External-API-URL': LLM.externalUrl,
                    'X-External-API-Key': LLM.externalKey
                },
                body: JSON.stringify({
                    model: LLM.model,
                    messages: [{ role: 'user', content: 'hi' }],
                    max_tokens: 5,
                    temperature: 0.1
                })
            });

            if (!testResp.ok) {
                const errText = await testResp.text().catch(() => '');
                throw new Error(`HTTP ${testResp.status}: ${errText.substring(0, 100)}`);
            }

            if (statusEl) {
                statusEl.textContent = t('llm.status_external_ready', { model: LLM.model });
                statusEl.className = 'model-status success';
            }
            updateLlmHint(t('llm.status_external_ready_hint', { model: LLM.model }));
            console.log(`[模型切换] 外部API模式: ${LLM.externalUrl}, 模型: ${LLM.model}`);
            return true;
        } catch (err) {
            console.error('[模型切换] 外部API验证失败:', err);
            if (statusEl) {
                statusEl.textContent = t('llm.status_external_fail', { error: err.message });
                statusEl.className = 'model-status error';
            }
            updateLlmHint(t('llm.status_external_fail', { error: err.message }));
            return false;
        }
    }

    // --- 本地模式 ---
    if (statusEl) {
        statusEl.textContent = t('llm.status_checking', { model: targetModel });
        statusEl.className = 'model-status loading';
    updateLlmHint(t('llm.status_checking', { model: targetModel }));
    }

    // ★ 先检测 llama-server 是否就绪
    let llamaServerReady = false;
    let shouldWaitLlama = false; // 是否需要等待 llama-server
    try {
        const statusResp = await fetchWithTimeout('/api/llm-status', {}, 8000);
        if (statusResp.ok) {
            const statusData = await statusResp.json();
            llamaServerReady = statusData.llamaReady === true;
            console.log(`[模型切换] llama-server 状态:`, statusData);

            // 如果 llama-server 正在运行但还没就绪（正在加载模型），标记需要等待
            if (!llamaServerReady && (statusData.llamaRunning || statusData.paths?.serverBinExists)) {
                shouldWaitLlama = true;
            }
        }
    } catch (e) {
        console.log('[模型切换] llama-server 状态检测超时/失败:', e.message);
        // 状态检测超时不代表 llama-server 不存在，可能后端正忙于加载模型
        // 仍然尝试等待 llama-server
        shouldWaitLlama = true;
    }

    // 如果 llama-server 未就绪但可能正在启动，等待它（支持多轮重试，因为后端可能在尝试多组GPU参数）
    if (!llamaServerReady && shouldWaitLlama) {
        console.log('[模型切换] llama-server 正在启动，等待就绪...');
        if (statusEl) statusEl.textContent = t('llm.status_loading');
        updateLlmHint(t('llm.status_loading_first'));

        // 最多等待 2 轮（后端可能在尝试多组参数，第一轮 llm-wait 可能因为进程重启而提前返回失败）
        for (let waitRound = 1; waitRound <= 2 && !llamaServerReady; waitRound++) {
            try {
                console.log(`[模型切换] 等待轮次 ${waitRound}/2 ...`);
                const waitResp = await fetchWithTimeout('/api/llm-wait', {}, 95000);
                if (waitResp.ok) {
                    const waitData = await waitResp.json();
                    console.log(`[模型切换] llm-wait 轮次${waitRound} 结果:`, waitData);
                    if (waitData.ready) {
                        llamaServerReady = true;
                        const sec = Math.round((waitData.waited || 0) / 1000);
                        console.log(`[模型切换] llama-server 就绪！等待了 ${sec} 秒`);
                        updateLlmHint(`AI 引擎已就绪（等待了 ${sec} 秒）`);
                    } else {
                        console.warn(`[模型切换] 等待轮次${waitRound}失败: ${waitData.error}`);
                        // 第一轮失败后，检查后端是否还在尝试（可能在切换参数组）
                        if (waitRound < 2) {
                        updateLlmHint(t('llm.status_retry'));
                            // 短暂等待后端重新启动进程
                            await new Promise(r => setTimeout(r, 3000));
                        } else {
                            updateLlmHint(`AI 引擎启动失败: ${waitData.error || '未知错误'}`);
                        }
                    }
                }
            } catch (waitErr) {
                console.error(`[模型切换] 等待轮次${waitRound}超时:`, waitErr.message);
                if (waitRound >= 2) {
                    updateLlmHint('AI 引擎启动超时');
                }
            }
        }
    }

    // 根据后端类型设置正确的 API 配置
    LLM.apiKey = '';
    if (llamaServerReady) {
        // 再次查询状态，获取 GPU 模式信息
        let gpuMode = null;
        let startAttemptInfo = '';
        try {
            const statusResp2 = await fetchWithTimeout('/api/llm-status', {}, 3000);
            if (statusResp2.ok) {
                const sd = await statusResp2.json();
                gpuMode = sd.gpuMode;
                startAttemptInfo = sd.startAttempt || '';
            }
        } catch (e) { /* ignore */ }

        const modeTag = gpuMode === true ? t('llm.gpu_mode') : gpuMode === false ? t('llm.cpu_mode') : '';
        
        // llama-server 模式：走 /llm/ 代理
        LLM.source = 'llama';
        LLM.apiUrl = '/llm/v1/chat/completions';
        LLM.useOllamaNative = false; // llama-server 不支持 Ollama 原生接口
        LLM.model = targetModel;
        LLM.fastModelEnabled = true; // llama-server 模式下默认启用（由后端管理模型）
        console.log(`[模型切换] 使用内嵌 llama-server 模式 ${modeTag}`);
        if (startAttemptInfo) console.log(`[模型切换] 启动配置: ${startAttemptInfo}`);

        if (gpuMode === false) {
            console.warn('⚠️⚠️⚠️ 当前使用 CPU 推理，速度会非常慢！请检查 CUDA 配置');
        }

        if (statusEl) {
            statusEl.textContent = t('llm.status_ready', { model: targetModel, mode: modeTag ? ' ' + modeTag : '' });
            statusEl.className = 'model-status success';
        }
        updateLlmHint(t('llm.status_ready_hint', { model: targetModel, mode: modeTag ? ' ' + modeTag : '' }));
        console.log(`[模型切换] ${targetModel} 就绪（llama-server 模式${modeTag ? ' ' + modeTag : ''}）`);
        return true;
    } else {
        // llama-server 未就绪且等待失败 —— 收集失败原因
        let failReason = 'llama-server 未能启动';
        try {
            const diagResp = await fetchWithTimeout('/api/llm-status', {}, 5000);
            if (diagResp.ok) {
                const diagData = await diagResp.json();
                if (!diagData.paths?.serverBinExists) {
                    failReason = 'llama-server 可执行文件不存在，请检查 llm 目录是否完整';
                } else if (!diagData.paths?.mainModelExists) {
                    failReason = '模型文件不存在，请检查 llm/models/ 目录中是否有 .gguf 模型文件';
                } else if (diagData.lastLogs && diagData.lastLogs.length > 0) {
                    // 从日志中提取关键错误信息
                    const errorLogs = diagData.lastLogs.filter(l => /error|fail|cuda|dll|missing/i.test(l));
                    if (errorLogs.length > 0) {
                        failReason = `llama-server 启动失败: ${errorLogs[errorLogs.length - 1]}`;
                    } else {
                        failReason = `llama-server 启动失败（${diagData.startAttempt || '未知原因'}）`;
                    }
                } else {
                    failReason = `llama-server 启动失败（${diagData.startAttempt || '所有GPU参数组合均失败，请检查显卡驱动和CUDA'}）`;
                }
            }
        } catch (e) {
            failReason = `llama-server 未响应且无法获取诊断信息: ${e.message}`;
        }

        console.error(`[模型切换] 失败: ${failReason}`);
        if (statusEl) {
            statusEl.textContent = `❌ ${failReason}`;
            statusEl.className = 'model-status error';
        }
        updateLlmHint(failReason);
        return false;
    }
}

// ============ 启动：模式选择 + 模型选择 ============
window.addEventListener('load', () => {
    const overlay = document.getElementById('mode-select-overlay');
    const btnReincarnation = document.getElementById('btn-mode-reincarnation');
    const btnContinue = document.getElementById('btn-mode-continue');
    const t = GST.t; // i18n 快捷引用

    // --- 检测并显示断点续玩存档 ---
    // 【v5.8.15】通关（完美结局）后不显示"继续游戏"，只显示"开始轮回"
    const saveInfo = GST.Game ? GST.Game.getSaveInfo() : null;
    let isPerfectCleared = false;
    try {
        // 检测是否已通关：存档中结局已触发 + 完美结局（8人存活）
        if (saveInfo && saveInfo.aliveCount >= 8 && saveInfo.mode === 'reincarnation') {
            // 检查存档中是否有结局标记
            const rawSave = localStorage.getItem('tihutown_save');
            if (rawSave) {
                const saveData = JSON.parse(rawSave);
                if (saveData.deathSystem && saveData.deathSystem.endingTriggered) {
                    isPerfectCleared = true;
                }
            }
        }
    } catch (e) { /* ignore */ }

    if (isPerfectCleared && btnContinue) {
        // 通关后不显示继续游戏，只显示开始轮回
        btnContinue.style.display = 'none';
        // 更新轮回按钮文案
        const btnText = document.getElementById('reincarnation-btn-text');
        const btnHint = document.getElementById('reincarnation-btn-hint');
        if (btnText) btnText.textContent = t('mode.btn_reincarnation_cleared');
        if (btnHint) btnHint.textContent = t('mode.btn_reincarnation_cleared_hint');
    } else if (saveInfo && btnContinue) {
        const modeLabel = { agent: t('game_mode.agent'), reincarnation: t('game_mode.reincarnation'), debug: t('game_mode.debug') };
        const continueHint = document.getElementById('continue-save-hint');
        if (continueHint) {
            continueHint.textContent = t('mode.continue_save_info', {
                day: saveInfo.day,
                time: saveInfo.timeStr,
                weather: saveInfo.weather,
                alive: saveInfo.aliveCount,
                total: saveInfo.totalCount,
                mode: modeLabel[saveInfo.mode] || saveInfo.mode,
                savedAt: saveInfo.savedAt
            });
        }
        btnContinue.style.display = '';
    } else if (btnContinue) {
        btnContinue.style.display = 'none';
    }

    // --- 检测并显示轮回历史状态 ---
    try {
        const lifeNumRaw = localStorage.getItem('gospel_reincarnation_life_num');
        const lifeNum = lifeNumRaw ? parseInt(lifeNumRaw, 10) : 0;
        if (lifeNum > 1) {
            const hintEl = document.getElementById('reincarnation-status-hint');
            const hintText = document.getElementById('reincarnation-hint-text');
            if (hintEl && hintText) {
                hintEl.style.display = '';
                hintText.textContent = t('mode.reincarnation_status', { n: lifeNum });
            }
        }
    } catch (e) { /* ignore */ }

    // --- 难度选择器初始化 ---
    const difficultySelectorEl = document.getElementById('difficulty-selector');
    const difficultyOptionsEl = document.getElementById('difficulty-options');
    const difficultyLockedText = document.getElementById('difficulty-locked-text');
    let selectedDifficultyKey = null;

    // 辅助函数：锁定所有难度卡片
    function lockDifficultyCards(currentKey) {
        if (!difficultyOptionsEl) return;
        difficultyOptionsEl.querySelectorAll('.difficulty-option').forEach(c => {
            c.classList.add('locked');
            // 移除之前的🔒标记
            const oldLock = c.querySelector('.lock-badge');
            if (oldLock) oldLock.remove();
            if (c.dataset.key === currentKey) {
                c.classList.add('current-locked');
                const lockBadge = document.createElement('span');
                lockBadge.className = 'lock-badge';
                lockBadge.textContent = '🔒';
                lockBadge.style.cssText = 'position:absolute;top:4px;right:6px;font-size:12px;';
                c.appendChild(lockBadge);
            }
        });
        if (difficultyLockedText) difficultyLockedText.style.display = '';
    }

    // 辅助函数：解锁所有难度卡片
    function unlockDifficultyCards() {
        if (!difficultyOptionsEl) return;
        difficultyOptionsEl.querySelectorAll('.difficulty-option').forEach(c => {
            c.classList.remove('locked', 'current-locked');
            const oldLock = c.querySelector('.lock-badge');
            if (oldLock) oldLock.remove();
        });
        if (difficultyLockedText) difficultyLockedText.style.display = 'none';
    }

    // 渲染难度卡片
    if (difficultyOptionsEl) {
        const levels = GST.getDifficultyList();
        levels.forEach(level => {
            const card = document.createElement('div');
            card.className = 'difficulty-option';
            card.dataset.key = level.key;
            card.innerHTML = `
                <div class="difficulty-stars">${level.stars}</div>
                <div class="difficulty-name" data-i18n="difficulty.${level.key}">${t('difficulty.' + level.key)}</div>
            `;
            card.addEventListener('click', () => {
                difficultyOptionsEl.querySelectorAll('.difficulty-option').forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
                selectedDifficultyKey = level.key;
            });
            difficultyOptionsEl.appendChild(card);
        });
        // 默认选中"简单"
        const easyCard = difficultyOptionsEl.querySelector('[data-key="easy"]');
        if (easyCard) {
            easyCard.classList.add('selected');
            selectedDifficultyKey = 'easy';
        }
    }

    // --- 根据轮回存档状态锁定/解锁难度卡片 ---
    try {
        const savedLifeNum = localStorage.getItem('gospel_reincarnation_life_num');
        const savedLife = savedLifeNum ? parseInt(savedLifeNum, 10) : 0;
        if (savedLife > 1) {
            const savedDiff = GST.getDifficulty();
            lockDifficultyCards(savedDiff.key);
            // 选中已保存的难度卡片
            if (difficultyOptionsEl) {
                difficultyOptionsEl.querySelectorAll('.difficulty-option').forEach(c => c.classList.remove('selected'));
                const savedCard = difficultyOptionsEl.querySelector(`[data-key="${savedDiff.key}"]`);
                if (savedCard) {
                    savedCard.classList.add('selected');
                    selectedDifficultyKey = savedDiff.key;
                }
            }
        }
    } catch (e) { /* ignore */ }

    // --- LLM 来源切换交互 ---
    const tabLocal = document.getElementById('tab-local');
    const tabExternal = document.getElementById('tab-external');
    const sourceLocal = document.getElementById('source-local');
    const sourceExternal = document.getElementById('source-external');
    const localModelSection = document.getElementById('local-model-section');

    function switchLLMSource(source) {
        LLM.source = source;
        if (source === 'local') {
            tabLocal.classList.add('active');
            tabExternal.classList.remove('active');
            sourceLocal.style.display = '';
            sourceExternal.style.display = 'none';
            // 模型信息区域保持隐藏，不暴露给玩家
        } else {
            tabLocal.classList.remove('active');
            tabExternal.classList.add('active');
            sourceLocal.style.display = 'none';
            sourceExternal.style.display = '';
            localModelSection.style.display = 'none';
        }
        // 清除之前的状态提示
        const statusEl = document.getElementById('model-status');
        if (statusEl) { statusEl.textContent = ''; statusEl.className = 'model-status'; }
    }

    if (tabLocal) tabLocal.addEventListener('click', () => switchLLMSource('local'));
    if (tabExternal) tabExternal.addEventListener('click', () => switchLLMSource('external'));

    // --- 外部API Key 显示/隐藏 ---
    const btnToggleKey = document.getElementById('btn-toggle-key');
    const inputApiKey = document.getElementById('external-api-key');
    if (btnToggleKey && inputApiKey) {
        btnToggleKey.addEventListener('click', () => {
            if (inputApiKey.type === 'password') {
                inputApiKey.type = 'text';
                btnToggleKey.textContent = '🙈';
            } else {
                inputApiKey.type = 'password';
                btnToggleKey.textContent = '👁️';
            }
        });
    }

    // --- 外部API测试连接 ---
    const btnTestApi = document.getElementById('btn-test-api');
    const apiTestResult = document.getElementById('api-test-result');
    if (btnTestApi) {
        btnTestApi.addEventListener('click', async () => {
            const url = document.getElementById('external-api-url').value.trim();
            const key = document.getElementById('external-api-key').value.trim();
            const model = document.getElementById('external-model-name').value.trim();

            if (!url) {
                apiTestResult.textContent = t('llm.test_no_url');
                apiTestResult.className = 'api-test-result error';
                return;
            }
            if (!model) {
                apiTestResult.textContent = t('llm.test_no_model');
                apiTestResult.className = 'api-test-result error';
                return;
            }

            apiTestResult.textContent = t('llm.test_loading');
            apiTestResult.className = 'api-test-result loading';
            btnTestApi.disabled = true;

            try {
                const resp = await fetch('/api/external-llm', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-External-API-URL': url,
                        'X-External-API-Key': key
                    },
                    body: JSON.stringify({
                        model: model,
                        messages: [{ role: 'user', content: '你好' }],
                        max_tokens: 10,
                        temperature: 0.1
                    })
                });

                if (resp.ok) {
                    const data = await resp.json();
                    const preview = data.choices?.[0]?.message?.content?.substring(0, 30) || '(response received)';
                    apiTestResult.textContent = t('llm.test_success', { preview });
                    apiTestResult.className = 'api-test-result success';
                } else {
                    const errText = await resp.text().catch(() => '');
                    apiTestResult.textContent = t('llm.test_fail_http', { status: resp.status, error: errText.substring(0, 80) });
                    apiTestResult.className = 'api-test-result error';
                }
            } catch (err) {
                apiTestResult.textContent = t('llm.test_fail', { error: err.message });
                apiTestResult.className = 'api-test-result error';
            } finally {
                btnTestApi.disabled = false;
            }
        });
    }

    // --- 从 localStorage 恢复外部API配置 ---
    try {
        const savedLLMSource = localStorage.getItem('gospel_llm_source');
        if (savedLLMSource === 'external') {
            const savedUrl = localStorage.getItem('gospel_external_api_url') || '';
            const savedKey = localStorage.getItem('gospel_external_api_key') || '';
            const savedModel = localStorage.getItem('gospel_external_model') || '';
            if (savedUrl) {
                document.getElementById('external-api-url').value = savedUrl;
                document.getElementById('external-api-key').value = savedKey;
                document.getElementById('external-model-name').value = savedModel;
                switchLLMSource('external');
            }
        }
    } catch (e) { /* ignore */ }

    // --- 获取选中模型（混合模式：固定使用8B主模型 + 0.6B快速模型） ---
    function getSelectedModel() {
        if (LLM.source === 'external') {
            return document.getElementById('external-model-name').value.trim() || 'gpt-4o-mini';
        }
        // 【v5.8.18】节能模式下使用0.6B小模型
        if (LLM.powerSaveMode) {
            return 'qwen3:0.6b';
        }
        // 本地模式固定使用 qwen3:8b 作为主模型（0.6B快速模型在switchModel中自动检测并启用）
        return 'qwen3:8b';
    }

    // --- 启动游戏（先切换模型再启动） ---
    let isStarting = false;
    async function startGame(mode, pendingDifficultyKey) {
        if (isStarting) return;
        isStarting = true;

        // 断点续玩：从存档中读取真实mode
        let isContinue = false;
        let realMode = mode;
        if (mode === '_continue_') {
            isContinue = true;
            const si = GST.Game ? GST.Game.getSaveInfo() : null;
            realMode = (si && si.mode) ? si.mode : 'agent';
            console.log(`[启动] 断点续玩模式，实际游戏模式: ${realMode}`);
        }

        // 非轮回模式强制使用简单难度（断点续玩不改难度）
        if (!isContinue && realMode !== 'reincarnation') {
            GST.setDifficulty('easy');
        }

        // 禁用按钮防止重复点击
        btnReincarnation.disabled = true;
        if (btnContinue) btnContinue.disabled = true;
        btnReincarnation.style.opacity = '0.5';
        if (btnContinue) btnContinue.style.opacity = '0.5';

        // --- 读取外部 API 配置并保存 ---
        if (LLM.source === 'external') {
            LLM.externalUrl = document.getElementById('external-api-url').value.trim();
            LLM.externalKey = document.getElementById('external-api-key').value.trim();
            LLM.externalModel = document.getElementById('external-model-name').value.trim();
            // 保存到 localStorage 方便下次恢复
            try {
                localStorage.setItem('gospel_llm_source', 'external');
                localStorage.setItem('gospel_external_api_url', LLM.externalUrl);
                localStorage.setItem('gospel_external_api_key', LLM.externalKey);
                localStorage.setItem('gospel_external_model', LLM.externalModel);
            } catch (e) { /* ignore */ }
        } else {
            try { localStorage.setItem('gospel_llm_source', 'local'); } catch (e) { /* ignore */ }
        }

        const selectedModel = getSelectedModel();

        // ====== 立即跳转到加载页面 ======
        overlay.style.display = 'none';
        const loadingOverlay = document.getElementById('asset-loading-overlay');
        const loadingBarFill = document.getElementById('loading-bar-fill');
        const loadingStatusText = document.getElementById('loading-status-text');
        const llmStatusContainer = document.getElementById('loading-llm-status');
        const llmStatusIcon = document.getElementById('llm-status-icon');
        const llmStatusText = document.getElementById('llm-status-text');

        loadingOverlay.style.display = 'flex';
        if (loadingBarFill) loadingBarFill.style.width = '0%';
        if (loadingStatusText) loadingStatusText.textContent = t('loading_page.status_waiting');

        // 【v5.8.15】初始化信息轮播
        _initCarousel();

        // 【v5.8.15】LLM加载阶段模拟进度条（不要一直是0）
        // 进度条在0~40%之间缓慢增长，给用户视觉反馈
        let llmFakeProgress = 0;
        const llmProgressTimer = setInterval(() => {
            llmFakeProgress += Math.random() * 3 + 0.5; // 每次增长0.5~3.5%
            if (llmFakeProgress > 40) llmFakeProgress = 40; // 最多到40%
            if (loadingBarFill) loadingBarFill.style.width = Math.round(llmFakeProgress) + '%';
        }, 500);

        // ====== 第一阶段：加载 LLM ======
        if (llmStatusIcon) llmStatusIcon.textContent = '🧠';
        if (llmStatusText) llmStatusText.textContent = t('loading_page.status_connecting');
        if (llmStatusContainer) llmStatusContainer.className = 'loading-llm-status';

        // 【v5.8.18】节能模式：通知后端切换到小模型
        if (LLM.powerSaveMode && LLM.source !== 'external') {
            try {
                if (llmStatusText) llmStatusText.textContent = '🔋 切换到节能模式 (0.6B)...';
                console.log('[启动] 节能模式：请求后端切换到 0.6B 小模型...');
                const switchResp = await fetch('/api/llm-switch-model?type=fast');
                if (switchResp.ok) {
                    const switchData = await switchResp.json();
                    console.log('[启动] 模型切换结果:', switchData);
                }
            } catch (e) {
                console.warn('[启动] 节能模式模型切换失败，继续使用当前模型:', e.message);
            }
        } else if (!LLM.powerSaveMode && LLM.source !== 'external') {
            // 非节能模式：确保后端使用主模型
            try {
                const statusResp = await fetch('/api/llm-status');
                if (statusResp.ok) {
                    const statusData = await statusResp.json();
                    if (statusData.currentModelType === 'fast') {
                        console.log('[启动] 检测到后端当前是小模型，切换回主模型...');
                        if (llmStatusText) llmStatusText.textContent = '⚡ 切换到性能模式 (8B)...';
                        await fetch('/api/llm-switch-model?type=main');
                    }
                }
            } catch (e) { /* ignore */ }
        }

        const success = await switchModel(selectedModel);
        clearInterval(llmProgressTimer); // 停止模拟进度

        if (!success) {
            // LLM 加载失败 —— 收集详细诊断信息
            let diagInfo = '';
            const llmConfig = {
                source: LLM.source,
                apiUrl: LLM.apiUrl,
                useOllamaNative: LLM.useOllamaNative,
                model: selectedModel,
            };
            console.error('[启动] LLM 加载失败，阻止进入游戏');
            console.error('[启动] LLM 配置:', JSON.stringify(llmConfig));
            diagInfo += `配置: source=${LLM.source}, model=${selectedModel}\n`;

            // 获取后端状态
            try {
                const dbgResp = await fetch('/api/llm-status');
                const dbgData = await dbgResp.json();
                console.error('[启动] 后端 llm-status:', JSON.stringify(dbgData));
                diagInfo += `后端: llamaReady=${dbgData.llamaReady}, running=${dbgData.llamaRunning}, backend=${dbgData.backend}\n`;
                if (dbgData.startAttempt) {
                    diagInfo += `启动尝试: ${dbgData.startAttempt}\n`;
                }
                if (!dbgData.llamaReady && !dbgData.llamaRunning) {
                    diagInfo += '⚠️ llama-server 未运行！可能原因：缺少DLL/不支持的参数/显存不足\n';
                } else if (dbgData.llamaRunning && !dbgData.llamaReady) {
                    diagInfo += '⚠️ llama-server 正在启动但未就绪（可能还在加载模型）\n';
                }
                // 显示 llama-server 最近日志
                if (dbgData.lastLogs && dbgData.lastLogs.length > 0) {
                    diagInfo += `\nllama-server 日志:\n`;
                    dbgData.lastLogs.forEach(log => {
                        diagInfo += `  ${log}\n`;
                    });
                }
            } catch (e) {
                console.error('[启动] 无法获取后端状态:', e.message);
                diagInfo += `后端状态获取失败: ${e.message}\n`;
            }

            // 在加载页面上显示详细错误
            if (llmStatusIcon) llmStatusIcon.textContent = '❌';
            if (llmStatusText) llmStatusText.textContent = t('llm.status_fail');
            if (llmStatusContainer) llmStatusContainer.className = 'loading-llm-status llm-fail';
            if (loadingStatusText) {
                loadingStatusText.innerHTML = `${t('loading_page.status_fail')}<br><span style="font-size:11px;color:rgba(255,150,150,0.7);white-space:pre-line;">${diagInfo}${t('loading_page.status_fail_hint')}</span>`;
            }
            if (loadingBarFill) loadingBarFill.style.width = '0%';

            // 3秒后返回启动页面，让用户可以重试
            await new Promise(r => setTimeout(r, 3000));
            loadingOverlay.style.display = 'none';
            overlay.style.display = '';
            isStarting = false;
            btnReincarnation.disabled = false;
            if (btnContinue) btnContinue.disabled = false;
            btnReincarnation.style.opacity = '';
            if (btnContinue) btnContinue.style.opacity = '';
            return;
        }

        // ====== LLM 加载成功 ======
        if (llmStatusIcon) llmStatusIcon.textContent = '✅';
        if (llmStatusText) llmStatusText.textContent = t('loading_page.status_ai_ready', { model: selectedModel });
        if (llmStatusContainer) llmStatusContainer.className = 'loading-llm-status llm-ok';
        // 进度条跳到50%（LLM占50%，素材占50%）
        if (loadingBarFill) loadingBarFill.style.width = '50%';

        // ====== 第二阶段：处理轮回数据 ======
        if (realMode === 'reincarnation' && !isContinue) {
            const chkReset = document.getElementById('chk-reset-reincarnation');
            if (chkReset && chkReset.checked) {
                try {
                    localStorage.removeItem('gospel_reincarnation');
                    localStorage.removeItem('gospel_reincarnation_life_num');
                    GST.clearDifficulty();
                    console.log('[启动] 用户选择从第1世重新开始，轮回数据已清除');
                } catch (e) { /* ignore */ }
            }
            // 【修复】在清除之后再保存用户选中的难度，避免先写后删导致难度丢失
            if (pendingDifficultyKey) {
                GST.setDifficulty(pendingDifficultyKey);
                console.log(`[启动] 难度已设置为: ${pendingDifficultyKey}`);
            }
        }

        // ====== 第三阶段：加载素材 ======
        if (typeof SpriteLoader !== 'undefined') {
            if (loadingStatusText) loadingStatusText.textContent = t('loading_page.status_loading_assets', { pct: '0' });

            // 启动进度轮询（从50%开始，LLM已占前50%）
            const progressTimer = setInterval(() => {
                const progress = SpriteLoader.progress;
                const pct = Math.round(50 + progress * 50); // 50%~100%
                if (loadingBarFill) loadingBarFill.style.width = pct + '%';
                if (loadingStatusText) loadingStatusText.textContent = t('loading_page.status_loading_assets', { pct: pct });
            }, 100);

            // 等待素材加载完成
            const loadOk = await SpriteLoader.load();
            clearInterval(progressTimer);

            // 加载完毕，更新UI
            if (loadingBarFill) loadingBarFill.style.width = '100%';
            if (loadingStatusText) {
                loadingStatusText.textContent = loadOk ? t('loading_page.status_assets_done') : t('loading_page.status_assets_partial');
            }
            if (loadOk) console.log('[启动] 图片素材加载完成');

            // 短暂展示完成状态
            await new Promise(r => setTimeout(r, 500));

            // 隐藏加载界面，启动游戏
            loadingOverlay.style.display = 'none';
        }

        document.getElementById('app-layout').style.display = 'flex';
        window.game = new GST.Game(realMode);

        // 【v5.8.18】Steam SDK 初始化
        if (GST.Steam) {
            GST.Steam.init().then(ok => {
                if (ok) {
                    console.log('[启动] Steam SDK 已连接');
                    // 更新 Rich Presence 为游戏状态
                    GST.Steam.updateRichPresence(`${realMode === 'agent' ? 'AI观察模式' : '手动模式'} - 正在游戏`);
                }
            }).catch(e => console.warn('[启动] Steam 初始化异常:', e));
        }

        // 断点续玩：如果是continue模式，创建游戏后加载存档
        if (isContinue) {
            window.game._isContinueSession = true;  // 标记断点续玩
            const loaded = window.game.load();
            if (loaded) {
                console.log('[启动] 断点续玩：存档加载成功');
                window.game.addEvent(t('event.save_continue'));
                // 同步UI
                window.game._updateReincarnationUI();
                window.game._updateSidebar();
                // 日志系统记录断点续玩恢复信息
                if (window.game.aiModeLogger) {
                    window.game.aiModeLogger.logContinueInfo();
                }
            } else {
                console.warn('[启动] 断点续玩：存档加载失败，从头开始');
                window.game._isContinueSession = false;
            }
        }

        // ============ 调试命令 ============
        /**
         * 手动触发资源紧急分配，验证完整的采集流程
         * 用法：在浏览器控制台输入 debugGather()
         */
        window.debugGather = function() {
            const g = window.game;
            if (!g) { console.error('game未初始化'); return; }

            console.log('=== debugGather: 开始端到端验证 ===');

            // 1. 检查当前资源状态
            const rs = g.resourceSystem;
            if (rs) {
                console.log(`[资源] 木柴:${Math.round(rs.woodFuel)} 食物:${Math.round(rs.food)} 电力:${Math.round(rs.power)}`);
                const urg = rs.getResourceUrgency();
                console.log(`[紧急度] 木柴:${urg.wood} 食物:${urg.food} 电力:${urg.power}`);
            }

            // 2. 手动触发紧急任务分配给第一个空闲NPC
            const idleNpc = g.npcs.find(n => !n.isDead && n.state !== 'CHATTING' && !n._taskOverride?.isActive);
            if (idleNpc) {
                console.log(`[分配] 将 ${idleNpc.name} 分配到伐木场 (urgent)`);
                idleNpc.activateTaskOverride('debug_gather_wood', 'lumber_camp', 'urgent', 'woodFuel');
                console.log(`[状态] ${idleNpc.name}: state=${idleNpc.state}, stateDesc=${idleNpc.stateDesc}, taskOverride=${JSON.stringify(idleNpc._taskOverride)}`);
            } else {
                console.warn('[分配] 没有空闲NPC可分配');
            }

            // 3. 显示所有NPC状态
            for (const npc of g.npcs) {
                if (npc.isDead) continue;
                const pos = npc.getGridPos();
                const gatherArea = g.taskSystem ? g.taskSystem._detectGatherArea(npc) : null;
                console.log(`  ${npc.name}: scene=${npc.currentScene} pos=(${pos.x},${pos.y}) state=${npc.state} stateDesc="${npc.stateDesc}" gathering=${npc._gatheringResource || '无'} inArea=${gatherArea || '无'} override=${npc._taskOverride?.isActive ? npc._taskOverride.targetLocation : '无'}`);
            }

            console.log('=== debugGather: 完成（观察控制台和资源栏变化） ===');
        };

        /**
         * 强制传送指定NPC到采集区并验证产出
         * 用法：debugTeleportGather('赵铁柱', 'lumber_camp')
         */
        window.debugTeleportGather = function(npcName, areaKey) {
            const g = window.game;
            if (!g) { console.error('game未初始化'); return; }

            const npc = g.npcs.find(n => n.name === npcName);
            if (!npc) { console.error(`找不到NPC: ${npcName}`); return; }

            const loc = { lumber_camp: {x:6,y:5}, frozen_lake: {x:6,y:35}, ruins_site: {x:43,y:5}, ore_pile: {x:43,y:35} };
            const target = loc[areaKey];
            if (!target) { console.error(`无效区域: ${areaKey}`); return; }

            console.log(`[debugTeleport] 传送 ${npcName} 到 ${areaKey} (${target.x},${target.y})`);
            npc._teleportTo('village', target.x, target.y);
            npc.activateTaskOverride(`debug_${areaKey}`, areaKey, 'urgent', areaKey === 'lumber_camp' ? 'woodFuel' : areaKey === 'frozen_lake' ? 'food' : areaKey === 'ore_pile' ? 'power' : 'explore');

            const gatherArea = g.taskSystem ? g.taskSystem._detectGatherArea(npc) : null;
            console.log(`[验证] ${npcName} 现在在 ${gatherArea || '未检测到'} 采集区`);
        };
    }

    // --- 继续游戏按钮 ---
    if (btnContinue) {
        btnContinue.addEventListener('click', () => {
            // 继续游戏使用存档中的模式，但startGame需要一个有效的mode来创建Game实例
            // 使用特殊标记'_continue_'，在创建Game后调用load()覆盖状态
            const si = GST.Game ? GST.Game.getSaveInfo() : null;
            const savedMode = si ? si.mode : 'agent';
            // 用存档中记录的真实mode创建Game，然后load()覆盖状态
            startGame('_continue_');
        });
    }

    // --- 轮回模式按钮：保存选中难度后直接启动游戏 ---
    btnReincarnation.addEventListener('click', () => {
        const lifeNumRaw = localStorage.getItem('gospel_reincarnation_life_num');
        const lifeNum = lifeNumRaw ? parseInt(lifeNumRaw, 10) : 0;
        const chkReset = document.getElementById('chk-reset-reincarnation');
        const isResetting = chkReset && chkReset.checked;

        if (lifeNum > 1 && !isResetting) {
            // 轮回中途：检测是否有同模式存档，有则自动断点续玩（避免丢失中途进度）
            const si = GST.Game ? GST.Game.getSaveInfo() : null;
            if (si && si.mode === 'reincarnation') {
                console.log(`[启动] 轮回模式检测到存档（第${si.day}天 ${si.timeStr}），自动断点续玩`);
                startGame('_continue_');
            } else {
                // 无存档或存档模式不匹配，正常启动新世代
                startGame('reincarnation');
            }
        } else {
            // 新轮回或重置：先保存选中的难度key到临时变量，startGame中清除后再写入
            startGame('reincarnation', selectedDifficultyKey);
        }
    });

    // "从第1世重新开始"勾选变化时，解锁/锁定难度卡片
    const chkResetEl = document.getElementById('chk-reset-reincarnation');
    if (chkResetEl) {
        chkResetEl.addEventListener('change', () => {
            const savedLifeNum = localStorage.getItem('gospel_reincarnation_life_num');
            const savedLife = savedLifeNum ? parseInt(savedLifeNum, 10) : 0;
            if (chkResetEl.checked) {
                // 勾选重置：解锁难度卡片，允许重新选择
                unlockDifficultyCards();
            } else {
                // 取消勾选：如果有存档则重新锁定
                if (savedLife > 1) {
                    const savedDiff = GST.getDifficulty();
                    lockDifficultyCards(savedDiff.key);
                }
            }
        });
    }

    // --- 语言切换时更新动态生成的文本 ---
    window.addEventListener('langchange', () => {
        // 更新轮回状态提示
        const hintText = document.getElementById('reincarnation-hint-text');
        if (hintText && hintText.textContent) {
            const lifeNumRaw = localStorage.getItem('gospel_reincarnation_life_num');
            const lifeNum = lifeNumRaw ? parseInt(lifeNumRaw, 10) : 0;
            if (lifeNum > 1) {
                hintText.textContent = t('mode.reincarnation_status', { n: lifeNum });
            }
        }
        // 更新难度锁定提示文本
        if (difficultyLockedText) {
            difficultyLockedText.textContent = t('difficulty.locked_text');
        }
    });

    // --- 速度选择器交互 ---
    const speedOptionsEl = document.getElementById('speed-options');
    let selectedSpeedIdx = 2; // 默认选中5×（index=2）
    // 从 localStorage 恢复上次选择的速度
    try {
        const savedSpeed = localStorage.getItem('gospel_start_speed_idx');
        if (savedSpeed !== null) {
            const idx = parseInt(savedSpeed, 10);
            if (idx >= 0 && idx <= 3) {
                selectedSpeedIdx = idx;
                // 更新UI选中状态
                if (speedOptionsEl) {
                    speedOptionsEl.querySelectorAll('.speed-option').forEach(c => c.classList.remove('selected'));
                    const target = speedOptionsEl.querySelector(`[data-speed="${idx}"]`);
                    if (target) target.classList.add('selected');
                }
            }
        }
    } catch (e) { /* ignore */ }

    if (speedOptionsEl) {
        speedOptionsEl.querySelectorAll('.speed-option').forEach(opt => {
            opt.addEventListener('click', () => {
                speedOptionsEl.querySelectorAll('.speed-option').forEach(c => c.classList.remove('selected'));
                opt.classList.add('selected');
                selectedSpeedIdx = parseInt(opt.dataset.speed, 10);
                try { localStorage.setItem('gospel_start_speed_idx', String(selectedSpeedIdx)); } catch (e) { /* ignore */ }
            });
        });
    }

    // 将选中的速度暴露给全局，供Game构造函数读取
    GST._pendingSpeedIdx = selectedSpeedIdx;

    // --- 【v5.8.18】节能模式选择器交互 ---
    const powersaveOptionsEl = document.getElementById('powersave-options');
    let selectedPowerSave = false; // 默认关闭
    // 从 localStorage 恢复上次选择的节能模式
    try {
        const savedPS = localStorage.getItem('gospel_power_save_mode');
        if (savedPS === 'true') {
            selectedPowerSave = true;
            if (powersaveOptionsEl) {
                powersaveOptionsEl.querySelectorAll('.powersave-option').forEach(c => c.classList.remove('selected'));
                const target = powersaveOptionsEl.querySelector('[data-powersave="on"]');
                if (target) target.classList.add('selected');
            }
            // 同步到 LLM 模块
            if (GST.LLM) GST.LLM.powerSaveMode = true;
        }
    } catch (e) { /* ignore */ }

    if (powersaveOptionsEl) {
        powersaveOptionsEl.querySelectorAll('.powersave-option').forEach(opt => {
            opt.addEventListener('click', () => {
                powersaveOptionsEl.querySelectorAll('.powersave-option').forEach(c => c.classList.remove('selected'));
                opt.classList.add('selected');
                selectedPowerSave = (opt.dataset.powersave === 'on');
                try { localStorage.setItem('gospel_power_save_mode', String(selectedPowerSave)); } catch (e) { /* ignore */ }
                // 同步到 LLM 模块
                if (GST.LLM) GST.LLM.powerSaveMode = selectedPowerSave;
                // 同步 HUD 上的节能按钮状态
                const btnPS = document.getElementById('btn-power-save');
                if (btnPS) {
                    if (selectedPowerSave) {
                        btnPS.classList.add('active');
                        btnPS.textContent = GST.t('hud.power_save_on');
                        btnPS.title = GST.t('hud.power_save_tip_on');
                    } else {
                        btnPS.classList.remove('active');
                        btnPS.textContent = GST.t('hud.power_save_off');
                        btnPS.title = GST.t('hud.power_save_tip_off');
                    }
                }
            });
        });
    }

    // 包装原始startGame，在启动前同步最新的速度选择和节能模式
    const _origStartGame = startGame;
    startGame = async function(...args) {
        GST._pendingSpeedIdx = selectedSpeedIdx;
        // 同步节能模式到 LLM 模块
        if (GST.LLM) GST.LLM.powerSaveMode = selectedPowerSave;
        return _origStartGame.apply(this, args);
    };
});

// ============ 【v5.8.15】加载页信息轮播系统 ============
function _initCarousel() {
    const track = document.getElementById('carousel-track');
    const dotsContainer = document.getElementById('carousel-dots');
    const prevBtn = document.getElementById('carousel-prev');
    const nextBtn = document.getElementById('carousel-next');
    if (!track || !dotsContainer) return;

    const pages = track.querySelectorAll('.carousel-page');
    const totalPages = pages.length;
    if (totalPages === 0) return;

    let currentPage = 0;
    let autoTimer = null;

    // 生成圆点指示器
    dotsContainer.innerHTML = '';
    for (let i = 0; i < totalPages; i++) {
        const dot = document.createElement('div');
        dot.className = 'carousel-dot' + (i === 0 ? ' active' : '');
        dot.addEventListener('click', () => goToPage(i));
        dotsContainer.appendChild(dot);
    }

    function goToPage(idx) {
        currentPage = ((idx % totalPages) + totalPages) % totalPages;
        track.style.transform = `translateX(-${currentPage * 100}%)`;
        // 更新圆点
        dotsContainer.querySelectorAll('.carousel-dot').forEach((d, i) => {
            d.classList.toggle('active', i === currentPage);
        });
        // 重置自动轮播计时器
        resetAutoPlay();
    }

    function nextPage() { goToPage(currentPage + 1); }
    function prevPage() { goToPage(currentPage - 1); }

    if (prevBtn) prevBtn.addEventListener('click', prevPage);
    if (nextBtn) nextBtn.addEventListener('click', nextPage);

    // 自动轮播：每6秒切换一页
    function resetAutoPlay() {
        if (autoTimer) clearInterval(autoTimer);
        autoTimer = setInterval(nextPage, 6000);
    }
    resetAutoPlay();

    // 支持触摸滑动（移动端友好）
    let touchStartX = 0;
    const viewport = track.parentElement;
    if (viewport) {
        viewport.addEventListener('touchstart', (e) => {
            touchStartX = e.touches[0].clientX;
        }, { passive: true });
        viewport.addEventListener('touchend', (e) => {
            const diff = touchStartX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 50) {
                diff > 0 ? nextPage() : prevPage();
            }
        }, { passive: true });
    }
}


})();
