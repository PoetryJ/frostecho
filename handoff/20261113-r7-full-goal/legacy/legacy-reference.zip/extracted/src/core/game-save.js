/**
 * 福音镇 - Game 存档系统 Mixin
 * 职责：存档/读档/自动保存
 * 从 game.js 拆分，遵循SRP原则（单一职责）
 * 挂载到 GST.Game.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.Game.prototype;

    proto.save = function() {
        if (this.deathSystem && this.deathSystem.endingTriggered) {
            console.log('[Save] 结局已触发，跳过保存');
            return;
        }
        const data = {
            ver: 2,
            mode: this.mode,
            day: this.dayCount,
            time: this.gameTimeSeconds,
            scene: this.currentScene,
            weather: this.weather,
            speedIdx: this.speedIdx,
            npcs: this.npcs.map(n => n.serialize()),
            eventLog: this.eventLog.slice(0, 30),
            resourceSystem: this.resourceSystem ? this.resourceSystem.serialize() : null,
            furnaceSystem: this.furnaceSystem ? this.furnaceSystem.serialize() : null,
            machineSystem: this.machineSystem ? this.machineSystem.serialize() : null,
            deathSystem: this.deathSystem ? this.deathSystem.serialize() : null,
            taskSystem: this.taskSystem ? this.taskSystem.serialize() : null,
            eventSystem: this.eventSystem ? this.eventSystem.serialize() : null,
            reincarnationSystem: this.reincarnationSystem ? this.reincarnationSystem.serialize() : null,
            _medkitCount: this._medkitCount,
            _medkitCraftProgress: this._medkitCraftProgress,
            _foodWasteReduction: this._foodWasteReduction,
            _patrolBonus: this._patrolBonus,
            _furnaceMaintained: this._furnaceMaintained,
            _nightSkipDone: this._nightSkipDone,
            savedAt: Date.now(),
        };
        localStorage.setItem('tihutown_save', JSON.stringify(data));
        this._showToast('💾 已保存');
    };

    proto.autoSave = function() { this.save(); };

    proto.load = function() {
        const raw = localStorage.getItem('tihutown_save');
        if (!raw) return false;
        try {
            const d = JSON.parse(raw);
            this.dayCount = d.day || 1;
            this.gameTimeSeconds = d.time || 8 * 3600;
            this.currentScene = d.scene || 'village';
            this.weather = d.weather || '晴天';
            if (d.speedIdx !== undefined) {
                this.speedIdx = d.speedIdx;
                const btnSpeed = document.getElementById('btn-speed');
                if (btnSpeed) btnSpeed.textContent = `${this.speedOptions[this.speedIdx]}×`;
            }
            if (d.npcs) {
                for (let i = 0; i < this.npcs.length && i < d.npcs.length; i++) {
                    this.npcs[i].deserialize(d.npcs[i]);
                }
            }
            if (d.eventLog) this.eventLog = d.eventLog;
            if (d.resourceSystem && this.resourceSystem && this.resourceSystem.deserialize) { this.resourceSystem.deserialize(d.resourceSystem); }
            if (d.furnaceSystem && this.furnaceSystem && this.furnaceSystem.deserialize) { this.furnaceSystem.deserialize(d.furnaceSystem); }
            if (d.machineSystem && this.machineSystem && this.machineSystem.deserialize) { this.machineSystem.deserialize(d.machineSystem); }
            if (d.deathSystem && this.deathSystem && this.deathSystem.deserialize) { this.deathSystem.deserialize(d.deathSystem); }
            if (d.taskSystem && this.taskSystem && this.taskSystem.deserialize) { this.taskSystem.deserialize(d.taskSystem); }
            if (d.eventSystem && this.eventSystem && this.eventSystem.deserialize) { this.eventSystem.deserialize(d.eventSystem); }
            if (d.reincarnationSystem && this.reincarnationSystem && this.reincarnationSystem.deserialize) { this.reincarnationSystem.deserialize(d.reincarnationSystem); }
            if (d._medkitCount !== undefined) this._medkitCount = d._medkitCount;
            if (d._medkitCraftProgress !== undefined) this._medkitCraftProgress = d._medkitCraftProgress;
            if (d._foodWasteReduction !== undefined) this._foodWasteReduction = d._foodWasteReduction;
            if (d._patrolBonus !== undefined) this._patrolBonus = d._patrolBonus;
            if (d._furnaceMaintained !== undefined) this._furnaceMaintained = d._furnaceMaintained;
            if (d._nightSkipDone !== undefined) this._nightSkipDone = d._nightSkipDone;
            if (this.weatherSystem) { this.weatherSystem.currentWeather = this.weather; }
            this._openingCouncilDone = true;
            this._openingCouncilScheduled = false;
            this._updateRainIntensity();

            // 【v5.2修复】读档后任务安全检查：如果dailyTasks为空，强制重新生成
            // 根因：存档可能发生在晨会讨论期间（任务尚未生成或被清空），
            // 读档后_openingCouncilDone=true导致不会再触发晨会和任务生成
            if (this.taskSystem && this.taskSystem.dailyTasks.length === 0) {
                console.warn('[Save] ⚠️ 读档后dailyTasks为空，强制重新生成任务');
                this.taskSystem._taskGeneratedForDay = -1; // 重置标记
                this.taskSystem.onDayChange(this.dayCount);
            }

            console.log(`[Game] 存档加载成功：第${this.dayCount}天 ${this.getTimeStr()} 模式=${d.mode || 'unknown'}`);
            return true;
        } catch (e) {
            console.warn('存档加载失败:', e);
            return false;
        }
    };

})();
