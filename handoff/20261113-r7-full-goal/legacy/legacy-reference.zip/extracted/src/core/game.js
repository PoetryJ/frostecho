/**
 * 福音镇 - Game 主类（精简调度中心）
 * 游戏主循环、子系统初始化/调度、场景切换、存档/读档
 * 挂载到 GST.Game
 */
(function() {
    'use strict';
    const GST = window.GST;

    class Game {
    constructor(mode) {
        // 模式: 'agent' = AI 观察模式, 'debug' = 手动模式, 'reincarnation' = 轮回模式
        this.mode = mode;
        // 轮回模式继承AI观察模式的全部行为（自动跟随、NPC自主行动等）
        this.isAgentMode = (mode === 'agent' || mode === 'reincarnation');

        // 【难度系统】读取当前难度配置
        this.difficulty = GST.getDifficulty();
        console.log(`[Game] 难度: ${this.difficulty.stars} ${this.difficulty.name} (key=${this.difficulty.key})`);

        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.ui = document.getElementById('ui');

        // 视口 — 高 DPI 适配，画面放大 1.5 倍且文字高清
        this.viewW = 20 * GST.TILE;
        this.viewH = 15 * GST.TILE;
        this.displayScale = 1.5; // 画面整体放大倍数
        this.dpr = window.devicePixelRatio || 1;
        // 内部渲染分辨率 = 逻辑尺寸 × displayScale × dpr，确保文字不模糊
        const renderScale = this.displayScale * this.dpr;
        this.canvas.width = this.viewW * renderScale;
        this.canvas.height = this.viewH * renderScale;
        this.canvas.style.width = (this.viewW * this.displayScale) + 'px';
        this.canvas.style.height = (this.viewH * this.displayScale) + 'px';
        this.ctx.scale(renderScale, renderScale);
        this.camera = new GST.Camera(this.viewW, this.viewH);

        // 时间系统
        this.gameTimeSeconds = 8 * 3600;
        this.dayCount = 1;
        this.timeSpeed = 60;
        this.paused = false;

        // 速度档位
        this.speedOptions = [1, 2, 5];
        this.speedIdx = 0;
        // 读取起始页预选的速度（如果有）
        if (typeof GST._pendingSpeedIdx === 'number' && GST._pendingSpeedIdx >= 0 && GST._pendingSpeedIdx < this.speedOptions.length) {
            this.speedIdx = GST._pendingSpeedIdx;
        }
        // 【修复】立即同步速度按钮文字，避免HTML默认的"1×"与实际速度不一致
        const _btnSpeed = document.getElementById('btn-speed');
        if (_btnSpeed) _btnSpeed.textContent = `${this.speedOptions[this.speedIdx]}×`;

        // 全员入睡跳夜系统
        this._nightSkipDone = false; // 当天是否已执行过跳夜（每天只跳一次）
        this._allSleepingFrames = 0; // 连续多少帧全员在睡觉（防抖动）

        // 天气系统
        this.weather = '晴天';
        this.rainDrops = [];     // 雨滴粒子
        this.rainIntensity = 0;  // 雨的强度 0~1
        this.weatherChangeTimer = 0;
        this.weatherChangeInterval = 3600; // 游戏内1小时可能变天

        // 地图 — 末日据点
        this.maps = {
            village:   new GST.VillageMap(),
            dorm_a:    new GST.DormAMap(),
            dorm_b:    new GST.DormBMap(),
            medical:   new GST.MedicalMap(),
            warehouse: new GST.WarehouseMap(),
            workshop:  new GST.WorkshopMap(),
            kitchen:   new GST.KitchenMap(),
            command:   new GST.CommandMap(),
        };

        // 当前观察的场景（AI 模式下跟随 NPC 自动切换）
        this.currentScene = 'village';

        // NPC 系统
        this.npcs = [];
        this._initNPCs();

        // 对话系统
        this.dialogueManager = new GST.DialogueManager(this);

        // ============ v5.0 核心防御系统初始化 ============
        // 结构化日志系统（最先初始化，供其他系统使用）
        this.structuredLogger = GST.StructuredLogger ? new GST.StructuredLogger(this) : null;
        // Bug自动检测系统
        this.bugDetector = GST.BugDetector ? new GST.BugDetector(this) : null;
        // NPC控制权仲裁器
        this.npcArbiter = GST.NPCArbiter ? new GST.NPCArbiter(this) : null;
        // 【v5.3】决策冲突解决器
        this.decisionResolver = GST.DecisionConflictResolver ? new GST.DecisionConflictResolver(this) : null;

        // ============ 极寒生存系统初始化 ============
this.weatherSystem = GST.WeatherSystem ? new GST.WeatherSystem(this) : null;
        // 【修复】初始化时同步WeatherSystem天气到game.weather，避免两套天气系统冲突
        if (this.weatherSystem) {
            this.weather = this.weatherSystem.currentWeather;
        }
this.resourceSystem = GST.ResourceSystem ? new GST.ResourceSystem(this) : null;
this.furnaceSystem = GST.FurnaceSystem ? new GST.FurnaceSystem(this) : null;
this.machineSystem = GST.MachineSystem ? new GST.MachineSystem(this) : null;
this.deathSystem = GST.DeathSystem ? new GST.DeathSystem(this) : null;
this.taskSystem = GST.TaskSystem ? new GST.TaskSystem(this) : null;
this.eventSystem = GST.EventSystem ? new GST.EventSystem(this) : null;
this.councilSystem = GST.CouncilSystem ? new GST.CouncilSystem(this) : null;

        // WebGL Shader 视觉效果系统（暴风雪粒子、昼夜光照、后处理）— 【已关闭】所有特效已禁用
        this.shaderFX = null; // GST.ShaderFX ? new GST.ShaderFX(this) : null;
        // 轮回记忆系统（非轮回模式下构造函数内部自动强制第1世）
this.reincarnationSystem = GST.ReincarnationSystem ? new GST.ReincarnationSystem(this) : null;
this.bgmSystem = GST.BgmSystem ? new GST.BgmSystem(this) : null;

        // 【智能分工系统】生成workPlan并存储到老钱
        this._initWorkPlan();

        // AI模式日志系统（仅 agent/reincarnation 模式下启用）
this.aiModeLogger = (this.isAgentMode && GST.AIModeLogger) ? new GST.AIModeLogger(this) : null;

        // ============ 全局物品/状态系统 ============
        // 急救包系统
        this._medkitCount = 0;           // 急救包库存
        this._medkitCraftProgress = 0;   // 制作进度
        // 无线电修理系统已移除（v4.5）
        // 食物浪费减少标记
        this._foodWasteReduction = false;
        this._foodWasteReductionTimer = 0;
        // 巡逻加成标记
        this._patrolBonus = false;
        this._patrolBonusTimer = 0;
        // 暖炉维护标记
        this._furnaceMaintained = false;

        // ---- AI 观察模式 ----
        this.followTarget = null;    // 当前跟随的 NPC
        this.autoFollow = true;      // 自动切换跟随
        this.followSwitchTimer = 0;
        this.followSwitchInterval = 30; // 每 30 秒兜底自动切换一次

        // ---- 事件驱动镜头切换 ----
        this._cameraLockTimer = 0;       // 事件锁定倒计时（秒），>0 时不响应低优先级切换
        this._cameraLockDuration = 5;    // 事件驱动切换后的锁定观看时长（秒）
        this._cameraLockPriority = 0;    // 当前锁定事件的优先级（0=无锁定）
        this._deathViewTimer = 0;        // 当前跟随目标死亡后延迟切走计时器

        // ---- Debug 模式 ----
        this.debugCamSpeed = 300;
        this.showGrid = false;

        // 输入
        this.keys = {};

        // 淡入淡出
        this.fadeAlpha = 0;
        this.fadeDirection = 0;
        this.nextScene = null;
        this.pendingFollowTarget = null;

// 事件日志
        this.eventLog = [];
        this.maxEventLog = 50;

        // 补发 _initWorkPlan 延迟的事件（因为 eventLog 在其之后才初始化）
        if (this._pendingWorkPlanEvent) {
            this.addEvent(this._pendingWorkPlanEvent);
            delete this._pendingWorkPlanEvent;
        }

        // 【开局资源随机提示】让玩家知道这局的资源配比
        if (this.resourceSystem) {
            const rs = this.resourceSystem;
            const diffKey = this.difficulty ? this.difficulty.key : 'easy';
            const diffName = GST.t('difficulty.' + diffKey + '_name');
            this.addEvent(GST.t('misc.initial_resources', { diff: diffName, wood: Math.round(rs.woodFuel), food: Math.round(rs.food), power: Math.round(rs.power) }));
        }

        // 向右侧「决策动态」面板写入第1天分工方案卡片
        this._addWorkPlanCardToDecisionPanel();

        // 设置输入
        this._setupInput();
        this._setupControls();
        this._setupSidebar();

        // 初始化摄像机位置 — 对准新地图中心（主暖炉附近）
        const map = this.maps[this.currentScene];
        this.camera.jumpTo(25 * GST.TILE, 20 * GST.TILE, map.width * GST.TILE, map.height * GST.TILE);

        // 初始跟随
        if (this.isAgentMode && this.npcs.length > 0) {
            this.followTarget = this.npcs[0];
        }

        // 自动存档
        this.autoSaveTimer = 0;
        this.autoSaveInterval = 120;

        // 首日开局晨会调度（新局/轮回触发，读档跳过）
        this._openingCouncilDone = false;
        this._openingCouncilScheduled = false;

        // 主循环（支持后台运行）
        this.lastTime = performance.now();
        this._bgTimerId = null;  // 后台 setTimeout ID
        this._isBgMode = false;  // 当前是否后台模式
        this._BG_FPS = 15;      // 后台帧率

        // 监听标签页可见性变化，实现前台/后台自动切换
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                // 切到后台：取消 rAF，启动 setTimeout 驱动
                this._isBgMode = true;
                this.lastTime = performance.now();
                this._bgLoop();
                console.log('🔄 游戏循环模式切换: 后台(setTimeout, ' + this._BG_FPS + 'fps)');
            } else {
                // 切回前台：取消 setTimeout，恢复 rAF 驱动
                this._isBgMode = false;
                if (this._bgTimerId) {
                    clearTimeout(this._bgTimerId);
                    this._bgTimerId = null;
                }
                this.lastTime = performance.now();
                requestAnimationFrame(t => this.loop(t));
                console.log('🔄 游戏循环模式切换: 前台(rAF)');
            }
        });

        requestAnimationFrame(t => this.loop(t));

        // 更新轮回世数UI
        this._updateReincarnationUI();

        this._scheduleOpeningCouncil();

console.log(`🏘️ 福音镇已启动！模式: ${mode}`);
    }

    _scheduleOpeningCouncil(options) {
        const force = !!(options && options.force);
        if (this._openingCouncilDone || this._openingCouncilScheduled) return false;
        // 【v4.33修复】去掉D1限制——每天都需要开晨会
        // 根因：之前只有D1有晨会，D2/D3/D4 NPC醒来后带着旧分工执行，
        // 导致D4清璇按D3的旧计划出去干活冻死
        if (!this.taskSystem || !this.councilSystem || !this.councilSystem.openOpeningCouncil) return false;

        this._openingCouncilScheduled = true;
        setTimeout(() => {
            this._openingCouncilScheduled = false;
            if (this._openingCouncilDone) return;
            if (!this.taskSystem || !this.councilSystem) return;

            if (this.taskSystem._taskGeneratedForDay !== this.dayCount && this.taskSystem.onDayChange) {
                this.taskSystem.onDayChange(this.dayCount);
            }
            if (this.councilSystem.isActive) return;

            this.paused = true;
            const btn = document.getElementById('btn-pause');
            if (btn) btn.textContent = '▶️';

            const opened = this.councilSystem.openOpeningCouncil();
            if (opened) {
                this._openingCouncilDone = true;
                this.addEvent(GST.t('misc.morning_council', { n: this.dayCount }));
            }
        }, 200);
        return true;
    }

    /**
     * 【难度系统】获取指定参数的难度倍率
     * @param {string} paramName - 参数名（如 'hungerDecayMult', 'staminaDrainMult' 等）
     * @returns {number} 对应的倍率值，默认返回 1.0
     */

    getDifficultyMult(paramName) {
        return (this.difficulty && this.difficulty[paramName] != null) ? this.difficulty[paramName] : 1.0;
    }

    // ---- 【智能分工系统】workPlan初始化 ----

    _initWorkPlan() {
        if (!this.reincarnationSystem) return;

        // 生成分工方案
        const workPlan = this.reincarnationSystem.generateWorkPlan();
        if (!workPlan) return;

        // 存储到老钱（或继任者）
        const holder = this.reincarnationSystem.getWorkPlanHolder();
        if (holder) {
            holder.workPlan = workPlan;
            const lifeNum = this.reincarnationSystem.getLifeNumber();
            console.log(`[WorkPlan] 第${lifeNum}世晨会建议稿已存储到${holder.name}`);
            // 延迟添加事件，因为构造函数中 eventLog 可能尚未初始化
            // 构建详细的分工建议日志
            const strategyLabel = workPlan.strategy || '默认';
            let detailLog = `\n📋━━━ 第${lifeNum}世·${holder.name}的晨会建议稿（策略:${strategyLabel}）━━━\n`;
            detailLog += `${workPlan.summary || workPlan.workPlanSummary}\n`;
            // 显示第1天的分工详情
            if (workPlan.dayPlans && workPlan.dayPlans[1]) {
                const nameMap = { zhao_chef: '赵铁柱', lu_chen: '陆辰', li_shen: '李婶', wang_teacher: '王策', old_qian: '老钱', su_doctor: '苏岩', ling_yue: '歆玥', qing_xuan: '清璇' };
                const taskShort = { COLLECT_WOOD: '砍柴', COLLECT_FOOD: '采食物', COLLECT_MATERIAL: '探索废墟', MAINTAIN_POWER: '维护电力', COORDINATE: '统筹协调', PREPARE_MEDICAL: '医疗', SCOUT_RUINS: '侦察', BOOST_MORALE: '鼓舞士气', PREPARE_WARMTH: '御寒', MAINTAIN_ORDER: '维持秩序', REST_RECOVER: '休息' };
                for (const a of workPlan.dayPlans[1]) {
                    const name = nameMap[a.npcId] || a.npcId;
                    const task = taskShort[a.task] || a.task;
                    detailLog += `  ${name}→${task}${a.reason ? '(' + a.reason + ')' : ''}\n`;
                }
            }
            detailLog += `📋━━━ 晨会开始前先供大家参考，最终分工以晨会表决为准 ━━━`;
            this._pendingWorkPlanEvent = detailLog;
        }

        // 日志输出
        if (workPlan.dayPlans) {
            const days = Object.keys(workPlan.dayPlans);
            const npcCounts = days.map(d => workPlan.dayPlans[d].length);
            console.log(`[WorkPlan] 第${this.reincarnationSystem.getLifeNumber()}世晨会建议稿生成完毕: { ${days.map((d, i) => `day${d}: ${npcCounts[i]}人`).join(', ')} }`);
        }
    }

    // ---- 向决策面板写入分工方案卡片 ----

    _addWorkPlanCardToDecisionPanel() {
        // 【v4.16】分工建议稿已由右上角常驻面板(#work-plan-panel)实时显示
        // 此处只在事件日志中留一条简要通知
        if (!this.reincarnationSystem) return;
        const holder = this.reincarnationSystem.getWorkPlanHolder();
        if (!holder || !holder.workPlan) return;
        // 面板会自动从reincarnationSystem读取workPlan，无需手动写入DOM
    }

    // ---- NPC 初始化 ----

    _initNPCs() {
        if (typeof GST.NPC_CONFIGS === 'undefined') return;
        for (const cfg of GST.NPC_CONFIGS) {
            this.npcs.push(new GST.NPC(cfg, this));
        }
    }
    // [已拆分到 game-follow.js] setFollowTarget
    // [已拆分到 game-follow.js] switchFollowTarget
    // [已拆分到 game-follow.js] _autoSwitchFollow
    // [已拆分到 game-follow.js] _doAutoSwitch
    // ---- 事件驱动镜头切换 ----
    /** 事件优先级映射 */
    static get CAMERA_EVENT_PRIORITY() {
        return { chat_start: 1, crazy: 2, death: 3 };
    }
    // [已拆分到 game-follow.js] onNPCEvent
    // [已拆分到 game-follow.js] _eventDrivenSwitch
    // [已拆分到 game-follow.js] _switchScene
    // ---- 主循环 ----

    loop(time) {
        // 如果已切到后台模式，不再通过 rAF 驱动
        if (this._isBgMode) return;

        const dt = Math.min((time - this.lastTime) / 1000, 0.1);
        this.lastTime = time;

        if (!this.paused) {
            this.update(dt);
        }
        // BGM系统独立于暂停状态运行（暂停时音乐也要继续播放）
        if (this.bgmSystem) this.bgmSystem.update();
        this.draw();

        // 自动存档
        this.autoSaveTimer += dt;
        if (this.autoSaveTimer >= this.autoSaveInterval) {
            this.autoSaveTimer = 0;
            this.autoSave();
        }
        requestAnimationFrame(t => this.loop(t));
    }

    /**
     * 后台循环 — 标签页隐藏时用 setTimeout 驱动，不受浏览器节流
     * 只执行 update()，不执行 draw()（后台没人看，省 CPU）
     */
    _bgLoop() {
        if (!this._isBgMode) return;

        const now = performance.now();
        const dt = Math.min((now - this.lastTime) / 1000, 0.1);
        this.lastTime = now;

        if (!this.paused) {
            this.update(dt);
        }
        // BGM系统独立于暂停状态运行
        if (this.bgmSystem) this.bgmSystem.update();

        // 自动存档
        this.autoSaveTimer += dt;
        if (this.autoSaveTimer >= this.autoSaveInterval) {
            this.autoSaveTimer = 0;
            this.autoSave();
        }

        this._bgTimerId = setTimeout(() => this._bgLoop(), 1000 / this._BG_FPS);
    }

    update(dt) {
        // 【兜底保护】结局已触发后，强制阻止游戏继续运行
        if (this.deathSystem && this.deathSystem.endingTriggered) {
            this.paused = true;
            return;
        }

        const gameDt = dt * this.speedOptions[this.speedIdx];
        this._lastRealDt = dt;
        this._lastGameDt = gameDt;

        // 时间流逝
        const oldH = Math.floor(this.gameTimeSeconds / 3600);
        this.gameTimeSeconds += gameDt * this.timeSpeed;
        const newH = Math.floor(this.gameTimeSeconds / 3600);
        if (newH > oldH) this._onHourChange(newH);
        if (this.gameTimeSeconds >= 24 * 3600) {
            // 【兜底保护】第4天不允许推进到第5天
            if (this.dayCount >= 4) {
                this.gameTimeSeconds = 24 * 3600 - 1; // 钉在23:59:59
                if (this.deathSystem) this.deathSystem._checkEndingCondition();
                return;
            }
            this.gameTimeSeconds -= 24 * 3600;
            this.dayCount++;
            this._nightSkipDone = false; // 新的一天重置跳夜标志
this.addEvent(GST.t('event.new_day', { n: this.dayCount }));
            // 重置所有NPC的每日客流统计和饥饿值
            for (const npc of this.npcs) {
                npc.shopVisitorCount = 0;
                npc.shopLastVisitorTime = null;
                npc.shopAloneMinutes = 0;
                
                // 【修复】如果NPC正在睡觉，保护睡眠状态，避免属性突变导致起床震荡
                if (npc.isSleeping) {
                    npc._dayChangeWhileSleeping = true; // 标记日切换发生在睡眠中
                    npc._forcedSleep = false;  // 【硬保护】日切换清除强制睡眠标记，新的一天恢复正常日程
                    npc._forcedSleepTimer = 0;
                    npc.hunger = Math.max(npc.hunger, 80); // 温和恢复，不强制重置为100
                    npc.isEating = false;
                    npc._hungerOverride = false;
                    npc._hungerTarget = null;
                    // 睡眠中体力和San值正常恢复
                    npc.stamina = Math.min(100, npc.stamina + 30);
                    npc.sanity = Math.min(100, npc.sanity + 15);
                } else {
                    npc.hunger = 100; // 新的一天，饱食重置
                    npc.isEating = false;
                    npc._hungerOverride = false;
                    npc._hungerTarget = null;
                    // 新的一天：体力部分恢复（睡了一晚）
                    npc.stamina = Math.min(100, npc.stamina + 30);
                    // 新的一天：San值部分恢复
                    npc.sanity = Math.min(100, npc.sanity + 15);
                }
                // 工作日薪结算（简化：每天结算一次固定收入）
                if (npc.workplaceName) {
                    npc.savings += 30; // 基础日薪
                } else if (npc.age >= 55) {
                    npc.savings += 20; // 退休金
                }
            }

            // ============ 通知极寒生存系统：天数切换 ============
            if (this.weatherSystem && this.weatherSystem.onDayChange) {
                this.weatherSystem.onDayChange(this.dayCount);
            }
            if (this.resourceSystem && this.resourceSystem.generateDayReport) {
                const report = this.resourceSystem.generateDayReport(this.dayCount - 1);
                if (report) {
                    console.log('[Game] 日结算报告:', this.resourceSystem.formatDayReport(report));
                    // AI模式日志：每日资源报告
                    if (this.aiModeLogger) {
                        this.aiModeLogger.log('DAILY_RESOURCE', this.resourceSystem.formatDayReport(report));
                    }
                }
            }
            // AI模式日志：每日总结（所有NPC属性快照 + 天气/难度）
            if (this.aiModeLogger && this.npcs.length > 0) {
                const aliveNpcs = this.npcs.filter(n => !n.isDead);
                const lines = aliveNpcs.map(npc => {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(npc);
                    return `  ${npc.name} | ${npc.state || '?'}/${npc.stateDesc || '?'} | ${snap} | ${npc.currentScene || '?'}`;
                });
                const deadCount = this.npcs.length - aliveNpcs.length;
                // 天气和难度信息
                let envInfo = '';
                if (this.weatherSystem) {
                    const ws = this.weatherSystem;
                    envInfo += ` | 天气:${ws.currentWeather || '?'} 温度:${ws.currentTemp != null ? ws.currentTemp + '°C' : '?'}`;
                    if (ws.dayConfig) {
                        envInfo += ` 户外限制:${ws.dayConfig.outdoorTimeLimit || '?'}秒`;
                    }
                }
                if (this.difficulty) {
                    envInfo += ` | 难度:${this.difficulty.name || '?'}(${this.difficulty.stars || '?'})`;
                }
                this.aiModeLogger.log('DAY_SUMMARY', `第${this.dayCount}天开始${envInfo} | 存活${aliveNpcs.length}人 死亡${deadCount}人:\n${lines.join('\n')}`);
            }
            if (this.furnaceSystem && this.furnaceSystem.onDayChange) {
                this.furnaceSystem.onDayChange(this.dayCount);
            }
            if (this.taskSystem && this.taskSystem.onDayChange) {
                this.taskSystem.onDayChange(this.dayCount);
            }
            if (this.deathSystem && this.deathSystem.addMilestone) {
                this.deathSystem.addMilestone(`🌅 第${this.dayCount}天开始`);
            }
            if (this.bgmSystem && this.bgmSystem.onDayChange) {
                this.bgmSystem.onDayChange(this.dayCount);
            }

            // 【v4.33修复】每天日切换时自动触发晨会
            // 根因：之前只有D1有晨会，D2/D3/D4 NPC醒来后带着旧分工执行
            // 修复：每天开始时重置晨会标记并触发晨会
            this._openingCouncilDone = false;
            this._openingCouncilScheduled = false;
            this._scheduleOpeningCouncil();
        }

        // 淡入淡出
        if (this.fadeDirection !== 0) {
            this.fadeAlpha += this.fadeDirection * dt * 3;
            if (this.fadeAlpha >= 1) {
                this.fadeAlpha = 1;
                this.fadeDirection = -1;
                this.currentScene = this.nextScene;
                if (this.pendingFollowTarget) {
                    const npc = this.pendingFollowTarget;
                    const map = this.maps[this.currentScene];
                    this.camera.jumpTo(npc.x + GST.TILE / 2, npc.y + GST.TILE / 2, map.width * GST.TILE, map.height * GST.TILE);
                    this.pendingFollowTarget = null;
                }
            } else if (this.fadeAlpha <= 0) {
                this.fadeAlpha = 0;
                this.fadeDirection = 0;
            }
            // 淡入淡出期间仍然更新 NPC
        }

        // ============ 极寒生存系统更新 ============
        if (this.weatherSystem) this.weatherSystem.update(gameDt);
        if (this.resourceSystem) this.resourceSystem.update(gameDt);
        if (this.furnaceSystem) this.furnaceSystem.update(gameDt);
        if (this.machineSystem) this.machineSystem.update(gameDt);
        if (this.deathSystem) this.deathSystem.update(gameDt);
        if (this.taskSystem) this.taskSystem.update(gameDt);
        if (this.eventSystem) this.eventSystem.update(gameDt);
        if (this.aiModeLogger) this.aiModeLogger.update(gameDt);
        // bgmSystem.update() 已移到 loop() 中独立调用，不受暂停影响

        // 【v5.0】防御系统更新（在子系统之后、NPC之前）
        if (this.npcArbiter) this.npcArbiter.update(dt);
        // 【v5.3】决策冲突检测与解决（在NPC更新之后）
        if (this.decisionResolver) this.decisionResolver.update(gameDt);

        // 无线电求救系统已移除（v4.5）

        // NPC 更新（传入 gameDt 使饥饿、移动等都受倍速影响）
        for (const npc of this.npcs) {
            npc.update(gameDt, this);
        }

        // NPC 之间碰撞推挤 —— 防止重叠站在一起
        this._resolveNPCCollisions();

        // 【v5.0】Bug检测和日志更新（在NPC更新之后，确保状态是最新的）
        if (this.bugDetector) this.bugDetector.update(dt);
        if (this.structuredLogger) this.structuredLogger.update(dt);

        // ============ 全员入睡跳夜检测（必须在NPC update之后，确保isSleeping状态是最新的） ============
        this._checkNightSkip();

        // 对话更新
        this.dialogueManager.update(dt);

        // 摄像机
        const map = this.maps[this.currentScene];
        if (this.isAgentMode) {
            // AI/轮回 模式：自动跟随

            // 事件驱动锁定计时器递减
            if (this._cameraLockTimer > 0) {
                this._cameraLockTimer -= dt;
                if (this._cameraLockTimer <= 0) {
                    this._cameraLockTimer = 0;
                    this._cameraLockPriority = 0;
                }
            }

            // 死亡延迟切走计时器
            if (this._deathViewTimer > 0) {
                this._deathViewTimer -= dt;
                if (this._deathViewTimer <= 0) {
                    this._deathViewTimer = 0;
                    this._autoSwitchFollow();
                }
            }

            // 兜底轮询：锁定期间不触发
            this.followSwitchTimer += dt;
            if (this.followSwitchTimer >= this.followSwitchInterval && this.autoFollow && this._cameraLockTimer <= 0) {
                this.followSwitchTimer = 0;
                this._autoSwitchFollow();
            }

            if (this.followTarget) {
                if (this.followTarget.currentScene === this.currentScene) {
                    this.camera.followSmooth(
                        this.followTarget.x + GST.TILE / 2,
                        this.followTarget.y + GST.TILE / 2,
                        map.width * GST.TILE, map.height * GST.TILE, dt
                    );
                } else if (this.fadeDirection === 0) {
                    // 【修复】跟随目标已经切换了场景（进入/离开建筑），自动同步切换
                    this._switchScene(this.followTarget.currentScene, this.followTarget);
                }
            }
        } else {
            // Debug 模式：WASD 移动镜头
            let dx = 0, dy = 0;
            if (this.keys['w'] || this.keys['W'] || this.keys['ArrowUp'])    dy = -1;
            if (this.keys['s'] || this.keys['S'] || this.keys['ArrowDown'])  dy = 1;
            if (this.keys['a'] || this.keys['A'] || this.keys['ArrowLeft'])  dx = -1;
            if (this.keys['d'] || this.keys['D'] || this.keys['ArrowRight']) dx = 1;
            if (dx !== 0 || dy !== 0) {
                this.camera.moveBy(dx * this.debugCamSpeed * dt, dy * this.debugCamSpeed * dt,
                    map.width * GST.TILE, map.height * GST.TILE);
            }
        }

        // 更新侧边栏（每帧更新太频繁，降为 0.5s 一次）
        this._sidebarTimer = (this._sidebarTimer || 0) + dt;
        if (this._sidebarTimer >= 0.5) {
            this._sidebarTimer = 0;
            this._updateSidebar();
        }
    }
    // [已拆分到 game-time.js] _onHourChange
    // [已拆分到 game-time.js] _performDailySettlement
    // [已拆分到 game-time.js] _checkNightSkip
    // [已拆分到 game-time.js] _updateRainIntensity
    // [已拆分到 game-time.js] isRaining
    // [已拆分到 game-time.js] togglePause
    // [已拆分到 game-time.js] cycleSpeed
    // Debug 模式: 交互

    async reincarnate() {
        console.log('[Game] 🔄 轮回重生开始...');

        // 0.5 轮回结束前：记录本世完整摘要日志（用于复盘）
        if (this.aiModeLogger) {
            let reincLog = `第${this.reincarnationSystem ? this.reincarnationSystem.currentLifeNumber : '?'}世轮回结束 | 存活${this.npcs.filter(n => !n.isDead).length}/${this.npcs.length}人\n`;
            // 死亡记录
            if (this.deathSystem && this.deathSystem.deathRecords && this.deathSystem.deathRecords.length > 0) {
                reincLog += `  死亡记录:\n`;
                for (const r of this.deathSystem.deathRecords) {
                    reincLog += `    ${r.npcName} - ${r.cause} - D${r.dayNum} ${r.time}\n`;
                }
            }
            // 最终资源
            const rs = this.resourceSystem;
            if (rs) {
                reincLog += `  最终资源: 木柴:${rs.woodFuel != null ? rs.woodFuel.toFixed(1) : '?'} 食物:${rs.food != null ? rs.food.toFixed(1) : '?'} 电力:${rs.power != null ? rs.power.toFixed(1) : '?'}\n`;
            }
            // 所有NPC最终状态
            reincLog += `  NPC状态:\n`;
            for (const npc of this.npcs) {
                const snap = GST.AIModeLogger.npcAttrSnapshot(npc);
                reincLog += `    ${npc.name} | ${npc.isDead ? '已故' : '存活'} | ${snap}\n`;
            }
            this.aiModeLogger.log('REINCARNATE', reincLog);
        }

        // 0.8 轮回结束前：自动保存完整debug log
        if (this._saveDebugLogToServer) {
            this._saveDebugLogToServer(true);
        }

        // 1. 保存当前世的轮回记忆
        if (this.reincarnationSystem) {
            await this.reincarnationSystem.savePastLife();
        }

        // 1.5 刷盘AI模式日志并重建
        if (this.aiModeLogger) {
            this.aiModeLogger.forceFlush();
        }

        // 2. 清除自动保存的debug log定时器
        if (this._debugLogAutoSaveInterval) {
            clearInterval(this._debugLogAutoSaveInterval);
        }

        // 2.5 清除轮回模式相关的自动轮回定时器（防止泄漏）
        if (this._reincarnationCountdownTimer) {
            clearTimeout(this._reincarnationCountdownTimer);
            this._reincarnationCountdownTimer = null;
        }
        if (this._reincarnationCountdownInterval) {
            clearInterval(this._reincarnationCountdownInterval);
            this._reincarnationCountdownInterval = null;
        }

        // 3. 清除NPC详情面板刷新定时器
        if (this._detailRefreshTimer) {
            clearInterval(this._detailRefreshTimer);
            this._detailRefreshTimer = null;
        }
        this._currentDetailNPC = null;
        const detailOverlay = document.getElementById('npc-detail-overlay');
        if (detailOverlay) detailOverlay.style.display = 'none';

        // 4. 清除对话系统状态
        if (this.dialogueManager) {
            this.dialogueManager.npcChatQueue = [];
            this.dialogueManager.isProcessing = false;
            this.dialogueManager.activeDialogue = null;
            if (this.dialogueManager.panel) this.dialogueManager.panel.style.display = 'none';
            // 清空聊天记录面板
            if (this.dialogueManager.chatLogContent) this.dialogueManager.chatLogContent.innerHTML = '';
        }

        // 5. 移除结局遮罩
        const endingOverlay = document.getElementById('ending-overlay');
        if (endingOverlay) endingOverlay.remove();

        // 6. 重置游戏时间
        this.gameTimeSeconds = 8 * 3600; // 第1天 08:00
        this.dayCount = 1;
        this.paused = false;
        // 【修复】轮回后保持用户的速度档位，不再强制重置为x1
        // this.speedIdx = 0;  // 移除：保持当前速度
        this.weather = '晴天';
        this.rainDrops = [];
        this.rainIntensity = 0;
        this.autoSaveTimer = 0;
        this.followSwitchTimer = 0;
        this.currentScene = 'village';
        this.fadeAlpha = 0;
        this.fadeDirection = 0;
        this.nextScene = null;
        this.pendingFollowTarget = null;

        // 清空事件日志
        this.eventLog = [];
        this._renderEventLog();

        // 7. 重建所有子系统（最干净的重置方式）
this.weatherSystem = GST.WeatherSystem ? new GST.WeatherSystem(this) : null;
        // 【修复】重置时同步天气
        if (this.weatherSystem) {
            this.weather = this.weatherSystem.currentWeather;
        }
this.resourceSystem = GST.ResourceSystem ? new GST.ResourceSystem(this) : null;
this.furnaceSystem = GST.FurnaceSystem ? new GST.FurnaceSystem(this) : null;
this.machineSystem = GST.MachineSystem ? new GST.MachineSystem(this) : null;
this.deathSystem = GST.DeathSystem ? new GST.DeathSystem(this) : null;
this.taskSystem = GST.TaskSystem ? new GST.TaskSystem(this) : null;
this.eventSystem = GST.EventSystem ? new GST.EventSystem(this) : null;
this.councilSystem = GST.CouncilSystem ? new GST.CouncilSystem(this) : null;

        // 8. 重新初始化轮回系统（更新世数）
        if (this.reincarnationSystem) {
            this.reincarnationSystem.advanceLife();
        }

        // 8.5 重建AI模式日志系统（新会话文件）
this.aiModeLogger = (this.isAgentMode && GST.AIModeLogger) ? new GST.AIModeLogger(this) : null;

        // 9. 重新初始化NPC（从NPC_CONFIGS重新创建，但会在之后应用轮回加成）
        this.npcs = [];
        if (typeof GST.NPC_CONFIGS !== 'undefined') {
            for (const cfg of GST.NPC_CONFIGS) {
                this.npcs.push(new GST.NPC(cfg, this));
            }
        }

        // 9.5 【智能分工系统】轮回后重新生成workPlan
        this._initWorkPlan();

        // 10. 重新设置对话管理器的game引用
        if (this.dialogueManager) {
            this.dialogueManager.game = this;
            this.dialogueManager.aiRoundRobinIdx = 0;
            this.dialogueManager.aiTickTimer = 0;
        }

        // 11. 重建侧边栏Agent卡片
        const agentList = document.getElementById('agent-list');
        if (agentList) {
            agentList.innerHTML = '';
            for (const npc of this.npcs) {
                const card = document.createElement('div');
                card.className = 'agent-card';
                card.id = `agent-card-${npc.id}`;
                card.innerHTML = `
                    <div class="agent-card-header">
                        <span class="agent-dot" style="background:${npc.color}"></span>
                        <span class="agent-name">${npc.name}</span>
                        <span class="agent-mood" id="mood-${npc.id}">😊</span>
                    </div>
                    <div class="agent-status" id="status-${npc.id}">${npc.occupation} · ${npc.stateDesc}</div>
                    <div class="agent-attrs-mini" id="attrs-${npc.id}"></div>
                    <div class="agent-thought" id="thought-${npc.id}"></div>
                `;
                card.addEventListener('click', () => this._openNPCDetail(npc));
                agentList.appendChild(card);
            }
        }

        // 12. 重建NPC跟随选择列表
        const selTarget = document.getElementById('sel-follow-target');
        if (selTarget) {
            // 保留第一个"自动切换"选项，删除其余
            while (selTarget.options.length > 1) selTarget.options.remove(1);
            for (const npc of this.npcs) {
                const opt = document.createElement('option');
                opt.value = npc.id;
                opt.textContent = npc.name;
                selTarget.appendChild(opt);
            }
            selTarget.value = 'auto';
        }

        // 13. 设置初始跟随目标
        if (this.isAgentMode && this.npcs.length > 0) {
            this.followTarget = this.npcs[0];
            this.autoFollow = true;
        }

        // 14. 重置摄像机位置
        const map = this.maps[this.currentScene];
        this.camera.jumpTo(25 * GST.TILE, 20 * GST.TILE, map.width * GST.TILE, map.height * GST.TILE);

        // 15. 更新UI控件
        const btnPause = document.getElementById('btn-pause');
        if (btnPause) btnPause.textContent = '⏸️';
        // 【修复】速度按钮文字同步当前实际速度（轮回后保持原速度）
        const btnSpeed = document.getElementById('btn-speed');
        if (btnSpeed) btnSpeed.textContent = `${this.speedOptions[this.speedIdx]}×`;
        const btnFollow = document.getElementById('btn-follow');
        if (btnFollow) {
            btnFollow.classList.remove('active');
            btnFollow.textContent = GST.t('hud.follow_free');
        }

        // 16. 更新轮回世数显示
        this._updateReincarnationUI();

        // 17. 重新启动debug log自动保存
        this._debugLogAutoSaveInterval = setInterval(() => {
            this._saveDebugLogToServer(true);
        }, 5 * 60 * 1000);

        this._openingCouncilDone = false;
        this._openingCouncilScheduled = false;
        this._scheduleOpeningCouncil({ force: true });

        // 18. 立即保存新世代的初始状态（断点续玩支持：刷新后可继续）
        this.save();

        // 通知
        const lifeNum = this.reincarnationSystem ? this.reincarnationSystem.getLifeNumber() : 1;
        this.addEvent(GST.t('misc.reincarnation_start', { n: lifeNum }));
        this.addEvent(GST.t('misc.reincarnation_day1'));

        // 【开局资源随机提示】轮回后资源重新随机分配
        if (this.resourceSystem) {
            const rs = this.resourceSystem;
            const diffKey = this.difficulty ? this.difficulty.key : 'easy';
            const diffName = GST.t('difficulty.' + diffKey + '_name');
            this.addEvent(GST.t('misc.initial_resources', { diff: diffName, wood: Math.round(rs.woodFuel), food: Math.round(rs.food), power: Math.round(rs.power) }));
        }

        console.log(`[Game] 🔄 轮回重生完成！进入第${lifeNum}世`);
    }
    // [已拆分到 game-collision.js / game-save.js] autoSave
    // [已拆分到 game-collision.js / game-save.js] load
    /**
     * 获取存档摘要信息（用于启动页面显示，不实际加载）
     * @returns {Object|null} 存档摘要或null
     */
    static getSaveInfo() {
        try {
            const raw = localStorage.getItem('tihutown_save');
            if (!raw) return null;
            const d = JSON.parse(raw);
            // ver=2才是完整存档，ver=1是旧版不完整存档（不支持断点续玩）
            if (!d.ver || d.ver < 2) return null;
            const aliveCount = d.npcs ? d.npcs.filter(n => !n.isDead).length : '?';
            const totalCount = d.npcs ? d.npcs.length : 8;
            const h = Math.floor((d.time / 3600) % 24);
            const m = Math.floor((d.time / 60) % 60);
            const timeStr = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
            const savedDate = d.savedAt ? new Date(d.savedAt) : null;
            const savedStr = savedDate ? `${savedDate.getMonth()+1}/${savedDate.getDate()} ${savedDate.getHours()}:${String(savedDate.getMinutes()).padStart(2,'0')}` : '未知';
            return {
                mode: d.mode || 'unknown',
                day: d.day || 1,
                timeStr: timeStr,
                aliveCount: aliveCount,
                totalCount: totalCount,
                savedAt: savedStr,
                weather: d.weather || '晴天',
            };
        } catch (e) {
            return null;
        }
    }
    // [已拆分到 game-time.js] getTimeStr
    // [已拆分到 game-time.js] getHour
    // [已拆分到 game-time.js] getTimePeriod
    }

    GST.Game = Game;
})();
