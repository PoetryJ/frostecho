/**
 * 福音镇 - 指挥官系统 Mixin (路由层)
 * 
 * 架构说明：
 * - 本文件只保留通用逻辑骨架和语言路由
 * - 中文数据 → commander-data-zh.js (GST._commanderDataZh)
 * - 英文数据 → commander-data-en.js (GST._commanderDataEn)
 * - 切换语言时自动切换数据源，彻底解耦
 * 
 * 职责：指挥官UI、命令解析、NPC指令下发、LLM意图规划
 * 挂载到 GST.Game.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.Game.prototype;

    // ============ 语言路由 ============
    function _getLang() {
        const isEn = GST.i18n && GST.i18n.isEn && GST.i18n.isEn();
        return isEn ? GST._commanderDataEn : GST._commanderDataZh;
    }

    // 以下常量已迁移到 commander-data-zh.js / commander-data-en.js
    // COMMANDER_ALIAS_MAP, COMMANDER_NAME_MAP, COMMANDER_ROLE_EMOJI,
    // COMMANDER_TASK_LABELS, COMMANDER_TASK_DEFAULTS, COMMANDER_ACTION_PRESETS,
    // COMMANDER_LLM_INTENT_LIBRARY
    // 通过 _getLang() 动态获取

    // 向后兼容：保留旧常量名的 getter（供 input.js 等外部引用）
    // 注意：这些是动态的，会根据当前语言返回对应数据
    Object.defineProperty(GST, '_COMMANDER_ALIAS_MAP', { get: () => _getLang().ALIAS_MAP });
    Object.defineProperty(GST, '_COMMANDER_NAME_MAP', { get: () => _getLang().NAME_MAP });
    Object.defineProperty(GST, '_COMMANDER_TASK_LABELS', { get: () => _getLang().TASK_LABELS });
    Object.defineProperty(GST, '_COMMANDER_LLM_INTENT_LIBRARY', { get: () => _getLang().LLM_INTENT_LIBRARY });


    proto._escapeCommanderHtml = function(text) {
        return String(text || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    proto._getCommanderDisplayName = function(npc) {
        // 优先使用 i18n 翻译名
        if (npc && npc.displayName) return npc.displayName;
        return GST.i18n.translateNpcName(npc?.id) || npc?.name || npc?.id || GST.t('commander.fallback');
    }

    proto._syncPauseButtonState = function() {
        const btn = document.getElementById('btn-pause');
        if (btn) btn.textContent = this.paused ? '▶️' : '⏸️';
    }

    proto._ensureCommanderState = function() {
        if (typeof this.commandModeActive !== 'boolean') this.commandModeActive = false;
        if (!Array.isArray(this.commandHistory)) this.commandHistory = [];
        if (typeof this._commanderPauseWasPaused !== 'boolean') this._commanderPauseWasPaused = false;
        if (typeof this._commanderBusy !== 'boolean') this._commanderBusy = false;
        if (!this._commanderUI) this._createCommanderUI();
    }

    proto._createCommanderUI = function() {
        const overlay = document.createElement('div');
        overlay.id = 'commander-overlay';
        overlay.style.cssText = [
            'display:none',
            'position:fixed',
            'left:50%',
            'top:50%',
            'transform:translate(-50%, -50%)',
            'width:min(780px, calc(100vw - 32px))',
            'max-height:calc(100vh - 32px)',
            'overflow:hidden',
            'z-index:10020',
            'background:linear-gradient(180deg, rgba(10,18,28,0.97), rgba(6,10,18,0.94))',
            'border:1px solid rgba(120,190,255,0.28)',
            'border-radius:16px',
            'box-shadow:0 30px 80px rgba(0,0,0,0.45)',
            'backdrop-filter:blur(10px)',
            'color:#e6f4ff',
            'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif'
        ].join(';');
        overlay.innerHTML = `
            <div style="padding:18px 20px 14px;border-bottom:1px solid rgba(120,190,255,0.16);display:flex;align-items:center;justify-content:space-between;gap:12px;">
                <div>
                    <div style="font-size:20px;font-weight:700;letter-spacing:0.5px;">${GST.t('commander.title')}</div>
                    <div style="margin-top:6px;font-size:12px;color:rgba(214,234,255,0.72);">${GST.t('commander.hint')}</div>
                </div>
                <button id="commander-close" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);color:#fff;border-radius:10px;padding:8px 12px;cursor:pointer;">${GST.t('commander.btn_close')}</button>
            </div>
            <div style="display:grid;grid-template-columns:minmax(0,1.2fr) minmax(280px,0.8fr);gap:16px;padding:16px;align-items:start;">
                <div style="display:flex;flex-direction:column;gap:12px;min-width:0;">
                    <textarea id="commander-input" placeholder="${GST.t('commander.placeholder')}" style="min-height:180px;resize:vertical;background:rgba(255,255,255,0.06);border:1px solid rgba(120,190,255,0.18);border-radius:12px;padding:14px 16px;color:#f8fbff;font-size:14px;line-height:1.7;outline:none;"></textarea>
                    <div id="commander-feedback" style="min-height:22px;font-size:12px;color:#9ed0ff;"></div>
                    <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
                        <button id="commander-submit" style="background:linear-gradient(135deg,#4ea8ff,#5ce1e6);color:#07131f;border:none;border-radius:10px;padding:10px 16px;font-weight:700;cursor:pointer;">${GST.t('commander.btn_submit')}</button>
                        <button id="commander-keep-paused" style="background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.14);color:#e6f4ff;border-radius:10px;padding:10px 14px;cursor:pointer;">${GST.t('commander.btn_keep_paused')}</button>
                        <span style="font-size:12px;color:rgba(214,234,255,0.6);">${GST.t('commander.shortcut_hint')}</span>
                    </div>
                    <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(120,190,255,0.12);border-radius:12px;padding:12px;">
                        <div style="font-size:13px;font-weight:700;margin-bottom:8px;">${GST.t('commander.history_title')}</div>
                        <div id="commander-history" style="display:flex;flex-direction:column;gap:8px;max-height:220px;overflow:auto;"></div>
                    </div>
                </div>
                <div style="display:flex;flex-direction:column;gap:12px;min-width:0;">
                    <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(120,190,255,0.12);border-radius:12px;padding:12px;">
                        <div style="font-size:13px;font-weight:700;margin-bottom:8px;">${GST.t('commander.team_status')}</div>
                        <div id="commander-status" style="display:flex;flex-direction:column;gap:8px;max-height:470px;overflow:auto;"></div>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        const input = overlay.querySelector('#commander-input');
        const submitBtn = overlay.querySelector('#commander-submit');
        const keepPausedBtn = overlay.querySelector('#commander-keep-paused');
        const closeBtn = overlay.querySelector('#commander-close');
        const feedback = overlay.querySelector('#commander-feedback');
        const history = overlay.querySelector('#commander-history');
        const status = overlay.querySelector('#commander-status');

        closeBtn.addEventListener('click', () => {
            if (this._commanderBusy) return;
            this._closeCommandMode({ restorePreviousPause: true });
        });
        submitBtn.addEventListener('click', () => {
            if (this._commanderBusy) return;
            this._submitCommanderCommand({ keepPaused: false });
        });
        keepPausedBtn.addEventListener('click', () => {
            if (this._commanderBusy) return;
            this._submitCommanderCommand({ keepPaused: true });
        });
        input.addEventListener('keydown', e => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                if (this._commanderBusy) return;
                this._submitCommanderCommand({ keepPaused: false });
            } else if (e.key === 'Escape') {
                e.preventDefault();
                if (this._commanderBusy) return;
                this._closeCommandMode({ restorePreviousPause: true });
            }
        });

        this._commanderUI = { overlay, input, submitBtn, keepPausedBtn, closeBtn, feedback, history, status };
    }

    proto._getCommanderAliasesForNpc = function(npc) {
        const extras = _getLang().ALIAS_MAP[npc.id] || [];
        const aliases = [npc.name, npc.id, ...extras]
            .map(v => (v || '').trim())
            .filter(Boolean);
        return [...new Set(aliases)];
    }

    proto._getCommanderSubjects = function() {
        const lang = _getLang();
        const subjects = lang.ALL_ALIASES.map(alias => ({ type: 'all', alias }));
        for (const npc of this.npcs) {
            for (const alias of this._getCommanderAliasesForNpc(npc)) {
                subjects.push({ type: 'npc', alias, npc });
            }
        }
        return subjects;
    }

    proto._splitCommanderStatements = function(rawText) {
        const roughParts = String(rawText || '')
            .replace(/[；;！!？?]/g, '。')
            .split(/[。\n]+/)
            .map(part => part.trim())
            .filter(Boolean);

        const results = [];
        for (const part of roughParts) {
            const matches = [];
            for (const subject of this._getCommanderSubjects()) {
                const idx = part.indexOf(subject.alias);
                if (idx >= 0) matches.push({ ...subject, idx });
            }
            matches.sort((a, b) => a.idx - b.idx || b.alias.length - a.alias.length);

            const splitPoints = [];
            for (const match of matches) {
                const lastPoint = splitPoints[splitPoints.length - 1];
                if (lastPoint === match.idx) continue;
                if (match.idx > 0) splitPoints.push(match.idx);
            }

            if (!splitPoints.length) {
                results.push(part);
                continue;
            }

            let start = 0;
            for (const point of splitPoints) {
                if (point <= start) continue;
                const section = part.slice(start, point).trim().replace(/^，|^,/, '').trim();
                if (section) results.push(section);
                start = point;
            }
            const tail = part.slice(start).trim();
            if (tail) results.push(tail);
        }
        return results;
    }

    proto._resolveCommanderTargets = function(statement, allowFallbackAll) {
        const text = String(statement || '');
        const lang = _getLang();
        const liveNpcs = this.npcs.filter(npc => !npc.isDead);
        if (!liveNpcs.length) return [];

        if (new RegExp(lang.ALL_ALIASES.join('|')).test(text)) return liveNpcs;

        const targets = [];
        for (const npc of liveNpcs) {
            const matched = this._getCommanderAliasesForNpc(npc).some(alias => alias && text.includes(alias));
            if (matched) targets.push(npc);
        }
        if (targets.length) return targets;
        return allowFallbackAll ? liveNpcs : [];
    }

    proto._setCommanderBusy = function(isBusy, text) {
        this._ensureCommanderState();
        this._commanderBusy = !!isBusy;
        if (!this._commanderUI) return;

        const ui = this._commanderUI;
        if (ui.input) ui.input.disabled = !!isBusy;
        if (ui.submitBtn) ui.submitBtn.disabled = !!isBusy;
        if (ui.keepPausedBtn) ui.keepPausedBtn.disabled = !!isBusy;
        if (ui.closeBtn) ui.closeBtn.disabled = !!isBusy;

        if (ui.submitBtn) ui.submitBtn.style.opacity = isBusy ? '0.65' : '1';
        if (ui.keepPausedBtn) ui.keepPausedBtn.style.opacity = isBusy ? '0.65' : '1';
        if (ui.closeBtn) ui.closeBtn.style.opacity = isBusy ? '0.55' : '1';
        if (ui.submitBtn) ui.submitBtn.style.cursor = isBusy ? 'wait' : 'pointer';
        if (ui.keepPausedBtn) ui.keepPausedBtn.style.cursor = isBusy ? 'wait' : 'pointer';
        if (ui.closeBtn) ui.closeBtn.style.cursor = isBusy ? 'not-allowed' : 'pointer';

        if (typeof text === 'string') {
            ui.feedback.textContent = text;
        }
    }

    proto._analyzeCommanderQuestion = function(statement) {
        const rawText = String(statement || '').trim();
        const compactText = rawText.replace(/[\s，,、：:“”"\"\u2018\u2019'\u2019？?！!。\.]/g, '');
        const qp = _getLang().QUESTION_PATTERNS;
        const aboutGenerator = qp.aboutGenerator.test(compactText);
        const aboutLumberMill = qp.aboutLumberMill.test(compactText);
        const aboutFoodCollector = qp.aboutFoodCollector.test(compactText);
        const asksResources = qp.asksResources.test(compactText);
        const asksConditions = qp.asksConditions.test(compactText);
        const asksProgress = qp.asksProgress.test(compactText);
        const asksTeamStatus = qp.asksTeamStatus.test(compactText);
        const asksSelfStatus = qp.asksSelfStatus.test(compactText)
            || (!asksTeamStatus && !aboutGenerator && !aboutLumberMill && !aboutFoodCollector && qp.asksSelfStatusFallback.test(compactText));
        const isQuestion = qp.isQuestion.test(compactText);
        return {
            rawText,
            compactText,
            isQuestion,
            aboutGenerator,
            aboutLumberMill,
            aboutFoodCollector,
            asksResources,
            asksConditions,
            asksProgress,
            asksTeamStatus,
            asksSelfStatus,
            sharedTopic: asksTeamStatus || aboutGenerator || aboutLumberMill || aboutFoodCollector || asksResources,
        };
    }

    proto._resolveCommanderQuestionTargets = function(statement, allowFallbackSingle) {
        const targets = this._resolveCommanderTargets(statement, false);
        if (targets.length) return targets;
        if (!allowFallbackSingle) return [];

        const nearest = this._nearestNPCToCamera(999);
        if (nearest && !nearest.isDead) return [nearest];

        const fallback = this.npcs.find(npc => !npc.isDead);
        return fallback ? [fallback] : [];
    }

    proto._parseCommanderQuestion = function(statement, allowFallbackSingle) {
        const analysis = this._analyzeCommanderQuestion(statement);
        if (!analysis.isQuestion) return null;

        return {
            raw: statement,
            analysis,
            targets: this._resolveCommanderQuestionTargets(statement, allowFallbackSingle),
        };
    }

    proto._parseCommanderAction = function(statement) {
        const compactText = String(statement || '').replace(/[\s，,、：:“”"\"\u2018\u2019'\u2019]/g, '');
        for (const preset of _getLang().ACTION_PRESETS) {            if (preset.match(compactText)) {
                return { ...preset.action };
            }
        }
        return null;
    }

    proto._parseCommanderDirective = function(statement, allowFallbackAll) {
        const action = this._parseCommanderAction(statement);
        if (!action) return null;
        return {
            raw: statement,
            action,
            targets: this._resolveCommanderTargets(statement, allowFallbackAll),
        };
    }

    proto._getCommanderActiveDirectiveDesc = function(npc) {
        if (!npc) return '';
        const lang = _getLang();
        const T = lang.REPLY_TEMPLATES;

        if (npc._taskOverride && npc._taskOverride.isActive) {
            if (typeof npc._getTaskOverrideDesc === 'function') {
                const taskDesc = npc._getTaskOverrideDesc();
                if (taskDesc) return taskDesc;
            }
            if (npc._taskOverride.stateDesc) {
                return npc._taskOverrideReached
                    ? npc._taskOverride.stateDesc
                    : T.goingTo(npc._taskOverride.stateDesc);
            }
        }

        if (npc._resourceGatherOverride && npc._resourceGatherTarget) {
            const gatherDesc = lang.GATHER_NAMES[npc._resourceGatherType] || lang.GATHER_DEFAULT;
            return T.goingTo(gatherDesc);
        }
        if (npc._actionOverride && npc._currentAction) {
            return npc._currentAction.reason || npc.stateDesc || npc._currentAction.type || '';
        }

        return '';
    }

    proto._normalizeCommanderReplyText = function(text) {
        const cleaned = String(text || '').trim();
        if (!cleaned) return '';
        const T = _getLang().REPLY_TEMPLATES;
        if (T.commanderPrefixRegex.test(cleaned)) {
            return cleaned.replace(T.commanderPrefixRegex, T.commanderPrefixNormalize);
        }
        return `${T.commanderPrefixNormalize}${cleaned.replace(/^，+/, '')}`;
    }

    proto._getCommanderWorldSummaryForLLM = function() {
        const lines = [];
        const lang = _getLang();
        const labels = lang.buildWorldSummaryLabels();
        const timeStr = typeof this.getTimeStr === 'function' ? this.getTimeStr() : '';
        const period = typeof this.getTimePeriod === 'function' ? this.getTimePeriod() : '';
        const header = labels.timeHeader(this.dayCount, timeStr, period).replace(/\s+/g, ' ').trim();
        if (header) lines.push(header);

        if (this.weatherSystem && typeof this.weatherSystem.getWeatherStr === 'function') {
            lines.push(labels.weather(this.weatherSystem.getWeatherStr()));
        } else if (this.weather) {
            lines.push(labels.weather(this.weather));
        }

        if (this.weatherSystem && typeof this.weatherSystem.getSurvivalSummary === 'function') {
            lines.push(labels.survival(this.weatherSystem.getSurvivalSummary()));
        }
        if (this.weatherSystem && typeof this.weatherSystem.getBlizzardUrgencyForPrompt === 'function') {
            const urgency = this.weatherSystem.getBlizzardUrgencyForPrompt();
            if (urgency) lines.push(urgency);
        }
        if (this.resourceSystem && typeof this.resourceSystem.getResourceStatusForPrompt === 'function') {
            lines.push(labels.resources(this.resourceSystem.getResourceStatusForPrompt()));
        }
        if (this.taskSystem && typeof this.taskSystem.getTaskSummaryForPrompt === 'function') {
            lines.push(labels.taskSummary(this.taskSystem.getTaskSummaryForPrompt()));
        }
        if (this.machineSystem && typeof this.machineSystem.getMachineStatusForPrompt === 'function') {
            lines.push(labels.facilities(this.machineSystem.getMachineStatusForPrompt()));
        }
        if (this.deathSystem && typeof this.deathSystem.getDeathSummaryForPrompt === 'function') {
            const deathSummary = this.deathSystem.getDeathSummaryForPrompt();
            if (deathSummary) lines.push(labels.death(deathSummary));
        }

        const aliveSummary = this.npcs
            .filter(npc => !npc.isDead)
            .map(npc => {
                const scene = typeof npc.getSceneLabel === 'function' ? npc.getSceneLabel() : (npc.currentScene || labels.unknownScene || '');
                const currentTask = this._getCommanderDisplayTaskForNpc(npc);
                const bodyTemp = Number.isFinite(npc.bodyTemp) ? npc.bodyTemp.toFixed(1) : '?';
                return labels.npcStatus(npc.id, this._getCommanderDisplayName(npc), scene, currentTask, npc.stamina || 0, npc.health || 0, npc.sanity || 0, npc.hunger || 0, bodyTemp);
            });
        if (aliveSummary.length) {
            lines.push(labels.aliveHeader + aliveSummary.join('；'));
        }

        return lines.filter(Boolean).join('\n');
    }

    proto._getCommanderPlannerIntentCatalog = function() {
        const lang = _getLang();
        return Object.entries(lang.LLM_INTENT_LIBRARY)
            .map(([key, action]) => lang.formatIntentCatalogEntry(key, action))
            .join('\n');
    }

    proto._resolveCommanderPlanTargets = function(targetSpecs, statement, allowFallbackSingle, isQuestion) {
        const liveNpcs = this.npcs.filter(npc => !npc.isDead);
        if (!liveNpcs.length) return [];

        const fallbackTargets = isQuestion
            ? this._resolveCommanderQuestionTargets(statement, allowFallbackSingle)
            : this._resolveCommanderTargets(statement, allowFallbackSingle);

        if (!Array.isArray(targetSpecs) || !targetSpecs.length) {
            return fallbackTargets;
        }

        const normalizedSpecs = targetSpecs
            .map(spec => String(spec || '').trim())
            .filter(Boolean);
        if (!normalizedSpecs.length) return fallbackTargets;

        if (normalizedSpecs.some(spec => {
            const allAliases = _getLang().ALL_ALIASES;
            return /^(all|ALL)$/.test(spec) || allAliases.some(a => a === spec);
        })) {
            return liveNpcs;
        }

        const results = [];
        for (const spec of normalizedSpecs) {
            for (const npc of liveNpcs) {
                const aliases = [
                    npc.id,
                    npc.name,
                    this._getCommanderDisplayName(npc),
                    ...this._getCommanderAliasesForNpc(npc),
                ].filter(Boolean);
                const matched = aliases.some(alias => alias === spec || alias.includes(spec) || spec.includes(alias));
                if (matched) {
                    if (!results.includes(npc)) results.push(npc);
                    break;
                }
            }
        }

        return results.length ? results : fallbackTargets;
    }

    proto._normalizeCommanderPlanAction = function(plan) {
        if (!plan || typeof plan !== 'object') return null;

        const key = String(plan.intentKey || plan.actionKey || '').trim().toUpperCase();
        const intentLib = _getLang().LLM_INTENT_LIBRARY;
        if (key && intentLib[key]) {
            const preset = intentLib[key];
            const customReason = String(plan.reason || '').trim();
            return {
                ...preset,
                reason: customReason || preset.reason,
                displayDesc: customReason || preset.reason,
            };
        }

        const rawAction = plan.action && typeof plan.action === 'object' ? plan.action : null;
        if (!rawAction) return null;

        const type = String(rawAction.type || '').trim();
        if (!GST.NPC.ACTION_TYPES || !GST.NPC.ACTION_TYPES.includes(type)) return null;

        const action = {
            type,
            target: rawAction.target || null,
            reason: String(rawAction.reason || plan.reason || '').trim() || _getLang().REPLY_TEMPLATES.defaultAction,
            priority: 'normal',
        };

        const priority = String(rawAction.priority || '').trim();
        if (priority === 'urgent' || priority === 'normal' || priority === 'low') {
            action.priority = priority;
        } else if (type === 'rest' || type === 'eat') {
            action.priority = 'urgent';
        }

        if (rawAction.companion) action.companion = rawAction.companion;
        if (action.target && GST.NPC.ACTION_TARGETS && !GST.NPC.ACTION_TARGETS[action.target]) {
        if (!['rest'].includes(type)) {
                return null;
            }
        }
        return action;
    }

    proto._planCommanderStatementWithLLM = async function(statement, allowFallbackSingle) {
        if (!GST || typeof GST.parseLLMJSON !== 'function') return null;
        const callLLM = typeof GST.callLLMDirect === 'function' ? GST.callLLMDirect : GST.callLLM;
        if (typeof callLLM !== 'function') return null;

        const lang = _getLang();
        const liveNpcs = this.npcs.filter(npc => !npc.isDead);
        if (!liveNpcs.length) return null;

        const npcCatalog = liveNpcs.map(npc => {
            const aliases = this._getCommanderAliasesForNpc(npc).join('/');
            return lang.formatNpcCatalogEntry(npc, this._getCommanderDisplayName(npc), aliases);
        }).join('\n');

        const fallbackHint = lang.buildFallbackHint(allowFallbackSingle);
        const systemPrompt = lang.buildPlannerSystemPrompt();
        const userPrompt = lang.buildPlannerUserPrompt(
            this._getCommanderWorldSummaryForLLM(),
            npcCatalog,
            this._getCommanderPlannerIntentCatalog(),
            statement,
            fallbackHint
        );
        try {
            const raw = await callLLM(systemPrompt, userPrompt, 700);
            const parsed = GST.parseLLMJSON(raw);
            if (parsed && typeof parsed === 'object') return parsed;

            // JSON 解析失败但 LLM 有返回内容 → 直接把原始文本当作角色回复
            // LLM 已经"想"了，不能丢弃它的思考结果
            if (raw && typeof raw === 'string' && raw.trim().length > 2) {
                let replyText = raw.trim();
                // 清理可能的 markdown/json 残留标记
                replyText = replyText.replace(/```json|```/g, '').replace(/^\{[\s\S]*$/, '').trim();
                // 清理 <think>...</think> 思考标签
                replyText = replyText.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
                if (replyText.length > 2) {
                    // 截取合理长度，避免过长
                    if (replyText.length > 200) replyText = replyText.slice(0, 200) + '……';
                    console.log('[CommanderLLM] JSON解析失败，使用LLM原始文本作为角色回复:', replyText.slice(0, 80));
                    return { kind: 'refuse', targets: ['all'], replyMode: 'single', reply: replyText };
                }
            }
            return null;
        } catch (err) {
            console.warn('[CommanderLLM] 解析指挥语句失败:', err);
            return null;
        }
    }

    proto._getCommanderResourceReply = function() {
        const rs = this.resourceSystem;
        const T = _getLang().REPLY_TEMPLATES;
        if (!rs) return T.noResourceAccess;

        const formatRemain = value => {
            if (!Number.isFinite(value) || value >= 999) return '∞';
            return String(Math.max(0, Math.round(value)));
        };

        const woodHours = typeof rs.getWoodFuelHoursRemaining === 'function' ? rs.getWoodFuelHoursRemaining() : 0;
        const foodMeals = typeof rs.getFoodMealsRemaining === 'function' ? rs.getFoodMealsRemaining() : 0;
        const powerHours = typeof rs.getPowerHoursRemaining === 'function' ? rs.getPowerHoursRemaining() : 0;

        let reply = T.resourceReply(Math.round(rs.woodFuel || 0), formatRemain(woodHours), Math.round(rs.food || 0), formatRemain(foodMeals), Math.round(rs.power || 0), formatRemain(powerHours));
        if (typeof rs.hasAnyCrisis === 'function' && rs.hasAnyCrisis()) {
            const crisis = [];
            if (rs.crisisFlags?.noFood) crisis.push(T.crisisLabels.noFood);
            if (rs.crisisFlags?.noPower) crisis.push(T.crisisLabels.noPower);
            if (rs.crisisFlags?.noWoodFuel) crisis.push(T.crisisLabels.noWoodFuel);
            if (crisis.length) {
                reply += T.crisisWarning(crisis.join('、'));
            }
        }
        return `${reply}。`;
    }

    proto._getCommanderNpcTaskReply = function(npc) {
        if (!npc) return _getLang().REPLY_TEMPLATES.noTaskAccess;
        const T = _getLang().REPLY_TEMPLATES;

        const activeDirectiveDesc = this._getCommanderActiveDirectiveDesc(npc);
        if (activeDirectiveDesc) {
            if (/建造发电机|Building Generator/i.test(activeDirectiveDesc) && this.machineSystem && typeof this.machineSystem.getMachineDetail === 'function') {
                const detail = this.machineSystem.getMachineDetail('generator');
                if (detail?.built) return T.directiveAlreadyBuilt(detail.name);
                if (detail?.building) return T.myTask(activeDirectiveDesc) + T.buildProgress(detail.buildProgressPercent) + '.';
            }
            if (/建造伐木机|Building Lumber/i.test(activeDirectiveDesc) && this.machineSystem && typeof this.machineSystem.getMachineDetail === 'function') {
                const detail = this.machineSystem.getMachineDetail('lumberMill');
                if (detail?.built) return T.directiveAlreadyBuilt(detail.name);
                if (detail?.building) return T.myTask(activeDirectiveDesc) + T.buildProgress(detail.buildProgressPercent) + '.';
            }
            return T.currentState(activeDirectiveDesc);
        }

        const taskSystem = this.taskSystem;
        const task = taskSystem && typeof taskSystem.getNpcTask === 'function'
            ? taskSystem.getNpcTask(npc.id)
            : null;
        const state = taskSystem?.npcTaskState ? taskSystem.npcTaskState[npc.id] : null;

        if (task) {
            const label = _getLang().TASK_LABELS[task.type] || task.name || task.type || T.defaultTaskLabel;
            let reply = T.myTask(label);

            if (task.type === 'BUILD_GENERATOR' || task.type === 'BUILD_LUMBER_MILL') {
                const machineType = task.type === 'BUILD_GENERATOR' ? 'generator' : 'lumberMill';
                const detail = this.machineSystem && typeof this.machineSystem.getMachineDetail === 'function'
                    ? this.machineSystem.getMachineDetail(machineType)
                    : null;
                if (detail?.built) {
                    reply += T.alreadyBuilt;
                } else if (detail?.building) {
                    reply += T.buildProgress(detail.buildProgressPercent);
                    if (detail.buildPaused) reply += T.buildPaused;
                } else if (detail) {
                    reply += T.notStarted;
                }
            } else if (task.status === 'completed') {
                reply += T.taskCompleted;
            } else if (state && state.paused) {
                reply += T.taskPaused(state.pauseReason);
            } else if (task.target > 0) {
                const pct = Math.max(0, Math.min(100, Math.round((task.progress / task.target) * 100)));
                reply += T.taskProgress(pct);
            }

            const stateDesc = npc.stateDesc || npc._currentAction?.reason || '';
            if (stateDesc && !reply.includes(stateDesc)) {
                reply += T.currentlyDoing(stateDesc);
            }
            return `${reply}。`;
        }

        const stateDesc = npc.stateDesc || npc._currentAction?.reason || npc.state || T.defaultStandby;
        return T.currentState(stateDesc);
    }

    proto._getCommanderTeamSummaryReply = function() {
        const living = this.npcs.filter(npc => !npc.isDead);
        const T = _getLang().REPLY_TEMPLATES;
        if (!living.length) return T.noSurvivors;

        const summary = living.map(npc => {
            const name = this._getCommanderDisplayName(npc);
            const task = this._getCommanderDisplayTaskForNpc(npc);
            return T.npcDoing(name, task);
        });
        return T.teamSummary(summary.join('；'));
    }

    proto._formatCommanderMachineReply = function(machineType, analysis) {
        const detail = this.machineSystem && typeof this.machineSystem.getMachineDetail === 'function'
            ? this.machineSystem.getMachineDetail(machineType)
            : null;
        if (!detail) return '';

        const T = _getLang().REPLY_TEMPLATES;
        const parts = [];

        if (detail.built) {
            let status = T.machineBuilt(detail.name, detail.running);
            status += T.machineOutput(detail.outputLabel, detail.outputPerHour, detail.consumeLabel, detail.consumePerHour);
            if (!detail.running) {
                status += T.machineRunReq(detail.runtimeRequirement.label, detail.runtimeRequirement.current);
            }
            parts.push(status);

            if (analysis.asksConditions) {
                parts.push(T.machineBuildReq(detail.buildWoodCost, detail.buildMaterialCost, detail.buildMinWorkers, detail.buildTimeHours));
            }
            if (analysis.asksProgress || analysis.asksConditions) {
                parts.push(T.machineTotalOutput(detail.totalProduced, detail.outputLabel, detail.totalConsumed, detail.consumeLabel));
            }
        } else if (detail.building) {
            let status = T.machineBuilding(detail.name, detail.buildProgressPercent);
            if (detail.buildWorkers.length) {
                status += T.machineWorkers(detail.buildWorkers.join('、'));
            }
            if (detail.buildPaused) {
                status += T.machineBuildPausedNote;
            }
            parts.push(status);
            parts.push(T.machineBuildCost(detail.buildWoodCost, detail.buildMaterialCost, detail.buildMinWorkers, detail.buildTimeHours));
        } else {
            const unmet = detail.unlockMissing.length
                ? T.machineUnlockMissing(detail.unlockMissing.join('，'))
                : T.machineUnlockReady;
            parts.push(T.machineNotStarted(detail.name, unmet));
            parts.push(T.machineBuildCost(detail.buildWoodCost, detail.buildMaterialCost, detail.buildMinWorkers, detail.buildTimeHours));
        }

        return parts
            .filter(Boolean)
            .map(text => String(text).replace(/。+$/g, ''))
            .join('。') + '。';
    }

    proto._buildCommanderQuestionReply = function(npc, question) {
        if (!npc || !question || !question.analysis) return '';
        const T = _getLang().REPLY_TEMPLATES;

        const { analysis } = question;
        if (analysis.asksTeamStatus) {
            return `${T.commanderPrefix}${this._getCommanderTeamSummaryReply()}`;
        }

        const parts = [];
        if (analysis.aboutGenerator) {
            parts.push(this._formatCommanderMachineReply('generator', analysis));
        }
        if (analysis.aboutLumberMill) {
            parts.push(this._formatCommanderMachineReply('lumberMill', analysis));
        }
        if (analysis.aboutFoodCollector) {
            parts.push(this._formatCommanderMachineReply('foodCollector', analysis));
        }

        if (analysis.asksResources && !analysis.aboutGenerator && !analysis.aboutLumberMill && !analysis.aboutFoodCollector) {
            parts.push(this._getCommanderResourceReply());
        }

        if ((analysis.aboutGenerator || analysis.aboutLumberMill || analysis.aboutFoodCollector) && (analysis.asksConditions || analysis.asksResources || analysis.asksProgress)) {
            parts.push(this._getCommanderResourceReply());
        }

        if (analysis.asksSelfStatus || !parts.length) {
            parts.push(this._getCommanderNpcTaskReply(npc));
        }

        const merged = parts
            .filter(Boolean)
            .map(text => String(text).trim())
            .join('');

        return merged ? `${T.commanderPrefix}${merged}` : '';
    }

    proto._buildCommanderDirectiveReply = function(npc, directive) {
        if (!npc || !directive || !directive.action) return '';
        const T = _getLang().REPLY_TEMPLATES;

        const action = directive.action;
        const baseReason = String(action.reason || action.stateDesc || T.defaultAction).replace(/。+$/g, '');

        if (action.mode === 'task_system' && (action.taskType === 'BUILD_GENERATOR' || action.taskType === 'BUILD_LUMBER_MILL')) {
            const machineType = action.taskType === 'BUILD_GENERATOR' ? 'generator' : 'lumberMill';
            const detail = this.machineSystem && typeof this.machineSystem.getMachineDetail === 'function'
                ? this.machineSystem.getMachineDetail(machineType)
                : null;

            if (detail) {
                if (detail.built) {
                    return T.directiveAlreadyBuilt(detail.name);
                }

                if (detail.building) {
                    let reply = T.directiveJoinBuild(detail.name, detail.buildProgressPercent);
                    if (detail.buildWorkers.length) {
                        reply += T.directiveCurrentWorkers(detail.buildWorkers.join('、'));
                    }
                    if (detail.buildPaused) {
                        reply += T.directiveBuildPaused;
                    }
                    return `${reply}。`;
                }

                if (detail.unlockMissing.length) {
                    return T.directiveUnlockMissing(baseReason, detail.unlockMissing.join('，'));
                }

                return T.directiveUnlockReady(baseReason);
            }
        }

        return T.directiveAck(baseReason);
    }

    proto._snapshotCommanderReplaceableContext = function(npc) {
        if (!npc) return null;

        const cloneAction = action => (action ? { ...action } : null);
        const cloneIntent = intent => intent ? {
            ...intent,
            action: cloneAction(intent.action),
            metadata: intent.metadata ? { ...intent.metadata } : null,
        } : null;

        return {
            taskOverride: npc._taskOverride ? { ...npc._taskOverride } : null,
            taskOverrideReached: !!npc._taskOverrideReached,
            taskOverrideStuckTimer: npc._taskOverrideStuckTimer || 0,
            taskOverrideTravelTimer: npc._taskOverrideTravelTimer || 0,
            resourceGatherOverride: !!npc._resourceGatherOverride,
            resourceGatherTarget: npc._resourceGatherTarget || null,
            resourceGatherType: npc._resourceGatherType || null,
            resourceGatherTravelTimer: npc._resourceGatherTravelTimer || 0,
            resourceGatherCooldown: npc._resourceGatherCooldown || 0,
            councilTask: npc._councilTask || null,
            councilTaskTime: npc._councilTaskTime || null,
            councilStateDesc: npc._councilStateDesc || null,
            currentIntent: cloneIntent(npc._currentIntent),
            pendingIntent: cloneIntent(npc._pendingIntent),
            pendingAction: cloneAction(npc._pendingAction),
            currentAction: cloneAction(npc._currentAction),
            actionOverride: !!npc._actionOverride,
            actionTarget: npc._actionTarget ? { ...npc._actionTarget } : null,
            actionStuckTimer: npc._actionStuckTimer || 0,
            actionTravelTimer: npc._actionTravelTimer || 0,
            stateDesc: npc.stateDesc || '',
            scheduleReached: !!npc.scheduleReached,
            activeOverride: npc._activeOverride || 'none',
        };
    }

    proto._restoreCommanderReplaceableContext = function(npc, snapshot) {
        if (!npc || !snapshot) return;

        const cloneAction = action => (action ? { ...action } : null);
        const cloneIntent = intent => intent ? {
            ...intent,
            action: cloneAction(intent.action),
            metadata: intent.metadata ? { ...intent.metadata } : null,
        } : null;

        if (snapshot.taskOverride) {
            npc._taskOverride = { ...npc._taskOverride, ...snapshot.taskOverride };
        }
        npc._taskOverrideReached = snapshot.taskOverrideReached;
        npc._taskOverrideStuckTimer = snapshot.taskOverrideStuckTimer;
        npc._taskOverrideTravelTimer = snapshot.taskOverrideTravelTimer;
        npc._resourceGatherOverride = snapshot.resourceGatherOverride;
        npc._resourceGatherTarget = snapshot.resourceGatherTarget;
        npc._resourceGatherType = snapshot.resourceGatherType;
        npc._resourceGatherTravelTimer = snapshot.resourceGatherTravelTimer;
        npc._resourceGatherCooldown = snapshot.resourceGatherCooldown;
        npc._councilTask = snapshot.councilTask;
        npc._councilTaskTime = snapshot.councilTaskTime;
        npc._councilStateDesc = snapshot.councilStateDesc;
        npc._currentIntent = cloneIntent(snapshot.currentIntent);
        npc._pendingIntent = cloneIntent(snapshot.pendingIntent);
        npc._pendingAction = cloneAction(snapshot.pendingAction);
        npc._currentAction = cloneAction(snapshot.currentAction);
        npc._actionOverride = snapshot.actionOverride;
        npc._actionTarget = snapshot.actionTarget ? { ...snapshot.actionTarget } : null;
        npc._actionStuckTimer = snapshot.actionStuckTimer;
        npc._actionTravelTimer = snapshot.actionTravelTimer;
        npc.stateDesc = snapshot.stateDesc;
        npc.scheduleReached = snapshot.scheduleReached;
        npc._activeOverride = snapshot.activeOverride;
        if (typeof npc._refreshBehaviorControl === 'function') npc._refreshBehaviorControl();
    }

    proto._clearCommanderRuntimeContext = function(npc) {
        if (!npc) return;
        npc._resourceGatherOverride = false;
        npc._resourceGatherTarget = null;
        npc._resourceGatherType = null;
        npc._resourceGatherTravelTimer = 0;
        npc._resourceGatherCooldown = 0;
        npc._councilTask = null;
        npc._councilTaskTime = null;
        npc._councilStateDesc = null;
        if (typeof npc._refreshBehaviorControl === 'function') npc._refreshBehaviorControl();
    }

    proto._clearCommanderConflictingOverrides = function(npc) {
        if (!npc) return;
        if (typeof npc._clearActionOverride === 'function') npc._clearActionOverride();
        this._clearCommanderRuntimeContext(npc);
    }

    proto._clearNpcDirectiveContext = function(npc) {
        if (!npc) return;
        if (typeof npc.deactivateTaskOverride === 'function') npc.deactivateTaskOverride();
        if (typeof npc._clearActionOverride === 'function') npc._clearActionOverride();
        npc._councilTask = null;
        npc._councilTaskTime = null;
        npc._councilStateDesc = null;
    }

    proto._removeCommanderTaskForNpc = function(npc) {
        const taskSystem = this.taskSystem;
        if (!taskSystem || !npc) return;

        const assignedTaskId = taskSystem.npcAssignments ? taskSystem.npcAssignments[npc.id] : null;
        if (assignedTaskId) {
            const taskIndex = taskSystem.dailyTasks
                ? taskSystem.dailyTasks.findIndex(task => task.id === assignedTaskId)
                : -1;
            if (taskIndex >= 0) {
                const assignedTask = taskSystem.dailyTasks[taskIndex];
                if (assignedTask && assignedTask.id && assignedTask.id.startsWith('commander_') && assignedTask.status !== 'completed') {
                    taskSystem.dailyTasks.splice(taskIndex, 1);
                }
            }
            delete taskSystem.npcAssignments[npc.id];
        }

        if (taskSystem.npcTaskState && taskSystem.npcTaskState[npc.id]) {
            delete taskSystem.npcTaskState[npc.id];
        }
    }

    proto._createCommanderTaskForNpc = function(npc, action, rawText) {
        const taskSystem = this.taskSystem;
        if (!taskSystem || !npc || !action || !action.taskType) return null;

        this._removeCommanderTaskForNpc(npc);

        const taskId = `commander_${action.taskType}_${npc.id}_${++taskSystem.taskIdCounter}`;
        const task = {
            id: taskId,
            type: action.taskType,
            name: action.reason,
            desc: rawText,
            target: action.targetValue || 1,
            progress: 0,
            assignedNpcId: npc.id,
            status: 'pending',
            priority: action.priority || 'urgent',
            isOutdoor: !!(action.targetLocation && !String(action.targetLocation).endsWith('_door') && action.targetLocation !== 'furnace_plaza'),
            startTime: null,
            completedTime: null,
            isCommanderTask: true,
            commanderRawText: rawText,
        };

        taskSystem.dailyTasks.push(task);
        taskSystem.npcAssignments[npc.id] = taskId;
        if (taskSystem.npcTaskState && taskSystem.npcTaskState[npc.id]) {
            delete taskSystem.npcTaskState[npc.id];
        }

        return task;
    }

    proto._applyCommanderTaskDirective = function(npc, directive) {
        const action = directive.action;
        if (!npc || !action || !action.targetLocation) {
            return false;
        }

        const control = typeof npc._refreshBehaviorControl === 'function'
            ? npc._refreshBehaviorControl()
            : null;
            if (control && (control.owner === 'priority' || control.owner === 'state' || control.owner === 'hunger')) {
                const T = _getLang().REPLY_TEMPLATES;
                // 【v4.22修复】指挥官urgent命令可以唤醒睡觉中的NPC
                const isUrgentCommand = action.priority === 'urgent' || action.issuedByPlayer;
                if (isUrgentCommand && control.owner === 'state' && npc.isSleeping) {
                    console.log(`[指挥官命令] ${npc.name} sleeping, urgent command wakes up`);
                    npc.isSleeping = false;
                    npc._forcedSleep = false;
                    npc._forcedSleepTimer = 0;
                    npc.state = 'IDLE';
                    npc.stateDesc = action.stateDesc || action.reason || T.defaultAction;            } else {
                return false;
            }
        }

        const snapshot = this._snapshotCommanderReplaceableContext(npc);
        if (snapshot?.taskOverride?.isActive && typeof npc.deactivateTaskOverride === 'function') {
            npc.deactivateTaskOverride();
        }
        this._clearCommanderConflictingOverrides(npc);

        const taskLabel = action.taskType || action.stateDesc || action.targetLocation || 'task';
        const taskId = `commander_${taskLabel}_${npc.id}_${Date.now()}`;

        let applied = false;
        if (typeof npc._submitExternalIntent === 'function') {
            applied = npc._submitExternalIntent({
                source: 'commander',
                taskId,
                targetLocation: action.targetLocation,
                priority: action.priority || 'high',
                resourceType: action.resourceType || null,
                    stateDesc: action.stateDesc || action.reason,
                    displayDesc: action.reason || action.stateDesc || _getLang().REPLY_TEMPLATES.defaultAction,
                effectKey: action.effectKey || null,
            });
        } else if (typeof npc.activateTaskOverride === 'function') {
            applied = npc.activateTaskOverride(
                taskId,
                action.targetLocation,
                action.priority || 'high',
                action.resourceType || null,
                action.stateDesc || action.reason,
                {
                    source: 'commander',
                    displayDesc: action.reason || action.stateDesc || '执行任务',
                    effectKey: action.effectKey || null,
                    intentId: null,
                }
            );
        }

        if (!applied) {
            this._restoreCommanderReplaceableContext(npc, snapshot);
            return false;
        }

        this._removeCommanderTaskForNpc(npc);
        npc._actionDecisionCooldown = 0;
        return true;
    }

    proto._applyCommanderDirectiveToNpc = function(npc, directive) {
        if (!npc || npc.isDead || !directive || !directive.action) return false;

        let action = {
            ...directive.action,
            priority: directive.action.priority || 'urgent',
            reason: directive.action.reason || directive.action.stateDesc || _getLang().REPLY_TEMPLATES.defaultAction,
            issuedByPlayer: true,
        };

        if (action.mode === 'task_system') {
            // already task_system, no conversion needed
        } else {
            const intentLib = _getLang().LLM_INTENT_LIBRARY;
            if (action.type === 'go_to' && action.target === 'ore_pile') {
                action = { ...intentLib.MINE_POWER };
            } else if (action.type === 'go_to' && action.target === 'warehouse_door') {
                action = { ...intentLib.WAREHOUSE };
            }
        }

        let applied = false;
        if (action.mode === 'task_system') {
            applied = this._applyCommanderTaskDirective(npc, { ...directive, action });
        } else {
            const control = typeof npc._refreshBehaviorControl === 'function'
                ? npc._refreshBehaviorControl()
                : null;
            if (control && (control.owner === 'priority' || control.owner === 'state' || control.owner === 'hunger')) {
                // 【v4.22修复】指挥官urgent命令可以唤醒睡觉中的NPC
                const isUrgentCommand = action.priority === 'urgent' || action.issuedByPlayer;
                if (isUrgentCommand && control.owner === 'state' && npc.isSleeping) {
                    console.log(`[指挥官命令] ${npc.name} sleeping, urgent command wakes up`);
                    npc.isSleeping = false;
                    npc._forcedSleep = false;
                    npc._forcedSleepTimer = 0;
                    npc.state = 'IDLE';
                    npc.stateDesc = action.reason || _getLang().REPLY_TEMPLATES.defaultAction;
                } else {
                    return false;
                }
            }

            const snapshot = this._snapshotCommanderReplaceableContext(npc);
            if (snapshot?.taskOverride?.isActive && typeof npc.deactivateTaskOverride === 'function') {
                npc.deactivateTaskOverride();
            }
            this._clearCommanderRuntimeContext(npc);

            if (typeof npc._createIntentFromAction === 'function' && typeof npc._submitIntent === 'function') {
                const intent = npc._createIntentFromAction(action, {
                    source: 'commander',
                    category: 'action',
                    reasoning: directive.raw,
                });
                const result = npc._submitIntent(intent, this);
                applied = result === 'execute';
                if (!applied) {
                    npc._pendingIntent = null;
                    npc._pendingAction = null;
                }
            } else if (typeof npc._executeAction === 'function') {
                npc._executeAction(action, this);
                applied = true;
            }

            if (!applied) {
                this._restoreCommanderReplaceableContext(npc, snapshot);
                return false;
            }

            this._removeCommanderTaskForNpc(npc);
            npc._actionDecisionCooldown = 0;
        }

        if (!applied) return false;

        if (typeof npc.addMemory === 'function') {
            npc.addMemory(`[指挥官命令] ${directive.raw}`);
        }
        return true;
    }

    proto._executeCommanderText = async function(rawText) {
        const statements = this._splitCommanderStatements(rawText);
        if (!statements.length) {
            return { ok: false, summary: GST.t('commander.empty_input') };
        }

        const details = [];
        let appliedCount = 0;
        let answeredCount = 0;

        for (let i = 0; i < statements.length; i++) {
            const statement = statements[i];
            const allowFallbackSingle = statements.length === 1 && i === 0;
            const llmPlan = await this._planCommanderStatementWithLLM(statement, allowFallbackSingle);

            // === refuse: 角色拒绝不合理指令，给出有情感的反馈 ===
            if (llmPlan && String(llmPlan.kind || '').trim() === 'refuse') {
                const targets = this._resolveCommanderPlanTargets(llmPlan.targets, statement, allowFallbackSingle, false);
                const replyMode = String(llmPlan.replyMode || '').trim().toLowerCase();
                const replyTargets = (replyMode === 'all' && targets.length > 1) ? targets : (targets.length ? [targets[0]] : []);
                const refuseReplies = [];

                for (const npc of replyTargets) {
                    const replyText = this._normalizeCommanderReplyText(llmPlan.reply)
                        || _getLang().REPLY_TEMPLATES.refuseDefault;
                    refuseReplies.push({
                        npc,
                        name: this._getCommanderDisplayName(npc),
                        text: replyText,
                    });
                }

                if (refuseReplies.length) {
                    this._appendCommanderConversationToChatLog(
                        statement,
                        refuseReplies.map(item => ({ name: item.name, text: item.text })),
                        '🚫 指令被拒绝'
                    );
                    for (const item of refuseReplies) {
                        this._showCommanderReplyBubble(item.npc, item.text);
                    }
                    details.push(`${refuseReplies.map(r => r.name).join('、')}拒绝执行：${refuseReplies[0].text}`);
                    answeredCount++;

                    if (this.addEvent) {
                        this.addEvent(GST.t('commander.refuse_order', { statement }));
                    }
                    continue;
                }
            }

            if (llmPlan && String(llmPlan.kind || '').trim() === 'question') {
                const question = this._parseCommanderQuestion(statement, allowFallbackSingle);
                const targets = this._resolveCommanderPlanTargets(llmPlan.targets, statement, allowFallbackSingle, true);
                if (!targets.length) {
                    details.push(`未找到回答者：${statement}`);
                    continue;
                }

                const replyMode = String(llmPlan.replyMode || '').trim().toLowerCase();
                const replyTargets = replyMode === 'all' ? targets : [targets[0]];
                const replies = [];

                for (const npc of replyTargets) {
                    const replyText = this._normalizeCommanderReplyText(llmPlan.reply)
                        || (question ? this._buildCommanderQuestionReply(npc, question) : '');
                    if (!replyText) continue;
                    replies.push({
                        npc,
                        name: this._getCommanderDisplayName(npc),
                        text: replyText,
                    });
                    answeredCount++;
                }

                if (replies.length) {
                    this._appendCommanderConversationToChatLog(statement, replies.map(item => ({ name: item.name, text: item.text })));
                    for (const item of replies) {
                        this._showCommanderReplyBubble(item.npc, item.text);
                    }
                    details.push(replies.map(item => `${item.name}答：${item.text}`).join(' / '));

                    if (this.addEvent) {
                        const first = replies[0];
                        if (replies.length === 1) {
                            const brief = first.text.length > 48 ? `${first.text.slice(0, 48)}…` : first.text;
                            this.addEvent(GST.t('commander.npc_replied', { name: first.name, brief }));
                        } else {
                            this.addEvent(GST.t('commander.npcs_replied', { count: replies.length }));
                        }
                    }
                    continue;
                }
            }

            if (llmPlan && String(llmPlan.kind || '').trim() === 'directive') {
                const action = this._normalizeCommanderPlanAction(llmPlan);
                const targets = this._resolveCommanderPlanTargets(llmPlan.targets, statement, allowFallbackSingle, false);
                if (action && targets.length) {
                    const directive = { raw: statement, action, targets };
                    const appliedNames = [];
                    const appliedReplies = [];

                    for (const npc of targets) {
                        if (this._applyCommanderDirectiveToNpc(npc, directive)) {
                            appliedNames.push(npc.name);
                            const replyText = this._normalizeCommanderReplyText(llmPlan.reply)
                                || this._buildCommanderDirectiveReply(npc, directive);
                            if (replyText) {
                                appliedReplies.push({
                                    npc,
                                    name: this._getCommanderDisplayName(npc),
                                    text: replyText,
                                });
                            }
                            appliedCount++;
                        }
                    }

                    if (appliedNames.length) {
                        if (appliedReplies.length) {
                            this._appendCommanderConversationToChatLog(
                                statement,
                                appliedReplies.map(item => ({ name: item.name, text: item.text })),
                                '🧭 指挥命令'
                            );
                            for (const item of appliedReplies) {
                                this._showCommanderReplyBubble(item.npc, item.text);
                            }
                        }
                        details.push(`${appliedNames.join('、')} → ${directive.action.reason}`);
                        continue;
                    }
                }
            }

            if (llmPlan) {
                const planKind = String(llmPlan.kind || '').trim() || 'unknown';
                // 即使 LLM 返回了 unknown 或无法执行的 directive，也尝试让角色给出反馈
                const fallbackReply = this._normalizeCommanderReplyText(llmPlan.reply);
                if (fallbackReply) {
                    const targets = this._resolveCommanderPlanTargets(llmPlan.targets, statement, allowFallbackSingle, false);
                    const responder = targets.length ? targets[0] : this.npcs.find(n => !n.isDead);
                    if (responder) {
                        const responderName = this._getCommanderDisplayName(responder);
                        this._appendCommanderConversationToChatLog(
                            statement,
                            [{ name: responderName, text: fallbackReply }],
                            '🤷 无法执行'
                        );
                        this._showCommanderReplyBubble(responder, fallbackReply);
                details.push(`${responderName}：${fallbackReply}`);
                        answeredCount++;
                        continue;
                    }
                }
                // LLM 返回了 plan 但无法执行且无 reply，再次调用 LLM 生成角色回复
                const localFallback = await this._generateLocalCommanderFallbackReply(statement);
                if (localFallback) {
                    const fbName = this._getCommanderDisplayName(localFallback.npc);
                    this._appendCommanderConversationToChatLog(
                        statement,
                        [{ name: fbName, text: localFallback.text }],
                        localFallback.label
                    );
                    this._showCommanderReplyBubble(localFallback.npc, localFallback.text);
                    details.push(`${fbName}：${localFallback.text}`);
                    answeredCount++;
                } else {
                    details.push(`未能按LLM计划执行（${planKind}）：${statement}`);
                }
                continue;
            }

            // LLM 调用失败时，再次用简化 prompt 调用 LLM 生成角色回复
            const localReply = await this._generateLocalCommanderFallbackReply(statement);
            if (localReply) {
                const responder = localReply.npc;
                const responderName = this._getCommanderDisplayName(responder);
                this._appendCommanderConversationToChatLog(
                    statement,
                    [{ name: responderName, text: localReply.text }],
                    localReply.label
                );
                this._showCommanderReplyBubble(responder, localReply.text);
                details.push(`${responderName}：${localReply.text}`);
                answeredCount++;
            } else {
                details.push(`指挥解析失败：${statement}`);
            }
        }

        const summary = details.join('；');
        const timeStr = typeof this.getTimeStr === 'function' ? this.getTimeStr() : '';
        this.commandHistory.unshift({
            text: rawText,
            summary,
            time: `第${this.dayCount}天 ${timeStr}`.trim(),
        });
        this.commandHistory = this.commandHistory.slice(0, 12);

        if (appliedCount > 0) {
            this._refreshCommanderDecisionCard();
            if (this.addEvent) {
                this.addEvent(GST.t('commander.order_issued', { summary }));
            }
        }

        const ok = appliedCount > 0 || answeredCount > 0;
        return {
            ok,
            summary: ok ? summary : `${GST.t('commander.parse_fail')}: ${summary}`,
            appliedCount,
            answeredCount,
        };
    }

    proto._renderCommanderHistory = function() {
        if (!this._commanderUI) return;
        const el = this._commanderUI.history;
        const items = this.commandHistory.slice(0, 8);
        if (!items.length) {
        el.innerHTML = '<div style="font-size:12px;color:rgba(214,234,255,0.58);">' + GST.t('commander.history_empty') + '</div>';
            return;
        }
        el.innerHTML = items.map(item => `
            <div style="padding:10px 12px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid rgba(120,190,255,0.08);">
                <div style="font-size:11px;color:rgba(214,234,255,0.55);margin-bottom:5px;">${this._escapeCommanderHtml(item.time)}</div>
                <div style="font-size:13px;color:#f3f9ff;line-height:1.6;white-space:pre-wrap;">${this._escapeCommanderHtml(item.text)}</div>
                <div style="margin-top:6px;font-size:12px;color:#8fd0ff;line-height:1.5;">${this._escapeCommanderHtml(item.summary)}</div>
            </div>
        `).join('');
    }

    proto._renderCommanderStatus = function() {
        if (!this._commanderUI) return;
        const el = this._commanderUI.status;
        const sceneLabel = npc => (typeof npc.getSceneLabel === 'function' ? npc.getSceneLabel() : (npc.currentScene || _getLang().REPLY_TEMPLATES.unknownScene));
        const living = this.npcs.filter(npc => !npc.isDead);
        if (!living.length) {
            el.innerHTML = '<div style="font-size:12px;color:rgba(214,234,255,0.58);">' + GST.t('commander.no_survivors') + '</div>';
            return;
        }

        el.innerHTML = living.map(npc => {
            const stateDesc = npc.stateDesc || npc._currentAction?.reason || npc.state || _getLang().REPLY_TEMPLATES.defaultStandby;
            const hunger = Math.round(npc.hunger || 0);
            const stamina = Math.round(npc.stamina || 0);
            const social = Math.round(npc.social || 0);
            return `
                <div style="padding:10px 12px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid rgba(120,190,255,0.08);">
                    <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;">
                        <div style="font-size:14px;font-weight:700;color:#f4fbff;">${this._escapeCommanderHtml(npc.displayName || npc.name)}</div>
                        <div style="font-size:11px;color:rgba(214,234,255,0.55);">${this._escapeCommanderHtml(sceneLabel(npc))}</div>
                    </div>
                    <div style="margin-top:6px;font-size:12px;color:#9ed0ff;line-height:1.5;">${this._escapeCommanderHtml(stateDesc)}</div>
                    <div style="margin-top:8px;font-size:11px;color:rgba(214,234,255,0.66);">🍽 ${hunger} / ⚡ ${stamina} / 🙂 ${social}</div>
                </div>
            `;
        }).join('');
    }

    proto._getCommanderDisplayTaskForNpc = function(npc) {
        if (!npc) return GST.t('misc.standby');

        const activeDirectiveDesc = this._getCommanderActiveDirectiveDesc(npc);
        if (activeDirectiveDesc) {
            return activeDirectiveDesc;
        }

        const taskSystem = this.taskSystem;
        const assignedTaskId = taskSystem?.npcAssignments ? taskSystem.npcAssignments[npc.id] : null;
        if (assignedTaskId && Array.isArray(taskSystem?.dailyTasks)) {
            const task = taskSystem.dailyTasks.find(item => item.id === assignedTaskId);
            if (task) {
                return GST.i18n.translateTaskLabel(task.type) || task.name || task.type || GST.t('misc.executing');
            }
        }

        const stateDesc = npc.stateDesc || npc._currentAction?.reason || npc.state || GST.t('misc.standby');
        // 【v5.8.17】统一走i18n翻译，避免英文模式下显示中文
        return GST.i18n?.translateStateDesc ? GST.i18n.translateStateDesc(stateDesc) : stateDesc;
    }

    /**
     * LLM 兜底角色反馈生成器 — 当第一次 LLM 调用失败时，用更简单的 prompt 再试一次
     * 核心原则：一切回复都由 AI 自己想，绝不用固定文本
     * 只有 LLM 彻底不可用（API 宕机）时才返回 null
     */
    proto._generateLocalCommanderFallbackReply = async function(statement) {
        const liveNpcs = this.npcs.filter(npc => !npc.isDead);
        if (!liveNpcs.length) return null;

        const responder = liveNpcs[Math.floor(Math.random() * liveNpcs.length)];
        const responderName = this._getCommanderDisplayName(responder);
        const lang = _getLang();

        const callLLM = typeof GST.callLLMDirect === 'function' ? GST.callLLMDirect : GST.callLLM;
        if (typeof callLLM === 'function' && !GST.LLM_STATUS?.isDown) {
            try {
                const simpleSystem = lang.buildFallbackSystemPrompt(responder);
                const simpleUser = lang.buildFallbackUserPrompt(responder, statement);

                console.log(`[LLM调用] 🔵 ${responder.name} fallback reply → callLLM`);
                const raw = await callLLM(simpleSystem, simpleUser, 200);  // 简单回复（v4.41测试：A10上4B比0.8B快3倍，统一用主模型）
                if (raw && typeof raw === 'string') {
                    let text = raw.trim();
                    // 清理思考标签和多余格式
                    text = text.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
                    text = text.replace(/```[\s\S]*?```/g, '').trim();
                    text = text.replace(/^["']|["']$/g, '').trim();
                    if (text.length > 200) text = text.slice(0, 200) + '……';
                    if (text.length > 2) {
                        return { npc: responder, text, label: '🤷 ?' };
                    }
                }
            } catch (err) {
                console.warn('[CommanderFallback] 兜底LLM调用失败:', err);
            }
        }

        // LLM 彻底不可用时返回 null，由调用方显示系统提示
        return null;
    }

    proto._showCommanderReplyBubble = function(npc, text) {
        if (!npc || !text) return;
        const T = _getLang().REPLY_TEMPLATES;
        const bubbleText = String(text).replace(T.commanderPrefixRegex, '').trim();
        npc.expression = bubbleText.length > 72 ? `${bubbleText.slice(0, 72)}…` : bubbleText;
        npc.expressionTimer = 12;
    }

    proto._appendCommanderConversationToChatLog = function(playerText, replies, label = '🧭') {
        if (!playerText || !Array.isArray(replies) || !replies.length) return;
        const T = _getLang().REPLY_TEMPLATES;

        const dm = this.dialogueManager;
        if (dm && typeof dm._addChatLogDivider === 'function' && typeof dm._addChatLogEntry === 'function') {
            dm._addChatLogDivider(label);
            dm._addChatLogEntry(T.commanderName, playerText, 'self');
            for (const item of replies) {
                dm._addChatLogEntry(item.name, item.text, 'other');
            }
            return;
        }

        const container = document.getElementById('chat-log-content');
        if (!container) return;

        const appendEntry = (speakerName, text, type) => {
            const entry = document.createElement('div');
            entry.className = `chat-log-msg ${type === 'self' ? 'right' : 'left'} new`;

            const speaker = document.createElement('span');
            speaker.className = 'chat-log-speaker';
            speaker.textContent = speakerName;

            const time = document.createElement('span');
            time.className = 'chat-log-time';
            time.textContent = this.getTimeStr ? ` ${this.getTimeStr()}` : '';
            speaker.appendChild(time);

            const body = document.createElement('div');
            body.className = 'chat-log-text';
            body.textContent = text;

            entry.appendChild(speaker);
            entry.appendChild(body);
            container.appendChild(entry);
            container.scrollTop = container.scrollHeight;
        };

        const divider = document.createElement('div');
        divider.className = 'chat-log-divider';
        divider.textContent = label;
        container.appendChild(divider);

        appendEntry(T.commanderName, playerText, 'self');
        for (const item of replies) {
            appendEntry(item.name, item.text, 'other');
        }
    }

    proto._refreshCommanderDecisionCard = function() {
        // 【v4.16】指挥分工已由右上角常驻面板(#work-plan-panel)实时显示
        // 此处触发一次面板更新即可
        if (typeof this._updateWorkPlanPanel === 'function') {
            this._updateWorkPlanPanel();
        }
    }

    proto._openCommandMode = function() {
        this._ensureCommanderState();
        this._commanderPauseWasPaused = !!this.paused;
        this.commandModeActive = true;
        this.paused = true;
        this._syncPauseButtonState();
        this._renderCommanderHistory();
        this._renderCommanderStatus();
        this._commanderUI.feedback.textContent = GST.t('commander.enter_command');
        this._commanderUI.overlay.style.display = 'block';
        requestAnimationFrame(() => this._commanderUI.input.focus());
    }

    proto._closeCommandMode = function(options) {
        this._ensureCommanderState();
        const opts = options || {};
        this.commandModeActive = false;
        this._commanderUI.overlay.style.display = 'none';
        this._commanderUI.feedback.textContent = '';
        if (opts.keepPaused === true) {
            this.paused = true;
        } else if (opts.restorePreviousPause) {
            this.paused = this._commanderPauseWasPaused;
        } else {
            this.paused = false;
        }
        this._syncPauseButtonState();
    }

    proto._toggleCommandMode = function() {
        this._ensureCommanderState();
        if (this.commandModeActive) {
            this._closeCommandMode({ restorePreviousPause: true });
        } else {
            this._openCommandMode();
        }
    }

    proto._submitCommanderCommand = async function(options) {
        this._ensureCommanderState();
        const opts = options || {};
        const rawText = this._commanderUI.input.value.trim();
        if (!rawText) {
            this._commanderUI.feedback.textContent = GST.t('commander.empty_input');
            return;
        }

        this._setCommanderBusy(true, GST.t('commander.parsing'));
        try {
            const result = await this._executeCommanderText(rawText);
            this._commanderUI.feedback.textContent = result.summary;
            this._renderCommanderHistory();
            this._renderCommanderStatus();

            if (!result.ok) return;

            this._commanderUI.input.value = '';
            if (opts.keepPaused) {
                this.paused = true;
                this._syncPauseButtonState();
                return;
            }
            this._closeCommandMode({ restorePreviousPause: false });
        } catch (err) {
            console.error('[Commander] 提交命令失败:', err);
            this._commanderUI.feedback.textContent = GST.t('commander.parse_fail');
        } finally {
            this._setCommanderBusy(false);
        }
    }


})();
