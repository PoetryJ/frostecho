/**
 * 福音镇 - 指挥官系统 英文数据层
 * 
 * 架构说明：
 * - 本文件只包含英文相关的数据：别名、正则、任务标签、LLM prompt 模板、回复模板
 * - 路由层在 commander.js 中，通过 GST._commanderDataEn 引用
 * - 中文数据层在 commander-data-zh.js 中
 * - 切换语言时自动切换数据源，彻底解耦
 */
(function() {
    'use strict';
    const GST = window.GST;

    // ============ NPC Alias Map (English input matching) ============
    const ALIAS_MAP = {
        zhao_chef: ['Zhao', 'Chef Zhao', 'Old Zhao'],
        lu_chen: ['Lu Chen', 'Chen'],
        li_shen: ['Aunt Li', 'Li'],
        wang_teacher: ['Wang Ce', 'Teacher Wang', 'Teacher'],
        old_qian: ['Old Qian', 'Uncle Qian'],
        su_doctor: ['Dr. Su', 'Su'],
        ling_yue: ['Ling Yue', 'Ling'],
        qing_xuan: ['Qing Xuan', 'Xuan'],
    };

    // ============ NPC Display Name Map ============
    const NAME_MAP = {
        zhao_chef: 'Zhao Tiezhu',
        lu_chen: 'Lu Chen',
        li_shen: 'Aunt Li',
        wang_teacher: 'Wang Ce',
        old_qian: 'Old Qian',
        su_doctor: 'Dr. Su',
        ling_yue: 'Ling Yue',
        qing_xuan: 'Qing Xuan',
    };

    // ============ NPC Role Emoji ============
    const ROLE_EMOJI = {
        zhao_chef: '👨‍🍳',
        lu_chen: '💪',
        li_shen: '👩‍🍳',
        wang_teacher: '👨‍🏫',
        old_qian: '👴',
        su_doctor: '👨‍⚕️',
        ling_yue: '🔍',
        qing_xuan: '🧪',
    };

    // ============ Task Labels ============
    const TASK_LABELS = {
        BUILD_LUMBER_MILL: 'Build Lumber Mill',
        BUILD_GENERATOR: 'Build Generator',
        BUILD_FOOD_COLLECTOR: 'Build Food Trap',
        REPAIR_LUMBER_MILL: 'Repair Lumber Mill',
        REPAIR_GENERATOR: 'Repair Generator',
        REPAIR_FOOD_COLLECTOR: 'Repair Food Trap',
        DISTRIBUTE_FOOD: 'Cook Food',
        PREPARE_MEDICAL: 'Medical Treatment',
        MAINTAIN_POWER: 'Maintain Power',
        COLLECT_WOOD: 'Collect Wood',
        COLLECT_FOOD: 'Collect Food',
        COLLECT_MATERIAL: 'Explore Ruins',
        BOOST_MORALE: 'Boost Morale',
        MAINTAIN_ORDER: 'Patrol & Guard',
        TREATMENT: 'Receive Treatment',
    };

    // ============ Task Defaults ============
    const TASK_DEFAULTS = {
        BUILD_LUMBER_MILL: {
            targetLocation: 'workshop_door',
            stateDesc: 'Building Lumber Mill',
            reason: 'Go to workshop to build lumber mill',
            effectKey: 'build_machine_lumber',
            targetValue: 1,
            priority: 'urgent',
        },
        BUILD_GENERATOR: {
            targetLocation: 'workshop_door',
            stateDesc: 'Building Generator',
            reason: 'Go to workshop to build generator',
            effectKey: 'build_machine_generator',
            targetValue: 1,
            priority: 'urgent',
        },
        BUILD_FOOD_COLLECTOR: {
            targetLocation: 'workshop_door',
            stateDesc: 'Building Food Trap',
            reason: 'Go to workshop to build food trap',
            effectKey: 'build_machine_food',
            targetValue: 1,
            priority: 'urgent',
        },
        REPAIR_LUMBER_MILL: {
            targetLocation: 'workshop_door',
            stateDesc: 'Repairing Lumber Mill',
            reason: 'Go to workshop to repair lumber mill',
            effectKey: 'repair_machine_lumber',
            targetValue: 1,
            priority: 'urgent',
        },
        REPAIR_GENERATOR: {
            targetLocation: 'workshop_door',
            stateDesc: 'Repairing Generator',
            reason: 'Go to workshop to repair generator',
            effectKey: 'repair_machine_generator',
            targetValue: 1,
            priority: 'urgent',
        },
        REPAIR_FOOD_COLLECTOR: {
            targetLocation: 'workshop_door',
            stateDesc: 'Repairing Food Trap',
            reason: 'Go to workshop to repair food trap',
            effectKey: 'repair_machine_food',
            targetValue: 1,
            priority: 'urgent',
        },
        DISTRIBUTE_FOOD: {
            targetLocation: 'kitchen_door',
            stateDesc: 'Cooking',
            reason: 'Go to kitchen to cook',
            targetValue: 1,
            priority: 'high',
        },
        PREPARE_MEDICAL: {
            targetLocation: 'medical_door',
            stateDesc: 'Medical Treatment',
            reason: 'Go to medical station for treatment',
            targetValue: 1,
            priority: 'urgent',
        },
        MAINTAIN_POWER: {
            targetLocation: 'workshop_door',
            stateDesc: 'Manual Power Generation',
            reason: 'Go to workshop for manual power generation',
            effectKey: 'maintain_power',
            targetValue: 20,
            priority: 'urgent',
        },
        COLLECT_WOOD: {
            targetLocation: 'lumber_camp',
            stateDesc: 'Chopping Wood',
            reason: 'Go to lumber camp to chop wood',
            targetValue: 30,
            priority: 'high',
        },
        COLLECT_FOOD: {
            targetLocation: 'frozen_lake',
            stateDesc: 'Collecting Food',
            reason: 'Go to frozen lake to collect food',
            targetValue: 20,
            priority: 'high',
        },
        COLLECT_MATERIAL: {
            targetLocation: 'ruins_site',
            stateDesc: 'Exploring Ruins',
            reason: 'Go to ruins to explore for supplies',
            targetValue: 1,
            priority: 'high',
        },
        BOOST_MORALE: {
            targetLocation: 'dorm_a_door',
            stateDesc: 'Boosting Morale',
            reason: 'Go to dorm to boost morale',
            targetValue: 1,
            priority: 'high',
        },
        MAINTAIN_ORDER: {
            targetLocation: 'dorm_a_door',
            stateDesc: 'Patrolling',
            reason: 'Go to dorm to patrol',
            targetValue: 1,
            priority: 'high',
        },
    };

    // ============ Action Presets (regex match → action) ============
    const ACTION_PRESETS = [
        {
            match: text => /repair.*lumber|fix.*lumber|repair.*mill/i.test(text),
            action: { mode: 'task_system', taskType: 'REPAIR_LUMBER_MILL', ...TASK_DEFAULTS.REPAIR_LUMBER_MILL }
        },
        {
            match: text => /repair.*generator|fix.*generator/i.test(text),
            action: { mode: 'task_system', taskType: 'REPAIR_GENERATOR', ...TASK_DEFAULTS.REPAIR_GENERATOR }
        },
        {
            match: text => /build.*lumber|auto.*lumber/i.test(text),
            action: { mode: 'task_system', taskType: 'BUILD_LUMBER_MILL', ...TASK_DEFAULTS.BUILD_LUMBER_MILL }
        },
        {
            match: text => /build.*generator|auto.*power/i.test(text),
            action: { mode: 'task_system', taskType: 'BUILD_GENERATOR', ...TASK_DEFAULTS.BUILD_GENERATOR }
        },
        { match: text => /rest|sleep|tired|nap/i.test(text), action: { type: 'rest', reason: 'Go back to dorm to rest' } },
        { match: text => /eat|food|meal|hungry/i.test(text), action: { type: 'eat', target: 'kitchen_door', reason: 'Go eat' } },
        {
            match: text => /cook|prepare.*meal|make.*food/i.test(text),
            action: { mode: 'task_system', taskType: 'DISTRIBUTE_FOOD', targetLocation: 'kitchen_door', stateDesc: 'Cooking', reason: 'Go to kitchen to cook', targetValue: 1, priority: 'high' }
        },
        {
            match: text => /medical|treat|heal|bandage|medicine|herb/i.test(text),
            action: { mode: 'task_system', taskType: 'PREPARE_MEDICAL', ...TASK_DEFAULTS.PREPARE_MEDICAL }
        },
        {
            match: text => /manual.*power|hand.*crank|generate.*power|power/i.test(text),
            action: { mode: 'task_system', taskType: 'MAINTAIN_POWER', ...TASK_DEFAULTS.MAINTAIN_POWER }
        },
        {
            match: text => /chop.*wood|lumber|firewood|wood/i.test(text),
            action: { mode: 'task_system', taskType: 'COLLECT_WOOD', ...TASK_DEFAULTS.COLLECT_WOOD }
        },
        {
            match: text => /fish|hunt|gather.*food|find.*food/i.test(text),
            action: { mode: 'task_system', taskType: 'COLLECT_FOOD', ...TASK_DEFAULTS.COLLECT_FOOD }
        },
        { match: text => /mine|ore|mining/i.test(text), action: { type: 'go_to', target: 'ore_pile', reason: 'Go to ore pile to mine' } },
        {
            match: text => /explore|ruins|scout|search/i.test(text),
            action: { mode: 'task_system', taskType: 'COLLECT_MATERIAL', ...TASK_DEFAULTS.COLLECT_MATERIAL }
        },
        {
            match: text => /comfort|encourage|cheer|console|talk|morale/i.test(text),
            action: { mode: 'task_system', taskType: 'BOOST_MORALE', ...TASK_DEFAULTS.BOOST_MORALE }
        },
        {
            match: text => /patrol|guard|watch|sentry/i.test(text),
            action: { mode: 'task_system', taskType: 'MAINTAIN_ORDER', ...TASK_DEFAULTS.MAINTAIN_ORDER }
        },
        { match: text => /warehouse|inventory|stockpile/i.test(text), action: { type: 'go_to', target: 'warehouse_door', reason: 'Go to warehouse to organize supplies' } },
        { match: text => /standby|stay|don't move|hold position/i.test(text), action: { type: 'go_to', target: 'dorm_a_door', reason: 'Go to dorm and stand by' } },
        { match: text => /wander|walk around|look around/i.test(text), action: { type: 'go_to', target: 'dorm_a_door', reason: 'Go to dorm and patrol' } },
        { match: text => /work|get to work|workshop/i.test(text), action: { type: 'go_to', target: 'workshop_door', reason: 'Go to workshop to work' } },
    ];

    // ============ LLM Intent Library ============
    const LLM_INTENT_LIBRARY = {
        BUILD_LUMBER_MILL: { mode: 'task_system', taskType: 'BUILD_LUMBER_MILL', resourceType: null, desc: 'Build auto lumber mill at workshop', ...TASK_DEFAULTS.BUILD_LUMBER_MILL },
        BUILD_GENERATOR: { mode: 'task_system', taskType: 'BUILD_GENERATOR', resourceType: null, desc: 'Build auto generator at workshop', ...TASK_DEFAULTS.BUILD_GENERATOR },
        REPAIR_LUMBER_MILL: { mode: 'task_system', taskType: 'REPAIR_LUMBER_MILL', resourceType: null, desc: 'Repair broken lumber mill at workshop', ...TASK_DEFAULTS.REPAIR_LUMBER_MILL },
        REPAIR_GENERATOR: { mode: 'task_system', taskType: 'REPAIR_GENERATOR', resourceType: null, desc: 'Repair broken generator at workshop', ...TASK_DEFAULTS.REPAIR_GENERATOR },
        BUILD_FOOD_COLLECTOR: { mode: 'task_system', taskType: 'BUILD_FOOD_COLLECTOR', resourceType: null, desc: 'Build auto food trap at workshop', ...TASK_DEFAULTS.BUILD_FOOD_COLLECTOR },
        REPAIR_FOOD_COLLECTOR: { mode: 'task_system', taskType: 'REPAIR_FOOD_COLLECTOR', resourceType: null, desc: 'Repair broken food trap at workshop', ...TASK_DEFAULTS.REPAIR_FOOD_COLLECTOR },
        DISTRIBUTE_FOOD: { mode: 'task_system', taskType: 'DISTRIBUTE_FOOD', resourceType: null, desc: 'Cook food at kitchen to reduce waste', ...TASK_DEFAULTS.DISTRIBUTE_FOOD },
        PREPARE_MEDICAL: { mode: 'task_system', taskType: 'PREPARE_MEDICAL', resourceType: null, desc: 'Treat wounded at medical station', ...TASK_DEFAULTS.PREPARE_MEDICAL },
        MAINTAIN_POWER: { mode: 'task_system', taskType: 'MAINTAIN_POWER', resourceType: 'power', desc: 'Manual power generation at workshop', ...TASK_DEFAULTS.MAINTAIN_POWER },
        COLLECT_WOOD: { mode: 'task_system', taskType: 'COLLECT_WOOD', resourceType: 'woodFuel', desc: 'Chop wood at lumber camp', ...TASK_DEFAULTS.COLLECT_WOOD },
        COLLECT_FOOD: { mode: 'task_system', taskType: 'COLLECT_FOOD', resourceType: 'food', desc: 'Collect food at frozen lake', ...TASK_DEFAULTS.COLLECT_FOOD },
        COLLECT_MATERIAL: { mode: 'task_system', taskType: 'COLLECT_MATERIAL', resourceType: null, desc: 'Explore ruins for supplies', ...TASK_DEFAULTS.COLLECT_MATERIAL },
        BOOST_MORALE: { mode: 'task_system', taskType: 'BOOST_MORALE', resourceType: null, desc: 'Comfort and encourage everyone', ...TASK_DEFAULTS.BOOST_MORALE },
        MAINTAIN_ORDER: { mode: 'task_system', taskType: 'MAINTAIN_ORDER', resourceType: null, desc: 'Patrol and guard the dorm', ...TASK_DEFAULTS.MAINTAIN_ORDER },
        MINE_POWER: { mode: 'task_system', taskType: 'MINE_POWER', targetLocation: 'ore_pile', stateDesc: 'Mining', reason: 'Go to ore pile to mine', targetValue: 20, priority: 'high', resourceType: 'power', desc: 'Mine ore for power generation' },
        PSYCHOLOGY: { mode: 'task_system', taskType: 'PSYCHOLOGY', targetLocation: 'medical_door', stateDesc: 'Counseling', reason: 'Go to medical station for counseling', targetValue: 1, priority: 'high', resourceType: null, desc: 'Psychological counseling at medical station' },
        WAREHOUSE: { mode: 'task_system', taskType: 'WAREHOUSE', targetLocation: 'warehouse_door', stateDesc: 'Inventory Check', reason: 'Go to warehouse to check inventory', targetValue: 1, priority: 'high', resourceType: null, desc: 'Check warehouse inventory to reduce waste' },
        REST: { type: 'rest', reason: 'Go back to dorm to rest', priority: 'urgent', desc: 'Rest at dorm to recover stamina' },
        EAT: { type: 'eat', target: 'kitchen_door', reason: 'Go eat', priority: 'urgent', desc: 'Eat at kitchen' },
        WORK: { type: 'go_to', target: 'workshop_door', reason: 'Go to workshop to work', priority: 'normal', desc: 'Work at workshop' },
        STAY: { type: 'go_to', target: 'dorm_a_door', reason: 'Stand by at dorm', priority: 'normal', desc: 'Stand by at dorm' },
        WANDER: { type: 'go_to', target: 'dorm_a_door', reason: 'Patrol around dorm', priority: 'low', desc: 'Patrol around dorm' },
    };

    // ============ "All" Aliases ============
    const ALL_ALIASES = ['everyone', 'all', 'everybody', 'team'];

    // ============ Question Analysis Patterns ============
    const QUESTION_PATTERNS = {
        aboutGenerator: /generator|auto.*power/i,
        aboutLumberMill: /lumber.*mill|auto.*lumber/i,
        aboutFoodCollector: /food.*trap|auto.*food/i,
        asksResources: /resource|supply|inventory|wood|food|power/i,
        asksConditions: /condition|require|need|lack|missing|threshold|unlock|how.*build|can.*build/i,
        asksProgress: /progress|how.*going|status|done.*yet|finished|situation/i,
        asksTeamStatus: /everyone|all|team|squad|assignment|what.*doing|what.*busy/i,
        asksSelfStatus: /(you.*now|what.*you.*doing|your.*task|your.*job|your.*side)/i,
        asksSelfStatusFallback: /what.*doing|doing.*what|busy.*with|progress|how.*going|done.*yet|finished/i,
        isQuestion: /ask|tell me|report|what.*condition|what.*need|lack|missing|progress|how.*going|status|what.*doing|busy|done.*yet|finished|resource.*how|supply.*how|unlock|can.*build|how.*now/i,
    };

    // ============ Gather Names ============
    const GATHER_NAMES = {
        wood: 'Chopping Wood',
        woodFuel: 'Chopping Wood',
        food: 'Collecting Food',
        power: 'Mining',
        explore: 'Exploring Ruins',
    };
    const GATHER_DEFAULT = 'Gathering Supplies';

    // ============ LLM Prompt Templates ============

    function buildPlannerSystemPrompt() {
        return `You are the "Player Command Parser" in a post-apocalyptic survival game. Your task is to parse a player's command into structured JSON, and generate a brief, natural NPC reply when needed.
Output JSON only. No Markdown, no explanation.
Only use the provided alive NPC ids; never assign tasks to dead NPCs.
If it's a question, kind must be "question", with a reply text for the commander.
If it's a command, kind must be "directive", and intentKey must be from the allowed list only.
If the command is unreasonable, dangerous, against survival instinct, absurd, or not in the allowed list (e.g. suicide, harming each other, giving up), kind must be "refuse", and reply should express the character's refusal with emotion and personality (anger, fear, questioning, persuasion, etc.).
targets is an NPC id array; use ["all"] for everyone.
replyMode can only be "single" or "all". For refuse, replyMode should be "all" to let multiple characters express their attitudes.
question reply should be in survivor's voice, concise and natural, can start with "Commander,".
directive reply is a brief acknowledgment after receiving the order, can be empty.
refuse reply should be in the character's own voice, expressing refusal, questioning or persuasion, with personality and emotion.
Prioritize understanding the real intent, don't mechanically copy the original sentence.`;
    }

    function buildPlannerUserPrompt(worldSummary, npcCatalog, intentCatalog, statement, fallbackHint) {
        return `[World State]
${worldSummary}

[Alive NPCs]
${npcCatalog}

[Available Command Intent Keys]
${intentCatalog}

[Parsing Rules]
- If the statement is asking about status, progress, resources, conditions, or who's doing what, use "question".
- If the statement is assigning work or commanding action, use "directive".
- If asking about "everyone/all/team" status, replyMode should usually be "single", let the most suitable person answer.
- Do not invent new intentKeys.
- Reply content should match the current world state.
- If the command is dangerous, unreasonable, or against survival instinct (suicide, harming each other, giving up), use "refuse" and let the character express their real reaction.
- If clearly incomprehensible, return {"kind":"unknown"}.
- ${fallbackHint}

[Statement to Parse]
${statement}

[Output JSON Examples]
{"kind":"directive","targets":["lu_chen"],"replyMode":"all","reply":"Commander, copy that. I'll go chop some wood.","intentKey":"COLLECT_WOOD","reason":"Go to lumber camp to chop wood"}
{"kind":"question","targets":["old_qian"],"replyMode":"single","reply":"Commander, the generator hasn't been started yet. We still need more wood and power."}
{"kind":"refuse","targets":["all"],"replyMode":"all","reply":"Commander, are you insane?! We've fought so hard to survive, we can't just give up!"}
{"kind":"unknown"}`;
    }

    function buildFallbackHint(allowFallbackSingle) {
        return allowFallbackSingle
            ? 'This is a single statement. If no one is named, you can choose the most suitable survivor, or use ["all"] for obvious group commands.'
            : 'If the statement already names someone or the context is limited, prioritize the named survivor.';
    }

    function buildFallbackSystemPrompt(npc) {
        return `You are a survivor named "${npc.name}" (${npc.occupation || 'survivor'}, age ${npc.age || '?'}, ${npc.gender || ''}) in a post-apocalyptic survival game.
It's a deadly snowstorm apocalypse, and your group is struggling to survive in a snow town. The commander (player) just gave you an order.
Reply as yourself, with your own voice, personality and emotions. No JSON format needed, just speak directly.
Keep it brief and natural (one or two sentences), with your character's personality.
If the command is absurd or dangerous, you can refuse, question, get angry, scared, or try to persuade — express your real reaction.`;
    }

    function buildFallbackUserPrompt(npc, statement) {
        return `The commander says: "${statement}"\n\nReply as ${npc.name}:`;
    }

    // ============ World Summary Labels ============

    function buildWorldSummaryLabels() {
        return {
            timeHeader: (dayCount, timeStr, period) => `Current Time: Day ${dayCount} ${timeStr} ${period}`,
            weather: w => `Weather: ${w}`,
            survival: s => `Survival Status: ${s}`,
            resources: r => `Resources: ${r}`,
            taskSummary: t => `Task Summary: ${t}`,
            facilities: f => `Facilities: ${f}`,
            death: d => `Deaths: ${d}`,
            aliveHeader: 'Alive Members: ',
            npcStatus: (id, name, scene, task, stamina, health, sanity, hunger, bodyTemp) =>
                `${id}/${name}: Scene ${scene}, Status ${task}, Stamina ${Math.round(stamina)}, Health ${Math.round(health)}, San ${Math.round(sanity)}, Hunger ${Math.round(hunger)}, Temp ${bodyTemp}°C`,
        };
    }

    // ============ Intent Catalog Formatting ============

    function formatIntentCatalogEntry(key, action) {
        if (action.mode === 'task_system') {
            return `${key}: ${action.desc || action.reason} (target: ${action.targetLocation}, state: ${action.stateDesc}, priority: ${action.priority || 'normal'})`;
        }
        const targetLabel = action.target && GST.NPC.ACTION_TARGETS
            ? (GST.NPC.ACTION_TARGETS[action.target] || action.target)
            : 'no fixed target';
        return `${key}: ${action.desc || action.reason} (action: ${action.type}, target: ${targetLabel}, priority: ${action.priority || 'normal'})`;
    }

    // ============ Reply Templates ============

    const REPLY_TEMPLATES = {
        commanderPrefix: 'Commander, ',
        goingTo: desc => `Heading to ${desc}`,
        resourceReply: (wood, woodHours, food, foodMeals, power, powerHours) =>
            `Current supplies: Wood ${wood} (~${woodHours}h left), Food ${food} (~${foodMeals} meals), Power ${power} (~${powerHours}h left)`,
        crisisWarning: crisisList => `. Most critical: ${crisisList}`,
        crisisLabels: { noFood: 'food running out', noPower: 'power critical', noWoodFuel: 'wood running out' },
        noResourceAccess: "I can't access the warehouse ledger right now.",
        noTaskAccess: "I can't report right now.",
        myTask: label => `I'm currently on ${label}`,
        alreadyBuilt: ', already completed',
        buildProgress: pct => `, construction progress ${pct}%`,
        buildPaused: ', but construction is paused',
        notStarted: ", hasn't started yet",
        taskCompleted: ', already done',
        taskPaused: reason => `, paused due to ${reason || 'insufficient conditions'}`,
        taskProgress: pct => `, about ${pct}% done`,
        currentlyDoing: desc => `, currently ${desc}`,
        currentState: desc => `I'm currently ${desc}.`,
        noSurvivors: 'No one is able to move right now.',
        teamSummary: summaryList => `I checked around: ${summaryList}.`,
        npcDoing: (name, task) => `${name} is ${task}`,
        machineBuilt: (name, running) => `${name} is built${running ? ' and running' : ' but stopped'}`,
        machineOutput: (outputLabel, outputPerHour, consumeLabel, consumePerHour) =>
            `, producing ${outputLabel} ${outputPerHour}/h, consuming ${consumeLabel} ${consumePerHour}/h`,
        machineRunReq: (label, current) => `, current ${label}: ${current}`,
        machineBuildReq: (woodCost, materialCost, minWorkers, timeHours) =>
            `Requires Wood ${woodCost}, Power ${materialCost}, at least ${minWorkers} workers, about ${timeHours}h`,
        machineTotalOutput: (produced, outputLabel, consumed, consumeLabel) =>
            `Total produced: ${Math.round(produced)} ${outputLabel}, consumed: ${Math.round(consumed)} ${consumeLabel}`,
        machineBuilding: (name, pct) => `${name} is under construction, progress ${pct}%`,
        machineWorkers: workers => `, workers: ${workers}`,
        machineBuildPausedNote: ', but paused due to low wood reserves',
        machineNotStarted: (name, unmetText) => `${name} hasn't started yet, ${unmetText}`,
        machineUnlockMissing: missing => `still need ${missing} to unlock`,
        machineUnlockReady: 'unlock conditions met',
        machineBuildCost: (woodCost, materialCost, minWorkers, timeHours) =>
            `Building requires Wood ${woodCost}, Power ${materialCost}, at least ${minWorkers} workers, about ${timeHours}h`,
        directiveAlreadyBuilt: (name) => `Commander, copy that. ${name} is already built, I'll go check on it.`,
        directiveJoinBuild: (name, pct) => `Commander, copy that. I'll join the ${name} construction, progress is ${pct}%`,
        directiveCurrentWorkers: workers => `, current workers: ${workers}`,
        directiveBuildPaused: ', but construction is paused',
        directiveUnlockMissing: (reason, missing) => `Commander, copy that. I'll ${reason}, but we still need ${missing}.`,
        directiveUnlockReady: reason => `Commander, copy that. I'll ${reason}, conditions are met.`,
        directiveAck: reason => `Commander, copy that. I'll ${reason}.`,
        refuseDefault: "Commander, I can't execute that order.",
        defaultTaskLabel: 'task',
        defaultAction: 'Execute order',
        defaultStandby: 'Standing by',
        unknownScene: 'Unknown',
        commanderName: 'Commander',
        commanderPrefixRegex: /^Commander[,，:：]?\s*/i,
        commanderPrefixNormalize: 'Commander, ',
    };

    // ============ NPC Catalog Formatting ============

    function formatNpcCatalogEntry(npc, displayName, aliases) {
        return `${npc.id} (display: ${displayName}, aliases: ${aliases || npc.name})`;
    }

    // ============ Export to Global ============
    GST._commanderDataEn = {
        ALIAS_MAP,
        NAME_MAP,
        ROLE_EMOJI,
        TASK_LABELS,
        TASK_DEFAULTS,
        ACTION_PRESETS,
        LLM_INTENT_LIBRARY,
        ALL_ALIASES,
        QUESTION_PATTERNS,
        GATHER_NAMES,
        GATHER_DEFAULT,
        REPLY_TEMPLATES,
        buildPlannerSystemPrompt,
        buildPlannerUserPrompt,
        buildFallbackHint,
        buildFallbackSystemPrompt,
        buildFallbackUserPrompt,
        buildWorldSummaryLabels,
        formatIntentCatalogEntry,
        formatNpcCatalogEntry,
    };
})();
