/**
 * 福音镇 - Game 碰撞系统 Mixin
 * 职责：NPC碰撞检测和解决、脱困、让路、气泡偏移
 * 从 game.js 拆分，遵循SRP原则（单一职责）
 * 挂载到 GST.Game.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.Game.prototype;

    proto._resolveNPCCollisions = function() {
        const outdoorRadius = GST.TILE * 0.45;
        const outdoorMinDist = outdoorRadius * 2;
        const outdoorPush = 0.8;
        const indoorRadius = GST.TILE * 0.25;
        const indoorMinDist = indoorRadius * 2;

        const sceneGroups = {};
        for (const n of this.npcs) {
            if (n.isDead || n.isSleeping || n.isEating) continue;
            if (!sceneGroups[n.currentScene]) sceneGroups[n.currentScene] = [];
            sceneGroups[n.currentScene].push(n);
        }

        for (const scene in sceneGroups) {
            const sceneNPCs = sceneGroups[scene];
            const map = this.maps[scene];
            const isIndoor = scene !== 'village';
            if (isIndoor) {
                this._computeBubbleOffsets(sceneNPCs, indoorMinDist);
            } else {
                this._resolveGroupCollisions(sceneNPCs, outdoorMinDist, outdoorPush, map, false);
            }
        }

        const bubbleMinDist = this.currentScene === 'village' ? outdoorMinDist : indoorMinDist;
        const visibleNPCs = this.npcs.filter(n => n.currentScene === this.currentScene && !n.isSleeping && !n.isEating && !n.isDead);
        this._computeBubbleOffsets(visibleNPCs, bubbleMinDist);
    };

    proto._resolveGroupCollisions = function(sceneNPCs, minDist, pushStrength, map, isIndoor) {
        for (let i = 0; i < sceneNPCs.length; i++) {
            for (let j = i + 1; j < sceneNPCs.length; j++) {
                const a = sceneNPCs[i];
                const b = sceneNPCs[j];
                const ax = a.x + GST.TILE / 2, ay = a.y + GST.TILE / 2;
                const bx = b.x + GST.TILE / 2, by = b.y + GST.TILE / 2;
                const dx = bx - ax, dy = by - ay;
                const dist = Math.sqrt(dx * dx + dy * dy);

                if (dist < minDist && dist > 0.1) {
                    const overlap = minDist - dist;
                    const nx = dx / dist, ny = dy / dist;
                    const push = overlap * pushStrength * 0.5;

                    let aMoving = a.isMoving ? 0.3 : 0.7;
                    let bMoving = b.isMoving ? 0.3 : 0.7;
                    if (a.isEating || a._isBeingTreated) aMoving = 0;
                    if (b.isEating || b._isBeingTreated) bMoving = 0;
                    if (!a.isMoving && a._currentBehaviorLock && aMoving > 0) aMoving = 0.1;
                    if (!b.isMoving && b._currentBehaviorLock && bMoving > 0) bMoving = 0.1;

                    const aOldX = a.x, aOldY = a.y;
                    const bOldX = b.x, bOldY = b.y;
                    a.x -= nx * push * aMoving;
                    a.y -= ny * push * aMoving;
                    b.x += nx * push * bMoving;
                    b.y += ny * push * bMoving;

                    // 【v5.4修复】碰撞推挤后检查NPC碰撞框4个角点，防止边缘嵌入建筑物
                    if (map) {
                        if (this._isNPCInSolid(a, map)) { a.x = aOldX; a.y = aOldY; }
                        if (this._isNPCInSolid(b, map)) { b.x = bOldX; b.y = bOldY; }
                    }

                    a.stuckTimer = Math.max(a.stuckTimer, 1.0);
                    b.stuckTimer = Math.max(b.stuckTimer, 1.0);

                    const realDt = this._lastRealDt || 0.016;
                    a.collisionStallTimer = (a.collisionStallTimer || 0) + realDt;
                    b.collisionStallTimer = (b.collisionStallTimer || 0) + realDt;

                    const aCanYield = !a.isSleeping && a.state !== 'CHATTING';
                    const bCanYield = !b.isSleeping && b.state !== 'CHATTING';

                    if (a.isMoving && !b.isMoving && bCanYield && b.collisionStallTimer > 0.3) {
                        this._tryYieldNPC(b, a, map);
                    } else if (b.isMoving && !a.isMoving && aCanYield && a.collisionStallTimer > 0.3) {
                        this._tryYieldNPC(a, b, map);
                    } else if (a.isMoving && b.isMoving) {
                        if (a.collisionStallTimer > 1.0 && b.collisionStallTimer > 1.0) {
                            const aRemain = a.currentPath.length - a.pathIndex;
                            const bRemain = b.currentPath.length - b.pathIndex;
                            if (aRemain > bRemain && aCanYield) { this._tryYieldNPC(a, b, map); }
                            else if (bCanYield) { this._tryYieldNPC(b, a, map); }
                        }
                        if (!isIndoor && a.collisionStallTimer > 2.5 && b.collisionStallTimer > 2.5) {
                            const aProtected = a.isEating || a.isSleeping || a._isBeingTreated || a._currentBehaviorLock;
                            const bProtected = b.isEating || b.isSleeping || b._isBeingTreated || b._currentBehaviorLock;
                            if (aProtected && bProtected) {
                                if (a.collisionStallTimer > 10) {
                                    console.warn(`[碰撞警告] ${a.name} 和 ${b.name} 双方都有行为锁，无法脱困`);
                                }
                            } else {
                                const teleported = this._forceUnstuck(a, b, map);
                                if (teleported) {
                                    console.log(`[碰撞脱困] ${a.name} 和 ${b.name} 碰撞死锁${a.collisionStallTimer.toFixed(1)}秒，强制脱困`);
                                }
                            }
                        }
                    }

                    if (a.collisionStallTimer > 1.5 && a.isCrazy) { this._forceCrazyEscape(a, map); }
                    if (b.collisionStallTimer > 1.5 && b.isCrazy) { this._forceCrazyEscape(b, map); }

                    if (!isIndoor && !a.isMoving && !b.isMoving && a.state !== 'CHATTING' && b.state !== 'CHATTING'
                        && !a.isSleeping && !b.isSleeping && !a.isEating && !b.isEating) {
                        const aHasLock = a._currentBehaviorLock;
                        const bHasLock = b._currentBehaviorLock;
                        const nudgeScale = (aHasLock || bHasLock) ? 0.1 : 1.0;
                        const nudge = GST.TILE * 0.3 * nudgeScale;
                        const angle = Math.random() * Math.PI * 2;
                        const nudgeX = Math.cos(angle) * nudge;
                        const nudgeY = Math.sin(angle) * nudge;
                        // 【v5.4修复】nudge也检查4角点
                        if (!bHasLock && (!map || !this._isPosSolid(b.x + nudgeX, b.y + nudgeY, map))) {
                            b.x += nudgeX; b.y += nudgeY;
                        } else if (!aHasLock && (!map || !this._isPosSolid(a.x - nudgeX, a.y - nudgeY, map))) {
                            a.x -= nudgeX; a.y -= nudgeY;
                        }
                        if (aHasLock && bHasLock && a.collisionStallTimer > 10) {
                            console.warn(`[碰撞警告] ${a.name} 和 ${b.name} 双方都有行为锁，无法脱困`);
                        }
                        if (a.collisionStallTimer > 3.0 && b.collisionStallTimer > 3.0) {
                            const aProtected = a._isBeingTreated || a._currentBehaviorLock;
                            const bProtected = b._isBeingTreated || b._currentBehaviorLock;
                            if (!(aProtected && bProtected)) {
                                this._forceUnstuck(a, b, map);
                                console.log(`[碰撞脱困] ${a.name} 和 ${b.name} 双静止死锁，强制脱困`);
                            }
                        }
                    }
                }
            }
        }
    };

    proto._forceUnstuck = function(a, b, map) {
        const aProtected = a.isEating || a.isSleeping || a._isBeingTreated;
        const bProtected = b.isEating || b.isSleeping || b._isBeingTreated;
        const aHasLock = !!a._currentBehaviorLock;
        const bHasLock = !!b._currentBehaviorLock;
        if (aProtected && bProtected) { console.log(`[碰撞脱困] ${a.name} 和 ${b.name} 双方都在保护状态，跳过传送`); return false; }
        if (aHasLock && bHasLock) { console.log(`[碰撞脱困] ${a.name} 和 ${b.name} 双方都有行为锁，跳过传送`); return false; }

        let toMove = b, other = a;
        if (aProtected && !bProtected) { toMove = b; other = a; }
        else if (bProtected && !aProtected) { toMove = a; other = b; }
        else if (aHasLock && !bHasLock) { toMove = b; other = a; }
        else if (bHasLock && !aHasLock) { toMove = a; other = b; }
        else if (a.isCrazy && !b.isCrazy) { toMove = a; other = b; }
        else if (!a.isMoving && b.isMoving) { toMove = a; other = b; }
        else if (a.currentPath.length < b.currentPath.length) { toMove = a; other = b; }

        if (toMove.isEating || toMove.isSleeping || toMove._isBeingTreated) {
            console.log(`[碰撞脱困] ${toMove.name} 处于保护状态，拒绝传送`); return false;
        }

        const gx = Math.floor((toMove.x + GST.TILE / 2) / GST.TILE);
        const gy = Math.floor((toMove.y + GST.TILE / 2) / GST.TILE);
        const candidates = [];
        for (let r = 1; r <= 2; r++) {
            for (let dx = -r; dx <= r; dx++) {
                for (let dy = -r; dy <= r; dy++) {
                    if (Math.abs(dx) !== r && Math.abs(dy) !== r) continue;
                    const nx = gx + dx, ny = gy + dy;
                    if (map && !map.isSolid(nx * GST.TILE + GST.TILE / 2, ny * GST.TILE + GST.TILE / 2)) {
                        const ox = Math.floor((other.x + GST.TILE / 2) / GST.TILE);
                        const oy = Math.floor((other.y + GST.TILE / 2) / GST.TILE);
                        if (Math.abs(nx - ox) > 1 || Math.abs(ny - oy) > 1) {
                            candidates.push({ x: nx, y: ny });
                        }
                    }
                }
            }
            if (candidates.length > 0) break;
        }

        if (candidates.length > 0) {
            const target = candidates[Math.floor(Math.random() * candidates.length)];
            toMove.x = target.x * GST.TILE;
            toMove.y = target.y * GST.TILE;
            toMove.collisionStallTimer = 0;
            toMove.stuckTimer = 0;
            toMove.currentPath = [];
            toMove.pathIndex = 0;
            toMove.isMoving = false;
            toMove._yieldMove = null;
            toMove._unstuckRecovery = true;
            other.collisionStallTimer = 0;
            other.stuckTimer = 0;
            if (toMove._logDebug) toMove._logDebug('collision', `与${other.name}碰撞死锁，被传送到(${target.x},${target.y})脱困`);
            if (other._logDebug) other._logDebug('collision', `与${toMove.name}碰撞死锁，对方被传送脱困`);
            return true;
        }
        return false;
    };

    proto._forceCrazyEscape = function(npc, map) {
        if (!map || !npc.isCrazy) return;
        if (npc._priorityOverride === 'crazy_emergency') return;
        const pos = npc.getGridPos();
        const angle = Math.random() * Math.PI * 2;
        const dist = 5 + Math.floor(Math.random() * 4);
        const tx = Math.max(0, Math.min(map.cols - 1, pos.x + Math.round(Math.cos(angle) * dist)));
        const ty = Math.max(0, Math.min(map.rows - 1, pos.y + Math.round(Math.sin(angle) * dist)));
        if (!map.isSolid(tx * GST.TILE + GST.TILE / 2, ty * GST.TILE + GST.TILE / 2)) {
            npc.currentPath = GST.findPath(pos.x, pos.y, tx, ty, map) || [];
            npc.pathIndex = 0;
            npc.collisionStallTimer = 0;
            npc.stuckTimer = 0;
            if (npc.currentPath.length > 0) {
                npc.isMoving = true;
                npc.state = 'WALKING';
                if (npc._logDebug) npc._logDebug('collision', `发疯碰撞逃逸→(${tx},${ty})，路径${npc.currentPath.length}步`);
            }
        }
    };

    proto._tryYieldNPC = function(yielder, mover, map) {
        if (yielder._yieldMove) return;
        const gx = Math.floor((yielder.x + GST.TILE / 2) / GST.TILE);
        const gy = Math.floor((yielder.y + GST.TILE / 2) / GST.TILE);
        const mgx = Math.floor((mover.x + GST.TILE / 2) / GST.TILE);
        const mgy = Math.floor((mover.y + GST.TILE / 2) / GST.TILE);
        const mdx = mgx - gx, mdy = mgy - gy;

        const candidates = [];
        if (Math.abs(mdx) >= Math.abs(mdy)) {
            candidates.push({ dx: 0, dy: -1 }, { dx: 0, dy: 1 }, { dx: -mdx, dy: 0 });
        } else {
            candidates.push({ dx: -1, dy: 0 }, { dx: 1, dy: 0 }, { dx: 0, dy: -mdy });
        }
        candidates.push({ dx: -1, dy: -1 }, { dx: 1, dy: -1 }, { dx: -1, dy: 1 }, { dx: 1, dy: 1 });

        for (const c of candidates) {
            const nx = gx + c.dx, ny = gy + c.dy;
            if (map && !map.isSolid(nx * GST.TILE + GST.TILE / 2, ny * GST.TILE + GST.TILE / 2)) {
                yielder._yieldMove = { x: nx, y: ny };
                yielder._yieldTimer = 0;
                yielder.collisionStallTimer = 0;
                if (yielder.currentPath.length > 0 && !yielder._savedPath) {
                    yielder._savedPath = { path: [...yielder.currentPath], index: yielder.pathIndex };
                }
                return;
            }
        }
        yielder.collisionStallTimer = 0;
    };

    proto._computeBubbleOffsets = function(sceneNPCs, minDist) {
        for (const npc of sceneNPCs) { npc._bubbleOffset = 0; }
        for (let i = 0; i < sceneNPCs.length; i++) {
            let overlapCount = 0;
            for (let j = 0; j < sceneNPCs.length; j++) {
                if (i === j) continue;
                const dx = sceneNPCs[j].x - sceneNPCs[i].x;
                const dy = sceneNPCs[j].y - sceneNPCs[i].y;
                if (Math.abs(dx) < minDist && Math.abs(dy) < minDist) overlapCount++;
            }
            sceneNPCs[i]._bubbleOffset = overlapCount > 0 ? (i % 2 === 0 ? -12 : 12) * overlapCount : 0;
        }
    };

    // 【v5.4新增】检查NPC碰撞框4个角点是否有任何一个在实体区域内
    proto._isNPCInSolid = function(npc, map) {
        const margin = 2; // 留2px边距，避免贴边判定
        const x = npc.x + margin;
        const y = npc.y + margin;
        const w = (npc.width || GST.TILE) - margin * 2;
        const h = (npc.height || GST.TILE) - margin * 2;
        // 检查4个角 + 中心
        return map.isSolid(x, y)                 // 左上
            || map.isSolid(x + w, y)             // 右上
            || map.isSolid(x, y + h)             // 左下
            || map.isSolid(x + w, y + h)         // 右下
            || map.isSolid(x + w / 2, y + h / 2); // 中心
    };

    // 【v5.4新增】检查指定像素坐标处NPC碰撞框是否在实体区域内
    proto._isPosSolid = function(px, py, map) {
        const margin = 2;
        const x = px + margin;
        const y = py + margin;
        const w = GST.TILE - margin * 2;
        const h = GST.TILE - margin * 2;
        return map.isSolid(x, y)
            || map.isSolid(x + w, y)
            || map.isSolid(x, y + h)
            || map.isSolid(x + w, y + h)
            || map.isSolid(x + w / 2, y + h / 2);
    };

})();
