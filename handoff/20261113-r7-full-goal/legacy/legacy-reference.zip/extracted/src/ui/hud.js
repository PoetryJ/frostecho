/**
 * 福音镇 - HUD / UI 面板
 * 侧边栏、NPC详情面板、资源面板、事件日志、轮回UI、Toast
 * 通过 mixin 模式挂载到 Game.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.Game.prototype;
    // [已拆分到 hud-npc-detail.js / hud-debug.js / hud-council.js] _closeNPCDetail
    // ---- 保存 Debug Log 到服务器 ----
    // 连续失败计数器：避免网络断开时刷屏报错
    proto._debugLogFailCount = 0;
    proto._debugLogMaxFails = 3; // 连续失败3次后暂停自动保存

    proto._saveDebugLogToServer = async function(quiet = false) {
        // 【v4.42修复】quiet模式下，连续失败超过阈值则静默跳过，不再尝试
        if (quiet && this._debugLogFailCount >= this._debugLogMaxFails) {
            return; // 静默跳过，等待手动触发或网络恢复
        }
        try {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
            const dayStr = `day${this.dayCount}`;
            const filename = `debug_${dayStr}_${timestamp}.log`;

            // ============ 1. 头部元信息 ============
            let content = `=== 福音镇 Debug Log ===\n`;
            content += `时间: ${new Date().toLocaleString()}\n`;
            content += `游戏日: 第${this.dayCount}天 ${this.getTimeStr()}\n`;
            content += `模式: ${this.mode}\n`;
            content += `模型: ${GST.LLM ? GST.LLM.model : '未知'}\n`;
            content += `LLM状态: 总调用${typeof LLM_STATUS !== 'undefined' ? LLM_STATUS.totalCalls : '?'} 成功${typeof LLM_STATUS !== 'undefined' ? LLM_STATUS.successCalls : '?'} 失败${typeof LLM_STATUS !== 'undefined' ? LLM_STATUS.failedCalls : '?'}\n`;

            // 天气信息
            if (this.weatherSystem) {
                const ws = this.weatherSystem;
                const outdoorTemp = typeof ws.getOutdoorTemp === 'function' ? ws.getOutdoorTemp() : ws.currentTemp;
                content += `天气: ${ws.weatherEmoji || ''} ${ws.currentWeather || '未知'} 室外:${outdoorTemp != null ? outdoorTemp + '°C' : '?'} 风偏移:${ws.windOffset || 0}\n`;
            }
            content += `${'='.repeat(60)}\n\n`;

            // ============ 2. 全局资源摘要 ============
            content += `【资源状态】\n`;
            const rs = this.resourceSystem;
            if (rs) {
                content += `  🪵木柴: ${Math.round(rs.woodFuel)} | 🍞食物: ${Math.round(rs.food)} | ⚡电力: ${Math.round(rs.power)}\n`;
                content += `  💊急救包: ${this._medkitCount || 0}\n`;
                const dc = rs.dailyConsumed || {};
                const dg = rs.dailyCollected || {};
                content += `  今日消耗: 木柴${(dc.woodFuel || 0).toFixed(1)} 食物${(dc.food || 0).toFixed(1)} 电力${(dc.power || 0).toFixed(1)}\n`;
                content += `  今日采集: 木柴${(dg.woodFuel || 0).toFixed(1)} 食物${(dg.food || 0).toFixed(1)} 电力${(dg.power || 0).toFixed(1)}\n`;
                // 资源预警
                const warnings = [];
                if (rs.food <= 0) warnings.push('🚨食物耗尽');
                else if (rs.getFoodMealsRemaining && rs.getFoodMealsRemaining() < 2) warnings.push('⚠️食物不足2餐');
                if (rs.woodFuel <= 0) warnings.push('🚨木柴耗尽');
                else if (rs.getWoodFuelHoursRemaining && rs.getWoodFuelHoursRemaining() < 2) warnings.push('⚠️木柴不足2小时');
                if (rs.power <= 0) warnings.push('🚨电力耗尽');
                if (warnings.length > 0) content += `  ⚠️ 资源预警: ${warnings.join(' ')}\n`;
            }
            // 暖炉/供暖状态
            const fs = this.furnaceSystem;
            if (fs) {
                const heatingPct = fs.heatingStrength != null ? Math.round(fs.heatingStrength * 100) + '%' : '?';
                content += `  🔥供暖: 强度${heatingPct} 室温${fs.indoorTemp != null ? fs.indoorTemp.toFixed(1) : '?'}°C\n`;
            }
            content += `\n`;

            // ============ 3. NPC 状态总览表（增强版） ============
            content += `【NPC 状态总览】\n`;
            content += `${'─'.repeat(60)}\n`;
            const aliveNpcs = [];
            const deadNpcs = [];
            for (const npc of this.npcs) {
                if (npc.isDead) { deadNpcs.push(npc); continue; }
                aliveNpcs.push(npc);
            }

            for (const npc of aliveNpcs) {
                // 基础属性行
                content += `【${npc.name}】${npc.occupation}\n`;
                content += `  属性: San:${Math.round(npc.sanity)} HP:${Math.round(npc.health)} 体力:${Math.round(npc.stamina)} 饱腹:${Math.round(npc.hunger)} 体温:${npc.bodyTemp != null ? npc.bodyTemp.toFixed(1) + '°C' : '?'}\n`;
                content += `  位置: ${npc.currentScene} (${Math.round(npc.x)},${Math.round(npc.y)})\n`;

                // 行为状态行（最关键的调试信息）
                const stateFlags = [];
                if (npc.isCrazy) stateFlags.push('🤯发疯');
                if (npc.isSleeping) stateFlags.push('😴睡觉');
                if (npc.isEating) stateFlags.push('🍜吃饭');
                if (npc.isMoving) stateFlags.push('🚶移动中');
                if (npc._isBeingTreated) stateFlags.push('🏥治疗中');
                if (npc._isDying) stateFlags.push('💀濒死');
                if (npc._rescueNeeded) stateFlags.push('🆘需救援');
                if (npc._hungerOverride) stateFlags.push('🍽️饥饿覆盖');
                if (npc._resourceGatherOverride) stateFlags.push('⛏️采集覆盖');
                content += `  ${GST.t('hud_status.label_state')}: ${npc.state} | ${stateFlags.length > 0 ? stateFlags.join(' ') : GST.t('hud_status.label_normal')} | ${GST.t('hud_status.label_mood')}:${npc.mood}\n`;
                content += `  ${GST.t('hud_status.label_desc')}: ${npc.stateDesc || GST.t('hud_status.none')}\n`;

                // 决策控制层（P0/stateOverride/taskOverride/actionOverride）
                const controls = [];
                if (npc._priorityOverride) controls.push(`P0:${npc._priorityOverride}`);
                if (npc._stateOverride) controls.push(`stateOverride:${npc._stateOverride}`);
                if (npc._taskOverride && npc._taskOverride.isActive) {
                    controls.push(`task:${npc._taskOverride.taskId || '?'}(${npc._taskOverride.priority || 'normal'})`);
                    if (npc._taskOverride.targetLocation) controls.push(`→${npc._taskOverride.targetLocation}`);
                }
                if (npc._actionOverride) controls.push(`actionOverride:${npc._actionTarget || '?'}`);
                if (npc._hungerOverride) controls.push(`hungerOverride→${npc._hungerTarget || '?'}`);
                content += `  ${GST.t('hud_status.label_controls')}: ${controls.length > 0 ? controls.join(' | ') : GST.t('hud_status.label_no_override')}\n`;

                // 移动状态
                const pathLen = (npc.currentPath && npc.currentPath.length) || 0;
                const schedTarget = npc._scheduleNavTarget || GST.t('hud_status.none');
                content += `  ${GST.t('hud_status.label_moving')}: ${npc.isMoving ? GST.t('hud_status.label_moving_yes') : GST.t('hud_status.label_moving_no')} ${GST.t('hud_status.label_path_remain')}:${pathLen}${GST.t('hud_status.label_steps')} ${GST.t('hud_status.label_sched_target')}:${schedTarget}\n`;

                // 最近决策（最近3条 _debugLog 中 type=think/action/schedule 的）
                if (npc._debugLog && npc._debugLog.length > 0) {
                    const recentDecisions = npc._debugLog
                        .filter(e => ['think', 'action', 'schedule', 'override', 'goal'].includes(e.type))
                        .slice(0, 5);
                    if (recentDecisions.length > 0) {
                        content += `  最近决策:\n`;
                        recentDecisions.forEach(e => {
                            const dayPrefix = e.day !== undefined ? `D${e.day} ` : '';
                            content += `    [${dayPrefix}${e.time}] ${e.type}: ${e.detail}\n`;
                        });
                    }
                }

                content += `${'─'.repeat(60)}\n`;
            }

            // 已故NPC简要列出
            if (deadNpcs.length > 0) {
                content += `\n【已故】`;
                deadNpcs.forEach(npc => {
                    content += ` ${npc.name}(${npc.currentScene} ${Math.round(npc.x)},${Math.round(npc.y)})`;
                });
                content += `\n`;
            }

            // ============ 4. 异常/告警汇总（从 aiModeLogger 提取） ============
            if (this.aiModeLogger && this.aiModeLogger._recentAnomalies) {
                const anomalies = this.aiModeLogger._recentAnomalies;
                if (anomalies.length > 0) {
                    content += `\n${'='.repeat(60)}\n`;
                    content += `【异常/告警】(最近${Math.min(20, anomalies.length)}条)\n`;
                    anomalies.slice(0, 20).forEach(a => {
                        content += `  ${a}\n`;
                    });
                }
            }

            // ============ 5. 事件日志（精简版，只保留关键事件） ============
            content += `\n${'='.repeat(60)}\n`;
            content += `【事件日志】(最近${Math.min(50, this.eventLog.length)}条)\n`;
            this.eventLog.slice(0, 50).forEach(e => {
                content += `  [${e.time}] ${e.text}\n`;
            });

            // ============ 6. NPC 完整行动轨迹（每人最近20条，含所有类型） ============
            content += `\n${'='.repeat(60)}\n`;
            content += `【NPC 完整行动轨迹】\n`;
            for (const npc of aliveNpcs) {
                if (npc._debugLog && npc._debugLog.length > 0) {
                    content += `  --- ${npc.name} (最近${Math.min(20, npc._debugLog.length)}条) ---\n`;
                    npc._debugLog.slice(0, 20).forEach(e => {
                        const dayPrefix = e.day !== undefined ? `D${e.day} ` : '';
                        // 用标记区分决策类和普通类，方便快速扫描
                        const isDecision = ['think', 'action', 'schedule', 'override', 'goal'].includes(e.type);
                        const marker = isDecision ? '⚡' : '  ';
                        content += `  ${marker}[${dayPrefix}${e.time}] ${e.type}: ${e.detail}\n`;
                    });
                }
            }

            // 注意：聊天记录面板内容不再写入debug log（那是UI展示内容，不是调试信息）

            // 发送到服务器
            const resp = await fetch('/api/save-debug-log', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ filename, content })
            });

            if (resp.ok) {
                const result = await resp.json();
                this._debugLogFailCount = 0; // 成功，重置失败计数
                console.log(`📝 Debug log 已保存: ${result.filename}`);
                if (!quiet) {
                    this.addEvent(GST.t('debug.log_saved', { filename }));
                }
            } else {
                throw new Error(`HTTP ${resp.status}`);
            }
        } catch (err) {
            this._debugLogFailCount = (this._debugLogFailCount || 0) + 1;
            // 【v4.42修复】quiet模式下只在首次失败时打印警告，避免刷屏
            if (!quiet) {
                console.warn('保存debug log失败:', err.message);
                this._downloadDebugLog();
            } else if (this._debugLogFailCount <= 1) {
                console.warn(`[Debug Log] 自动保存失败(${this._debugLogFailCount}/${this._debugLogMaxFails}):`, err.message);
            } else if (this._debugLogFailCount === this._debugLogMaxFails) {
                console.warn(`[Debug Log] 连续失败${this._debugLogMaxFails}次，暂停自动保存。手动点击保存按钮可重新尝试。`);
            }
        }
    }

    // 降级方案：浏览器下载debug log;

    proto._renderEventLog = function() {
        const el = document.getElementById('event-log');
        if (!el) return;
        el.innerHTML = this.eventLog.slice(0, 30).map(e =>
            `<div class="event-item"><span class="event-time">${e.time}</span> ${e.text}</div>`
        ).join('');
    }
    // [已拆分到 hud-npc-detail.js / hud-debug.js / hud-council.js] _renderMemoryTab
    proto._setupSidebar = function() {
        const list = document.getElementById('agent-list');
        for (const npc of this.npcs) {
            const card = document.createElement('div');
            card.className = 'agent-card';
            card.id = `agent-card-${npc.id}`;
            card.innerHTML = `
                <div class="agent-card-header">
                    <span class="agent-dot" style="background:${npc.color}"></span>
                    <span class="agent-name">${npc.displayName || npc.name}</span>
                    <span class="agent-mood" id="mood-${npc.id}">😊</span>
                </div>
                <div class="agent-status" id="status-${npc.id}">${npc.displayOccupation || npc.occupation} · ${npc.stateDesc}</div>
                <div class="agent-attrs-mini" id="attrs-${npc.id}"></div>
                <div class="agent-thought" id="thought-${npc.id}"></div>
            `;
            card.addEventListener('click', () => this._openNPCDetail(npc));
            list.appendChild(card);
        }
        // 详情面板事件绑定
        this._setupNPCDetailPanel();
    }

    /** 更新侧边栏信息 */;

    proto._showPastLivesPanel = function() {
        const overlay = document.getElementById('past-lives-overlay');
        const body = document.getElementById('past-lives-body');
        const closeBtn = document.getElementById('past-lives-close');
        if (!overlay || !body) return;

        const rs = this.reincarnationSystem;
        if (!rs) return;

        const pastLives = rs.pastLives || [];
        const currentLife = rs.getLifeNumber();

        // 结局类型映射
        const t = GST.t;
        const endingMap = {
            perfect: { text: t('past_lives_panel.ending_perfect'), cls: 'perfect' },
            normal:  { text: t('past_lives_panel.ending_normal'), cls: 'normal' },
            bleak:   { text: t('past_lives_panel.ending_bleak'), cls: 'bleak' },
            extinction: { text: t('past_lives_panel.ending_extinction'), cls: 'extinction' },
            unknown: { text: t('past_lives_panel.ending_unknown'), cls: 'unknown' },
        };

        let html = '';

        if (pastLives.length === 0) {
            html = `
                <div class="past-lives-empty">
                    <span class="past-lives-empty-icon">📜</span>
                    ${t('past_lives_panel.empty_text')}<br>
                    <span style="font-size:11px; opacity:0.6; margin-top:8px; display:inline-block;">
                        ${t('past_lives_panel.empty_hint')}
                    </span>
                </div>
            `;
        } else {
            // 从最近的世代开始显示
            for (let i = pastLives.length - 1; i >= 0; i--) {
                const life = pastLives[i];
                const ending = endingMap[life.endingType] || endingMap.unknown;
                const lifeNum = life.lifeNumber || (i + 1);

                // 存活统计
                const aliveCount = life.aliveCount || 0;
                const deadCount = life.deadCount || (8 - aliveCount);

                // 资源快照
                const res = life.resourceSnapshot;
                let resHtml = '';
                if (res) {
                    resHtml = `
                        <div class="past-life-stats">
                            <span class="past-life-stat">🪵 <span class="past-life-stat-val">${res.woodFuel}</span></span>
                            <span class="past-life-stat">🍞 <span class="past-life-stat-val">${res.food}</span></span>
                            <span class="past-life-stat">⚡ <span class="past-life-stat-val">${res.power}</span></span>
                <span class="past-life-stat">🔍 <span class="past-life-stat-val">${t('past_lives_panel.explore_label')}</span></span>
                <span class="past-life-stat">${t('past_lives_panel.heating_label')} <span class="past-life-stat-val">${life.heatingStrength !== undefined ? Math.round(life.heatingStrength * 100) + '%' : '—'}</span></span>
                        </div>
                    `;
                }

                // 死亡记录
                let deathHtml = '';
                if (life.deathRecords && life.deathRecords.length > 0) {
                    deathHtml = '<div class="past-life-deaths">';
                    for (const d of life.deathRecords) {
                        const dName = GST.i18n.translateNpcName(d.name) || d.name;
                        const dCause = GST.i18n.translateDeathCause(d.cause) || d.cause;
                        const dTime = GST.i18n.translateTimePeriod(d.time) || d.time || '';
                        deathHtml += `<div class="past-life-death-item">${t('past_lives_panel.death_record', { name: dName, day: d.day, time: dTime, cause: dCause })}${d.location ? ' (' + d.location + ')' : ''}</div>`;
                    }
                    deathHtml += '</div>';
                }

                // 教训
                let lessonHtml = '';
                if (life.lessons && life.lessons.length > 0) {
                    lessonHtml = '<div class="past-life-lessons">';
                    for (const l of life.lessons) {
                        lessonHtml += `<div class="past-life-lesson-item">${l}</div>`;
                    }
                    lessonHtml += '</div>';
                }

                html += `
                    <div class="past-life-card">
                        <div class="past-life-card-header">
                            <span class="past-life-num">${t('past_lives_panel.life_n', { n: lifeNum })}</span>
                            <span class="past-life-ending ${ending.cls}">${ending.text}</span>
                        </div>
                        <div class="past-life-stats">
                            <span class="past-life-stat">👥 <span class="past-life-stat-val">${t('past_lives_panel.alive_n', { n: aliveCount })}</span></span>
                            <span class="past-life-stat">💀 <span class="past-life-stat-val">${t('past_lives_panel.dead_n', { n: deadCount })}</span></span>
                        </div>
                        ${resHtml}
                        ${deathHtml}
                        ${lessonHtml}
                    </div>
                `;
            }

            // 末尾加当前世提示
            html += `
                <div class="past-life-card past-life-current">
                    <div class="past-life-card-header">
                        <span class="past-life-num">${t('past_lives_panel.life_n', { n: currentLife })}${t('past_lives_panel.current')}</span>
                        <span class="past-life-ending unknown">${t('past_lives_panel.in_progress')}</span>
                    </div>
                    <div style="font-size:12px; color:rgba(200,210,220,0.5); padding:4px 0;">
                        ${t('past_lives_panel.in_progress_hint')}
                    </div>
                </div>
            `;
        }

        body.innerHTML = html;
        overlay.style.display = 'flex';

        // 关闭逻辑
        const closeFn = () => { overlay.style.display = 'none'; };
        closeBtn.onclick = closeFn;
        overlay.onclick = (e) => {
            if (e.target === overlay) closeFn();
        };
    }

    // ---- 存档 ----;

    proto._showToast = function(msg) {
        const el = document.getElementById('save-toast');
        el.textContent = msg;
        el.style.display = 'block';
        el.style.opacity = '1';
        setTimeout(() => {
            el.style.opacity = '0';
            setTimeout(() => { el.style.display = 'none'; }, 300);
        }, 1200);
    }

    // ---- 工具方法 ----;

    proto._updateReincarnationUI = function() {
        const el = document.getElementById('surv-reincarnation');
        if (!el) return;
        // 轮回模式下始终显示当前世数（包括第1世），agent/debug模式隐藏
        if (this.mode === 'reincarnation' && this.reincarnationSystem) {
            el.style.display = '';
            el.title = t('hud.reincarnation_click_hint');
            const valEl = document.getElementById('surv-reincarnation-val');
            const lifeNum = this.reincarnationSystem.getLifeNumber();
            if (valEl) valEl.textContent = t('hud.reincarnation_n', { n: lifeNum });

            // 绑定点击事件（只绑一次）
            if (!el._pastLivesClickBound) {
                el._pastLivesClickBound = true;
                el.addEventListener('click', () => this._showPastLivesPanel());
            }
        } else {
            el.style.display = 'none';
        }

        // 【难度系统】更新难度状态栏显示
        const diffEl = document.getElementById('surv-difficulty');
        if (diffEl) {
            if (this.mode === 'reincarnation' && this.difficulty) {
                diffEl.style.display = '';
                const diffValEl = document.getElementById('surv-difficulty-val');
                if (diffValEl) {
                    const diffName = GST.i18n.isEn() ? this.difficulty.nameEn || this.difficulty.name : this.difficulty.name;
                    diffValEl.textContent = `${this.difficulty.stars} ${diffName}`;
                }
                // 悬停提示显示核心倍率参数
                const d = this.difficulty;
                const diffName = _isEn ? (d.nameEn || d.name) : d.name;
                diffEl.title = _isEn
                    ? `Difficulty: ${d.stars} ${diffName}\nConsumption: Wood×${d.consumptionMult.wood} Power×${d.consumptionMult.power} Food×${d.consumptionMult.food}\nInitial Resources: ×${d.initialResources.woodFuel}\nGather Efficiency: ×${d.gatherEfficiencyMult}\nDecay Rate: Hunger×${d.hungerDecayMult} Stamina×${d.staminaDrainMult} San×${d.sanDecayMult}\nTemp Offset: -${d.tempOffset}°C\nReincarnation Buff: ×${d.reincarnationBuffMult}`
                    : `难度: ${d.stars} ${d.name}\n消耗倍率: 木柴×${d.consumptionMult.wood} 电力×${d.consumptionMult.power} 食物×${d.consumptionMult.food}\n初始资源: ×${d.initialResources.woodFuel}\n采集效率: ×${d.gatherEfficiencyMult}\n属性衰减: 饱腹×${d.hungerDecayMult} 体力×${d.staminaDrainMult} San×${d.sanDecayMult}\n温度偏移: -${d.tempOffset}°C\n轮回Buff: ×${d.reincarnationBuffMult}`;
            } else {
                diffEl.style.display = 'none';
            }
        }
    }

    /** 显示往世结局弹窗 */;

    proto._updateResBar = function(fillId, valId, current, max) {
        const fill = document.getElementById(fillId);
        const val = document.getElementById(valId);
        if (fill) fill.style.width = `${Math.min(100, (current / max) * 100)}%`;
        if (val) {
            const rounded = Math.round(current);
            const prevKey = `_prevRes_${valId}`;
            const prev = this[prevKey];
            if (prev !== undefined && prev !== rounded) {
                // 移除旧的动画class再添加新的
                val.classList.remove('res-increase', 'res-decrease');
                // 强制reflow以重新触发动画
                void val.offsetWidth;
                val.classList.add(rounded > prev ? 'res-increase' : 'res-decrease');
                // 1秒后移除动画class
                clearTimeout(this[`_resTimer_${valId}`]);
                this[`_resTimer_${valId}`] = setTimeout(() => {
                    val.classList.remove('res-increase', 'res-decrease');
                }, 1000);
            }
            this[prevKey] = rounded;
            val.textContent = rounded;
        }
    };

    proto._updateSidebar = function() {
        const t = GST.t;
        const _isEn = GST.i18n && GST.i18n.isEn();

        // tooltip helper — 根据语言生成机器tooltip
        const machineTooltip = (icon, name, lines) => `${icon} ${name}\n${lines.join('\n')}`;
        const _l = (zh, en) => _isEn ? en : zh;
        // 时间
        const ws = this.weatherSystem;
        document.getElementById('sidebar-time').textContent =
            `${t('hud.day_n', { n: this.dayCount })} ${this.getTimeStr()} ${ws ? ws.weatherEmoji : ''} ${GST.i18n.translateWeather(this.weather)}`;

        // ============ 生存状态栏更新 ============
        const survDayEl = document.getElementById('surv-day-val');
        const survTempEl = document.getElementById('surv-temp-val');
        const survWeatherEl = document.getElementById('surv-weather-val');
        const survWeatherIcon = document.getElementById('surv-weather-icon');
        const survAliveEl = document.getElementById('surv-alive-val');
        const survFurnaceEl = document.getElementById('surv-furnace-val');

        if (survDayEl) survDayEl.textContent = t('hud.day_n', { n: this.dayCount });

        // ============ 结算状态更新 ============
        const lockEl = document.getElementById('surv-settlement-lock');
        const lockValEl = document.getElementById('surv-lock-val');
        if (lockEl && lockValEl) {
            const gameHour = this.getHour ? this.getHour() : 0;
            const settled = this._lastSettlementDay === this.dayCount;
            if (settled) {
                // 今天已结算
                lockEl.style.display = '';
                lockValEl.textContent = t('hud.settlement_done');
                lockValEl.style.color = '#6BC98A';
                lockEl.title = `Day ${this.dayCount} settled at 21:00`;
            } else if (gameHour < 21) {
                // 还未到结算时间
                const hoursLeft = 21 - gameHour;
                lockEl.style.display = '';
                lockValEl.textContent = t('hud.settlement_hours', { n: hoursLeft });
                lockValEl.style.color = '#f0c050';
                lockEl.title = `Day ${this.dayCount} settlement at 21:00`;
            } else {
                lockEl.style.display = 'none';
            }
        }

        if (ws) {
            const temp = ws.getEffectiveTemp();
            if (survTempEl) {
                survTempEl.textContent = `${temp}°C`;
                survTempEl.className = 'surv-value' + (temp <= -30 ? ' danger' : temp < 0 ? ' cold' : '');
            }
        if (survWeatherEl) survWeatherEl.textContent = GST.i18n.translateWeather(ws.currentWeather);
            if (survWeatherIcon) survWeatherIcon.textContent = ws.weatherEmoji;
        }
        const aliveCount = this.npcs.filter(n => !n.isDead).length;
        if (survAliveEl) {
            survAliveEl.textContent = `${aliveCount}/8`;
            survAliveEl.className = 'surv-value' + (aliveCount <= 4 ? ' danger' : '');
        }
        if (survFurnaceEl && this.furnaceSystem) {
            const fs = this.furnaceSystem;
            const pct = Math.round(fs.heatingStrength * 100);
            const label = GST.i18n.translateFurnaceLevel(fs.getHeatingLevelLabel());
            survFurnaceEl.textContent = `${pct}%(${label})`;
            // 颜色提示：稳定=绿，吃紧=黄，危险/失效=红
            if (fs.heatingStatus === 'stable') {
                survFurnaceEl.className = 'surv-value';
            } else if (fs.heatingStatus === 'strained') {
                survFurnaceEl.className = 'surv-value cold';
            } else {
                survFurnaceEl.className = 'surv-value danger';
            }
        }

        // ============ 资源面板更新 ============
        const rs = this.resourceSystem;
        if (rs) {
            const maxWood = 120, maxFood = 80, maxPower = 120;
            this._updateResBar('res-wood-fill', 'res-wood-val', rs.woodFuel, maxWood);
            this._updateResBar('res-food-fill', 'res-food-val', rs.food, maxFood);
            this._updateResBar('res-power-fill', 'res-power-val', rs.power, maxPower);

            // 废墟探索次数显示
            const exploreRemaining = rs.getRuinsExploresRemaining ? rs.getRuinsExploresRemaining() : 3;
            const exploreMax = 3;
            const exploreFill = document.getElementById('res-explore-fill');
            const exploreVal = document.getElementById('res-explore-val');
            if (exploreFill) exploreFill.style.width = `${(exploreRemaining / exploreMax) * 100}%`;
            if (exploreVal) {
                exploreVal.textContent = `${exploreRemaining}/${exploreMax}`;
                exploreVal.style.color = exploreRemaining === 0 ? '#f87171' : '';
            }

            // 急救包数量显示
            const medkitVal = document.getElementById('res-medkit-val');
            if (medkitVal) {
                const count = this._medkitCount || 0;
                medkitVal.textContent = count;
                medkitVal.style.color = count === 0 ? '#f87171' : '';
            }
            // 急救包不足提示（每60秒最多提示一次）
            if (this._medkitCount <= 0) {
                const hasLowHpNpc = this.npcs.some(n => !n.isDead && n.health < 30);
                if (hasLowHpNpc) {
                    const now = Date.now();
                    if (!this._medkitLastWarnTime || (now - this._medkitLastWarnTime) >= 60000) {
                        this.addEvent(t('event.medkit_warning'));
                        this._medkitLastWarnTime = now;
                    }
                }
            } else {
                this._medkitLastWarnTime = 0;
            }
        }
        // ============ 自动化机器状态更新 ============
        if (this.machineSystem) {
            const ms = this.machineSystem;
            const cfg = GST.MACHINE_CONFIG;
            const canUnlockGen = ms.canUnlockGenerator();
            const canUnlockLum = ms.canUnlockLumberMill();
            const canUnlockFood = ms.canUnlockFoodCollector ? ms.canUnlockFoodCollector() : false;

            // --- 发电机 ---
            const genBar = document.getElementById('machine-generator-bar');
            const genFill = document.getElementById('machine-generator-fill');
            const genVal = document.getElementById('machine-generator-val');
            const showGen = ms.shouldShowGenerator ? ms.shouldShowGenerator() : (ms.generator.built || ms.generator.building || canUnlockGen);
            if (genBar) genBar.style.display = showGen ? '' : 'none';
            if (showGen && genFill && genVal) {
                if (ms.generator.building) {
                    // 建造中 — 进度条显示建造进度
                    const pct = Math.round(ms.generator.buildProgress * 100);
                    genFill.style.width = `${Math.max(pct, 3)}%`; // 最小3%宽度，确保可见
                    genFill.style.background = 'linear-gradient(90deg, #f59e0b, #fbbf24)';
                    genFill.classList.add('building');
                    genVal.textContent = t('machine.building', { pct, n: ms.generator.buildWorkers.length });
                    genVal.style.color = '#fbbf24';
                    genVal.classList.add('building-text');
                    genBar.title = _isEn
                        ? `⚡ Auto Generator building ${pct}%\nWorkers: ${ms.generator.buildWorkers.length}${ms.generator.buildPaused ? '\n⏸️ Paused (low wood)' : ''}`
                        : `⚡ 自动发电机建造中 ${pct}%\n工人: ${ms.generator.buildWorkers.length}人${ms.generator.buildPaused ? '\n⏸️ 已暂停（木柴不足）' : ''}`;
                } else if (ms.generator.built) {
                    // 已建成 — 进度条满格，显示效率
                    genFill.style.width = '100%';
                    genFill.classList.remove('building');
                    genVal.classList.remove('building-text');
                    if (ms.generator.broken) {
                        genFill.style.background = 'linear-gradient(90deg, #dc2626, #f87171)';
                        const repairPct = Math.round((ms.generator._repairProgress || 0) * 100);
                        genVal.textContent = repairPct > 0 ? t('machine.repair_progress', { pct: repairPct }) : t('machine.broken');
                        genVal.style.color = '#f87171';
                        genVal.classList.add('building-text');
                        genBar.title = _isEn
                            ? `⚡ Auto Generator BROKEN!\nRepair: ${repairPct}%\nNPC must repair at Workshop\nTotal produced: ${Math.round(ms.generator.totalProduced)}`
                            : `⚡ 自动发电机故障停机！\n维修进度: ${repairPct}%\n需要NPC在工坊维修\n累计产电: ${Math.round(ms.generator.totalProduced)}`;
                    } else if (ms.generator.running) {
                        genFill.style.background = 'linear-gradient(90deg, #4A90D9, #68B8FF)';
                        const c = cfg.generator;
                        genVal.textContent = t('machine.running_gen', { n: c.powerOutputPerHour });
                        genVal.style.color = '#34d399';
                        genBar.title = _isEn
                            ? `⚡ Auto Generator running\nOutput: Power +${c.powerOutputPerHour}/h\nConsumes: Wood -${c.woodConsumptionPerHour}/h\nTotal produced: ${Math.round(ms.generator.totalProduced)}\nTotal consumed: ${Math.round(ms.generator.totalConsumed)}`
                            : `⚡ 自动发电机运行中\n产出: 电力 +${c.powerOutputPerHour}/h\n消耗: 木柴 -${c.woodConsumptionPerHour}/h\n累计产电: ${Math.round(ms.generator.totalProduced)}\n累计耗柴: ${Math.round(ms.generator.totalConsumed)}`;
                    } else {
                        genFill.style.background = 'linear-gradient(90deg, #6b7280, #9ca3af)';
                        genVal.textContent = t('machine.stopped');
                        genVal.style.color = '#f87171';
                        genBar.title = _isEn
                            ? `⚡ Auto Generator stopped\nReason: Low wood (<${cfg.generator.minWoodToRun})\nTotal produced: ${Math.round(ms.generator.totalProduced)}`
                            : `⚡ 自动发电机已停机\n原因: 木柴不足（<${cfg.generator.minWoodToRun}）\n累计产电: ${Math.round(ms.generator.totalProduced)}`;
                    }
                } else if (canUnlockGen) {
                    // 已解锁但未建造 — 显示待建造状态
                    genFill.style.width = '0%';
                    genFill.style.background = 'linear-gradient(90deg, #6b7280, #9ca3af)';
                    genFill.classList.remove('building');
                    genVal.textContent = t('machine.not_built');
                    genVal.style.color = '#a78bfa';
                    genVal.classList.remove('building-text');
                    genBar.title = _isEn
                        ? `⚡ Auto Generator unlocked\nBuild cost: Power ${cfg.generator.buildMaterialCost} + Wood ${cfg.generator.buildWoodCost}\nBuild time: ${cfg.generator.buildTimeSeconds / 3600}h\nOutput: Power +${cfg.generator.powerOutputPerHour}/h, uses Wood ${cfg.generator.woodConsumptionPerHour}/h`
                        : `⚡ 自动发电机已解锁\n建造需要: 电力${cfg.generator.buildMaterialCost} + 木柴${cfg.generator.buildWoodCost}\n建造时间: ${cfg.generator.buildTimeSeconds / 3600}小时\n建成后: 产电${cfg.generator.powerOutputPerHour}/h，耗柴${cfg.generator.woodConsumptionPerHour}/h`;
                } else {
                    // 未解锁 — 灰色显示
                    genFill.style.width = '0%';
                    genFill.style.background = 'linear-gradient(90deg, #374151, #4b5563)';
                    genFill.classList.remove('building');
                    genVal.textContent = t('machine.locked');
                    genVal.style.color = '#6b7280';
                    genVal.classList.remove('building-text');
                    genBar.title = _isEn
                        ? `⚡ Auto Generator locked\nUnlock: Power >${cfg.generator.buildUnlockPower} (current ${Math.round(this.resourceSystem?.power || 0)})\nBuild cost: Power ${cfg.generator.buildMaterialCost} + Wood ${cfg.generator.buildWoodCost}`
                        : `⚡ 自动发电机未解锁\n解锁条件: 电力>${cfg.generator.buildUnlockPower}（当前${Math.round(this.resourceSystem?.power || 0)}）\n建造需要: 电力${cfg.generator.buildMaterialCost} + 木柴${cfg.generator.buildWoodCost}`;
                }
            }

            // --- 伐木机 ---
            const lumBar = document.getElementById('machine-lumber-bar');
            const lumFill = document.getElementById('machine-lumber-fill');
            const lumVal = document.getElementById('machine-lumber-val');
            const showLum = ms.shouldShowLumberMill ? ms.shouldShowLumberMill() : (ms.lumberMill.built || ms.lumberMill.building || canUnlockLum);
            if (lumBar) lumBar.style.display = showLum ? '' : 'none';
            if (showLum && lumFill && lumVal) {
                if (ms.lumberMill.building) {
                    const pct = Math.round(ms.lumberMill.buildProgress * 100);
                    lumFill.style.width = `${Math.max(pct, 3)}%`; // 最小3%宽度，确保可见
                    lumFill.style.background = 'linear-gradient(90deg, #f59e0b, #fbbf24)';
                    lumFill.classList.add('building');
                    lumVal.textContent = t('machine.building', { pct, n: ms.lumberMill.buildWorkers.length });
                    lumVal.style.color = '#fbbf24';
                    lumVal.classList.add('building-text');
                    lumBar.title = _isEn
                        ? `🪵 Auto Lumber Mill building ${pct}%\nWorkers: ${ms.lumberMill.buildWorkers.length}${ms.lumberMill.buildPaused ? '\n⏸️ Paused (low wood)' : ''}`
                        : `🪵 自动伐木机建造中 ${pct}%\n工人: ${ms.lumberMill.buildWorkers.length}人${ms.lumberMill.buildPaused ? '\n⏸️ 已暂停（木柴不足）' : ''}`;
                } else if (ms.lumberMill.built) {
                    lumFill.style.width = '100%';
                    lumFill.classList.remove('building');
                    lumVal.classList.remove('building-text');
                    if (ms.lumberMill.broken) {
                        lumFill.style.background = 'linear-gradient(90deg, #dc2626, #f87171)';
                        const repairPct = Math.round((ms.lumberMill._repairProgress || 0) * 100);
                        lumVal.textContent = repairPct > 0 ? t('machine.repair_progress', { pct: repairPct }) : t('machine.broken');
                        lumVal.style.color = '#f87171';
                        lumVal.classList.add('building-text');
                        lumBar.title = _isEn
                            ? `🪵 Auto Lumber Mill BROKEN!\nRepair: ${repairPct}%\nNPC must repair at Workshop\nTotal produced: ${Math.round(ms.lumberMill.totalProduced)}`
                            : `🪵 自动伐木机故障停机！\n维修进度: ${repairPct}%\n需要NPC在工坊维修\n累计产柴: ${Math.round(ms.lumberMill.totalProduced)}`;
                    } else if (ms.lumberMill.running) {
                        lumFill.style.background = 'linear-gradient(90deg, #8B5E3C, #C4863C)';
                        const c = cfg.lumberMill;
                        lumVal.textContent = t('machine.running_lum', { n: c.woodOutputPerHour });
                        lumVal.style.color = '#34d399';
                        lumBar.title = _isEn
                            ? `🪵 Auto Lumber Mill running\nOutput: Wood +${c.woodOutputPerHour}/h\nConsumes: Power -${c.powerConsumptionPerHour}/h\nTotal produced: ${Math.round(ms.lumberMill.totalProduced)}\nTotal consumed: ${Math.round(ms.lumberMill.totalConsumed)}`
                            : `🪵 自动伐木机运行中\n产出: 木柴 +${c.woodOutputPerHour}/h\n消耗: 电力 -${c.powerConsumptionPerHour}/h\n累计产柴: ${Math.round(ms.lumberMill.totalProduced)}\n累计耗电: ${Math.round(ms.lumberMill.totalConsumed)}`;
                    } else {
                        lumFill.style.background = 'linear-gradient(90deg, #6b7280, #9ca3af)';
                        lumVal.textContent = t('machine.stopped');
                        lumVal.style.color = '#f87171';
                        lumBar.title = `🪵 Lumber Mill stopped`;
                    }
                } else if (canUnlockLum) {
                    lumFill.style.width = '0%';
                    lumFill.style.background = 'linear-gradient(90deg, #6b7280, #9ca3af)';
                    lumFill.classList.remove('building');
                    lumVal.textContent = t('machine.not_built');                    lumVal.style.color = '#a78bfa';
                    lumVal.classList.remove('building-text');
                    lumBar.title = _isEn
                        ? `🪵 Auto Lumber Mill unlocked\nBuild cost: Power ${cfg.lumberMill.buildMaterialCost} + Wood ${cfg.lumberMill.buildWoodCost}\nBuild time: ${cfg.lumberMill.buildTimeSeconds / 3600}h\nOutput: Wood +${cfg.lumberMill.woodOutputPerHour}/h, uses Power ${cfg.lumberMill.powerConsumptionPerHour}/h`
                        : `🪵 自动伐木机已解锁\n建造需要: 电力${cfg.lumberMill.buildMaterialCost} + 木柴${cfg.lumberMill.buildWoodCost}\n建造时间: ${cfg.lumberMill.buildTimeSeconds / 3600}小时\n建成后: 产柴${cfg.lumberMill.woodOutputPerHour}/h，耗电${cfg.lumberMill.powerConsumptionPerHour}/h`;
                } else {
                    // 未解锁 — 灰色显示
                    lumFill.style.width = '0%';
                    lumFill.style.background = 'linear-gradient(90deg, #374151, #4b5563)';
                    lumFill.classList.remove('building');
                    lumVal.textContent = t('machine.locked');
                    lumVal.style.color = '#6b7280';
                    lumVal.classList.remove('building-text');
                    lumBar.title = _isEn
                        ? `🪵 Auto Lumber Mill locked\nUnlock: Wood >${cfg.lumberMill.buildUnlockWood} (current ${Math.round(this.resourceSystem?.woodFuel || 0)})\nBuild cost: Power ${cfg.lumberMill.buildMaterialCost} + Wood ${cfg.lumberMill.buildWoodCost}`
                        : `🪵 自动伐木机未解锁\n解锁条件: 木柴>${cfg.lumberMill.buildUnlockWood}（当前${Math.round(this.resourceSystem?.woodFuel || 0)}）\n建造需要: 电力${cfg.lumberMill.buildMaterialCost} + 木柴${cfg.lumberMill.buildWoodCost}`;
                }
            }

            // --- 捕猎机 ---
            const foodBar = document.getElementById('machine-food-bar');
            const foodFill = document.getElementById('machine-food-fill');
            const foodVal = document.getElementById('machine-food-val');
            const showFood = ms.shouldShowFoodCollector ? ms.shouldShowFoodCollector() : (ms.foodCollector.built || ms.foodCollector.building || canUnlockFood);
            if (foodBar) foodBar.style.display = showFood ? '' : 'none';
            if (showFood && foodFill && foodVal) {
                if (ms.foodCollector.building) {
                    const pct = Math.round(ms.foodCollector.buildProgress * 100);
                    foodFill.style.width = `${Math.max(pct, 3)}%`;
                    foodFill.style.background = 'linear-gradient(90deg, #f59e0b, #fbbf24)';
                    foodFill.classList.add('building');
                    foodVal.textContent = t('machine.building', { pct, n: ms.foodCollector.buildWorkers.length });
                    foodVal.style.color = '#fbbf24';
                    foodVal.classList.add('building-text');
                    foodBar.title = _isEn
                        ? `🍞 Auto Food Trap building ${pct}%\nWorkers: ${ms.foodCollector.buildWorkers.length}${ms.foodCollector.buildPaused ? '\n⏸️ Paused (low resources)' : ''}`
                        : `🍞 自动捕猎机建造中 ${pct}%\n工人: ${ms.foodCollector.buildWorkers.length}人${ms.foodCollector.buildPaused ? '\n⏸️ 已暂停（资源不足）' : ''}`;
                } else if (ms.foodCollector.built) {
                    foodFill.style.width = '100%';
                    foodFill.classList.remove('building');
                    foodVal.classList.remove('building-text');
                    if (ms.foodCollector.broken) {
                        foodFill.style.background = 'linear-gradient(90deg, #dc2626, #f87171)';
                        const repairPct = Math.round((ms.foodCollector._repairProgress || 0) * 100);
                        foodVal.textContent = repairPct > 0 ? t('machine.repair_progress', { pct: repairPct }) : t('machine.broken');
                        foodVal.style.color = '#f87171';
                        foodVal.classList.add('building-text');
                        foodBar.title = _isEn
                            ? `🍞 Auto Food Trap BROKEN!\nRepair: ${repairPct}%\nNPC must repair at Workshop\nTotal produced: ${Math.round(ms.foodCollector.totalProduced)}`
                            : `🍞 自动捕猎机故障停机！\n维修进度: ${repairPct}%\n需要NPC在工坊维修\n累计产食物: ${Math.round(ms.foodCollector.totalProduced)}`;
                    } else if (ms.foodCollector.running) {
                        foodFill.style.background = 'linear-gradient(90deg, #d97706, #f59e0b)';
                        const c = cfg.foodCollector;
                        foodVal.textContent = `+${c.foodOutputPerHour}🍞/h`;
                        foodVal.style.color = '#34d399';
                        foodBar.title = _isEn
                            ? `🍞 Auto Food Trap running\nOutput: Food +${c.foodOutputPerHour}/h\nConsumes: Power -${c.powerConsumptionPerHour}/h\nTotal produced: ${Math.round(ms.foodCollector.totalProduced)}\nTotal consumed: ${Math.round(ms.foodCollector.totalConsumed)}`
                            : `🍞 自动捕猎机运行中\n产出: 食物 +${c.foodOutputPerHour}/h\n消耗: 电力 -${c.powerConsumptionPerHour}/h\n累计产食物: ${Math.round(ms.foodCollector.totalProduced)}\n累计耗电: ${Math.round(ms.foodCollector.totalConsumed)}`;
                    } else {
                        foodFill.style.background = 'linear-gradient(90deg, #6b7280, #9ca3af)';
                        foodVal.textContent = t('machine.stopped');
                        foodVal.style.color = '#f87171';
                        foodBar.title = _isEn
                            ? `🍞 Auto Food Trap stopped\nReason: Low power (<${cfg.foodCollector.minPowerToRun})\nTotal produced: ${Math.round(ms.foodCollector.totalProduced)}`
                            : `🍞 自动捕猎机已停机\n原因: 电力不足（<${cfg.foodCollector.minPowerToRun}）\n累计产食物: ${Math.round(ms.foodCollector.totalProduced)}`;
                    }
                } else if (canUnlockFood) {
                    foodFill.style.width = '0%';
                    foodFill.style.background = 'linear-gradient(90deg, #6b7280, #9ca3af)';
                    foodFill.classList.remove('building');
                    foodVal.textContent = t('machine.not_built');
                    foodVal.style.color = '#a78bfa';
                    foodVal.classList.remove('building-text');
                    foodBar.title = _isEn
                        ? `🍞 Auto Food Trap unlocked\nBuild cost: Power ${cfg.foodCollector.buildMaterialCost} + Wood ${cfg.foodCollector.buildWoodCost}\nBuild time: ${cfg.foodCollector.buildTimeSeconds / 3600}h\nOutput: Food +${cfg.foodCollector.foodOutputPerHour}/h, uses Power ${cfg.foodCollector.powerConsumptionPerHour}/h`
                        : `🍞 自动捕猎机已解锁\n建造需要: 电力${cfg.foodCollector.buildMaterialCost} + 木柴${cfg.foodCollector.buildWoodCost}\n建造时间: ${cfg.foodCollector.buildTimeSeconds / 3600}小时\n建成后: 产食物${cfg.foodCollector.foodOutputPerHour}/h，耗电${cfg.foodCollector.powerConsumptionPerHour}/h`;
                } else {
                    foodFill.style.width = '0%';
                    foodFill.style.background = 'linear-gradient(90deg, #374151, #4b5563)';
                    foodFill.classList.remove('building');
                    foodVal.textContent = t('machine.locked');
                    foodVal.style.color = '#6b7280';
                    foodVal.classList.remove('building-text');
                    foodBar.title = _isEn
                        ? `🍞 Auto Food Trap locked\nUnlock: Food >${cfg.foodCollector.buildUnlockFood} (current ${Math.round(this.resourceSystem?.food || 0)})\nBuild cost: Power ${cfg.foodCollector.buildMaterialCost} + Wood ${cfg.foodCollector.buildWoodCost}`
                        : `🍞 自动捕猎机未解锁\n解锁条件: 食物>${cfg.foodCollector.buildUnlockFood}（当前${Math.round(this.resourceSystem?.food || 0)}）\n建造需要: 电力${cfg.foodCollector.buildMaterialCost} + 木柴${cfg.foodCollector.buildWoodCost}`;
                }
            }

            // 控制机器行可见性：有任何机器可见时显示第二行
            const machineRow = document.getElementById('res-row-machines');
            if (machineRow) {
                const anyVisible = machineRow.querySelectorAll('.res-bar-item-machine:not([style*="display:none"])').length > 0 ||
                                   machineRow.querySelectorAll('.res-bar-item-machine:not([style*="display: none"])').length > 0;
                machineRow.style.display = anyVisible ? '' : 'none';
            }
        }
        if (this.taskSystem) {
            const taskEl = document.getElementById('task-progress-val');
            if (taskEl) taskEl.textContent = this.taskSystem.getTaskSummaryForHUD();
        }

        // 【v5.0】Bug检测状态指示器
        this._updateBugDetectorIndicator();

        // Agent 卡片
        for (const npc of this.npcs) {
            const statusEl = document.getElementById(`status-${npc.id}`);
            const moodEl = document.getElementById(`mood-${npc.id}`);
            const thoughtEl = document.getElementById(`thought-${npc.id}`);
            const cardEl = document.getElementById(`agent-card-${npc.id}`);

            if (npc.isDead) {
                if (statusEl) statusEl.textContent = t('npc_state.dead', { cause: npc._deathCause || t('npc_state.dead_unknown') });
                if (moodEl) moodEl.textContent = '💀';
                if (cardEl) cardEl.style.opacity = '0.4';
                continue;
            }

            if (statusEl) {
                const roleIcons = { worker: '🔨', engineer: '🔧', support: '📋', special: '⭐' };
                const roleIcon = roleIcons[npc.config.role] || '';
                statusEl.textContent = `${roleIcon} ${npc.displayOccupation || npc.occupation} · ${npc.getStatusLine()}${npc.isCrazy ? ' · ' + t('npc_state.crazy') : ''}${npc.isHypothermic ? ' · ' + t('npc_state.hypothermic') : ''}${npc.isWatchingShow ? ' · ' + t('npc_state.watching_show') : ''}${npc.isInTherapy ? ' · ' + t('npc_state.in_therapy') : ''}`;
            }
            // 更新迷你属性条 — 添加体温
            const attrsEl = document.getElementById(`attrs-${npc.id}`);
            if (attrsEl) {
                const bodyTempColor = npc.bodyTemp >= 36 ? '#4ade80' : npc.bodyTemp >= 35 ? '#facc15' : npc.bodyTemp >= 32 ? '#f87171' : '#c084fc';
                attrsEl.innerHTML = [
                    { label: t('npc_detail.stamina'), e: '💪', v: npc.stamina, c: '#6BC98A' },
                    { label: t('npc_detail.hunger'), e: '🍚', v: npc.hunger, c: '#F0C050' },
                    { label: t('npc_detail.sanity'), e: '🧠', v: npc.sanity, c: '#C49BDB' },
                    { label: t('npc_detail.body_temp'), e: '🌡️', v: npc.bodyTemp, max: 36.5, c: bodyTempColor, suffix: '°C' },
                ].map(a => {
                    const max = a.max || 100;
                    const pct = Math.round(Math.min(a.v, max) / max * 100);
                    const val = a.suffix ? a.v.toFixed(1) + a.suffix : Math.round(a.v);
                    return `<span class="mini-attr-labeled"><span class="mini-attr-label">${a.e}${a.label}</span><span class="mini-bar-bg-wide"><span class="mini-bar" style="width:${pct}%;background:${a.c}"></span></span><span class="mini-attr-val">${val}</span></span>`;
                }).join('');
            }
            if (moodEl) moodEl.textContent = npc.isSleeping ? '😴' : this._moodEmoji(npc.mood);
            if (thoughtEl && npc.expression) {
                thoughtEl.textContent = `💬 "${npc.expression}"`;
                thoughtEl.style.display = 'block';
            } else if (thoughtEl) {
                thoughtEl.style.display = 'none';
            }

            // 高亮当前跟随的
            if (cardEl) {
                cardEl.classList.toggle('active', this.followTarget === npc);
            }
        }

        // 决策分工对比面板
        this._updateCouncilPanel();

        // 【v4.16】右上角常驻分工方案面板
        this._updateWorkPlanPanel();
    }
    // [已拆分到 hud-npc-detail.js / hud-debug.js / hud-council.js] _updateCouncilPanel
    proto.addEvent = function(text) {
        const time = this.getTimeStr();
        // 【v5.9】在事件日志中翻译NPC名字
        const translatedText = GST.i18n && GST.i18n.translateNpcNamesInText ? GST.i18n.translateNpcNamesInText(text) : text;
        this.eventLog.unshift({ time, text: translatedText });
        if (this.eventLog.length > this.maxEventLog) this.eventLog.pop();
        this._renderEventLog();
    };

})();
