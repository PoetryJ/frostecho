/**
 * 福音镇 - HUD NPC详情面板 Mixin
 * 职责：NPC详情面板的打开/关闭、属性/记忆/关系/日程/Debug Tab渲染
 * 从 hud.js 拆分，遵循SRP原则
 * 挂载到 GST.Game.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.Game.prototype;

    proto._closeNPCDetail = function() {
        document.getElementById('npc-detail-overlay').style.display = 'none';
        this._currentDetailNPC = null;
        if (this._detailRefreshTimer) { clearInterval(this._detailRefreshTimer); this._detailRefreshTimer = null; }
    };

    proto._moodEmoji = function(mood) {
        const map = { '平静':'😊','开心':'😄','高兴':'😁','兴奋':'🤩','疲惫':'😮‍💨','困倦':'😴','烦躁':'😤','生气':'😠','郁闷':'😞','压抑':'😫','好奇':'🤔','思考':'🧐','满足':'😌','愧疚':'😔','紧张':'😰','期待':'🥰','无聊':'😑','惊讶':'😲','睡眠':'😴' };
        return map[mood] || '😊';
    };

    proto._openNPCDetail = function(npc) {
        this._currentDetailNPC = npc;
        this.switchFollowTarget(npc);
        const avatarEl = document.getElementById('npc-detail-avatar');
        if (npc.portrait && npc.portrait.src) { avatarEl.innerHTML = `<img src="${npc.portrait.src}" alt="${npc.name}">`; }
        else { avatarEl.textContent = npc.name[0]; }
        document.getElementById('npc-detail-name').textContent = npc.displayName || npc.name;
        document.getElementById('npc-detail-meta').textContent =
            GST.t('npc_detail.age_meta', { age: npc.age, occ: npc.displayOccupation || npc.occupation, mood: npc.mood, san: npc.getSanityLevel(), hungerEmoji: npc.getHungerEmoji(), hunger: npc.getHungerStatus() }) + (npc.isSick ? GST.t('npc_detail.sick_tag') : '') + (npc.isCrazy ? GST.t('npc_detail.crazy_tag') : '');
        this._renderAttributesTab(npc);
        this._renderScheduleTab(npc);
        this._renderMemoryTab(npc);
        this._renderRelationsTab(npc);
        const debugTabBtn = document.getElementById('npc-tab-debug');
        if (debugTabBtn) debugTabBtn.style.display = this.mode === 'debug' ? '' : 'none';
        if (this.mode === 'debug') this._renderDebugTab(npc);
        document.querySelectorAll('.npc-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.npc-tab-content').forEach(c => c.classList.remove('active'));
        document.querySelector('.npc-tab[data-tab="attributes"]').classList.add('active');
        document.getElementById('tab-attributes').classList.add('active');
        document.getElementById('npc-detail-overlay').style.display = 'flex';
        this._detailRefreshTimer = setInterval(() => {
            if (this._currentDetailNPC) {
                this._renderMemoryTab(this._currentDetailNPC);
                this._renderAttributesTab(this._currentDetailNPC);
                if (this.mode === 'debug') this._renderDebugTab(this._currentDetailNPC);
                document.getElementById('npc-detail-meta').textContent =
                    GST.t('npc_detail.age_meta', { age: this._currentDetailNPC.age, occ: this._currentDetailNPC.displayOccupation || this._currentDetailNPC.occupation, mood: this._currentDetailNPC.mood, san: this._currentDetailNPC.getSanityLevel(), hungerEmoji: this._currentDetailNPC.getHungerEmoji(), hunger: this._currentDetailNPC.getHungerStatus() }) + (this._currentDetailNPC.isSick ? GST.t('npc_detail.sick_tag') : '') + (this._currentDetailNPC.isCrazy ? GST.t('npc_detail.crazy_tag') : '');
            }
        }, 3000);
    };

    proto._setupNPCDetailPanel = function() {
        const overlay = document.getElementById('npc-detail-overlay');
        const closeBtn = document.getElementById('npc-detail-close');
        closeBtn.addEventListener('click', () => this._closeNPCDetail());
        overlay.addEventListener('click', (e) => { if (e.target === overlay) this._closeNPCDetail(); });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && overlay.style.display !== 'none') this._closeNPCDetail();
        });
        const tabs = document.querySelectorAll('.npc-tab');
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                document.querySelectorAll('.npc-tab-content').forEach(c => c.classList.remove('active'));
                document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
            });
        });
    };

    proto._renderAttributesTab = function(npc) {
        const el = document.getElementById('tab-attributes');
        const t = GST.t;
        const attrs = [
            { key: 'stamina', label: t('npc_detail.attr_stamina'), value: npc.stamina, level: npc.getStaminaLevel(), max: 100 },
            { key: 'sanity', label: t('npc_detail.attr_sanity'), value: npc.sanity, level: npc.getSanityLevel(), max: 100 },
            { key: 'health', label: t('npc_detail.attr_health'), value: npc.health, level: npc.getHealthLevel(), max: 100 },
            { key: 'hunger', label: t('npc_detail.attr_hunger'), value: npc.hunger || 50, level: npc.getHungerStatus ? npc.getHungerStatus() : t('npc_detail.status_normal'), max: 100 },
            { key: 'bodyTemp', label: t('npc_detail.attr_bodytemp'), value: npc.bodyTemp || 36.5, level: npc.getBodyTempStatus ? npc.getBodyTempStatus() : t('npc_detail.status_normal'), max: 36.5, isTemp: true },
        ];
        const rateSources = npc._attrRateSources || {};
        let html = '<div class="attr-grid">';
        for (const a of attrs) {
            const val = Math.round(a.value);
            const pct = a.isTemp ? Math.min(100, Math.max(0, (val / a.max) * 100)) : Math.min(100, Math.max(0, val));
            const displayVal = a.isTemp ? a.value.toFixed(1) + '°C' : val;
            const sources = rateSources[a.key] || [];
            let netRate = 0;
            for (const s of sources) netRate += Number(s.rate) || 0;
            const netRateStr = a.isTemp ? (netRate >= 0 ? '+' : '') + netRate.toFixed(2) + '°C/h' : (netRate >= 0 ? '+' : '') + Math.round(netRate) + '/h';
            const netColor = netRate > 0 ? '#6BC98A' : netRate < 0 ? '#E06060' : '#6a6a7a';
            html += `<div class="attr-card"><div class="attr-card-header"><span class="attr-label">${a.label}</span><span class="attr-value"${a.isTemp && npc.getBodyTempColor ? ` style="color:${npc.getBodyTempColor()}"` : ''}>${displayVal}</span></div><div class="attr-bar-bg"><div class="attr-bar ${a.key}" style="width:${pct}%"></div></div><div class="attr-card-footer"><span class="attr-level">${a.level}</span><span class="attr-net-rate" style="color:${netColor}">${sources.length > 0 ? netRateStr : ''}</span></div>`;
            if (sources.length > 0) {
                html += '<div class="attr-sources">';
                for (const s of sources) {
                    const r = Number(s.rate) || 0;
                    const rColor = r > 0 ? '#6BC98A' : r < 0 ? '#E06060' : '#6a6a7a';
                    const rStr = a.isTemp ? (r >= 0 ? '+' : '') + r.toFixed(2) + '°C/h' : (r >= 0 ? '+' : '') + Math.round(r) + '/h';
                    const noteStr = s.note ? ` <span class="attr-src-note">${s.note}</span>` : '';
                    html += `<div class="attr-src-item"><span class="attr-src-label">${s.label}</span><span class="attr-src-rate" style="color:${rColor}">${r !== 0 ? rStr : ''}${noteStr}</span></div>`;
                }
                html += '</div>';
            }
            html += '</div>';
        }
        html += '</div>';
        const hints = [];
        if (npc.isHypothermic) hints.push({ text: t('npc_detail.hint_hypothermic', { temp: npc.bodyTemp.toFixed(1) }), cls: 'warn' });
        if (npc.isSevereHypothermic) hints.push({ text: t('npc_detail.hint_severe_hypo'), cls: 'warn' });
        if (npc.isFrostbitten) hints.push({ text: t('npc_detail.hint_frostbite'), cls: 'warn' });
        if (npc.isSick) hints.push({ text: t('npc_detail.hint_sick'), cls: 'warn' });
        if (npc.isCrazy) hints.push({ text: t('npc_detail.hint_crazy'), cls: 'warn' });
        if (npc.isWatchingShow) hints.push({ text: t('npc_detail.hint_inspired'), cls: 'good' });
        if (npc.isInTherapy) hints.push({ text: t('npc_detail.hint_therapy'), cls: 'good' });        if (hints.length > 0) {
            html += '<div class="attr-status-hints">';
            html += hints.map(h => `<div class="attr-hint-item ${h.cls}">${h.text}</div>`).join('');
            html += '</div>';
        }
        if (npc.goals && npc.goals.length > 0) {
            html += '<div class="goal-section" style="margin-top:14px;"><div style="font-size:13px;font-weight:bold;color:#e0e0e0;margin-bottom:8px;">' + t('npc_detail.goal_title') + '</div>';
            for (const g of npc.goals) {
                const pctG = g.targetValue > 0 ? Math.min(100, Math.round((g.progress / g.targetValue) * 100)) : 0;
                const isComplete = g.completed;
                const typeIcon = g.type === 'daily' ? '📅' : '🏆';
                const statusIcon = isComplete ? '✅' : (pctG >= 50 ? '🔶' : '⬜');
                const barColor = isComplete ? '#6BC98A' : (pctG >= 50 ? '#F0C050' : '#5a5a6a');
                html += `<div class="goal-item" style="margin-bottom:6px;padding:4px 8px;background:${isComplete ? 'rgba(107,201,138,0.12)' : 'rgba(255,255,255,0.04)'};border-radius:6px;"><div style="display:flex;justify-content:space-between;align-items:center;font-size:12px;"><span style="color:${isComplete ? '#6BC98A' : '#c0c0d0'};">${statusIcon} ${typeIcon} ${g.desc}</span><span style="color:#8a8a9a;font-size:11px;">${isComplete ? t('npc_detail.goal_done') : `${pctG}%`}</span></div><div style="height:3px;background:#2a2a3a;border-radius:2px;margin-top:3px;overflow:hidden;"><div style="height:100%;width:${pctG}%;background:${barColor};border-radius:2px;transition:width 0.5s;"></div></div><div style="font-size:10px;color:#6a6a7a;margin-top:2px;">${t('npc_detail.goal_reward', { desc: g.rewardDesc })}</div></div>`;
            }
            html += '</div>';
        }
        el.innerHTML = html;
    };

    proto._renderMemoryTab = function(npc) {
        const el = document.getElementById('tab-memory');
        const memories = npc.memories || [];
        if (memories.length === 0) { el.innerHTML = '<div class="memory-empty">' + GST.t('npc_detail.memory_empty') + '</div>'; return; }
        el.innerHTML = [...memories].reverse().map(m => {
            const type = m.type || 'event';
            if (type === 'chat' && m.lines && m.lines.length > 0) {
                const bubbles = m.lines.map(line => {
                    const isSelf = line.speaker === npc.name;
                    return `<div class="chat-bubble ${isSelf ? 'self' : 'other'}"><span class="chat-speaker">${line.speaker}</span><span class="chat-text">${line.text}</span></div>`;
                }).join('');
                return `<div class="mem-block mem-chat"><div class="mem-header"><span class="mem-time">${m.time || '--:--'}</span><span class="mem-tag tag-chat">💬 ${m.text}</span></div><div class="chat-bubbles">${bubbles}</div></div>`;
            }
            if (type === 'thought') {
                const content = m.text.replace(/^\[想法\]\s*|\[Thought\]\s*/i, '');
                return `<div class="mem-block mem-thought"><div class="mem-header"><span class="mem-time">${m.time || '--:--'}</span><span class="mem-tag tag-thought">${GST.t('npc_detail.memory_thought')}</span></div><div class="thought-content">${content}</div></div>`;
            }
            return `<div class="mem-block mem-event"><div class="mem-header"><span class="mem-time">${m.time || '--:--'}</span><span class="mem-tag tag-event">${GST.t('npc_detail.memory_event')}</span></div><div class="event-content">${m.text}</div></div>`;
        }).join('');
    };

    proto._renderRelationsTab = function(npc) {
        const el = document.getElementById('tab-relations');
        const otherNPCs = this.npcs.filter(n => n.id !== npc.id);
        if (otherNPCs.length === 0) { el.innerHTML = '<div class="memory-empty">' + GST.t('npc_detail.relation_empty') + '</div>'; return; }
        el.innerHTML = otherNPCs.map(other => {
            const value = npc.getAffinity(other.id);
            let barColor; if (value < 30) barColor = '#E06060'; else if (value < 60) barColor = '#D0A040'; else barColor = '#4A9F6E';
            let label; if (value < 20) label = GST.t('npc_detail.rel_cold'); else if (value < 40) label = GST.t('npc_detail.rel_neutral'); else if (value < 70) label = GST.t('npc_detail.rel_friendly'); else if (value < 90) label = GST.t('npc_detail.rel_close'); else label = GST.t('npc_detail.rel_best');
            return `<div class="relation-item"><span class="relation-name" style="color:${other.color}">${other.displayName || other.name}</span><div class="relation-bar-bg"><div class="relation-bar" style="width:${value}%;background:${barColor}"></div></div><span class="relation-value">${value} ${label}</span></div>`;
        }).join('');
    };

    proto._renderScheduleTab = function(npc) {
        const el = document.getElementById('tab-schedule');
        const stateDesc = npc.stateDesc || GST.t('npc_detail.standby');
        const action = npc._currentAction;
        const behaviorOwner = npc._behaviorOwner || 'unknown';
        const scene = npc.currentScene || GST.t('npc_detail.unknown_scene');
        const councilDesc = npc._councilStateDesc || '';
        const taskOverride = npc._taskOverride;
        const isMoving = npc.isMoving;
        const isSleeping = npc.isSleeping;
        const isEating = npc.isEating;
        let statusEmoji = '🟢', statusText = GST.t('npc_detail.status_normal');
        if (npc.isDead) { statusEmoji = '💀'; statusText = GST.t('npc_detail.status_dead'); }
        else if (isSleeping) { statusEmoji = '😴'; statusText = GST.t('npc_detail.status_sleeping'); }
        else if (isEating) { statusEmoji = '🍽️'; statusText = GST.t('npc_detail.status_eating'); }
        else if (isMoving) { statusEmoji = '🚶'; statusText = GST.t('npc_detail.status_moving'); }
        const ownerMap = { priority: GST.t('npc_detail.owner_priority'), task: GST.t('npc_detail.owner_task'), hunger: GST.t('npc_detail.owner_hunger'), state: GST.t('npc_detail.owner_state'), resource: GST.t('npc_detail.owner_resource'), action: GST.t('npc_detail.owner_action'), schedule: GST.t('npc_detail.owner_schedule') };
        const ownerLabel = ownerMap[behaviorOwner] || behaviorOwner;
        let html = `<div class="action-status-section"><div class="action-status-title">${GST.t('npc_detail.schedule_current')}</div><div class="action-status-main">${stateDesc}</div></div>`;
        html += `<div class="action-status-section"><div class="action-status-title">${GST.t('npc_detail.schedule_status')}</div><div class="action-status-row"><span class="action-label">${GST.t('npc_detail.schedule_label_status')}</span><span class="action-value">${statusEmoji} ${statusText}</span></div><div class="action-status-row"><span class="action-label">${GST.t('npc_detail.schedule_label_scene')}</span><span class="action-value">📍 ${scene}</span></div><div class="action-status-row"><span class="action-label">${GST.t('npc_detail.schedule_label_controller')}</span><span class="action-value">${ownerLabel}</span></div></div>`;
        if (councilDesc) html += `<div class="action-status-section"><div class="action-status-title">${GST.t('npc_detail.schedule_council')}</div><div class="action-status-main council">${councilDesc}</div></div>`;
        if (taskOverride && taskOverride.isActive) html += `<div class="action-status-section"><div class="action-status-title">${GST.t('npc_detail.schedule_task')}</div><div class="action-status-main task">${taskOverride.desc || taskOverride.effectKey || GST.t('npc_detail.schedule_task_default')}</div></div>`;        if (action) {
            html += `<div class="action-status-section"><div class="action-status-title">${GST.t('npc_detail.schedule_action_detail')}</div><div class="action-status-row"><span class="action-label">${GST.t('npc_detail.schedule_label_type')}</span><span class="action-value">${action.type || '-'}</span></div>`;
            if (action.target) html += `<div class="action-status-row"><span class="action-label">${GST.t('npc_detail.schedule_label_target')}</span><span class="action-value">${action.target}</span></div>`;
            if (action.reason) html += `<div class="action-status-row"><span class="action-label">${GST.t('npc_detail.schedule_label_reason')}</span><span class="action-value">${action.reason}</span></div>`;
            html += `</div>`;
        }
        el.innerHTML = html;
    };

})();
