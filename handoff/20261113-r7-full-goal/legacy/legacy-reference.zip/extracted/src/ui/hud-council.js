/**
 * 福音镇 - HUD 议会面板 + 工作计划面板 + Bug指示器 Mixin
 * 职责：议会决策对比面板、右上角分工方案面板、Bug检测状态指示器
 * 从 hud.js 拆分，遵循SRP原则（单一职责）
 * 挂载到 GST.Game.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.Game.prototype;

    // ---- 决策分工对比面板 ----

    proto._updateCouncilPanel = function() {
        const panel = document.getElementById('council-decision-panel');
        if (!panel) return;
        const cs = this.councilSystem;
        if (!cs || !cs._winnerProposal || !cs._winnerProposal.assignments) {
            panel.classList.add('hidden');
            return;
        }
        // 【v5.9】统一走i18n翻译，不再硬编码中文
        const getTaskLabel = (task) => GST.i18n.translateTaskLabel(task) || task;
        const hasActive = this.npcs.some(n => n._councilTask);
        if (!hasActive) { panel.classList.add('hidden'); return; }

        const proposal = cs._winnerProposal;
        const assignments = proposal.assignments;
        const rows = [];
        const assignedNames = new Set(Object.keys(assignments));

        for (const [name, task] of Object.entries(assignments)) {
            const npc = this.npcs.find(n => n.name === name);
            if (!npc) continue;
            const taskLabel = getTaskLabel(task);
            const planned = npc._councilStateDesc || taskLabel;
            const actualRaw = npc.stateDesc || npc.state || '—';
            const actual = GST.i18n.translateStateDesc ? GST.i18n.translateStateDesc(actualRaw) : actualRaw;
            const icon = this._councilStatusIcon(npc, planned, actual);
            let actualStyle = '';
            if (icon === '🔄') actualStyle = 'color:#4ade80';
            else if (icon === '⏳') actualStyle = 'color:#facc15';
            else if (icon === '📋') actualStyle = 'color:#94a3b8';
            rows.push(`<div class="cdp-row"><span class="cdp-icon">${icon}</span><span class="cdp-name">${npc.displayName || name}</span><span class="cdp-plan" title="${planned}">${planned}</span><span class="cdp-arrow">→</span><span class="cdp-actual" title="${actual}" style="${actualStyle}">${actual}</span></div>`);
        }

        const ROLE_DEFAULTS = {
            'old_qian': 'BOOST_MORALE', 'li_shen': 'DISTRIBUTE_FOOD', 'zhao_chef': 'COLLECT_WOOD',
            'su_doctor': 'PREPARE_MEDICAL', 'wang_teacher': 'MAINTAIN_POWER', 'lu_chen': 'COLLECT_WOOD',
            'ling_yue': 'COLLECT_MATERIAL', 'qing_xuan': 'PREPARE_MEDICAL',
        };
        for (const npc of this.npcs) {
            if (npc.isDead || assignedNames.has(npc.name)) continue;
            const fallbackTask = ROLE_DEFAULTS[npc.id] || 'REST';
            assignments[npc.name] = fallbackTask;
            const fallbackLabel = getTaskLabel(fallbackTask);
            const planned = npc._councilStateDesc || fallbackLabel;
            const actualRaw = npc.stateDesc || npc.state || '—';
            const actual = GST.i18n.translateStateDesc ? GST.i18n.translateStateDesc(actualRaw) : actualRaw;
            const icon = this._councilStatusIcon(npc, planned, actual);
            let actualStyle = '';
            if (icon === '🔄') actualStyle = 'color:#4ade80';
            else if (icon === '⏳') actualStyle = 'color:#facc15';
            else if (icon === '📋') actualStyle = 'color:#94a3b8';
            rows.push(`<div class="cdp-row"><span class="cdp-icon">${icon}</span><span class="cdp-name">${npc.displayName || npc.name}</span><span class="cdp-plan" title="${fallbackLabel}">${planned}</span><span class="cdp-arrow">→</span><span class="cdp-actual" title="${actual}" style="${actualStyle}">${actual}</span></div>`);
        }

        const tNpc = this.npcs.find(n => n._councilTaskTime);
        const timeStr = tNpc ? new Date(tNpc._councilTaskTime).toLocaleTimeString(GST.i18n.isEn() ? 'en-US' : 'zh-CN', { hour: '2-digit', minute: '2-digit' }) : '';
        panel.innerHTML = `<div class="cdp-header"><span class="cdp-title">⚡ ${proposal.name}</span><span class="cdp-time">${timeStr}</span></div><div class="cdp-subtitle">${GST.t('council_panel.vote_event', { name: proposal.name })}</div><div class="cdp-body">${rows.join('')}</div>`;
        panel.classList.remove('hidden');
    };

    proto._councilMatchCheck = function(planned, actual) {
        if (!planned || !actual) return false;
        const p = planned.toLowerCase();
        const a = actual.toLowerCase();
        const keywords = p.match(/[\u4e00-\u9fff]{2,}|[a-z]{3,}/g);
        if (!keywords) return false;
        return keywords.some(kw => a.includes(kw));
    };

    proto._councilStatusIcon = function(npc, planned, actual) {
        if (npc.isDead) return '💀';
        if (npc.isSleeping) return '💤';
        if (npc.state === 'eating' || (actual && (actual.includes('吃') || actual.toLowerCase().includes('eat')))) return '🍜';
        if (npc.state === 'healing' || npc.isInTherapy) return '💊';
        if (planned && actual && this._councilMatchCheck(planned, actual)) {
            if (npc.isMoving || npc._walkingToDoor) return '⏳';
            return '🔄';
        }
        if (npc.isMoving || npc._walkingToDoor) return '⏳';
        return '📋';
    };

    // ---- 右上角常驻分工方案面板 ----

    proto._initWorkPlanPanel = function() {
        const toggleBtn = document.getElementById('wpp-toggle');
        if (toggleBtn) {
            toggleBtn.addEventListener('click', () => {
                const panel = document.getElementById('work-plan-panel');
                if (panel) panel.classList.toggle('collapsed');
            });
        }
    };

    proto._updateWorkPlanPanel = function() {
        const panel = document.getElementById('work-plan-panel');
        if (!panel) return;
        if (!this._wppInitialized) {
            this._wppInitialized = true;
            this._initWorkPlanPanel();
        }
        const now = Date.now();
        if (this._wppLastUpdate && now - this._wppLastUpdate < 1000) return;
        this._wppLastUpdate = now;

        const body = document.getElementById('wpp-body');
        const timeEl = document.getElementById('wpp-time');
        if (!body) return;

        const nameMap = {};
        for (const npc of (this.npcs || [])) {
            nameMap[npc.id] = npc.displayName || npc.name;
        }
        const roleEmoji = { zhao_chef: '👨‍🍳', lu_chen: '💪', li_shen: '👩‍🍳', wang_teacher: '👨‍🏫', old_qian: '👴', su_doctor: '👨‍⚕️', ling_yue: '🔍', qing_xuan: '🧪' };

        if (timeEl) { timeEl.textContent = GST.t('misc.day_n_time', { n: this.dayCount, time: this.getTimeStr() }); }

        const ts = this.taskSystem;
        const cs = this.councilSystem;
        const rs = this.reincarnationSystem;
        const deadNpcs = this.npcs.filter(n => n.isDead);
        let rows = [];
        let sourceLabel = '';

        if (ts && ts.dailyTasks && ts.dailyTasks.length > 0) {
            sourceLabel = '📋 ' + GST.t('workplan.title');
            const completed = ts.dailyTasks.filter(t => t.status === 'completed').length;
            sourceLabel += ` (${completed}/${ts.dailyTasks.length})`;
            const tasksByNpc = {};
            for (const task of ts.dailyTasks) {
                const npcId = task.assignedNpcId || 'unassigned';
                if (!tasksByNpc[npcId]) tasksByNpc[npcId] = [];
                tasksByNpc[npcId].push(task);
            }
            for (const npc of this.npcs) {
                const tasks = tasksByNpc[npc.id];
                if (!tasks) continue;
                const taskStr = tasks.map(t => {
                    const progress = t.target > 0 ? Math.min(100, Math.round(t.progress / t.target * 100)) : (t.status === 'completed' ? 100 : 0);
                    const statusMark = t.status === 'completed' ? '✅' : (progress > 0 ? `${progress}%` : '');
                    // 【v5.9】任务名走i18n翻译
                    const taskName = GST.i18n.translateStateDesc ? GST.i18n.translateStateDesc(t.name) : t.name;
                    return taskName + (statusMark ? `(${statusMark})` : '');
                }).join('+');
                const actual = npc.stateDesc || npc.state || '—';
                let statusIcon = '📋';
                if (npc.isDead) statusIcon = '💀';
                else if (npc.isSleeping) statusIcon = '💤';
                else if (actual.includes('砍') || actual.includes('采') || actual.includes('修') || actual.includes('探') || actual.includes('巡') || /chop|gather|repair|explor|patrol/i.test(actual)) statusIcon = '🔄';
                else if (npc.isMoving) statusIcon = '⏳';
                rows.push({ npcId: npc.id, name: npc.displayName || npc.name, emoji: roleEmoji[npc.id] || '👤', task: taskStr, status: statusIcon, stamina: Math.round(npc.stamina || 0), isDead: npc.isDead, isExecuting: statusIcon === '🔄', isTraveling: statusIcon === '⏳' });
            }
        } else if (cs && cs._winnerProposal && cs._winnerProposal.assignments) {
            sourceLabel = `🗳️ ${GST.t('council_panel.vote_event', { name: cs._winnerProposal.name || '?' })}`;
            for (const [name, task] of Object.entries(cs._winnerProposal.assignments)) {
                const npc = this.npcs.find(n => n.name === name);
                if (!npc) continue;
                const actual = npc.stateDesc || npc.state || '—';
                let statusIcon = '📋';
                if (npc.isDead) statusIcon = '💀';
                else if (npc.isSleeping) statusIcon = '💤';
                else if (this._councilMatchCheck && this._councilMatchCheck(task, actual)) statusIcon = '🔄';
                else if (npc.isMoving) statusIcon = '⏳';
                rows.push({ npcId: npc.id, name: npc.displayName || name, emoji: roleEmoji[npc.id] || '👤', task: npc._councilStateDesc || task, status: statusIcon, stamina: Math.round(npc.stamina || 0), isDead: npc.isDead, isExecuting: statusIcon === '🔄', isTraveling: statusIcon === '⏳' });
            }
        } else if (rs) {
            const holder = rs.getWorkPlanHolder && rs.getWorkPlanHolder();
            if (holder && holder.workPlan) {
                const wp = holder.workPlan;
                const day = this.dayCount || 1;
                const dayPlan = wp.dayPlans && wp.dayPlans[day];
                sourceLabel = `📝 ${wp.strategy || 'Default'}`;
                if (dayPlan) {
                    // 【v5.9】统一走i18n翻译
                    for (const a of dayPlan) {
                        const npc = this.npcs.find(n => n.id === a.npcId);
                    rows.push({ npcId: a.npcId, name: nameMap[a.npcId] || a.npcId, emoji: roleEmoji[a.npcId] || '👤', task: GST.i18n.translateTaskLabel(a.task) || a.task, status: npc && npc.isDead ? '💀' : '📋', stamina: npc ? Math.round(npc.stamina || 0) : 0, isDead: npc ? npc.isDead : false, isExecuting: false, isTraveling: false });
                    }
                }
            }
        }

        if (rows.length === 0) {
            if (this._wppLastValidHtml) {
                const councilActive = cs && (cs.isActive || cs.isGenerating);
                const hint = councilActive ? '⏳ ...' : '⏳ ...';
                const hintHtml = `<div class="wpp-source" style="color:rgba(250,204,21,0.7)">${hint}</div>`;
                const oldRows = this._wppLastValidHtml.replace(/<div class="wpp-source">.*?<\/div>/, '');
                body.innerHTML = hintHtml + oldRows;
            } else {
                body.innerHTML = '<div class="wpp-empty">⏳</div>';
            }
            return;
        }

        for (const npc of deadNpcs) {
            if (!rows.find(r => r.npcId === npc.id)) {
                rows.push({ npcId: npc.id, name: npc.displayName || npc.name, emoji: roleEmoji[npc.id] || '👤', task: '💀', status: '💀', stamina: 0, isDead: true, isExecuting: false, isTraveling: false });
            }
        }

        let html = `<div class="wpp-source">${sourceLabel}</div>`;
        for (const row of rows) {
            const cls = row.isDead ? ' dead' : (row.isExecuting ? ' executing' : (row.isTraveling ? ' traveling' : ''));
            html += `<div class="wpp-row${cls}"><span class="wpp-row-icon">${row.emoji}</span><span class="wpp-row-name">${row.name}</span><span class="wpp-row-task" title="${row.task}">${row.task}</span><span class="wpp-row-status">${row.status}</span><span class="wpp-row-stamina">${row.isDead ? '' : row.stamina}</span></div>`;
        }
        body.innerHTML = html;
        this._wppLastValidHtml = html;
    };

    // ---- Bug检测状态指示器（v5.8已隐藏，不再在UI上显示） ----

    proto._updateBugDetectorIndicator = function() {
        // 【v5.8】隐藏bug检测面板，不再在左上角显示
        // bug检测器仍在后台运行并写入日志，只是不在UI上显示
        const indicatorEl = document.getElementById('bug-detector-indicator');
        if (indicatorEl) indicatorEl.remove();
    };

})();
