/**
 * 福音镇 - HUD Debug面板 Mixin
 * 职责：Debug Tab渲染、Bug检测面板、Debug日志保存/下载
 * 从 hud.js 拆分，遵循SRP原则
 * 挂载到 GST.Game.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.Game.prototype;

    proto._renderDebugTab = function(npc) {
        const el = document.getElementById('tab-debug');
        if (!el) return;
        if (this.mode !== 'debug') { el.innerHTML = ''; return; }
        const t = (k) => GST.t('hud_debug.' + k);
        const none = t('none');
        const stateInfo = `<div class="debug-section"><div class="debug-section-title">${t('section_state')}</div><div class="debug-state-grid"><div class="debug-state-item"><span class="debug-label">${t('label_state')}</span><span class="debug-val">${npc.state || '—'}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_desc')}</span><span class="debug-val">${npc.stateDesc || '—'}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_scene')}</span><span class="debug-val">${npc.currentScene || '—'}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_mood')}</span><span class="debug-val">${npc.mood || '—'}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_moving')}</span><span class="debug-val">${npc.isMoving ? '✅' : '❌'}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_sleeping')}</span><span class="debug-val">${npc.isSleeping ? '✅' : '❌'}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_sick')}</span><span class="debug-val">${npc.isSick ? '✅' : '❌'}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_crazy')}</span><span class="debug-val">${npc.isCrazy ? '✅' : '❌'}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_hunger_override')}</span><span class="debug-val">${npc._hungerOverride ? '✅' : '❌'}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_action_override')}</span><span class="debug-val">${npc._actionOverride ? '✅' : '❌'}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_state_override')}</span><span class="debug-val">${npc._stateOverrideType || none}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_chat_target')}</span><span class="debug-val">${npc._chatWalkTarget || none}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_coords')}</span><span class="debug-val">(${Math.round(npc.x)}, ${Math.round(npc.y)})</span></div><div class="debug-state-item"><span class="debug-label">${t('label_path_len')}</span><span class="debug-val">${npc.currentPath ? npc.currentPath.length : 0}</span></div><div class="debug-state-item"><span class="debug-label">${t('label_api')}</span><span class="debug-val" style="color:${typeof LLM_STATUS !== 'undefined' && LLM_STATUS.isDown ? '#E06060' : (typeof LLM_STATUS !== 'undefined' && LLM_STATUS.consecutiveFails > 0 ? '#F0C050' : '#6BC98A')}">${typeof LLM_STATUS !== 'undefined' ? (LLM_STATUS.isDown ? t('api_down') : `✅${LLM_STATUS.successCalls}/${LLM_STATUS.totalCalls}`) : t('api_unknown')}</span></div>${typeof LLM_STATUS !== 'undefined' && LLM_STATUS.lastError ? `<div class="debug-state-item" style="grid-column:span 2;"><span class="debug-label">${t('label_last_error')}</span><span class="debug-val" style="color:#E06060;font-size:10px;">${LLM_STATUS.lastError.substring(0, 60)}</span></div>` : ''}</div></div>`;
        const actionInfo = npc._currentAction ? `<div class="debug-section"><div class="debug-section-title">${t('section_action')}</div><div class="debug-action-detail"><div>${t('label_type')}: ${npc._currentAction.type}</div><div>${t('label_target')}: ${npc._currentAction.target || none}</div><div>${t('label_companion')}: ${npc._currentAction.companion || none}</div><div>${t('label_priority')}: ${npc._currentAction.priority || '—'}</div><div>${t('label_reason')}: ${npc._currentAction.reason || '—'}</div></div></div>` : '';
        const logText = npc.getDebugLogText();
        const actionLog = `<div class="debug-section"><div class="debug-section-title">${t('section_action_log')}</div><div class="debug-log-content">${logText.split('\n').map(l => `<div class="debug-log-line">${l}</div>`).join('')}</div></div>`;
        const dialogueText = npc.getDebugDialogueText();
        const dialogueLog = `<div class="debug-section"><div class="debug-section-title">${t('section_dialogue_log')}</div><div class="debug-log-content debug-dialogue-log">${dialogueText.split('\n').map(l => l.startsWith('===') ? `<div class="debug-dialogue-header">${l}</div>` : `<div class="debug-log-line">${l}</div>`).join('')}</div></div>`;
        let goalSection = '';
        if (npc.goals && npc.goals.length > 0) {
            const goalRows = npc.goals.map(g => {
                const pct = g.targetValue > 0 ? Math.min(100, Math.round((g.progress / g.targetValue) * 100)) : 0;
                const typeIcon = g.type === 'daily' ? '📅' : '🏆';
                const statusIcon = g.completed ? '✅' : (pct >= 50 ? '🔶' : '⬜');
                const barColor = g.completed ? '#6BC98A' : (pct >= 50 ? '#F0C050' : '#5a5a6a');
                return `<div style="margin-bottom:4px;"><div style="display:flex;justify-content:space-between;font-size:11px;"><span>${statusIcon} ${typeIcon} ${g.desc}</span><span style="color:#8a8a9a;">${g.completed ? t('label_completed') : `${pct}% (${typeof g.progress === 'number' ? Math.round(g.progress * 10) / 10 : g.progress}/${g.targetValue})`}</span></div><div style="height:2px;background:#2a2a3a;border-radius:1px;margin-top:2px;overflow:hidden;"><div style="height:100%;width:${pct}%;background:${barColor};border-radius:1px;"></div></div></div>`;
            }).join('');
            goalSection = `<div class="debug-section"><div class="debug-section-title">${t('section_goals')}</div>${goalRows}<div style="margin-top:6px;font-size:10px;color:#6a6a7a;">${t('label_concern')}: ${npc._lastConcern || none} | ${t('label_focus')}: ${npc._lastGoalFocus || none}</div></div>`;
        }
        const rewardLogs = npc._debugLog.filter(e => e.type === 'reward' || e.type === 'penalty' || e.type === 'goal').slice(0, 30);
        let rewardLogHtml = '';
        if (rewardLogs.length > 0) {
            const logLines = rewardLogs.map(e => {
                const icon = { 'reward': '⚖️', 'penalty': '⚠️', 'goal': '🎯' }[e.type] || '📝';
                const dayStr = e.day !== undefined ? `D${e.day} ` : '';
                const color = e.type === 'penalty' ? '#E06060' : (e.type === 'goal' ? '#6BC98A' : '#C0C0D0');
                return `<div class="debug-log-line" style="color:${color};">[${dayStr}${e.time}] ${icon} ${e.detail}</div>`;
            }).join('');
            rewardLogHtml = `<div class="debug-section"><div class="debug-section-title">${t('section_reward_log')}</div><div class="debug-log-content">${logLines}</div></div>`;
        }
        el.innerHTML = stateInfo + actionInfo + goalSection + rewardLogHtml + actionLog + dialogueLog;
        // Bug检测面板追加到Debug Tab
        this._renderBugDetectorPanel(el, npc);
    };

    proto._renderBugDetectorPanel = function(parentEl, npc) {
        if (!this.bugDetector) return;
        const allResults = this.bugDetector.getRecentResults(50);
        const npcResults = allResults.filter(r => r.npcId === npc.id);
        const globalResults = allResults.filter(r => !r.npcId);
        let arbiterHtml = '';
        if (this.npcArbiter) {
            const controller = this.npcArbiter.getCurrentController(npc.id);
            const history = this.npcArbiter.getHistory(npc.id);
            const recentHistory = history.slice(-5);
            arbiterHtml = `<div class="debug-section"><div class="debug-section-title">🎯 控制权仲裁器</div><div style="font-size:11px;color:#c0c0d0;margin-bottom:4px;">当前控制: ${controller ? `<span style="color:#fbbf24;">${controller.system}(P${controller.priority})</span> → ${controller.action} <span style="color:#8a8a9a;">(${controller.reason})</span>` : '<span style="color:#6BC98A;">无（自由状态）</span>'}</div>${recentHistory.length > 0 ? `<div style="font-size:10px;color:#8a8a9a;">最近控制权变更:${recentHistory.map(h => `<div style="margin-left:8px;">• ${h.system}(P${h.priority}) → ${h.action} [${h.result}]</div>`).join('')}</div>` : ''}</div>`;
        }
        let detectorHtml = '';
        if (npcResults.length > 0 || globalResults.length > 0) {
            const resultLines = [...npcResults, ...globalResults].slice(-10).map(r => {
                const color = r.severity.includes('致命') ? '#f87171' : r.severity.includes('严重') ? '#fbbf24' : r.severity.includes('中等') ? '#60a5fa' : '#6BC98A';
                return `<div style="margin-bottom:4px;border-left:2px solid ${color};padding-left:6px;"><div style="font-size:10px;color:${color};">${r.severity} [${r.type}] <span style="color:#8a8a9a;">${r.gameTime}</span></div><div style="font-size:11px;color:#c0c0d0;">${r.detail}</div>${r.suggestion ? `<div style="font-size:10px;color:#a78bfa;">💡 ${r.suggestion}</div>` : ''}</div>`;
            }).join('');
            detectorHtml = `<div class="debug-section"><div class="debug-section-title">🔍 Bug自动检测 <span style="font-size:10px;color:#8a8a9a;">(${npcResults.length}条NPC + ${globalResults.length}条全局)</span></div>${resultLines}</div>`;
        } else {
            detectorHtml = `<div class="debug-section"><div class="debug-section-title">🔍 Bug自动检测</div><div style="font-size:11px;color:#6BC98A;">✅ 未检测到异常</div></div>`;
        }
        let sceneAuditHtml = '';
        if (this.structuredLogger) {
            const audit = this.structuredLogger.getSceneAudit(npc.id);
            if (audit.length > 0) {
                const recentAudit = audit.slice(-8);
                const auditLines = recentAudit.map(a => {
                    const h = Math.floor(a.time / 3600), m = Math.floor((a.time % 3600) / 60);
                    return `<div style="font-size:10px;color:#8a8a9a;">${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')} ${a.from} → ${a.to} <span style="color:#60a5fa;">(${a.reason})</span></div>`;
                }).join('');
                sceneAuditHtml = `<div class="debug-section"><div class="debug-section-title">🚪 场景切换审计 <span style="font-size:10px;color:#8a8a9a;">(最近${recentAudit.length}条)</span></div>${auditLines}</div>`;
            }
        }
        parentEl.innerHTML += arbiterHtml + detectorHtml + sceneAuditHtml;
    };

    proto._downloadDebugLog = function() {
        try {
            let content = `=== 福音镇 Debug Log (浏览器导出) ===\n`;
            content += `时间: ${new Date().toLocaleString()}\n`;
            content += `游戏日: 第${this.dayCount}天 ${this.getTimeStr()}\n`;
            content += `模式: ${this.mode}\n\n`;
            const rs = this.resourceSystem;
            if (rs) content += `【资源】🪵${Math.round(rs.woodFuel)} 🍞${Math.round(rs.food)} ⚡${Math.round(rs.power)} 💊${this._medkitCount || 0}\n\n`;
            for (const npc of this.npcs) {
                if (npc.isDead) { content += `【${npc.name}】已故 | ${npc.currentScene}\n\n`; continue; }
                content += `【${npc.name}】${npc.occupation}\n`;
                content += `  属性: San:${Math.round(npc.sanity)} HP:${Math.round(npc.health)} 体力:${Math.round(npc.stamina)} 饱腹:${Math.round(npc.hunger)}\n`;
                content += `  位置: ${npc.currentScene} (${Math.round(npc.x)},${Math.round(npc.y)})\n`;
                const flags = [];
                if (npc.isCrazy) flags.push('🤯发疯'); if (npc.isSleeping) flags.push('😴睡觉'); if (npc.isMoving) flags.push('🚶移动');
                content += `  状态: ${npc.state} ${flags.join(' ')} | ${npc.stateDesc || '无'}\n`;
                const ctrls = [];
                if (npc._priorityOverride) ctrls.push(`P0:${npc._priorityOverride}`);
                if (npc._stateOverride) ctrls.push(`state:${npc._stateOverride}`);
                if (npc._taskOverride && npc._taskOverride.isActive) ctrls.push(`task:${npc._taskOverride.taskId}`);
                content += `  控制: ${ctrls.length > 0 ? ctrls.join('|') : '正常日程'} 移动:${npc.isMoving ? '是' : '否'} 路径:${(npc.currentPath||[]).length}\n`;
                content += npc.getDebugLogText() + '\n\n';
            }
            const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a'); a.href = url;
            a.download = `debug_day${this.dayCount}_${Date.now()}.log`;
            a.click(); URL.revokeObjectURL(url);
            this.addEvent(GST.t('debug.log_downloaded'));
        } catch (err) { console.error('下载debug log失败:', err); }
    };

    proto._debugLogFailCount = 0;
    proto._debugLogMaxFails = 3;

    proto._saveDebugLogToServer = async function(quiet = false) {
        if (quiet && this._debugLogFailCount >= this._debugLogMaxFails) return;
        try {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
            const filename = `debug_day${this.dayCount}_${timestamp}.log`;
            let content = `=== 福音镇 Debug Log ===\n时间: ${new Date().toLocaleString()}\n游戏日: 第${this.dayCount}天 ${this.getTimeStr()}\n模式: ${this.mode}\n`;
            content += `模型: ${GST.LLM ? GST.LLM.model : '未知'}\nLLM状态: 总调用${typeof LLM_STATUS !== 'undefined' ? LLM_STATUS.totalCalls : '?'} 成功${typeof LLM_STATUS !== 'undefined' ? LLM_STATUS.successCalls : '?'}\n`;
            if (this.weatherSystem) {
                const ws = this.weatherSystem;
                const ot = typeof ws.getOutdoorTemp === 'function' ? ws.getOutdoorTemp() : ws.currentTemp;
                content += `天气: ${ws.weatherEmoji || ''} ${ws.currentWeather || '未知'} 室外:${ot != null ? ot + '°C' : '?'}\n`;
            }
            content += `${'='.repeat(60)}\n\n【资源状态】\n`;
            const rs = this.resourceSystem;
            if (rs) {
                content += `  🪵木柴: ${Math.round(rs.woodFuel)} | 🍞食物: ${Math.round(rs.food)} | ⚡电力: ${Math.round(rs.power)} | 💊急救包: ${this._medkitCount || 0}\n`;
                const dc = rs.dailyConsumed || {}, dg = rs.dailyCollected || {};
                content += `  今日消耗: 木柴${(dc.woodFuel||0).toFixed(1)} 食物${(dc.food||0).toFixed(1)} 电力${(dc.power||0).toFixed(1)}\n`;
                content += `  今日采集: 木柴${(dg.woodFuel||0).toFixed(1)} 食物${(dg.food||0).toFixed(1)} 电力${(dg.power||0).toFixed(1)}\n`;
            }
            const fs = this.furnaceSystem;
            if (fs) content += `  🔥供暖: 强度${fs.heatingStrength != null ? Math.round(fs.heatingStrength * 100) + '%' : '?'} 室温${fs.indoorTemp != null ? fs.indoorTemp.toFixed(1) : '?'}°C\n`;
            content += `\n【NPC 状态总览】\n${'─'.repeat(60)}\n`;
            for (const npc of this.npcs) {
                if (npc.isDead) { content += `【${npc.name}】已故 ${npc.currentScene}\n`; continue; }
                content += `【${npc.name}】${npc.occupation}\n`;
                content += `  属性: San:${Math.round(npc.sanity)} HP:${Math.round(npc.health)} 体力:${Math.round(npc.stamina)} 饱腹:${Math.round(npc.hunger)} 体温:${npc.bodyTemp != null ? npc.bodyTemp.toFixed(1) + '°C' : '?'}\n`;
                content += `  位置: ${npc.currentScene} (${Math.round(npc.x)},${Math.round(npc.y)})\n`;
                const sf = []; if (npc.isCrazy) sf.push('🤯发疯'); if (npc.isSleeping) sf.push('😴睡觉'); if (npc.isEating) sf.push('🍜吃饭'); if (npc.isMoving) sf.push('🚶移动中');
                content += `  状态: ${npc.state} | ${sf.length > 0 ? sf.join(' ') : '正常'} | 心情:${npc.mood}\n`;
                const ct = []; if (npc._priorityOverride) ct.push(`P0:${npc._priorityOverride}`); if (npc._stateOverride) ct.push(`stateOverride:${npc._stateOverride}`);
                if (npc._taskOverride && npc._taskOverride.isActive) ct.push(`task:${npc._taskOverride.taskId || '?'}`);
                content += `  控制层: ${ct.length > 0 ? ct.join(' | ') : '无覆盖'}\n`;
                content += `  移动: ${npc.isMoving ? '✅' : '❌'} 路径:${(npc.currentPath||[]).length}步\n`;
                if (npc._debugLog && npc._debugLog.length > 0) {
                    const rd = npc._debugLog.filter(e => ['think','action','schedule','override','goal'].includes(e.type)).slice(0, 5);
                    if (rd.length > 0) { content += `  最近决策:\n`; rd.forEach(e => { content += `    [${e.day !== undefined ? 'D'+e.day+' ' : ''}${e.time}] ${e.type}: ${e.detail}\n`; }); }
                }
                content += `${'─'.repeat(60)}\n`;
            }
            if (this.aiModeLogger && this.aiModeLogger._recentAnomalies) {
                const an = this.aiModeLogger._recentAnomalies;
                if (an.length > 0) { content += `\n【异常/告警】\n`; an.slice(0, 20).forEach(a => { content += `  ${a}\n`; }); }
            }
            content += `\n【事件日志】\n`;
            this.eventLog.slice(0, 50).forEach(e => { content += `  [${e.time}] ${e.text}\n`; });
            content += `\n【NPC 完整行动轨迹】\n`;
            for (const npc of this.npcs.filter(n => !n.isDead)) {
                if (npc._debugLog && npc._debugLog.length > 0) {
                    content += `  --- ${npc.name} ---\n`;
                    npc._debugLog.slice(0, 20).forEach(e => { content += `  [${e.day !== undefined ? 'D'+e.day+' ' : ''}${e.time}] ${e.type}: ${e.detail}\n`; });
                }
            }
            const resp = await fetch('/api/save-debug-log', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ filename, content }) });
            if (resp.ok) { this._debugLogFailCount = 0; console.log(`📝 Debug log 已保存: ${filename}`); if (!quiet) this.addEvent(GST.t('debug.log_saved', { filename })); }
            else throw new Error(`HTTP ${resp.status}`);
        } catch (err) {
            this._debugLogFailCount = (this._debugLogFailCount || 0) + 1;
            if (!quiet) { console.warn('保存debug log失败:', err.message); this._downloadDebugLog(); }
            else if (this._debugLogFailCount <= 1) console.warn(`[Debug Log] 自动保存失败:`, err.message);
            else if (this._debugLogFailCount === this._debugLogMaxFails) console.warn(`[Debug Log] 连续失败${this._debugLogMaxFails}次，暂停自动保存`);
        }
    };

})();
