/**
 * 福音镇 - 地图装饰与特殊区域
 * 从 village-map.js 拆分，遵循SRP原则
 * 挂载到 GST.VillageMap.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.VillageMap.prototype;


    proto._addDecorations = function() {
        // 枯树 — 外围雪原散布
        const treePositions = [
            [1,1],[9,1],[1,8],[10,8],
            [39,1],[47,1],[48,7],
            [1,33],[8,37],[1,38],
            [39,38],[47,33],[48,38],
            // 围墙外散落
            [10,15],[10,25],[40,15],[40,25],
        ];
        for (const [x, y] of treePositions) {
            this.decorations.push({
                type: 'tree', x, y,
                color: GST.C.TREE_CROWN2, // 枯枝积雪
                solid: true
            });
        }

        // 雪堆 — 围墙内外
        const snowPiles = [
            [20,16],[29,16],[20,24],[29,24],
            [12,20],[37,20],[25,10],[25,30],
        ];
        for (const [x, y] of snowPiles) {
            this.decorations.push({ type: 'snowpile', x, y, label: '雪堆' });
        }

        // 冰锥 — 建筑屋檐装饰（纯视觉）
        const icicles = [[14,11],[17,11],[31,11],[34,11],[14,18],[17,18],[31,18],[34,18]];
        for (const [x, y] of icicles) {
            this.decorations.push({ type: 'icicle', x, y });
        }

        // 废墟碎片 — 外围区域
        const debris = [[5,10],[44,10],[5,30],[44,30],[15,2],[35,2],[15,37],[35,37]];
        for (const [x, y] of debris) {
            this.decorations.push({ type: 'debris', x, y, label: '废墟碎片', solid: true });
        }

        // 围墙内道路旁的路灯 (简易火把)
        const torches = [[20,20],[29,20],[25,16],[25,24]];
        for (const [x, y] of torches) {
            this.decorations.push({ type: 'lamppost', x, y, label: '火把' });
        }

        // 告示牌
        this.decorations.push({ type: 'sign', x: 23, y: 16, label: '任务告示栏', solid: true });
    };


    /** 绘制单个装饰物（重写父类以支持末日新类型 — 升级版） */
    proto.drawDecoration = function(ctx, d, px, py) {
        switch (d.type) {
            case 'snowpile':
                // 雪堆阴影
                ctx.fillStyle = 'rgba(160,170,185,0.15)';
                ctx.beginPath();
                ctx.ellipse(px + 17, py + 28, 15, 4, 0, 0, Math.PI * 2);
                ctx.fill();
                // 雪堆主体（多层）
                ctx.fillStyle = '#E0E4EA';
                ctx.beginPath();
                ctx.ellipse(px + 16, py + 22, 14, 8, 0, 0, Math.PI * 2);
                ctx.fill();
                ctx.fillStyle = '#E8ECF2';
                ctx.beginPath();
                ctx.ellipse(px + 14, py + 20, 10, 6, -0.2, 0, Math.PI * 2);
                ctx.fill();
                // 雪堆高光
                ctx.fillStyle = 'rgba(255,255,255,0.35)';
                ctx.beginPath();
                ctx.ellipse(px + 12, py + 18, 6, 3, -0.3, 0, Math.PI * 2);
                ctx.fill();
                // 雪堆上的细碎冰晶
                ctx.fillStyle = 'rgba(200,220,240,0.3)';
                ctx.fillRect(px + 8, py + 16, 2, 2);
                ctx.fillRect(px + 20, py + 19, 2, 2);
                break;
            case 'icicle':
                // 冰锥（更精致，带透明折射效果）
                for (let i = 0; i < 4; i++) {
                    const ix = px + 4 + i * 7;
                    const ilen = 8 + GST.getTileNoise(d.x * 10 + i, d.y) * 8;
                    // 冰锥主体
                    ctx.fillStyle = 'rgba(180,220,240,0.6)';
                    ctx.beginPath();
                    ctx.moveTo(ix, py);
                    ctx.lineTo(ix + 3, py);
                    ctx.lineTo(ix + 1.5, py + ilen);
                    ctx.closePath();
                    ctx.fill();
                    // 高光
                    ctx.fillStyle = 'rgba(220,240,255,0.4)';
                    ctx.beginPath();
                    ctx.moveTo(ix + 0.5, py + 1);
                    ctx.lineTo(ix + 2, py + 1);
                    ctx.lineTo(ix + 1.5, py + ilen * 0.5);
                    ctx.closePath();
                    ctx.fill();
                }
                break;
            case 'debris':
                // 废墟阴影
                ctx.fillStyle = 'rgba(60,50,40,0.12)';
                ctx.fillRect(px + 4, py + 26, 24, 4);
                // 碎石主体
                ctx.fillStyle = '#8A7A6A';
                ctx.fillRect(px + 2, py + 16, 12, 8);
                ctx.fillRect(px + 8, py + 12, 16, 6);
                ctx.fillStyle = '#6A5A4A';
                ctx.fillRect(px + 6, py + 20, 8, 6);
                // 碎石细节
                ctx.fillStyle = '#9A8A7A';
                ctx.fillRect(px + 16, py + 10, 6, 4);
                // 积雪覆盖
                ctx.fillStyle = 'rgba(220,224,230,0.4)';
                ctx.fillRect(px + 3, py + 14, 10, 2);
                ctx.fillRect(px + 10, py + 10, 12, 2);
                break;
            default:
                GST.BaseMap.prototype.drawDecoration.call(this, ctx, d, px, py);
                break;
        }
    };


    /** 主暖炉广场渲染对象 — 升级版 */
    proto._makeFurnacePlazaObj = function() {
        const fp = this.furnacePlaza;
        return {
            fp,
            isGround: true,
            getSortY() { return (this.fp.y + this.fp.h) * GST.TILE; },
            draw(ctx) {
                const px = this.fp.x * GST.TILE;
                const py = this.fp.y * GST.TILE;
                const pw = this.fp.w * GST.TILE;
                const ph = this.fp.h * GST.TILE;

                // ★ 底图模式：静态部分已烘焙进底图，只绘制动态火焰+光晕
                const _hasBaseMap = typeof SpriteLoader !== 'undefined' && SpriteLoader.enabled && SpriteLoader.getMap('village_base');
                if (_hasBaseMap) {
                    const cx = px + pw / 2;
                    const cy = py + ph / 2;
                    // 火焰动画
                    const t = Date.now() / 200;
                    const flicker = Math.sin(t) * 3;
                    const flicker2 = Math.cos(t * 1.3) * 2;
                    ctx.fillStyle = 'rgba(200,60,10,0.35)';
                    ctx.beginPath();
                    ctx.ellipse(cx, cy, 16 + flicker, 20 + flicker, 0, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillStyle = 'rgba(255,120,20,0.55)';
                    ctx.beginPath();
                    ctx.ellipse(cx, cy - 2, 12 + flicker * 0.8, 16 + flicker * 0.8, 0, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillStyle = 'rgba(255,200,50,0.75)';
                    ctx.beginPath();
                    ctx.ellipse(cx, cy - 2, 7 + flicker2, 10 + flicker2, 0, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillStyle = 'rgba(255,240,200,0.5)';
                    ctx.beginPath();
                    ctx.ellipse(cx, cy - 1, 3, 5, 0, 0, Math.PI * 2);
                    ctx.fill();
                    // 火星
                    ctx.fillStyle = 'rgba(255,180,60,0.6)';
                    for (let i = 0; i < 3; i++) {
                        const sx = cx + Math.sin(t * 2 + i * 2) * 8;
                        const sy = cy - 10 - Math.abs(Math.sin(t * 3 + i)) * 12;
                        ctx.beginPath();
                        ctx.arc(sx, sy, 1.5, 0, Math.PI * 2);
                        ctx.fill();
                    }
                    // 暖光辐射
                    const grad = ctx.createRadialGradient(cx, cy, 8, cx, cy, 100);
                    grad.addColorStop(0, 'rgba(255,180,60,0.2)');
                    grad.addColorStop(0.5, 'rgba(255,150,40,0.06)');
                    grad.addColorStop(1, 'rgba(255,180,60,0)');
                    ctx.fillStyle = grad;
                    ctx.fillRect(cx - 100, cy - 100, 200, 200);
                    return; // 跳过完整绘制
                }

                // 广场石砖底座
                ctx.fillStyle = GST.C.PLAZA;
                ctx.fillRect(px, py, pw, ph);
                // 石砖纹理
                ctx.strokeStyle = 'rgba(0,0,0,0.06)';
                ctx.lineWidth = 0.5;
                for (let by = py; by < py + ph; by += 16) {
                    ctx.beginPath();
                    ctx.moveTo(px, by);
                    ctx.lineTo(px + pw, by);
                    ctx.stroke();
                    const offset = ((by - py) / 16 % 2) * 8;
                    for (let bx = px + offset; bx < px + pw; bx += 16) {
                        ctx.beginPath();
                        ctx.moveTo(bx, by);
                        ctx.lineTo(bx, by + 16);
                        ctx.stroke();
                    }
                }
                // 广场边缘装饰线
                ctx.strokeStyle = 'rgba(120,110,100,0.2)';
                ctx.lineWidth = 1.5;
                ctx.setLineDash([6, 3]);
                ctx.strokeRect(px + 4, py + 4, pw - 8, ph - 8);
                ctx.setLineDash([]);

                // 暖炉主体（更丰富的结构）
                const cx = px + pw / 2;
                const cy = py + ph / 2;
                // 暖炉底座
                ctx.fillStyle = '#484848';
                ctx.fillRect(cx - 24, cy - 18, 48, 36);
                // 暖炉主体
                ctx.fillStyle = '#3A3A3A';
                ctx.fillRect(cx - 20, cy - 14, 40, 28);
                // 暖炉顶盖
                ctx.fillStyle = '#505050';
                ctx.fillRect(cx - 22, cy - 18, 44, 6);
                // 暖炉排气管
                ctx.fillStyle = '#444';
                ctx.fillRect(cx + 10, cy - 26, 6, 12);
                // 暖炉铆钉装饰
                ctx.fillStyle = '#707070';
                const rivets = [[-16,-10],[-16,6],[16,-10],[16,6]];
                for (const [rx,ry] of rivets) {
                    ctx.beginPath();
                    ctx.arc(cx + rx, cy + ry, 2, 0, Math.PI * 2);
                    ctx.fill();
                }
                // 暖炉开口（火焰可见处）
                ctx.fillStyle = '#2A1A0A';
                ctx.fillRect(cx - 12, cy - 6, 24, 18);

                // 火焰动画（多层，更丰富）
                const t = Date.now() / 200;
                const flicker = Math.sin(t) * 3;
                const flicker2 = Math.cos(t * 1.3) * 2;
                // 最外层——红焰
                ctx.fillStyle = 'rgba(200,60,10,0.35)';
                ctx.beginPath();
                ctx.ellipse(cx, cy, 16 + flicker, 20 + flicker, 0, 0, Math.PI * 2);
                ctx.fill();
                // 外焰——橙色
                ctx.fillStyle = 'rgba(255,120,20,0.55)';
                ctx.beginPath();
                ctx.ellipse(cx, cy - 2, 12 + flicker * 0.8, 16 + flicker * 0.8, 0, 0, Math.PI * 2);
                ctx.fill();
                // 内焰——黄色
                ctx.fillStyle = 'rgba(255,200,50,0.75)';
                ctx.beginPath();
                ctx.ellipse(cx, cy - 2, 7 + flicker2, 10 + flicker2, 0, 0, Math.PI * 2);
                ctx.fill();
                // 核心白热
                ctx.fillStyle = 'rgba(255,240,200,0.5)';
                ctx.beginPath();
                ctx.ellipse(cx, cy - 1, 3, 5, 0, 0, Math.PI * 2);
                ctx.fill();
                // 火星粒子
                ctx.fillStyle = 'rgba(255,180,60,0.6)';
                for (let i = 0; i < 3; i++) {
                    const sx = cx + Math.sin(t * 2 + i * 2) * 8;
                    const sy = cy - 10 - Math.abs(Math.sin(t * 3 + i)) * 12;
                    ctx.beginPath();
                    ctx.arc(sx, sy, 1.5, 0, Math.PI * 2);
                    ctx.fill();
                }

                // 暖光辐射（更大范围）
                const grad = ctx.createRadialGradient(cx, cy, 8, cx, cy, 100);
                grad.addColorStop(0, 'rgba(255,180,60,0.2)');
                grad.addColorStop(0.5, 'rgba(255,150,40,0.06)');
                grad.addColorStop(1, 'rgba(255,180,60,0)');
                ctx.fillStyle = grad;
                ctx.fillRect(cx - 100, cy - 100, 200, 200);

                // 标签（带背景）
                ctx.font = 'bold 10px sans-serif';
                ctx.textAlign = 'center';
                const label = '🔥 主暖炉';
                const lw = ctx.measureText(label).width;
                ctx.fillStyle = 'rgba(0,0,0,0.3)';
                ctx.beginPath();
                ctx.roundRect(cx - lw/2 - 4, py - 14, lw + 8, 14, 3);
                ctx.fill();
                ctx.fillStyle = 'rgba(255,200,80,0.9)';
                ctx.fillText(label, cx, py - 4);
                ctx.textAlign = 'left';
            }
        };
    };


    /** 户外资源区域渲染对象 */
    proto._makeResourceAreaObj = function(area) {
        return {
            area,
            isGround: true,
            getSortY() { return (this.area.y + this.area.h) * GST.TILE; },
            draw(ctx) {
                // ★ 底图模式：资源区域已烘焙进底图，跳过绘制
                if (typeof SpriteLoader !== 'undefined' && SpriteLoader.enabled && SpriteLoader.getMap('village_base')) return;

                const px = this.area.x * GST.TILE;
                const py = this.area.y * GST.TILE;
                const pw = this.area.w * GST.TILE;
                const ph = this.area.h * GST.TILE;

                // 区域底色（渐变）
                const areaGrad = ctx.createRadialGradient(
                    px + pw/2, py + ph/2, 10,
                    px + pw/2, py + ph/2, Math.max(pw, ph) * 0.6
                );
                areaGrad.addColorStop(0, this.area.color);
                areaGrad.addColorStop(1, 'rgba(0,0,0,0)');
                ctx.fillStyle = areaGrad;
                ctx.globalAlpha = 0.25;
                ctx.fillRect(px, py, pw, ph);
                ctx.globalAlpha = 1;

                // 边框（带角装饰）
                ctx.strokeStyle = this.area.color;
                ctx.lineWidth = 1.5;
                ctx.setLineDash([6, 4]);
                ctx.strokeRect(px + 3, py + 3, pw - 6, ph - 6);
                ctx.setLineDash([]);
                // 角落标记
                ctx.fillStyle = this.area.color;
                ctx.globalAlpha = 0.4;
                ctx.fillRect(px + 2, py + 2, 8, 2);
                ctx.fillRect(px + 2, py + 2, 2, 8);
                ctx.fillRect(px + pw - 10, py + 2, 8, 2);
                ctx.fillRect(px + pw - 4, py + 2, 2, 8);
                ctx.fillRect(px + 2, py + ph - 4, 8, 2);
                ctx.fillRect(px + 2, py + ph - 10, 2, 8);
                ctx.fillRect(px + pw - 10, py + ph - 4, 8, 2);
                ctx.fillRect(px + pw - 4, py + ph - 10, 2, 8);
                ctx.globalAlpha = 1;

                // 区域特色装饰
                if (this.area.id === 'lumber_camp') {
                    // 伐木场 — 树桩+斧头+原木堆
                    for (let i = 0; i < 4; i++) {
                        const sx = px + 16 + (i % 2) * 60;
                        const sy = py + 20 + Math.floor(i / 2) * 50;
                        // 树桩阴影
                        ctx.fillStyle = 'rgba(60,50,40,0.12)';
                        ctx.beginPath();
                        ctx.ellipse(sx + 8, sy + 14, 12, 4, 0, 0, Math.PI * 2);
                        ctx.fill();
                        // 树桩主体
                        ctx.fillStyle = GST.C.TREE_TRUNK;
                        ctx.fillRect(sx, sy, 16, 12);
                        // 年轮顶面
                        ctx.fillStyle = '#B8A088';
                        ctx.beginPath();
                        ctx.ellipse(sx + 8, sy, 10, 6, 0, 0, Math.PI * 2);
                        ctx.fill();
                        ctx.strokeStyle = 'rgba(100,80,60,0.3)';
                        ctx.lineWidth = 0.5;
                        ctx.beginPath();
                        ctx.ellipse(sx + 8, sy, 6, 3, 0, 0, Math.PI * 2);
                        ctx.stroke();
                        ctx.beginPath();
                        ctx.ellipse(sx + 8, sy, 3, 1.5, 0, 0, Math.PI * 2);
                        ctx.stroke();
                        // 积雪
                        ctx.fillStyle = 'rgba(230,234,240,0.4)';
                        ctx.beginPath();
                        ctx.ellipse(sx + 6, sy - 2, 6, 3, 0, 0, Math.PI * 2);
                        ctx.fill();
                    }
                    // 原木堆
                    ctx.fillStyle = '#7B5828';
                    ctx.fillRect(px + pw - 60, py + 20, 40, 14);
                    ctx.fillStyle = '#6B4820';
                    ctx.fillRect(px + pw - 58, py + 34, 36, 12);
                    ctx.fillStyle = 'rgba(230,234,240,0.3)';
                    ctx.fillRect(px + pw - 60, py + 18, 40, 3);
                } else if (this.area.id === 'ruins_site') {
                    // 废墟 — 碎石堆+断墙+钢筋
                    ctx.fillStyle = '#8A7A6A';
                    ctx.fillRect(px + 20, py + 20, 40, 20);
                    ctx.fillRect(px + 80, py + 40, 40, 25);
                    ctx.fillStyle = '#6A5A4A';
                    ctx.fillRect(px + 50, py + 10, 20, 30);
                    // 断墙
                    ctx.fillStyle = '#7A726A';
                    ctx.fillRect(px + 120, py + 15, 8, 40);
                    ctx.fillStyle = '#6A625A';
                    ctx.fillRect(px + 128, py + 25, 6, 20);
                    // 钢筋
                    ctx.strokeStyle = '#808080';
                    ctx.lineWidth = 1.5;
                    ctx.beginPath();
                    ctx.moveTo(px + 126, py + 15);
                    ctx.lineTo(px + 130, py + 5);
                    ctx.moveTo(px + 122, py + 12);
                    ctx.lineTo(px + 118, py + 2);
                    ctx.stroke();
                    // 积雪
                    ctx.fillStyle = 'rgba(220,224,230,0.35)';
                    ctx.fillRect(px + 22, py + 18, 36, 3);
                    ctx.fillRect(px + 82, py + 38, 36, 3);
                    ctx.fillRect(px + 120, py + 13, 8, 3);
                } else if (this.area.id === 'frozen_lake') {
                    // 冰湖 — 更丰富的冰面效果
                    // 湖岸
                    ctx.fillStyle = 'rgba(160,170,180,0.2)';
                    ctx.beginPath();
                    ctx.ellipse(px + pw/2, py + ph/2, pw/2 - 4, ph/2 - 4, 0, 0, Math.PI * 2);
                    ctx.fill();
                    // 冰面主体
                    const iceGrad = ctx.createRadialGradient(
                        px + pw/2 - 10, py + ph/2 - 10, 10,
                        px + pw/2, py + ph/2, pw/2 - 10
                    );
                    iceGrad.addColorStop(0, '#C8E0F0');
                    iceGrad.addColorStop(0.5, '#B8D4E8');
                    iceGrad.addColorStop(1, '#A0C0D8');
                    ctx.fillStyle = iceGrad;
                    ctx.beginPath();
                    ctx.ellipse(px + pw/2, py + ph/2, pw/2 - 8, ph/2 - 8, 0, 0, Math.PI * 2);
                    ctx.fill();
                    // 冰面高光
                    ctx.fillStyle = 'rgba(220,240,255,0.25)';
                    ctx.beginPath();
                    ctx.ellipse(px + pw/2 - 15, py + ph/2 - 15, 20, 12, -0.3, 0, Math.PI * 2);
                    ctx.fill();
                    // 冰裂纹（多条）
                    ctx.strokeStyle = 'rgba(180,210,230,0.3)';
                    ctx.lineWidth = 0.8;
                    ctx.beginPath();
                    ctx.moveTo(px + pw/2 - 30, py + ph/2 + 5);
                    ctx.lineTo(px + pw/2 + 25, py + ph/2 - 15);
                    ctx.moveTo(px + pw/2 - 5, py + ph/2 - 20);
                    ctx.lineTo(px + pw/2 + 15, py + ph/2 + 20);
                    ctx.moveTo(px + pw/2 + 10, py + ph/2 - 10);
                    ctx.lineTo(px + pw/2 + 30, py + ph/2 + 5);
                    ctx.stroke();
                    // 冰钓洞（小）
                    ctx.fillStyle = '#708090';
                    ctx.beginPath();
                    ctx.arc(px + pw/2 + 20, py + ph/2 + 10, 4, 0, Math.PI * 2);
                    ctx.fill();
                } else if (this.area.id === 'ore_pile') {
                    // 矿渣堆 — 各色矿石+矿车
                    const oreColors = ['#6A6A6A', '#7A7A6A', '#5A6A6A', '#6A5A5A', '#7A6A5A'];
                    for (let i = 0; i < 6; i++) {
                        const ox = px + 18 + (i * 42) % (pw - 36);
                        const oy = py + 22 + Math.floor(i / 3) * 44;
                        const r = 8 + (i % 3) * 3;
                        // 阴影
                        ctx.fillStyle = 'rgba(40,40,40,0.1)';
                        ctx.beginPath();
                        ctx.ellipse(ox, oy + r + 2, r + 2, 3, 0, 0, Math.PI * 2);
                        ctx.fill();
                        // 石头
                        ctx.fillStyle = oreColors[i % oreColors.length];
                        ctx.beginPath();
                        ctx.arc(ox, oy, r, 0, Math.PI * 2);
                        ctx.fill();
                        // 高光
                        ctx.fillStyle = 'rgba(200,200,200,0.15)';
                        ctx.beginPath();
                        ctx.arc(ox - 2, oy - 2, r * 0.4, 0, Math.PI * 2);
                        ctx.fill();
                    }
                    // 小矿车轮廓
                    ctx.fillStyle = '#505050';
                    ctx.fillRect(px + pw - 50, py + ph - 30, 30, 16);
                    ctx.fillStyle = '#606060';
                    ctx.fillRect(px + pw - 48, py + ph - 28, 26, 12);
                    // 车轮
                    ctx.fillStyle = '#404040';
                    ctx.beginPath();
                    ctx.arc(px + pw - 44, py + ph - 12, 4, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.beginPath();
                    ctx.arc(px + pw - 26, py + ph - 12, 4, 0, Math.PI * 2);
                    ctx.fill();
                }

                // 区域名称标签（带背景板）
                ctx.font = 'bold 10px sans-serif';
                ctx.textAlign = 'center';
                const nameText = this.area.name;
                const nameW = ctx.measureText(nameText).width;
                // 标签底板
                ctx.fillStyle = 'rgba(0,0,0,0.35)';
                ctx.beginPath();
                ctx.roundRect(px + pw/2 - nameW/2 - 5, py + ph + 4, nameW + 10, 14, 3);
                ctx.fill();
                ctx.fillStyle = 'rgba(255,255,255,0.85)';
                ctx.fillText(nameText, px + pw / 2, py + ph + 14);
                // 危险等级
                const dangerColor = this.area.danger === '高' ? '#FF6060' : '#F0C050';
                const dangerBg = this.area.danger === '高' ? 'rgba(255,60,60,0.15)' : 'rgba(240,192,80,0.12)';
                const dangerText = `⚠ 危险:${this.area.danger}`;
                const dangerW = ctx.measureText(dangerText).width;
                ctx.fillStyle = dangerBg;
                ctx.beginPath();
                ctx.roundRect(px + pw/2 - dangerW/2 - 4, py + ph + 18, dangerW + 8, 12, 3);
                ctx.fill();
                ctx.fillStyle = dangerColor;
                ctx.font = '9px sans-serif';
                ctx.fillText(dangerText, px + pw / 2, py + ph + 27);
                ctx.textAlign = 'left';
            }
        };
    };


    /** 围墙渲染对象 — 升级版（石砖纹理+积雪+瞭望塔） */
    proto._makeWallObj = function() {
        const wb = this.wallBounds;
        const ng = this.northGate;
        const sg = this.southGate;
        const self = this;
        return {
            getSortY() { return wb.y2 * GST.TILE; },
            draw(ctx) {
                // ★ 底图模式：围墙已烘焙进底图，跳过绘制
                if (typeof SpriteLoader !== 'undefined' && SpriteLoader.enabled && SpriteLoader.getMap('village_base')) return;

                const wallColor = '#706858';
                const wallTopColor = '#5A4A3A';
                const snowColor = 'rgba(230,234,240,0.5)';
                const lineW = 4;

                // 绘制围墙四边（留出大门）— 带石砖纹理
                const drawWallSegment = (x1, y1, w, h) => {
                    // 主墙体
                    ctx.fillStyle = wallColor;
                    ctx.fillRect(x1, y1, w, h);
                    // 砖缝纹理
                    ctx.strokeStyle = 'rgba(0,0,0,0.1)';
                    ctx.lineWidth = 0.5;
                    if (w > h) {
                        // 水平墙
                        for (let bx = x1; bx < x1 + w; bx += 12) {
                            ctx.beginPath();
                            ctx.moveTo(bx, y1);
                            ctx.lineTo(bx, y1 + h);
                            ctx.stroke();
                        }
                    } else {
                        // 垂直墙
                        for (let by = y1; by < y1 + h; by += 12) {
                            ctx.beginPath();
                            ctx.moveTo(x1, by);
                            ctx.lineTo(x1 + w, by);
                            ctx.stroke();
                        }
                    }
                    // 顶部积雪
                    ctx.fillStyle = snowColor;
                    if (w > h) {
                        ctx.fillRect(x1, y1 - 2, w, 3);
                    } else {
                        ctx.fillRect(x1 - 1, y1, 2, h);
                    }
                };

                // 北墙 — 留北门
                drawWallSegment(wb.x1 * GST.TILE, wb.y1 * GST.TILE - 2, (ng.x - wb.x1) * GST.TILE, lineW + 4);
                drawWallSegment((ng.x + ng.w) * GST.TILE, wb.y1 * GST.TILE - 2, (wb.x2 - ng.x - ng.w) * GST.TILE, lineW + 4);
                // 南墙 — 留南门
                drawWallSegment(wb.x1 * GST.TILE, wb.y2 * GST.TILE - 2, (sg.x - wb.x1) * GST.TILE, lineW + 4);
                drawWallSegment((sg.x + sg.w) * GST.TILE, wb.y2 * GST.TILE - 2, (wb.x2 - sg.x - sg.w) * GST.TILE, lineW + 4);
                // 西墙
                drawWallSegment(wb.x1 * GST.TILE - 2, wb.y1 * GST.TILE, lineW + 4, (wb.y2 - wb.y1) * GST.TILE);
                // 东墙
                drawWallSegment(wb.x2 * GST.TILE - 2, wb.y1 * GST.TILE, lineW + 4, (wb.y2 - wb.y1) * GST.TILE);

                // 围墙柱子 (每隔3格) — 带积雪顶
                ctx.fillStyle = wallTopColor;
                for (let x = wb.x1; x <= wb.x2; x += 3) {
                    if (x < ng.x || x >= ng.x + ng.w) {
                        ctx.fillStyle = wallTopColor;
                        ctx.fillRect(x * GST.TILE - 3, wb.y1 * GST.TILE - 8, 8, 14);
                        ctx.fillStyle = snowColor;
                        ctx.fillRect(x * GST.TILE - 3, wb.y1 * GST.TILE - 10, 8, 3);
                    }
                    if (x < sg.x || x >= sg.x + sg.w) {
                        ctx.fillStyle = wallTopColor;
                        ctx.fillRect(x * GST.TILE - 3, wb.y2 * GST.TILE - 8, 8, 14);
                        ctx.fillStyle = snowColor;
                        ctx.fillRect(x * GST.TILE - 3, wb.y2 * GST.TILE - 10, 8, 3);
                    }
                }
                for (let y = wb.y1; y <= wb.y2; y += 3) {
                    ctx.fillStyle = wallTopColor;
                    ctx.fillRect(wb.x1 * GST.TILE - 8, y * GST.TILE - 3, 14, 8);
                    ctx.fillRect(wb.x2 * GST.TILE - 6, y * GST.TILE - 3, 14, 8);
                }

                // === 四角瞭望塔 ===
                const drawTower = (tx, ty) => {
                    // 塔身
                    ctx.fillStyle = '#605848';
                    ctx.fillRect(tx - 8, ty - 8, 18, 18);
                    // 塔顶
                    ctx.fillStyle = '#504838';
                    ctx.fillRect(tx - 10, ty - 12, 22, 6);
                    // 积雪
                    ctx.fillStyle = snowColor;
                    ctx.fillRect(tx - 10, ty - 14, 22, 3);
                    // 垛口
                    ctx.fillStyle = '#504838';
                    for (let i = 0; i < 3; i++) {
                        ctx.fillRect(tx - 8 + i * 7, ty - 16, 4, 4);
                    }
                };
                drawTower(wb.x1 * GST.TILE, wb.y1 * GST.TILE);
                drawTower(wb.x2 * GST.TILE, wb.y1 * GST.TILE);
                drawTower(wb.x1 * GST.TILE, wb.y2 * GST.TILE);
                drawTower(wb.x2 * GST.TILE, wb.y2 * GST.TILE);

                // === 大门渲染（升级版：门楼结构） ===
                const gateColor = self.gatesClosed ? '#5A3020' : '#8B6830';
                const gateLabel = self.gatesClosed ? '🔒' : '🚪';

                // 北门门楼
                const ngPx = ng.x * GST.TILE;
                const ngPy = wb.y1 * GST.TILE;
                // 门楼柱
                ctx.fillStyle = wallTopColor;
                ctx.fillRect(ngPx - 4, ngPy - 14, 6, 20);
                ctx.fillRect(ngPx + ng.w * GST.TILE - 2, ngPy - 14, 6, 20);
                // 门楼横梁
                ctx.fillStyle = wallTopColor;
                ctx.fillRect(ngPx - 4, ngPy - 16, ng.w * GST.TILE + 8, 5);
                // 积雪
                ctx.fillStyle = snowColor;
                ctx.fillRect(ngPx - 4, ngPy - 18, ng.w * GST.TILE + 8, 3);
                // 门板
                ctx.fillStyle = gateColor;
                ctx.fillRect(ngPx, ngPy - 4, ng.w * GST.TILE, 8);
                // 门铁条装饰
                ctx.strokeStyle = 'rgba(80,70,60,0.4)';
                ctx.lineWidth = 1;
                for (let gx = ngPx + 4; gx < ngPx + ng.w * GST.TILE; gx += 8) {
                    ctx.beginPath();
                    ctx.moveTo(gx, ngPy - 4);
                    ctx.lineTo(gx, ngPy + 4);
                    ctx.stroke();
                }
                // 标签
                ctx.fillStyle = 'rgba(255,255,255,0.85)';
                ctx.font = 'bold 10px sans-serif';
                ctx.textAlign = 'center';
                ctx.fillText(`${gateLabel}北门`, (ng.x + ng.w / 2) * GST.TILE, ngPy - 22);

                // 南门门楼 (同北门镜像)
                const sgPx = sg.x * GST.TILE;
                const sgPy = wb.y2 * GST.TILE;
                ctx.fillStyle = wallTopColor;
                ctx.fillRect(sgPx - 4, sgPy - 6, 6, 20);
                ctx.fillRect(sgPx + sg.w * GST.TILE - 2, sgPy - 6, 6, 20);
                ctx.fillStyle = wallTopColor;
                ctx.fillRect(sgPx - 4, sgPy - 8, sg.w * GST.TILE + 8, 5);
                ctx.fillStyle = snowColor;
                ctx.fillRect(sgPx - 4, sgPy - 10, sg.w * GST.TILE + 8, 3);
                ctx.fillStyle = gateColor;
                ctx.fillRect(sgPx, sgPy - 4, sg.w * GST.TILE, 8);
                ctx.strokeStyle = 'rgba(80,70,60,0.4)';
                ctx.lineWidth = 1;
                for (let gx = sgPx + 4; gx < sgPx + sg.w * GST.TILE; gx += 8) {
                    ctx.beginPath();
                    ctx.moveTo(gx, sgPy - 4);
                    ctx.lineTo(gx, sgPy + 4);
                    ctx.stroke();
                }
                ctx.fillStyle = 'rgba(255,255,255,0.85)';
                ctx.font = 'bold 10px sans-serif';
                ctx.fillText(`${gateLabel}南门`, (sg.x + sg.w / 2) * GST.TILE, sgPy - 14);
                ctx.textAlign = 'left';
            }
        };
    };

})();
