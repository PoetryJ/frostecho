/**
 * 福音镇 - KitchenMap 炊事房
 */
(function() {
    'use strict';
    const GST = window.GST;

    class KitchenMap extends GST.IndoorMap {
        constructor() {
            super(8, 8, '炊事房', 'village', { x: 15, y: 31 });
            this.locationKey = 'kitchen';
            this.indoorMapKey = 'kitchen_indoor';
            this.floorColor = GST.C.FLOOR_TILE;
            this.furniture = [
                { x: 1, y: 1, w: 3, h: 1, color: GST.C.STOVE,   get name() { return GST.i18n && GST.i18n.isEn() ? 'Stove' : '灶台'; } },
                { x: 5, y: 1, w: 2, h: 2, color: GST.C.SHELF,   get name() { return GST.i18n && GST.i18n.isEn() ? 'Pantry' : '食材架'; } },
                { x: 2, y: 4, w: 4, h: 2, color: GST.C.TABLE,   get name() { return GST.i18n && GST.i18n.isEn() ? 'Table' : '餐桌'; } },
            ];
            // 餐桌座位（可坐6人）
            this.seats = [
                { x: 1, y: 4 }, { x: 1, y: 5 },   // 左侧
                { x: 6, y: 4 }, { x: 6, y: 5 },   // 右侧
                { x: 3, y: 3 }, { x: 4, y: 3 },   // 上方
            ];
        }
    
        drawGrid(ctx, camera) {
            super.drawGrid(ctx, camera);
            if (!this._hasBaseMap) {
                for (const f of this.furniture) {
                    ctx.fillStyle = f.color;
                    ctx.fillRect(f.x * GST.TILE, f.y * GST.TILE, f.w * GST.TILE, f.h * GST.TILE);
                    ctx.fillStyle = 'rgba(255,255,255,0.4)';
                    ctx.font = '7px sans-serif';
                    ctx.textAlign = 'center';
                    ctx.fillText(f.name, (f.x + f.w / 2) * GST.TILE, (f.y - 0.2) * GST.TILE);
                    ctx.textAlign = 'left';
                }
            }
            // 灶台动态火焰特效（底图模式下也绘制）
            {
                const t = Date.now() / 200;
                const cx = 2.5 * GST.TILE, cy = 1.5 * GST.TILE;
                const flicker = Math.sin(t) * 2;

                ctx.save();

                // 暖光辐射
                const pulse = 0.85 + Math.sin(t * 0.6) * 0.15;
                const grad = ctx.createRadialGradient(cx, cy, 3, cx, cy, 50 * pulse);
                grad.addColorStop(0, 'rgba(255,160,50,0.18)');
                grad.addColorStop(0.4, 'rgba(255,120,30,0.06)');
                grad.addColorStop(1, 'rgba(255,60,10,0)');
                ctx.fillStyle = grad;
                ctx.fillRect(cx - 55, cy - 55, 110, 110);

                // 外焰——橙色
                ctx.fillStyle = `rgba(255,120,20,${0.4 + Math.sin(t * 1.1) * 0.1})`;
                ctx.beginPath();
                ctx.ellipse(cx, cy - 1, 10 + flicker * 0.6, 12 + flicker * 0.6, 0, 0, Math.PI * 2);
                ctx.fill();

                // 内焰——黄色
                ctx.fillStyle = `rgba(255,200,50,${0.55 + Math.sin(t * 1.5) * 0.1})`;
                ctx.beginPath();
                ctx.ellipse(cx, cy - 1, 6 + flicker * 0.4, 8 + flicker * 0.4, 0, 0, Math.PI * 2);
                ctx.fill();

                // 核心白热
                ctx.fillStyle = 'rgba(255,240,200,0.45)';
                ctx.beginPath();
                ctx.ellipse(cx, cy, 2.5, 4, 0, 0, Math.PI * 2);
                ctx.fill();

                // 火花粒子（3颗小火星）
                ctx.fillStyle = 'rgba(255,180,60,0.65)';
                for (let i = 0; i < 3; i++) {
                    const phase = t * 1.8 + i * 2.1;
                    const life = (phase % 2.5) / 2.5;
                    const sx = cx + Math.sin(phase * 2.5) * (4 + life * 5);
                    const sy = cy - 5 - life * 15;
                    const sparkAlpha = (1 - life) * 0.7;
                    ctx.globalAlpha = sparkAlpha;
                    ctx.beginPath();
                    ctx.arc(sx, sy, (1 - life) * 1.5 + 0.3, 0, Math.PI * 2);
                    ctx.fill();
                }
                ctx.globalAlpha = 1;

                ctx.restore();
            }
    
            // 座位标记（fallback模式下绘制）
            if (!this._hasBaseMap) {
                ctx.fillStyle = 'rgba(255,255,255,0.1)';
                for (const s of this.seats) {
                    ctx.fillRect(s.x * GST.TILE + 4, s.y * GST.TILE + 4, GST.TILE - 8, GST.TILE - 8);
                }
            }
        }
    
        _isFurnitureSolid(gx, gy) {
            for (const f of this.furniture) {
                if (gx >= f.x && gx < f.x + f.w && gy >= f.y && gy < f.y + f.h) return true;
            }
            return false;
        }
    
        describe(gx, gy) {
            const others = this._getOtherPeopleHere();
            const isEn = GST.i18n && GST.i18n.isEn();
            const dn = this.displayName;
            let desc = isEn
                ? `You are in the ${dn}. Steam rises from the stove, the dining table seats 6.`
                : `你在${dn}里。灶台上冒着热气，餐桌可以在6个人。`;
            if (others.length > 0) desc += isEn ? ` ${others.join(', ')} are here.` : `这里有${others.join('、')}。`;
            else desc += isEn ? ' No one else is here.' : '目前空无一人。';
            desc += isEn ? ' Exit is to the south.' : '出口在南边。';
            return desc;
        }    
        getInterestPoints(gx, gy) {
            const isEn = GST.i18n && GST.i18n.isEn();
            return [
                { x: 2, y: 2, name: isEn ? 'Stove' : '灶台', desc: isEn ? 'Cook' : '做饭', walkTo: { x: 2, y: 2 } },
                { x: 3, y: 6, name: isEn ? 'Dining Table' : '餐桌旁', desc: isEn ? 'Sit down and eat' : '坐下吃饭', walkTo: { x: 3, y: 6 } },
                ...super.getInterestPoints(gx, gy)
            ];
        }
    }

    GST.KitchenMap = KitchenMap;
})();
