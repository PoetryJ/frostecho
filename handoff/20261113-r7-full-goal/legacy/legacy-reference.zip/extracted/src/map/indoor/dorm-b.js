/**
 * 福音镇 - DormBMap 宿舍B
 */
(function() {
    'use strict';
    const GST = window.GST;

    class DormBMap extends GST.IndoorMap {
        constructor() {
            super(12, 8, '宿舍B', 'village', { x: 33, y: 24 });
            this.locationKey = 'dorm_b';
            this.indoorMapKey = 'dorm_b_indoor';
            this.floorColor = GST.C.FLOOR_WOOD;
            this.secondFurnaceBuilt = true; // 兼容旧存档字段：不再存在第二暖炉玩法
            this.furniture = [
                { x: 1, y: 1, w: 2, h: 1, color: GST.C.BED,     name: '李婶的床' },
                { x: 4, y: 1, w: 2, h: 1, color: '#E080A0', name: '歆玥的床' },
                { x: 7, y: 1, w: 2, h: 1, color: '#4090B0', name: '清璇的床' },
                { x: 10, y: 1, w: 1, h: 1, color: '#E0A0B0', name: '空床位' },
                { x: 1,  y: 4, w: 2, h: 2, color: '#A05030', name: '取暖火盆' },
                { x: 5,  y: 5, w: 2, h: 1, color: GST.C.TABLE,  name: '简易桌' },
                { x: 9,  y: 4, w: 2, h: 2, color: '#6E5A3A', name: '保暖物资角' },
            ];
            this.beds = [
                { npc: '李婶', x: 1, y: 2 },
                { npc: '歆玥', x: 4, y: 2 },
                { npc: '清璇', x: 7, y: 2 },
            ];
            this.storageCorner = { x: 9, y: 4, w: 2, h: 2 }; // 保暖物资角
        }
    
        drawGrid(ctx, camera) {
            super.drawGrid(ctx, camera);
            // 底图模式下跳过家具色块
            if (!this._hasBaseMap) {
                for (const f of this.furniture) {
                    ctx.fillStyle = f.color;
                    ctx.fillRect(f.x * GST.TILE, f.y * GST.TILE, f.w * GST.TILE, f.h * GST.TILE);
                    ctx.fillStyle = 'rgba(255,255,255,0.4)';
                    ctx.font = '7px sans-serif';
                    ctx.textAlign = 'center';
                    ctx.fillText(f.name, (f.x + f.w / 2) * GST.TILE, (f.y - 0.2) * GST.TILE);
                    ctx.textAlign = 'left';
                }
            }
            // 火盆动态火焰特效（底图模式下也绘制，覆盖在静态底图上方）
            {
                const t = Date.now() / 200;
                const cx = 2 * GST.TILE, cy = 5 * GST.TILE;
                const flicker = Math.sin(t) * 2.5;
                const flicker2 = Math.cos(t * 1.3) * 2;

                ctx.save();

                // 暖光辐射（大范围脉动光晕）
                const pulse = 0.85 + Math.sin(t * 0.7) * 0.15;
                const grad = ctx.createRadialGradient(cx, cy, 4, cx, cy, 80 * pulse);
                grad.addColorStop(0, 'rgba(255,160,50,0.25)');
                grad.addColorStop(0.3, 'rgba(255,120,30,0.10)');
                grad.addColorStop(0.6, 'rgba(255,80,20,0.04)');
                grad.addColorStop(1, 'rgba(255,60,10,0)');
                ctx.fillStyle = grad;
                ctx.fillRect(cx - 90, cy - 90, 180, 180);

                // 最外层——红焰光晕
                ctx.fillStyle = `rgba(200,60,10,${0.25 + Math.sin(t * 0.8) * 0.1})`;
                ctx.beginPath();
                ctx.ellipse(cx, cy - 2, 18 + flicker, 20 + flicker, 0, 0, Math.PI * 2);
                ctx.fill();

                // 外焰——橙色
                ctx.fillStyle = `rgba(255,120,20,${0.45 + Math.sin(t * 1.1) * 0.1})`;
                ctx.beginPath();
                ctx.ellipse(cx, cy - 3, 13 + flicker * 0.7, 15 + flicker * 0.7, 0, 0, Math.PI * 2);
                ctx.fill();

                // 内焰——黄色
                ctx.fillStyle = `rgba(255,200,50,${0.6 + Math.sin(t * 1.5) * 0.1})`;
                ctx.beginPath();
                ctx.ellipse(cx, cy - 3, 8 + flicker2, 10 + flicker2, 0, 0, Math.PI * 2);
                ctx.fill();

                // 核心白热
                ctx.fillStyle = 'rgba(255,240,200,0.55)';
                ctx.beginPath();
                ctx.ellipse(cx, cy - 2, 3.5, 5, 0, 0, Math.PI * 2);
                ctx.fill();

                // 火花粒子（6颗，向上飘散）
                ctx.fillStyle = 'rgba(255,180,60,0.7)';
                for (let i = 0; i < 6; i++) {
                    const phase = t * 1.5 + i * 1.05;
                    const life = (phase % 3.0) / 3.0;
                    const sx = cx + Math.sin(phase * 2.3) * (6 + life * 8);
                    const sy = cy - 8 - life * 25;
                    const sparkAlpha = (1 - life) * 0.8;
                    const sparkSize = (1 - life) * 2.0 + 0.5;
                    ctx.globalAlpha = sparkAlpha;
                    ctx.beginPath();
                    ctx.arc(sx, sy, sparkSize, 0, Math.PI * 2);
                    ctx.fill();
                }
                ctx.globalAlpha = 1;

                ctx.restore();
            }
        }
    
        _isFurnitureSolid(gx, gy) {
            for (const f of this.furniture) {
                if (gx >= f.x && gx < f.x + f.w && gy >= f.y && gy < f.y + f.h) return true;
            }
            return false;
        }
    
        describe(gx, gy) {
            const others = this._getOtherPeopleHere();
            let desc = '你在宿舍B里。这里住着李婶、歆玥、清璇，角落堆着备用毯子和保暖物资。';
            if (others.length > 0) desc += `房间里有${others.join('、')}。`;
            desc += '出口在南边。';
            return desc;
        }
    
        getInterestPoints(gx, gy) {
            return [
                { x: 2, y: 2, name: '床边', desc: '休息', walkTo: { x: 2, y: 2 } },
                { x: 2, y: 5, name: '火盆旁', desc: '取暖', walkTo: { x: 2, y: 5 } },
                ...super.getInterestPoints(gx, gy)
            ];
        }
    
        getRoomForNPC(npcName) {
            const bed = this.beds.find(b => b.npc === npcName);
            if (bed) return { x: bed.x, y: bed.y };
            return { x: 6, y: 4 };
        }
    }

    GST.DormBMap = DormBMap;
})();
