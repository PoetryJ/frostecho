/**
 * 福音镇 - VillageMap 村庄主地图 (50×40)
 * 末日据点主地图，含围墙、建筑、资源区
 */
(function() {
    'use strict';
    const GST = window.GST;

    class VillageMap extends GST.BaseMap {
        constructor() {
            super(50, 40, '末日据点');
            this.locationKey = 'village';
            this.useBaseImage = true; // 使用预烘焙底图 PNG 渲染，室内场景不设此标记
    
            // ---- 户外资源采集区域 ----
            this.resourceAreas = [
                { id: 'lumber_camp', name: '🌲伐木场', x: 2, y: 2, w: 8, h: 6, color: '#5A6B50', resource: 'wood', danger: '中' },
                { id: 'ruins_site',  name: '🔍废墟',   x: 38, y: 2, w: 10, h: 6, color: '#7A6A5A', resource: 'explore', danger: '高' },
                { id: 'frozen_lake', name: '🎣冰湖',   x: 2, y: 32, w: 8, h: 6, color: '#90B8D0', resource: 'food', danger: '中' },
                { id: 'ore_pile',    name: '⛏️矿渣堆', x: 38, y: 32, w: 10, h: 6, color: '#8A7A6A', resource: 'power', danger: '中' },
            ];
    
            // ---- 围墙定义 ----
            this.wallBounds = { x1: 11, y1: 9, x2: 39, y2: 31 };
            this.northGate = { x: 24, y: 9, w: 2 };  // 北门
            this.southGate = { x: 24, y: 31, w: 2 }; // 南门
            this.gatesClosed = false; // 第4天关闭
    
            // ---- 建筑定义 (安全区内) ----
            this.buildings = [
        { id: 'warehouse', name: '📦仓库',     x: 13, y: 11, w: 6, h: 4, wallColor: GST.C.WALL_WOOD,  roofColor: GST.C.ROOF_BROWN, doorX: 16, doorY: 15, target: 'warehouse', get displayName() { return '📦' + GST.t('location.warehouse'); } },
        { id: 'medical',   name: '🏥医疗站',   x: 30, y: 11, w: 6, h: 4, wallColor: GST.C.WALL_WHITE, roofColor: GST.C.ROOF_RED,   doorX: 33, doorY: 15, target: 'medical', get displayName() { return '🏥' + GST.t('location.medical'); } },
        { id: 'dorm_a',    name: '🏠宿舍A',    x: 13, y: 18, w: 7, h: 5, wallColor: GST.C.WALL_WOOD,  roofColor: GST.C.ROOF_BLUE,  doorX: 16, doorY: 23, target: 'dorm_a', get displayName() { return '🏠' + GST.t('location.dorm_a'); } },
        { id: 'dorm_b',    name: '🏠宿舍B',    x: 30, y: 18, w: 7, h: 5, wallColor: GST.C.WALL_WOOD,  roofColor: GST.C.ROOF_GREEN, doorX: 33, doorY: 23, target: 'dorm_b', get displayName() { return '🏠' + GST.t('location.dorm_b'); } },
        { id: 'kitchen',   name: '🍳炊事房',   x: 13, y: 26, w: 5, h: 4, wallColor: GST.C.WALL_STONE, roofColor: GST.C.ROOF_RED,   doorX: 15, doorY: 30, target: 'kitchen', get displayName() { return '🍳' + GST.t('location.kitchen'); } },
        { id: 'workshop',  name: '🔧工坊',     x: 21, y: 26, w: 7, h: 4, wallColor: GST.C.WALL_STONE, roofColor: GST.C.ROOF_BROWN, doorX: 24, doorY: 30, target: 'workshop', get displayName() { return '🔧' + GST.t('location.workshop'); } },
        { id: 'command',   name: '🏛️指挥所',   x: 33, y: 26, w: 4, h: 3, wallColor: GST.C.WALL_STONE, roofColor: GST.C.ROOF_BROWN, doorX: 35, doorY: 29, target: 'command', get displayName() { return '🏛️' + GST.t('location.command'); } },
            ];
    
            // 用建筑数据生成 objects (绘制用)
            for (const b of this.buildings) {
                this.objects.push(this._makeBuildingObj(b));
            }
    
            // 主暖炉广场 (露天，中心位置)
            this.furnacePlaza = { x: 22, y: 18, w: 6, h: 4 };
            this.objects.push(this._makeFurnacePlazaObj());
    
            // 户外资源区域渲染对象
            for (const area of this.resourceAreas) {
                this.objects.push(this._makeResourceAreaObj(area));
            }
    
            // 围墙渲染对象
            this.objects.push(this._makeWallObj());
    
            // ---- 门/传送点 ----
            for (const b of this.buildings) {
                if (b.target) {
                    this.triggers.push({
                        x: b.doorX, y: b.doorY, w: 1, h: 1,
                        target: b.target,
                        get name() { return b.displayName || b.name; },
                        spawnX: b.doorX, spawnY: b.doorY + 1
                    });
                }
            }
    
            // ---- 地标 (AI 感知用) ----
            this.landmarks = [
                { get name() { return GST.t('location.furnace_plaza') || '主暖炉广场'; }, cx: 25, cy: 20, type: 'rect', x1: 22, y1: 18, x2: 28, y2: 22 },
                ...this.buildings.map(b => ({
                    get name() { const dn = (b.displayName || b.name); return dn.replace(/[^\u4e00-\u9fa5A-Za-z\s]/g, ''); },
                    cx: b.x + b.w / 2,
                    cy: b.y + b.h / 2,
                    type: 'rect',
                    x1: b.x, y1: b.y, x2: b.x + b.w, y2: b.y + b.h
                })),
                ...this.resourceAreas.map(a => ({
                    get name() { return GST.t('location.' + a.id) || a.name; },
                    cx: a.x + a.w / 2,
                    cy: a.y + a.h / 2,
                    type: 'rect',
                    x1: a.x, y1: a.y, x2: a.x + a.w, y2: a.y + a.h
                })),
                { get name() { return GST.t('location.north_gate') || '北门'; }, cx: 25, cy: 9, type: 'rect', x1: 24, y1: 9, x2: 26, y2: 10 },
                { get name() { return GST.t('location.south_gate') || '南门'; }, cx: 25, cy: 31, type: 'rect', x1: 24, y1: 31, x2: 26, y2: 32 },
            ];
    
            // ---- 装饰物 ----
            this._addDecorations();
        }
        // [已拆分到 village-decorations.js] _addDecorations
        // [已拆分到 village-decorations.js] drawDecoration
        _makeBuildingObj(b) {
            return {
                b,
                getSortY() { return (this.b.y + this.b.h) * GST.TILE; },
                draw(ctx) {
                    const px = this.b.x * GST.TILE;
                    const py = this.b.y * GST.TILE;
                    const pw = this.b.w * GST.TILE;
                    const ph = this.b.h * GST.TILE;
    
                    // ★ 优先使用图片素材绘制建筑
                    if (typeof SpriteLoader !== 'undefined' && SpriteLoader.enabled) {
                        // 尝试通过建筑id查找素材
                        const spriteId = this.b.spriteId || this.b.id;
                        if (spriteId && SpriteLoader.drawBuilding(ctx, spriteId, px - 4, py - GST.TILE, pw + 8, ph + GST.TILE)) {
                            // 图片绘制成功，只绘制标签
                            ctx.font = 'bold 9px sans-serif';
                            ctx.textAlign = 'center';
                            const nameText = GST.t('location.' + this.b.id) || this.b.name;
                            const nameWidth = ctx.measureText(nameText).width;
                            ctx.fillStyle = 'rgba(0,0,0,0.35)';
                            ctx.beginPath();
                            ctx.roundRect(px + pw / 2 - nameWidth/2 - 4, py - GST.TILE - 8, nameWidth + 8, 12, 3);
                            ctx.fill();
                            ctx.fillStyle = 'rgba(255,255,255,0.85)';
                            ctx.fillText(nameText, px + pw / 2, py - GST.TILE);
                            ctx.textAlign = 'left';
                            return;
                        }
                    }
    
                    // === fallback: 代码绘制 ===
    
                    // === 建筑投影 ===
                    ctx.fillStyle = 'rgba(40,50,60,0.18)';
                    ctx.beginPath();
                    ctx.moveTo(px + 6, py + ph + 2);
                    ctx.lineTo(px + pw + 8, py + ph + 2);
                    ctx.lineTo(px + pw + 12, py + ph + 8);
                    ctx.lineTo(px + 10, py + ph + 8);
                    ctx.closePath();
                    ctx.fill();
    
                    // === 墙体（带纹理） ===
                    const wallTop = py + ph * 0.3;
                    const wallH = ph * 0.7;
                    ctx.fillStyle = this.b.wallColor;
                    ctx.fillRect(px, wallTop, pw, wallH);
                    // 墙体横线纹理（砖/木缝）
                    ctx.strokeStyle = 'rgba(0,0,0,0.06)';
                    ctx.lineWidth = 0.5;
                    for (let ly = wallTop + 8; ly < wallTop + wallH - 4; ly += 8) {
                        ctx.beginPath();
                        ctx.moveTo(px + 2, ly);
                        ctx.lineTo(px + pw - 2, ly);
                        ctx.stroke();
                    }
                    // 墙体右侧阴影面
                    ctx.fillStyle = 'rgba(0,0,0,0.08)';
                    ctx.fillRect(px + pw - 6, wallTop, 6, wallH);
                    // 墙基线
                    ctx.fillStyle = 'rgba(60,50,40,0.25)';
                    ctx.fillRect(px, py + ph - 3, pw, 3);
    
                    // === 屋顶（梯形 + 积雪 + 边缘线） ===
                    // 屋顶主体
                    ctx.fillStyle = this.b.roofColor;
                    ctx.beginPath();
                    ctx.moveTo(px - 6, wallTop + 4);
                    ctx.lineTo(px + pw / 2, py - 4);
                    ctx.lineTo(px + pw + 6, wallTop + 4);
                    ctx.closePath();
                    ctx.fill();
                    // 屋顶积雪层
                    ctx.fillStyle = GST.C.ROOF_SNOW;
                    ctx.globalAlpha = 0.55;
                    ctx.beginPath();
                    ctx.moveTo(px - 2, wallTop);
                    ctx.lineTo(px + pw / 2, py - 2);
                    ctx.lineTo(px + pw + 2, wallTop);
                    ctx.lineTo(px + pw / 2 + 8, py + 6);
                    ctx.lineTo(px + pw / 2 - 8, py + 6);
                    ctx.closePath();
                    ctx.fill();
                    ctx.globalAlpha = 1;
                    // 屋顶边缘线
                    ctx.strokeStyle = 'rgba(60,50,40,0.2)';
                    ctx.lineWidth = 1;
                    ctx.beginPath();
                    ctx.moveTo(px - 6, wallTop + 4);
                    ctx.lineTo(px + pw / 2, py - 4);
                    ctx.lineTo(px + pw + 6, wallTop + 4);
                    ctx.stroke();
                    // 屋檐底部阴影
                    ctx.fillStyle = 'rgba(0,0,0,0.1)';
                    ctx.fillRect(px - 4, wallTop + 2, pw + 8, 3);
    
                    // === 烟囱 ===
                    const chimneyX = px + pw * 0.7;
                    const chimneyY = py + 4;
                    ctx.fillStyle = GST.C.CHIMNEY;
                    ctx.fillRect(chimneyX, chimneyY, 10, 16);
                    ctx.fillStyle = GST.C.CHIMNEY_TOP;
                    ctx.fillRect(chimneyX - 1, chimneyY - 2, 12, 4);
                    // 积雪
                    ctx.fillStyle = 'rgba(230,234,240,0.5)';
                    ctx.fillRect(chimneyX, chimneyY - 3, 10, 2);
                    // 烟雾（动画）
                    let isNight = false;
                    if (typeof window !== 'undefined' && window.game) {
                        const hour = window.game.getHour();
                        isNight = hour >= 19 || hour < 6;
                    }
                    const t = Date.now() / 1000;
                    const smokeAlpha = 0.12 + Math.sin(t * 2) * 0.04;
                    ctx.fillStyle = `rgba(180,190,200,${smokeAlpha})`;
                    ctx.beginPath();
                    ctx.arc(chimneyX + 5 + Math.sin(t) * 3, chimneyY - 8, 5 + Math.sin(t*1.5)*2, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillStyle = `rgba(180,190,200,${smokeAlpha * 0.6})`;
                    ctx.beginPath();
                    ctx.arc(chimneyX + 3 + Math.sin(t*0.8) * 5, chimneyY - 16, 4 + Math.cos(t)*2, 0, Math.PI * 2);
                    ctx.fill();
    
                    // === 门（带门框） ===
                    const doorPx = this.b.doorX * GST.TILE;
                    const doorPy = (this.b.y + this.b.h - 1) * GST.TILE;
                    // 门框
                    ctx.fillStyle = GST.C.DOOR_FRAME || '#5A3A08';
                    ctx.fillRect(doorPx + 6, doorPy - 2, 20, GST.TILE + 2);
                    // 门
                    ctx.fillStyle = GST.C.DOOR;
                    ctx.fillRect(doorPx + 8, doorPy, 16, GST.TILE);
                    // 门把手
                    ctx.fillStyle = '#C0A060';
                    ctx.fillRect(doorPx + 20, doorPy + 14, 3, 3);
                    // 门上方小窗
                    ctx.fillStyle = isNight ? 'rgba(255,232,128,0.4)' : 'rgba(120,184,216,0.3)';
                    ctx.fillRect(doorPx + 11, doorPy + 2, 10, 6);
    
                    // === 窗户（带窗框 + 窗台） ===
                    const winY = py + ph * 0.45;
                    const winCount = Math.max(1, Math.floor(this.b.w / 3));
                    const winSpacing = pw / (winCount + 1);
    
                    for (let i = 1; i <= winCount; i++) {
                        const wx = px + winSpacing * i - 7;
                        // 窗框
                        ctx.fillStyle = GST.C.WINDOW_FRAME || '#606058';
                        ctx.fillRect(wx - 1, winY - 1, 14, 12);
                        // 窗玻璃
                        ctx.fillStyle = isNight ? GST.C.WINDOW_LIT : GST.C.WINDOW;
                        ctx.fillRect(wx, winY, 12, 10);
                        // 十字窗格
                        ctx.strokeStyle = GST.C.WINDOW_FRAME || '#606058';
                        ctx.lineWidth = 1;
                        ctx.beginPath();
                        ctx.moveTo(wx + 6, winY);
                        ctx.lineTo(wx + 6, winY + 10);
                        ctx.moveTo(wx, winY + 5);
                        ctx.lineTo(wx + 12, winY + 5);
                        ctx.stroke();
                        // 窗台
                        ctx.fillStyle = 'rgba(200,196,190,0.6)';
                        ctx.fillRect(wx - 2, winY + 10, 16, 3);
                        // 窗台积雪
                        ctx.fillStyle = 'rgba(230,234,240,0.5)';
                        ctx.fillRect(wx - 1, winY + 9, 14, 2);
                    }
    
                    // 夜间窗户灯光溢出
                    if (isNight) {
                        for (let i = 1; i <= winCount; i++) {
                            const grad = ctx.createRadialGradient(
                                px + winSpacing * i, winY + 5, 2,
                                px + winSpacing * i, winY + 5, 20
                            );
                            grad.addColorStop(0, 'rgba(255,232,128,0.15)');
                            grad.addColorStop(1, 'rgba(255,232,128,0)');
                            ctx.fillStyle = grad;
                            ctx.fillRect(px + winSpacing * i - 20, winY - 15, 40, 40);
                        }
                        // 门口灯光
                        const doorGrad = ctx.createRadialGradient(
                            doorPx + 16, doorPy + GST.TILE, 2,
                            doorPx + 16, doorPy + GST.TILE + 8, 24
                        );
                        doorGrad.addColorStop(0, 'rgba(255,220,120,0.12)');
                        doorGrad.addColorStop(1, 'rgba(255,220,120,0)');
                        ctx.fillStyle = doorGrad;
                        ctx.fillRect(doorPx - 8, doorPy + 8, 48, 32);
                    }
    
                    // === 建筑名标签（带背景） ===
                    ctx.font = 'bold 9px sans-serif';
                    ctx.textAlign = 'center';
                    const nameText = GST.t('location.' + this.b.id) || this.b.name;
                    const nameWidth = ctx.measureText(nameText).width;
                    // 标签底板
                    ctx.fillStyle = 'rgba(0,0,0,0.35)';
                    const labelX = px + pw / 2;
                    const labelY = py - 8;
                    ctx.beginPath();
                    ctx.roundRect(labelX - nameWidth/2 - 4, labelY - 8, nameWidth + 8, 12, 3);
                    ctx.fill();
                    // 标签文字
                    ctx.fillStyle = 'rgba(255,255,255,0.85)';
                    ctx.fillText(nameText, labelX, labelY);
                    ctx.textAlign = 'left';
                }
            };
        }
        // [已拆分到 village-decorations.js] _makeFurnacePlazaObj
        // [已拆分到 village-decorations.js] _makeResourceAreaObj
        // [已拆分到 village-decorations.js] _makeWallObj
        getTileColor(x, y) {
            if (x < 0 || y < 0 || x >= this.width || y >= this.height) return GST.C.GRASS_DARK;
    
            const wb = this.wallBounds;
            const n = GST.getTileNoise(x, y);
    
            // 围墙内 — 安全区
            if (x >= wb.x1 && x <= wb.x2 && y >= wb.y1 && y <= wb.y2) {
                // 主暖炉广场区域
                const fp = this.furnacePlaza;
                if (x >= fp.x && x < fp.x + fp.w && y >= fp.y && y < fp.y + fp.h) return GST.C.PLAZA;
    
                // 安全区内道路 — 十字主路（踩踏痕迹变化）
                if (y >= 20 && y <= 21 && x >= wb.x1 + 1 && x <= wb.x2 - 1) {
                    return n > 0.6 ? GST.C.PATH_DARK : GST.C.PATH;
                }
                if (x >= 24 && x <= 26 && y >= wb.y1 + 1 && y <= wb.y2 - 1) {
                    return n > 0.6 ? GST.C.PATH_DARK : GST.C.PATH;
                }
    
                // 通往各建筑的小路
                if (x >= 15 && x <= 17 && y >= 15 && y <= 17) return n > 0.5 ? '#988878' : GST.C.DIRT;
                if (x >= 32 && x <= 34 && y >= 15 && y <= 17) return n > 0.5 ? '#988878' : GST.C.DIRT;
                if (x >= 15 && x <= 17 && y >= 24 && y <= 25) return n > 0.5 ? '#988878' : GST.C.DIRT;
                if (x >= 22 && x <= 26 && y >= 24 && y <= 25) return n > 0.5 ? '#988878' : GST.C.DIRT;
    
                // 建筑物周围 — 泥雪混合（靠近建筑的地面会有脏雪）
                for (const b of this.buildings) {
                    const bx1 = b.x - 1, by1 = b.y - 1, bx2 = b.x + b.w, by2 = b.y + b.h;
                    if (x >= bx1 && x <= bx2 && y >= by1 && y <= by2) {
                        // 在建筑紧邻一圈
                        if (x === bx1 || x === bx2 || y === by1 || y === by2) {
                            return n > 0.5 ? '#C8C4BC' : '#D0CCC4';
                        }
                    }
                }
    
                // 安全区内默认 — 基于噪声的平滑雪地渐变（消除棋盘格）
                if (n < 0.25) return GST.C.GRASS_LIGHT;
                if (n > 0.75) return GST.C.GRASS_DARK;
                // 中间区域：使用噪声插值出柔和的中间色
                return GST.blendColors(GST.C.GRASS, GST.C.GRASS_DARK, n * 0.3);
            }
    
            // 围墙线上 — 地面仍为雪地，围墙线条由 _makeWallObj.draw() 叠加绘制
            // （不再返回 GST.C.FENCE，避免整格 32px 都变成暗色造成脏乱感）
            if ((x === wb.x1 || x === wb.x2) && y >= wb.y1 && y <= wb.y2) {
                return GST.blendColors(GST.C.GRASS, GST.C.GRASS_DARK, GST.getTileNoise(x, y) * 0.3);
            }
            if ((y === wb.y1 || y === wb.y2) && x >= wb.x1 && x <= wb.x2) {
                return GST.blendColors(GST.C.GRASS, GST.C.GRASS_DARK, GST.getTileNoise(x, y) * 0.3);
            }
    
            // 户外资源区域
            for (const area of this.resourceAreas) {
                if (x >= area.x && x < area.x + area.w && y >= area.y && y < area.y + area.h) {
                    if (area.id === 'frozen_lake') {
                        // 冰面渐变
                        const cx = area.x + area.w / 2, cy = area.y + area.h / 2;
                        const dist = Math.sqrt((x-cx)*(x-cx) + (y-cy)*(y-cy));
                        return dist < 2 ? GST.C.WATER_DEEP : GST.C.WATER;
                    }
                    // 其他资源区 — 冻土+碎石
                    return n > 0.6 ? '#988070' : GST.C.DIRT;
                }
            }
    
            // 外围雪原 — 基于噪声的平滑渐变
            if (n < 0.2) return GST.C.GRASS_LIGHT;  // 新鲜积雪
            if (n > 0.8) return GST.C.GRASS_DARK;   // 被风吹过的深色雪
            // 中间区域用噪声插值，避免棋盘格
            return GST.blendColors(GST.C.GRASS, GST.C.GRASS_DARK, n * 0.4);
        }
    
        isSolid(px, py) {
            const gx = px / GST.TILE;
            const gy = py / GST.TILE;
    
            // 地图边界
            if (gx < 0 || gy < 0 || gx >= this.width || gy >= this.height) return true;
    
            const igx = Math.floor(gx);
            const igy = Math.floor(gy);
            const wb = this.wallBounds;
    
            // 围墙碰撞（排除大门位置）
            // 北墙
            if (igy === wb.y1 && igx >= wb.x1 && igx <= wb.x2) {
                if (igx >= this.northGate.x && igx < this.northGate.x + this.northGate.w) {
                    if (this.gatesClosed) return true; // 大门关闭
                } else {
                    return true;
                }
            }
            // 南墙
            if (igy === wb.y2 && igx >= wb.x1 && igx <= wb.x2) {
                if (igx >= this.southGate.x && igx < this.southGate.x + this.southGate.w) {
                    if (this.gatesClosed) return true;
                } else {
                    return true;
                }
            }
            // 西墙
            if (igx === wb.x1 && igy >= wb.y1 && igy <= wb.y2) return true;
            // 东墙
            if (igx === wb.x2 && igy >= wb.y1 && igy <= wb.y2) return true;
    
            // 建筑碰撞 (不含门口那格)
            for (const b of this.buildings) {
                if (gx >= b.x && gx < b.x + b.w && gy >= b.y && gy < b.y + b.h) {
                    if (Math.floor(gx) === b.doorX && Math.floor(gy) === b.doorY) continue;
                    return true;
                }
            }
    
            // 主暖炉广场中心（暖炉主体不可穿过，但周围可走）
            const fp = this.furnacePlaza;
            const furnaceCenterX = fp.x + fp.w / 2;
            const furnaceCenterY = fp.y + fp.h / 2;
            const dx = gx - furnaceCenterX;
            const dy = gy - furnaceCenterY;
            if (dx * dx + dy * dy < 1.8 * 1.8) return true;
    
            // 装饰物碰撞
            for (const dec of this.decorations) {
                if (dec.solid && igx === dec.x && igy === dec.y) return true;
            }
    
            return false;
        }
    
        /** 判断坐标是否在安全区内 */
        isInsideWalls(gx, gy) {
            const wb = this.wallBounds;
            return gx > wb.x1 && gx < wb.x2 && gy > wb.y1 && gy < wb.y2;
        }
    
        /** 判断坐标是否在暖炉附近 */
        isNearFurnace(gx, gy, radius) {
            radius = radius || 5;
            const fp = this.furnacePlaza;
            const cx = fp.x + fp.w / 2;
            const cy = fp.y + fp.h / 2;
            const dx = gx - cx;
            const dy = gy - cy;
            return Math.sqrt(dx * dx + dy * dy) <= radius;
        }
    
        describe(gx, gy) {
            let desc = '你在末日据点户外。';
            const wb = this.wallBounds;
    
            // 判断区域
            if (this.isInsideWalls(gx, gy)) {
                desc = '你在据点围墙内的安全区。';
                if (this.isNearFurnace(gx, gy, 4)) {
                    const isEn = GST.i18n && GST.i18n.isEn();
                    desc += isEn ? 'The main furnace is nearby, its warm glow dispels some of the cold.' : '主暖炉就在旁边，温暖的火光驱散了一些寒意。';
                }
            } else {
                const isEn = GST.i18n && GST.i18n.isEn();
                desc = isEn ? 'You are outside the walls in a dangerous area. The wind is biting!' : '你在围墙外的危险区域，寒风刺骨！';
                for (const area of this.resourceAreas) {
                    if (gx >= area.x && gx < area.x + area.w && gy >= area.y && gy < area.y + area.h) {
                        const areaName = GST.t('location.' + area.id) || area.name;
                        desc = isEn
                            ? `You are at ${areaName}, gathering resources. Danger level: ${area.danger}.`
                            : `你在${areaName}，正在进行资源采集。危险等级:${area.danger}。`;
                        break;
                    }
                }
            }
    
            // 找最近的地标
            const sorted = this.landmarks.map(lm => {
                const dist = Math.floor(Math.sqrt(Math.pow(gx - lm.cx, 2) + Math.pow(gy - lm.cy, 2)));
                const dir = this._dir(gx, gy, lm.cx, lm.cy);
                return { name: lm.name, dist, dir };
            }).sort((a, b) => a.dist - b.dist);
    
            const isEnLm = GST.i18n && GST.i18n.isEn();
            if (sorted[0] && sorted[0].dist < 4) desc += isEnLm ? `${sorted[0].name} is nearby.` : `${sorted[0].name}就在附近。`;
            sorted.slice(1, 3).forEach(l => {
                if (l.dist < 20) desc += isEnLm ? `${l.name} is about ${l.dist} tiles to the ${l.dir}.` : `${l.name}在${l.dir}方约${l.dist}格。`;
            });
    
            return desc;
        }
    
        getInterestPoints(gx, gy) {
            const pts = [];
            // 建筑门口
            for (const b of this.buildings) {
                if (b.target) {
                    const bdn = b.displayName || b.name;
                    const isEnPt = GST.i18n && GST.i18n.isEn();
                    pts.push({
                        x: b.doorX, y: b.doorY + 1,
                        name: bdn.replace(/[^\u4e00-\u9fa5A-Za-z\s]/g, ''),
                        desc: isEnPt ? `Enter ${bdn}` : `进入${bdn}`,
                        walkTo: { x: b.doorX, y: b.doorY + 1 }
                    });
                }
            }
            // 暖炉广场
            const _isEn = GST.i18n && GST.i18n.isEn();
            pts.push({ x: 25, y: 21, name: _isEn ? 'Plaza Bonfire' : '广场篝火', desc: _isEn ? 'Go warm up by the bonfire' : '去广场篝火旁取暖', walkTo: { x: 25, y: 21 } });
            pts.push({ x: 25, y: 10, name: GST.t('location.north_gate') || '北门', desc: _isEn ? 'Go to North Gate' : '前往北门', walkTo: { x: 25, y: 10 } });
            pts.push({ x: 25, y: 30, name: GST.t('location.south_gate') || '南门', desc: _isEn ? 'Go to South Gate' : '前往南门', walkTo: { x: 25, y: 30 } });
            // 户外资源区
            for (const area of this.resourceAreas) {
                const areaName = GST.t('location.' + area.id) || area.name;
                pts.push({
                    x: area.x + Math.floor(area.w / 2),
                    y: area.y + Math.floor(area.h / 2),
                    name: areaName,
                    desc: _isEn ? `Go to ${areaName} to gather` : `前往${areaName}采集`,
                    walkTo: { x: area.x + Math.floor(area.w / 2), y: area.y + Math.floor(area.h / 2) }
                });
            }
            return pts;
        }
    }

    GST.VillageMap = VillageMap;
})();
