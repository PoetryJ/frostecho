/**
 * 🔍 Bug 自动检测系统 (BugDetector)
 * 
 * 运行时自动扫描所有已知 bug 模式，生成 ANOMALY 日志和修复建议。
 * 基于 11-recurring-bugs.md 中记录的 7 次弹弹乐、14 个计时器 bug、
 * 5 次空转 bug 等历史经验，建立自动化检测管线。
 * 
 * 设计原则：
 * - 每个检测器独立运行，互不干扰
 * - 检测结果包含：bug类型、严重程度、受影响NPC、修复建议、参考文档
 * - 检测频率可配置，避免性能开销
 * - 所有检测结果通过 StructuredLogger 记录
 * 
 * 挂载到 GST.BugDetector
 */
(function() {
    'use strict';
    const GST = window.GST || (window.GST = {});

    // ============ 检测结果严重程度 ============
    const SEVERITY = {
        CRITICAL: '🔴 致命',   // 会导致NPC死亡或游戏崩溃
        HIGH:     '🟠 严重',   // 会导致NPC行为异常
        MEDIUM:   '🟡 中等',   // 影响体验但不致命
        LOW:      '🟢 低',     // 日志噪音或UI问题
    };

    class BugDetector {
        constructor(game) {
            this.game = game;
            this.enabled = true;

            // ============ 检测频率控制（真实秒） ============
            this._checkInterval = 2;        // 每2秒检测一次
            this._checkTimer = 0;
            this._deepCheckInterval = 10;   // 深度检测每10秒一次
            this._deepCheckTimer = 0;

            // ============ 弹弹乐检测 ============
            // 每个NPC的场景切换历史 { npcId: [{ scene, time, reason }] }
            this._sceneChangeHistory = {};
            this._bounceAlerted = {};       // 已告警的NPC（防重复）

            // ============ 场景不匹配检测 ============
            // { npcId: { mismatchStart, stateDesc, scene } }
            this._sceneMismatchTracker = {};

            // ============ 属性异常检测 ============
            // { npcId: { zeroStart: { attr: timestamp } } }
            this._attrZeroTracker = {};

            // ============ 决策矛盾检测 ============
            this._decisionContradictions = {};

            // ============ NaN 传播检测 ============
            this._nanDetected = {};

            // ============ 控制权冲突检测 ============
            // { npcId: [{ system, target, frame }] }
            this._controlConflicts = {};

            // ============ 虚假行动检测 ============
            // { npcId: { action, startTime, lastOutput } }
            this._idleActionTracker = {};

        // ============ 检测结果缓冲 ============
            this._results = [];
            this._resultHistory = [];       // 历史结果（最多保留100条）

            // 【v5.4.1修复】全局异常检测冷却（防止每10秒重复报告同一问题）
            this._globalCrisisCooldown = {};  // { crisisType: lastReportTime }

            // ============ LLM Bug 分析 ============
            this._llmAnalysisCooldown = {};  // { bugType_npcId: lastAnalysisTime } 同类Bug 60秒内只分析一次
            this._llmAnalysisQueue = [];     // 待分析队列
            this._isAnalyzing = false;       // 是否正在分析中
            this._bugReports = [];           // LLM 分析报告历史（最多50条）

            console.log('[BugDetector] ✅ Bug自动检测系统已初始化（含LLM分析）');
        }

        // ============ 主检测循环 ============
        update(realDt) {
            if (!this.enabled || !this.game || !this.game.npcs) return;

            this._checkTimer += realDt;
            this._deepCheckTimer += realDt;

            // 常规检测（每2秒）
            if (this._checkTimer >= this._checkInterval) {
                this._checkTimer = 0;
                this._runFastChecks();
            }

            // 深度检测（每10秒）
            if (this._deepCheckTimer >= this._deepCheckInterval) {
                this._deepCheckTimer = 0;
                this._runDeepChecks();
            }
        }

        // ============ 快速检测（高频，低开销） ============
        _runFastChecks() {
            const npcs = this.game.npcs;
            if (!npcs || npcs.length === 0) return;

            for (const npc of npcs) {
                if (!npc || npc.isDead) continue;

                // 1. NaN 传播检测
                this._checkNaN(npc);

                // 2. 弹弹乐检测（基于场景切换频率）
                this._checkBounce(npc);

                // 3. 属性持续为0检测
                this._checkAttrZero(npc);
            }
        }

        // ============ 深度检测（低频，高开销） ============
        _runDeepChecks() {
            const npcs = this.game.npcs;
            if (!npcs || npcs.length === 0) return;

            for (const npc of npcs) {
                if (!npc || npc.isDead) continue;

                // 4. 场景不匹配检测
                this._checkSceneMismatch(npc);

                // 5. 决策矛盾检测
                this._checkDecisionContradiction(npc);

                // 6. 虚假行动检测
                this._checkIdleAction(npc);

                // 7. 控制权冲突检测
                this._checkControlConflict(npc);
            }

            // 8. 全局检测
            this._checkGlobalAnomalies();
        }

        // ============ 检测器1: NaN 传播 ============
        _checkNaN(npc) {
            const attrs = ['health', 'stamina', 'hunger', 'sanity', 'bodyTemp'];
            for (const attr of attrs) {
                const val = npc[attr];
                if (val !== undefined && (isNaN(val) || val === null || val === undefined)) {
                    const key = `${npc.id}_${attr}`;
                    if (!this._nanDetected[key]) {
                        this._nanDetected[key] = true;
                        this._report({
                            type: 'NAN_PROPAGATION',
                            severity: SEVERITY.CRITICAL,
                            npcId: npc.id,
                            npcName: npc.name,
                            detail: `${npc.name} 的 ${attr} 值为 ${val}（NaN/null/undefined）`,
                            suggestion: `检查最近修改 ${attr} 的代码路径，可能是除以0或未初始化`,
                            ref: 'guide/11-recurring-bugs.md#NaN传播',
                        });
                    }
                }
            }
        }

        // ============ 检测器2: 弹弹乐（场景切换频率） ============
        /**
         * 外部调用：NPC场景切换时记录
         * @param {string} npcId 
         * @param {string} newScene 
         * @param {string} reason 
         */
        recordSceneChange(npcId, newScene, reason) {
            if (!this._sceneChangeHistory[npcId]) {
                this._sceneChangeHistory[npcId] = [];
            }
            const history = this._sceneChangeHistory[npcId];
            // 【v5.2修复】改用游戏时间，确保所有播放速度下检测窗口一致
            const gameTime = (this.game.dayCount - 1) * 86400 + this.game.gameTimeSeconds;
            history.push({
                scene: newScene,
                time: gameTime,
                reason: reason || 'unknown',
            });
            // 只保留最近30条
            if (history.length > 30) history.splice(0, history.length - 30);
        }

        _checkBounce(npc) {
            const history = this._sceneChangeHistory[npc.id];
            if (!history || history.length < 6) return;

            // 【v5.8修复】弹弹乐检测大幅优化，区分真正弹弹乐和正常日常作息
            // 之前：5分钟内≥6次场景切换就报致命 → 正常日常作息被大量误报
            // 现在：必须检测到A→B→A→B来回弹跳模式才报致命
            const gameNow = (this.game.dayCount - 1) * 86400 + this.game.gameTimeSeconds;
            const WINDOW = 300; // 300游戏秒 = 游戏5分钟
            const recent = history.filter(h => gameNow - h.time < WINDOW);

            // 阈值从6提高到10：正常日常作息一天约8次场景切换，5分钟内不太可能超过10次
            if (recent.length < 10) return;

            const key = `bounce_${npc.id}`;
            // 冷却从300游戏秒增加到600游戏秒（10游戏分钟）
            if (this._bounceAlerted[key] && gameNow - this._bounceAlerted[key] <= 600) return;

            // 【v5.8新增】检测A→B→A→B来回弹跳模式
            // 真正的弹弹乐特征：短时间内在2个场景之间来回切换
            const scenes = recent.map(h => h.scene);
            let bouncePatternCount = 0;
            for (let i = 0; i < scenes.length - 3; i++) {
                if (scenes[i] === scenes[i+2] && scenes[i+1] === scenes[i+3] && scenes[i] !== scenes[i+1]) {
                    bouncePatternCount++;
                }
            }
            const hasBouncePattern = bouncePatternCount >= 2; // 至少2次A→B→A→B

            // 如果NPC正在弹弹乐恢复期或强制睡眠中，不报告（已经在处理了）
            if (npc._bounceRecoveryTimer > 0 || npc._forcedSleep) return;

            const reasons = recent.map(h => h.reason);
            const uniqueScenes = [...new Set(scenes)];
            const uniqueReasons = [...new Set(reasons)];

            let bounceType = '未知型';
            let severity = SEVERITY.MEDIUM; // 默认中等
            if (hasBouncePattern) {
                // 真正的弹弹乐：有A→B→A→B模式
                severity = SEVERITY.CRITICAL;
                if (uniqueScenes.length === 2) {
                    bounceType = '导航型弹弹乐（两个场景之间来回）';
                } else {
                    bounceType = '多场景弹弹乐（涉及3+个场景来回）';
                }
            } else {
                // 频繁切换但没有来回模式，可能是正常但频繁的日常作息
                bounceType = '频繁切换（无来回模式，可能是正常行为）';
                severity = SEVERITY.LOW;
            }

            this._bounceAlerted[key] = gameNow;
            this._report({
                type: 'BOUNCE_DETECTED',
                severity,
                npcId: npc.id,
                npcName: npc.name,
                detail: `${npc.name} 游戏5分钟内场景切换 ${recent.length} 次！类型: ${bounceType}`,
                extra: {
                    scenes: uniqueScenes,
                    reasons: uniqueReasons,
                    changeCount: recent.length,
                    bounceType,
                    bouncePatternCount,
                    recentHistory: recent.slice(-6).map(h => `${h.scene}(${h.reason})`),
                },
                suggestion: hasBouncePattern
                    ? `检查涉及的系统: ${uniqueReasons.join(', ')}。参考弹弹乐防御检查清单。`
                    : `频繁切换但无来回模式，可能是正常行为。`,
                ref: 'guide/11-recurring-bugs.md#弹弹乐',
            });
        }

        // ============ 检测器3: 属性持续为0 ============
        _checkAttrZero(npc) {
            const now = this.game.gameTimeSeconds;
            if (!this._attrZeroTracker[npc.id]) {
                this._attrZeroTracker[npc.id] = {};
            }
            const tracker = this._attrZeroTracker[npc.id];

            const criticalAttrs = [
                { key: 'health', name: '健康', threshold: 10 },
                { key: 'stamina', name: '体力', threshold: 0 },
                { key: 'hunger', name: '饱腹', threshold: 5 },
                { key: 'sanity', name: 'San值', threshold: 5 },
            ];

            for (const attr of criticalAttrs) {
                const val = npc[attr.key];
                if (val !== undefined && val <= attr.threshold) {
                    if (!tracker[attr.key]) {
                        tracker[attr.key] = now;
                    } else {
                        const duration = now - tracker[attr.key];
                        // 【v5.8修复】排除正在恢复中的NPC（弹弹乐冻结+强制入睡中）
                        // 这些NPC的属性为0是已知的，正在通过入睡恢复，不需要报告
                        if (duration > 600 && !npc.isSleeping && !npc._forcedSleep && !(npc._bounceRecoveryTimer > 0)) {
                            const key = `attr_zero_${npc.id}_${attr.key}`;
                            // 【v5.8修复】冷却从300秒增加到600秒（10分钟），进一步减少重复报告
                            if (!this._nanDetected[key] || Date.now() - this._nanDetected[key] > 600000) {
                                this._nanDetected[key] = Date.now();
                                const durationMin = Math.round(duration / 60);
                                this._report({
                                    type: 'ATTR_STUCK_ZERO',
                                    severity: SEVERITY.HIGH,
                                    npcId: npc.id,
                                    npcName: npc.name,
                                    detail: `${npc.name} 的 ${attr.name} 持续 ≤${attr.threshold} 已 ${durationMin} 游戏分钟`,
                                    extra: {
                                        attr: attr.key,
                                        value: val,
                                        duration: durationMin,
                                        currentAction: npc.stateDesc,
                                        scene: npc.currentScene,
                                        priorityOverride: npc._priorityOverride,
                                    },
                                    suggestion: `检查 ${attr.name} 的恢复路径是否被阻断。当前P0: ${npc._priorityOverride || '无'}`,
                                    ref: 'guide/11-recurring-bugs.md',
                                });
                            }
                        }
                    }
                } else {
                    // 恢复了，清除追踪
                    delete tracker[attr.key];
                }
            }
        }

        // ============ 检测器4: 场景不匹配 ============
        _checkSceneMismatch(npc) {
            if (!npc.stateDesc || !npc.currentScene) return;
            if (!GST.ACTION_EFFECT_MAP) return;

            let mismatch = false;
            let matchedEffect = null;

            for (const entry of GST.ACTION_EFFECT_MAP) {
                if (!entry.requiredScene) continue;
                const descMatch = entry.keywords && entry.keywords.some(kw => npc.stateDesc.includes(kw));
                if (descMatch && entry.requiredScene !== npc.currentScene) {
                    mismatch = true;
                    matchedEffect = entry;
                    break;
                }
            }

            const trackKey = npc.id;
            if (mismatch) {
                if (!this._sceneMismatchTracker[trackKey]) {
                    this._sceneMismatchTracker[trackKey] = {
                        startTime: Date.now(),
                        stateDesc: npc.stateDesc,
                        scene: npc.currentScene,
                        requiredScene: matchedEffect.requiredScene,
                    };
                } else {
                    const duration = Date.now() - this._sceneMismatchTracker[trackKey].startTime;
                    // 持续30秒以上
                    if (duration > 30000) {
                        const durationSec = Math.round(duration / 1000);
                        this._report({
                            type: 'SCENE_MISMATCH',
                            severity: SEVERITY.MEDIUM,
                            npcId: npc.id,
                            npcName: npc.name,
                            detail: `${npc.name} 在 ${npc.currentScene} 执行 "${npc.stateDesc}"（需要 ${matchedEffect.requiredScene}），已持续 ${durationSec}秒`,
                            extra: {
                                currentScene: npc.currentScene,
                                requiredScene: matchedEffect.requiredScene,
                                stateDesc: npc.stateDesc,
                                effectType: matchedEffect.effectType,
                                isMoving: npc.isMoving,
                            },
                            suggestion: `NPC可能卡在错误场景。检查导航是否被阻断，或stateDesc是否在到达目标场景前被提前设置。`,
                            ref: 'guide/11-recurring-bugs.md#场景不匹配',
                        });
                        // 重置追踪，避免重复告警
                        this._sceneMismatchTracker[trackKey].startTime = Date.now();
                    }
                }
            } else {
                delete this._sceneMismatchTracker[trackKey];
            }
        }

        // ============ 检测器5: 决策矛盾 ============
        // 【v5.4.1修复】大幅降低误报率：
        //   - 阈值收紧（体力<10、饱腹<5、San<10、体温<30）
        //   - 排除正在移动/前往目标的NPC（可能正在去解决问题的路上）
        //   - 排除有stateOverride/priorityOverride的NPC（已有紧急系统在处理）
        //   - 严重程度从HIGH降为MEDIUM（决策矛盾不是致命bug）
        _checkDecisionContradiction(npc) {
            const contradictions = [];

            // 排除正在移动的NPC（可能正在前往目标）
            if (npc.isMoving) return;
            // 排除已有紧急系统在处理的NPC
            if (npc._priorityOverride || npc._stateOverride) return;

            // 体力<10 却在户外工作（从<20收紧到<10）
            if (npc.stamina < 10 && npc.currentScene === 'village' && !npc.isSleeping && !npc._isDying) {
                const isWorking = npc.stateDesc && !npc.stateDesc.includes('前往') && !npc.stateDesc.includes('返回');
                if (isWorking) {
                    contradictions.push(`体力=${Math.round(npc.stamina)} 却在户外工作: "${npc.stateDesc}"`);
                }
            }

            // 饱腹<5 却不去吃饭（从<10收紧到<5）
            if (npc.hunger < 5 && !npc.isEating && !npc._hungerOverride && !npc.isSleeping && !npc._isDying) {
                contradictions.push(`饱腹=${Math.round(npc.hunger)} 却没有去吃饭`);
            }

            // San<10 却在户外（从<20收紧到<10）
            if (npc.sanity < 10 && npc.currentScene === 'village' && !npc.isSleeping && !npc._isDying) {
                contradictions.push(`San=${Math.round(npc.sanity)} 却在户外（应回室内休息）`);
            }

            // 体温<30 却在户外（从<35收紧到<30，极寒环境下<35是常态）
            if (npc.bodyTemp < 30 && npc.currentScene === 'village' && !npc._isDying) {
                contradictions.push(`体温=${npc.bodyTemp.toFixed(1)}°C 却在户外（严重失温）`);
            }

            if (contradictions.length > 0) {
                const key = `decision_${npc.id}`;
                // 【v5.4.1修复】冷却从60秒增加到300秒，减少重复报告
                if (!this._decisionContradictions[key] || Date.now() - this._decisionContradictions[key] > 300000) {
                    this._decisionContradictions[key] = Date.now();
                    this._report({
                        type: 'DECISION_CONTRADICTION',
                        severity: SEVERITY.MEDIUM,  // 【v5.4.1】从HIGH降为MEDIUM
                        npcId: npc.id,
                        npcName: npc.name,
                        detail: `${npc.name} 决策矛盾: ${contradictions.join('; ')}`,
                        extra: {
                            contradictions,
                            priorityOverride: npc._priorityOverride,
                            stateDesc: npc.stateDesc,
                            scene: npc.currentScene,
                        },
                        suggestion: `检查P0优先级是否正确触发。当前P0: ${npc._priorityOverride || '无'}`,
                        ref: 'guide/11-recurring-bugs.md#决策矛盾',
                    });
                }
            }
        }

        // ============ 检测器6: 虚假行动 ============
        _checkIdleAction(npc) {
            if (!npc.stateDesc || npc.isSleeping || npc.isEating || npc._isDying) return;

            const key = npc.id;
            const tracker = this._idleActionTracker[key];

            if (!tracker || tracker.action !== npc.stateDesc) {
                this._idleActionTracker[key] = {
                    action: npc.stateDesc,
                    startTime: Date.now(),
                    lastOutput: this._getActionOutput(npc),
                };
                return;
            }

            // 检查5分钟内是否有产出变化
            const duration = Date.now() - tracker.startTime;
            if (duration > 5 * 60 * 1000) {
                const currentOutput = this._getActionOutput(npc);
                if (JSON.stringify(currentOutput) === JSON.stringify(tracker.lastOutput)) {
                    this._report({
                        type: 'IDLE_ACTION',
                        severity: SEVERITY.MEDIUM,
                        npcId: npc.id,
                        npcName: npc.name,
                        detail: `${npc.name} 执行 "${npc.stateDesc}" 已 ${Math.round(duration / 60000)} 分钟但无产出变化`,
                        extra: {
                            action: npc.stateDesc,
                            scene: npc.currentScene,
                            duration: Math.round(duration / 60000),
                        },
                        suggestion: `检查行动效果是否因场景不匹配、缺少目标等原因未执行`,
                        ref: 'guide/11-recurring-bugs.md#NPC专业行为空转',
                    });
                    // 重置追踪
                    tracker.startTime = Date.now();
                    tracker.lastOutput = currentOutput;
                }
            }
        }

        _getActionOutput(npc) {
            // 获取NPC当前行动的产出指标
            return {
                health: Math.round(npc.health || 0),
                stamina: Math.round(npc.stamina || 0),
                _craftProgress: npc._craftProgress || 0,
            };
        }

        // ============ 检测器7: 控制权冲突 ============
        _checkControlConflict(npc) {
            // 检查是否有多个系统同时试图控制NPC
            const controllers = [];
            if (npc._priorityOverride) controllers.push(`P0:${npc._priorityOverride}`);
            if (npc._taskOverride) controllers.push('P1:任务系统');
            if (npc._hungerOverride) controllers.push('饥饿系统');
            if (npc._stateOverride) controllers.push(`状态覆盖:${npc._stateOverride}`);
            if (npc._actionOverride) controllers.push('行动覆盖');
            if (npc._resourceGatherOverride) controllers.push('资源采集覆盖');

            if (controllers.length >= 3) {
                const key = `control_${npc.id}`;
                if (!this._controlConflicts[key] || Date.now() - this._controlConflicts[key] > 120000) {
                    this._controlConflicts[key] = Date.now();
                    this._report({
                        type: 'CONTROL_CONFLICT',
                        severity: SEVERITY.MEDIUM,
                        npcId: npc.id,
                        npcName: npc.name,
                        detail: `${npc.name} 同时被 ${controllers.length} 个系统控制: ${controllers.join(', ')}`,
                        extra: { controllers },
                        suggestion: `多个系统同时控制NPC可能导致行为冲突。检查优先级仲裁是否正确。`,
                        ref: 'guide/11-recurring-bugs.md#弹弹乐',
                    });
                }
            }
        }

        // ============ 检测器8: 全局异常 ============
        _checkGlobalAnomalies() {
            const game = this.game;
            if (!game) return;

            // 检查资源系统NaN
            if (game.resourceSystem) {
                const rs = game.resourceSystem;
                const resources = ['woodFuel', 'food', 'power', 'buildMaterial', 'medkitCount'];
                for (const res of resources) {
                    if (rs[res] !== undefined && (isNaN(rs[res]) || rs[res] < 0)) {
                        this._report({
                            type: 'RESOURCE_ANOMALY',
                            severity: SEVERITY.CRITICAL,
                            detail: `资源 ${res} 值异常: ${rs[res]}`,
                            suggestion: `检查资源计算代码，可能存在负数或NaN传播`,
                        });
                    }
                }
            }

            // 检查全员属性异常
            // 【v5.4.1修复】加冷却机制，同类全局危机300秒内只报告一次
            const aliveNpcs = game.npcs ? game.npcs.filter(n => n && !n.isDead) : [];
            const now = Date.now();
            if (aliveNpcs.length > 0) {
                const allZeroStamina = aliveNpcs.every(n => n.stamina <= 0);
                const allZeroHunger = aliveNpcs.every(n => n.hunger <= 0);
                if (allZeroStamina) {
                    const ck = 'stamina_crisis';
                    if (!this._globalCrisisCooldown[ck] || now - this._globalCrisisCooldown[ck] > 300000) {
                        this._globalCrisisCooldown[ck] = now;
                        this._report({
                            type: 'GLOBAL_CRISIS',
                            severity: SEVERITY.CRITICAL,
                            detail: `全员体力为0！可能存在系统性bug导致体力无法恢复`,
                            suggestion: `检查体力恢复路径：睡眠恢复、室内休息恢复是否正常工作`,
                        });
                    }
                }
                if (allZeroHunger) {
                    const ck = 'hunger_crisis';
                    if (!this._globalCrisisCooldown[ck] || now - this._globalCrisisCooldown[ck] > 300000) {
                        this._globalCrisisCooldown[ck] = now;
                        this._report({
                            type: 'GLOBAL_CRISIS',
                            severity: SEVERITY.CRITICAL,
                            detail: `全员饱腹为0！可能食物系统或进食系统异常`,
                            suggestion: `检查食物资源是否为0、进食逻辑是否正常触发`,
                        });
                    }
                }
            }
        }

        // ============ 报告生成 ============
        _report(result) {
            const entry = {
                ...result,
                timestamp: new Date().toISOString(),
                gameTime: this.game ? `D${this.game.dayCount} ${this._formatGameTime(this.game.gameTimeSeconds)}` : 'unknown',
            };

            this._results.push(entry);
            this._resultHistory.push(entry);
            if (this._resultHistory.length > 100) {
                this._resultHistory.splice(0, this._resultHistory.length - 100);
            }

            // 输出到控制台
            const prefix = `[BugDetector] ${entry.severity}`;
            console.warn(`${prefix} [${entry.type}] ${entry.detail}`);
            if (entry.suggestion) {
                console.warn(`  💡 建议: ${entry.suggestion}`);
            }
            if (entry.ref) {
                console.warn(`  📖 参考: ${entry.ref}`);
            }

            // 如果有 StructuredLogger，也记录到结构化日志
            if (GST.StructuredLogger && GST.StructuredLogger.instance) {
                GST.StructuredLogger.instance.logBugDetection(entry);
            }

            // 🧠 CRITICAL/HIGH 级别 Bug 自动触发 LLM 分析
            if (entry.severity === SEVERITY.CRITICAL || entry.severity === SEVERITY.HIGH) {
                this._enqueueLLMAnalysis(entry);
            }
        }

        _formatGameTime(seconds) {
            const h = Math.floor(seconds / 3600);
            const m = Math.floor((seconds % 3600) / 60);
            return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
        }

        // ============ 外部接口 ============

        /** 获取最近的检测结果 */
        getRecentResults(count = 20) {
            return this._resultHistory.slice(-count);
        }

        /** 获取并清空当前帧的检测结果 */
        flushResults() {
            const results = this._results;
            this._results = [];
            return results;
        }

        /** 获取检测统计 */
        getStats() {
            const stats = {};
            for (const r of this._resultHistory) {
                stats[r.type] = (stats[r.type] || 0) + 1;
            }
            return stats;
        }

        /** 生成检测报告（用于日志保存） */
        generateReport() {
            const stats = this.getStats();
            const lines = [
                '═══════════════════════════════════════',
                '  🔍 Bug 自动检测报告',
                '═══════════════════════════════════════',
                `  检测时间: ${new Date().toISOString()}`,
                `  总检测数: ${this._resultHistory.length}`,
                '',
                '  按类型统计:',
            ];
            for (const [type, count] of Object.entries(stats).sort((a, b) => b[1] - a[1])) {
                lines.push(`    ${type}: ${count} 次`);
            }
            lines.push('');
            lines.push('  最近20条检测结果:');
            for (const r of this._resultHistory.slice(-20)) {
                lines.push(`    [${r.gameTime}] ${r.severity} ${r.type}: ${r.detail}`);
                if (r.suggestion) lines.push(`      💡 ${r.suggestion}`);
            }
            lines.push('═══════════════════════════════════════');
            return lines.join('\n');
        }

        // ============================================================
        //  🧠 LLM Bug 分析系统
        //  检测到 CRITICAL/HIGH Bug 时，自动收集上下文快照，
        //  调用 LLM（qwen3:0.6b）分析根因，生成结构化诊断报告。
        // ============================================================

        /** Bug 分析的 System Prompt（经过单元测试验证，平均质量92%） */
        static get BUG_ANALYSIS_PROMPT() {
            return `你是"福音雪镇"末日生存游戏的Bug诊断AI。分析异常，找根因，给修复线索。

## 系统架构
控制层级（高→低）：P0紧急系统 > P1任务系统(taskOverride) > P1状态覆盖(stateOverride) > P1饥饿驱动(hungerOverride) > P1-AI行动(actionOverride) > P2日程系统(schedule)
关键系统名称（involvedSystems必须从以下选择）：
- "P0紧急系统" — 濒死/体力危机/发疯等，设置_priorityOverride
- "日程系统" — P2默认日程，设置_scheduleNavTarget
- "actionOverride" — AI决策的行动覆盖
- "taskOverride" — 议会任务系统
- "stateOverride" — 状态覆盖（exhausted/sick等）
- "hungerOverride" — 饥饿驱动进食
- "工作驻留" — _workResidence，NPC在工作场景驻留
- "导航系统" — 路径寻找和场景切换
- "属性计算" — HP/体力/饱腹/San/体温的增减计算
- "体力消耗" — stamina消耗逻辑

## 输出格式
只返回JSON，不要任何解释文字。

bugType必须从以下5个中选1个：
- BOUNCE（弹弹乐）
- NAN_PROPAGATION（NaN传播）
- DECISION_CONTRADICTION（决策矛盾）
- ATTR_STUCK_ZERO（属性卡零）
- CONTROL_CONFLICT（控制权冲突）

severity必须从以下4个中选1个：CRITICAL, HIGH, MEDIUM, LOW

示例输出：
{"bugType":"NAN_PROPAGATION","severity":"CRITICAL","rootCause":"体力消耗计算中除以0导致NaN","involvedSystems":["属性计算","体力消耗"],"evidence":"stamina从10变为NaN，发生在工作消耗计算时","suggestion":"检查npc-attributes.js中体力消耗的除法运算","confidence":0.9}`;
        }

        /**
         * 将 Bug 检测结果加入 LLM 分析队列
         * 同类 Bug 60秒内只分析一次，避免高频 Bug 疯狂调 LLM
         */
        _enqueueLLMAnalysis(bugEntry) {
            // 冷却检查：同类Bug（type + npcId）60秒内只分析一次
            const cooldownKey = `${bugEntry.type}_${bugEntry.npcId || 'global'}`;
            const now = Date.now();
            if (this._llmAnalysisCooldown[cooldownKey] && now - this._llmAnalysisCooldown[cooldownKey] < 60000) {
                return; // 冷却中，跳过
            }
            this._llmAnalysisCooldown[cooldownKey] = now;

            // 检查 LLM 是否可用
            if (!GST.callLLMFast) {
                console.warn('[BugDetector] LLM 未就绪，跳过 Bug 分析');
                return;
            }

            // 收集上下文快照并加入队列
            const context = this._collectBugContext(bugEntry);
            this._llmAnalysisQueue.push({ bugEntry, context, enqueuedAt: now });

            // 如果没有正在分析的任务，立即开始处理队列
            if (!this._isAnalyzing) {
                this._processAnalysisQueue();
            }
        }

        /**
         * 收集 Bug 上下文快照
         * 包含：NPC完整状态 + 控制权状态 + 场景切换历史 + 最近决策 + 日程信息
         */
        _collectBugContext(bugEntry) {
            const context = {
                bugDetection: {
                    type: bugEntry.type,
                    severity: bugEntry.severity,
                    npcName: bugEntry.npcName || '全局',
                    detail: bugEntry.detail,
                    extra: bugEntry.extra || {},
                },
                gameTime: bugEntry.gameTime,
                weather: this.game ? this._getWeatherInfo() : '未知',
            };

            // 如果是 NPC 相关的 Bug，收集 NPC 完整状态
            if (bugEntry.npcId) {
                const npc = this.game?.npcs?.find(n => n && n.id === bugEntry.npcId);
                if (npc) {
                    // NPC 基础状态
                    context.npcState = {
                        name: npc.name,
                        occupation: npc.occupation || '未知',
                        currentScene: npc.currentScene,
                        stateDesc: npc.stateDesc,
                        health: Math.round(npc.health || 0),
                        stamina: Math.round((npc.stamina || 0) * 10) / 10,
                        hunger: Math.round((npc.hunger || 0) * 10) / 10,
                        sanity: Math.round((npc.sanity || 0) * 10) / 10,
                        bodyTemp: Math.round((npc.bodyTemp || 0) * 10) / 10,
                        isMoving: !!npc.isMoving,
                        isSleeping: !!npc.isSleeping,
                        isDead: !!npc.isDead,
                        state: npc.state || 'UNKNOWN',
                        mood: npc.mood || '未知',
                    };

                    // 控制权状态（核心诊断信息）
                    context.controlState = {
                        _priorityOverride: npc._priorityOverride || null,
                        _stateOverride: npc._stateOverride || null,
                        _taskOverride: npc._taskOverride ? {
                            isActive: !!npc._taskOverride.isActive,
                            taskId: npc._taskOverride.taskId || npc._taskOverride.id,
                            targetLocation: npc._taskOverride.targetLocation,
                        } : null,
                        _actionOverride: npc._actionOverride || null,
                        _hungerOverride: !!npc._hungerOverride,
                        _workResidence: npc._workResidence || null,
                        _scheduleNavTarget: npc._scheduleNavTarget || null,
                    };

                    // 场景切换历史（从 StructuredLogger 获取）
                    if (GST.StructuredLogger?.instance) {
                        const sceneAudit = GST.StructuredLogger.instance.getSceneAudit(npc.id);
                        if (sceneAudit && sceneAudit.length > 0) {
                            context.sceneHistory = sceneAudit.slice(-8).map(h => ({
                                from: h.from,
                                to: h.to,
                                reason: h.reason,
                                time: this._formatGameTime(h.time),
                            }));
                        }
                    }

                    // 弹弹乐场景切换历史（从 BugDetector 自身获取）
                    const bounceHistory = this._sceneChangeHistory[npc.id];
                    if (bounceHistory && bounceHistory.length > 0 && !context.sceneHistory) {
                        context.sceneHistory = bounceHistory.slice(-8).map(h => ({
                            to: h.scene,
                            reason: h.reason,
                            time: new Date(h.time).toLocaleTimeString('zh-CN', { hour12: false }),
                        }));
                    }

                    // 日程信息
                    if (this.game?.scheduleSystem) {
                        try {
                            const schedule = this.game.scheduleSystem;
                            const period = schedule.getCurrentPeriod ? schedule.getCurrentPeriod() : null;
                            const npcSchedule = schedule.getNPCSchedule ? schedule.getNPCSchedule(npc.id) : null;
                            if (period || npcSchedule) {
                                context.schedule = {
                                    currentPeriod: period?.name || period || '未知',
                                    scheduledScene: npcSchedule?.scene || npc._scheduleNavTarget || '未知',
                                    scheduledAction: npcSchedule?.action || '未知',
                                };
                            }
                        } catch (e) { /* 日程系统可能未初始化 */ }
                    }
                }
            }

            return context;
        }

        /** 获取天气信息 */
        _getWeatherInfo() {
            try {
                if (this.game?.weatherSystem) {
                    const ws = this.game.weatherSystem;
                    return `${ws.currentWeather || '未知'} ${ws.temperature || '?'}°C`;
                }
                if (this.game?.outdoorTemp !== undefined) {
                    return `${this.game.outdoorTemp}°C`;
                }
            } catch (e) {}
            return '未知';
        }

        /**
         * 处理 LLM 分析队列（串行处理，避免并发）
         */
        async _processAnalysisQueue() {
            if (this._isAnalyzing || this._llmAnalysisQueue.length === 0) return;
            this._isAnalyzing = true;

            while (this._llmAnalysisQueue.length > 0) {
                const item = this._llmAnalysisQueue.shift();
                // 超过30秒的过期任务跳过
                if (Date.now() - item.enqueuedAt > 30000) continue;

                try {
                    await this._analyzeBugWithLLM(item.bugEntry, item.context);
                } catch (e) {
                    console.error('[BugDetector] LLM分析异常:', e);
                }

                // 每次分析间隔至少2秒，避免打爆 LLM
                await new Promise(r => setTimeout(r, 2000));
            }

            this._isAnalyzing = false;
        }

        /**
         * 调用 LLM 分析 Bug 根因
         */
        async _analyzeBugWithLLM(bugEntry, context) {
            const startTime = Date.now();
            const npcName = bugEntry.npcName || '全局';

            console.log(`[BugDetector] 🧠 开始LLM分析: ${bugEntry.type} (${npcName})`);

            // 构造 User Prompt：把上下文快照序列化给 LLM
            const userPrompt = this._buildAnalysisPrompt(context);

            // 调用快速小模型分析
            const llmResponse = await GST.callLLMFast(
                BugDetector.BUG_ANALYSIS_PROMPT,
                userPrompt,
                400  // Bug分析不需要太长的输出
            );

            const elapsed = Date.now() - startTime;

            if (!llmResponse) {
                console.warn(`[BugDetector] 🧠 LLM分析失败（无响应）: ${bugEntry.type} (${npcName}) ${elapsed}ms`);
                // 即使 LLM 失败，也保存上下文快照（没有 LLM 分析部分）
                this._saveBugReport(bugEntry, context, null, elapsed);
                return;
            }

            // 解析 LLM 返回的 JSON
            const analysis = GST.parseLLMJSON ? GST.parseLLMJSON(llmResponse) : null;

            if (analysis) {
                console.log(`[BugDetector] 🧠 LLM分析完成 (${elapsed}ms):`);
                console.log(`  bugType: ${analysis.bugType}`);
                console.log(`  rootCause: ${analysis.rootCause}`);
                console.log(`  evidence: ${analysis.evidence}`);
                console.log(`  suggestion: ${analysis.suggestion}`);
                console.log(`  confidence: ${analysis.confidence}`);
                console.log(`  involvedSystems: ${JSON.stringify(analysis.involvedSystems)}`);
            } else {
                console.warn(`[BugDetector] 🧠 LLM返回非JSON (${elapsed}ms): ${llmResponse.substring(0, 200)}`);
            }

            // 保存完整的 Bug 报告（上下文 + LLM 分析）
            this._saveBugReport(bugEntry, context, analysis, elapsed, llmResponse);
        }

        /**
         * 构造发送给 LLM 的分析 Prompt
         */
        _buildAnalysisPrompt(context) {
            const parts = [];

            parts.push(`## Bug 检测信息`);
            parts.push(JSON.stringify(context.bugDetection, null, 2));

            if (context.npcState) {
                parts.push(`\n## NPC 当前状态`);
                parts.push(JSON.stringify(context.npcState, null, 2));
            }

            if (context.controlState) {
                parts.push(`\n## 控制权状态`);
                parts.push(JSON.stringify(context.controlState, null, 2));
            }

            if (context.sceneHistory && context.sceneHistory.length > 0) {
                parts.push(`\n## 场景切换历史（最近${context.sceneHistory.length}条）`);
                for (const h of context.sceneHistory) {
                    const from = h.from ? `${h.from} → ` : '';
                    parts.push(`  ${h.time} ${from}${h.to} (${h.reason})`);
                }
            }

            if (context.schedule) {
                parts.push(`\n## 当前日程`);
                parts.push(`  时段: ${context.schedule.currentPeriod}`);
                parts.push(`  目标场景: ${context.schedule.scheduledScene}`);
                parts.push(`  目标行动: ${context.schedule.scheduledAction}`);
            }

            parts.push(`\n## 游戏环境`);
            parts.push(`  游戏时间: ${context.gameTime}`);
            parts.push(`  天气: ${context.weather}`);

            parts.push(`\n请分析这个Bug的根因，返回JSON格式的诊断报告。`);

            return parts.join('\n');
        }

        /**
         * 保存 Bug 报告到服务器
         */
        _saveBugReport(bugEntry, context, llmAnalysis, elapsed, rawLLMResponse) {
            const report = {
                id: `bug_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
                timestamp: new Date().toISOString(),
                gameTime: bugEntry.gameTime,

                // Bug 检测信息
                detection: {
                    type: bugEntry.type,
                    severity: bugEntry.severity,
                    npcId: bugEntry.npcId,
                    npcName: bugEntry.npcName,
                    detail: bugEntry.detail,
                    suggestion: bugEntry.suggestion,
                },

                // 完整上下文快照
                context: context,

                // LLM 分析结果
                llmAnalysis: llmAnalysis || null,
                llmRaw: rawLLMResponse ? rawLLMResponse.substring(0, 500) : null,
                llmElapsed: elapsed,

                // 元信息
                meta: {
                    analyzerModel: 'qwen3:0.6b',
                    analyzerVersion: '1.0',
                },
            };

            // 保存到内存历史
            this._bugReports.push(report);
            if (this._bugReports.length > 50) {
                this._bugReports.splice(0, this._bugReports.length - 50);
            }

            // 异步保存到服务器文件
            this._saveBugReportToServer(report);

            // 同步到 AIModeLogger（如果存在）
            if (GST.AIModeLogger?.instance) {
                try {
                    const logMsg = llmAnalysis
                        ? `🧠 LLM Bug分析 [${bugEntry.type}] ${bugEntry.npcName || '全局'}: rootCause="${llmAnalysis.rootCause}" | systems=${JSON.stringify(llmAnalysis.involvedSystems)} | suggestion="${llmAnalysis.suggestion}" | confidence=${llmAnalysis.confidence}`
                        : `🧠 Bug上下文已记录 [${bugEntry.type}] ${bugEntry.npcName || '全局'} (LLM分析失败)`;
                    GST.AIModeLogger.instance.logAnomaly?.(logMsg);
                } catch (e) { /* 静默 */ }
            }

            return report;
        }

        /**
         * 将 Bug 报告保存到服务器文件系统
         */
        async _saveBugReportToServer(report) {
            try {
                // 格式化为可读的日志文本
                const lines = [
                    `${'═'.repeat(80)}`,
                    `🔍 Bug 诊断报告 #${report.id}`,
                    `${'═'.repeat(80)}`,
                    `时间: ${report.timestamp} | 游戏时间: ${report.gameTime}`,
                    `类型: ${report.detection.type} | 严重程度: ${report.detection.severity}`,
                    `NPC: ${report.detection.npcName || '全局'}`,
                    `描述: ${report.detection.detail}`,
                    ``,
                ];

                // NPC 状态
                if (report.context.npcState) {
                    const s = report.context.npcState;
                    lines.push(`── NPC状态 ──`);
                    lines.push(`  场景: ${s.currentScene} | 行为: ${s.stateDesc}`);
                    lines.push(`  HP:${s.health} STA:${s.stamina} HUN:${s.hunger} SAN:${s.sanity} TEMP:${s.bodyTemp}°C`);
                    lines.push(`  移动中:${s.isMoving} 睡觉:${s.isSleeping} 心情:${s.mood}`);
                    lines.push(``);
                }

                // 控制权状态
                if (report.context.controlState) {
                    const c = report.context.controlState;
                    lines.push(`── 控制权 ──`);
                    lines.push(`  P0: ${c._priorityOverride || '无'}`);
                    lines.push(`  stateOverride: ${c._stateOverride || '无'}`);
                    lines.push(`  taskOverride: ${c._taskOverride ? JSON.stringify(c._taskOverride) : '无'}`);
                    lines.push(`  actionOverride: ${c._actionOverride ? JSON.stringify(c._actionOverride) : '无'}`);
                    lines.push(`  hungerOverride: ${c._hungerOverride}`);
                    lines.push(`  workResidence: ${c._workResidence ? JSON.stringify(c._workResidence) : '无'}`);
                    lines.push(`  scheduleNavTarget: ${c._scheduleNavTarget || '无'}`);
                    lines.push(``);
                }

                // 场景切换历史
                if (report.context.sceneHistory && report.context.sceneHistory.length > 0) {
                    lines.push(`── 场景切换历史 ──`);
                    for (const h of report.context.sceneHistory) {
                        const from = h.from ? `${h.from} → ` : '';
                        lines.push(`  ${h.time} ${from}${h.to} (${h.reason})`);
                    }
                    lines.push(``);
                }

                // LLM 分析结果
                if (report.llmAnalysis) {
                    const a = report.llmAnalysis;
                    lines.push(`── 🧠 LLM 分析 (${report.llmElapsed}ms) ──`);
                    lines.push(`  bugType: ${a.bugType}`);
                    lines.push(`  severity: ${a.severity}`);
                    lines.push(`  rootCause: ${a.rootCause}`);
                    lines.push(`  involvedSystems: ${JSON.stringify(a.involvedSystems)}`);
                    lines.push(`  evidence: ${a.evidence}`);
                    lines.push(`  suggestion: ${a.suggestion}`);
                    lines.push(`  confidence: ${a.confidence}`);
                } else {
                    lines.push(`── 🧠 LLM 分析: 失败/未执行 (${report.llmElapsed || 0}ms) ──`);
                }

                lines.push(`${'═'.repeat(80)}\n`);

                const content = lines.join('\n');

                await fetch('/api/save-bug-report', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        // 文本格式的可读报告（追加写入）
                        content: content,
                        // JSON 格式的完整报告（独立文件）
                        jsonReport: report,
                    }),
                });
            } catch (e) {
                console.error('[BugDetector] 保存Bug报告失败:', e);
            }
        }

        /** 获取 LLM 分析报告历史 */
        getBugReports(count = 20) {
            return this._bugReports.slice(-count);
        }
    }

    GST.BugDetector = BugDetector;
})();
