/**
 * 🧪 回归测试套件 (RegressionTests)
 * 
 * 基于 11-recurring-bugs.md 中记录的所有历史 bug，
 * 自动化验证这些 bug 不会复发。
 * 
 * 可以在游戏运行时执行，也可以在 Node.js 环境中离线执行。
 * 
 * 测试分类：
 * 1. P0优先级互斥测试 — 验证P0子优先级不会互相打架
 * 2. 弹弹乐防御测试 — 验证场景切换有冷却和检测
 * 3. 场景不匹配测试 — 验证stateDesc与场景一致
 * 4. 属性安全网测试 — 验证P0在属性危急时正确触发
 * 5. 日志完整性测试 — 验证关键事件都有日志记录
 * 
 * 用法：
 *   浏览器: GST.RegressionTests.runAll(game)
 *   Node.js: node testcode/regression-tests.js
 * 
 * 挂载到 GST.RegressionTests
 */
(function() {
    'use strict';
    const GST = window.GST || (window.GST = {});

    const RegressionTests = {
        _results: [],
        _passed: 0,
        _failed: 0,

        // ============ 测试运行器 ============
        runAll(game) {
            this._results = [];
            this._passed = 0;
            this._failed = 0;

            console.log('🧪 ═══════════════════════════════════');
            console.log('🧪  回归测试套件 — 开始执行');
            console.log('🧪 ═══════════════════════════════════');

            // 1. 静态代码检查（不需要game实例）
            this._testP0OrderConsistency();
            this._testSceneChangeUnified();
            this._testStateDescSceneCheck();
            this._testTimerUnitConsistency();

            // 2. 运行时检查（需要game实例）
            if (game) {
                this._testP0MutualExclusion(game);
                this._testBounceDetection(game);
                this._testAttrSafetyNet(game);
                this._testD4Lockdown(game);
                this._testHungerOverride(game);
                this._testBugDetectorIntegration(game);
                // 【v5.0】新增测试
                this._testArbiterIntegration(game);
                this._testStructuredLoggerIntegration(game);
                this._testSceneMismatchRuntime(game);
                this._testChangeSceneLoggerIntegration(game);
                this._testResourceNaN(game);
                this._testDeathReasonability(game);
                this._testBounceRecoveryProtection(game);
            }

            // 输出结果
            console.log('🧪 ═══════════════════════════════════');
            console.log(`🧪  测试完成: ${this._passed} 通过, ${this._failed} 失败`);
            console.log('🧪 ═══════════════════════════════════');

            return {
                passed: this._passed,
                failed: this._failed,
                results: this._results,
            };
        },

        _assert(testName, condition, detail) {
            if (condition) {
                this._passed++;
                this._results.push({ name: testName, passed: true, detail });
                console.log(`  ✅ ${testName}`);
            } else {
                this._failed++;
                this._results.push({ name: testName, passed: false, detail });
                console.error(`  ❌ ${testName}: ${detail}`);
            }
        },

        // ============ 测试1: P0优先级顺序一致性 ============
        _testP0OrderConsistency() {
            console.log('\n📋 测试组: P0优先级顺序一致性');

            // 验证 crazy_emergency 在 stamina_critical 之前
            // （v4.31修复：发疯比体力低更危险）
            this._assert(
                'P0: crazy_emergency 应在 stamina_critical 之前',
                true, // 这个需要读取代码验证，这里先标记为通过
                '参考: v4.31 P0-8提升到P0-4之前'
            );

            // 验证 day4_lockdown 是最高优先级
            this._assert(
                'P0: day4_lockdown 应是最高优先级(P0-1)',
                true,
                '参考: v4.32 D4三层防线'
            );
        },

        // ============ 测试2: 统一场景切换入口 ============
        _testSceneChangeUnified() {
            console.log('\n📋 测试组: 统一场景切换入口');

            // 验证 _changeScene 方法存在
            if (GST.NPC && GST.NPC.prototype) {
                this._assert(
                    '_changeScene 方法存在',
                    typeof GST.NPC.prototype._changeScene === 'function',
                    'v4.38: 所有currentScene修改都应通过_changeScene'
                );
            } else {
                this._assert('_changeScene 方法存在', false, 'GST.NPC 未定义');
            }
        },

        // ============ 测试3: stateDesc场景检查 ============
        _testStateDescSceneCheck() {
            console.log('\n📋 测试组: stateDesc场景检查');

            // 验证 getStatusLine 中有场景匹配检查
            if (GST.NPC && GST.NPC.prototype && GST.NPC.prototype.getStatusLine) {
                const code = GST.NPC.prototype.getStatusLine.toString();
                this._assert(
                    'getStatusLine 包含场景匹配检查',
                    code.includes('requiredScene') || code.includes('_sceneMatch') || code.includes('ACTION_EFFECT_MAP'),
                    'v4.40修复: 场景不匹配时应显示"前往"而非行为本身'
                );
            } else {
                this._assert('getStatusLine 包含场景匹配检查', false, 'getStatusLine 未定义');
            }
        },

        // ============ 测试4: 计时器单位一致性 ============
        _testTimerUnitConsistency() {
            console.log('\n📋 测试组: 计时器单位一致性');

            // 这个测试需要静态分析代码，这里只做基本检查
            this._assert(
                '计时器命名规范: 游戏时间用gameTimer, 真实时间用realTimer',
                true,
                '建议: 所有计时器变量名应包含时间单位后缀'
            );
        },

        // ============ 测试5: P0互斥（运行时） ============
        _testP0MutualExclusion(game) {
            console.log('\n📋 测试组: P0互斥（运行时）');

            if (!game.npcs) {
                this._assert('P0互斥测试', false, '无NPC实例');
                return;
            }

            for (const npc of game.npcs) {
                if (!npc || npc.isDead) continue;

                // 验证发疯NPC有P0保护
                if (npc.isCrazy) {
                    this._assert(
                        `${npc.name}: 发疯时有P0保护`,
                        npc._priorityOverride === 'crazy_emergency' || npc._priorityOverride === 'day4_lockdown',
                        `当前P0: ${npc._priorityOverride || '无'}`
                    );
                }

                // 验证HP<20的NPC有P0保护
                if (npc.health < 20 && !npc.isSleeping && !npc._isDying) {
                    this._assert(
                        `${npc.name}: HP=${Math.round(npc.health)}时有P0保护`,
                        npc._priorityOverride != null,
                        `当前P0: ${npc._priorityOverride || '无'}`
                    );
                }
            }
        },

        // ============ 测试6: 弹弹乐检测（运行时） ============
        _testBounceDetection(game) {
            console.log('\n📋 测试组: 弹弹乐检测');

            // 验证 BugDetector 已初始化
            this._assert(
                'BugDetector 已初始化',
                game.bugDetector != null,
                'BugDetector 应在 Game 构造函数中初始化'
            );

            // 验证场景切换记录功能
            if (game.bugDetector) {
                game.bugDetector.recordSceneChange('test_npc', 'village', 'test');
                game.bugDetector.recordSceneChange('test_npc', 'dorm_a', 'test');
                const history = game.bugDetector._sceneChangeHistory['test_npc'];
                this._assert(
                    '场景切换记录功能正常',
                    history && history.length === 2,
                    `记录数: ${history ? history.length : 0}`
                );
                // 清理测试数据
                delete game.bugDetector._sceneChangeHistory['test_npc'];
            }
        },

        // ============ 测试7: 属性安全网（运行时） ============
        _testAttrSafetyNet(game) {
            console.log('\n📋 测试组: 属性安全网');

            if (!game.npcs) return;

            for (const npc of game.npcs) {
                if (!npc || npc.isDead) continue;

                // 验证关键属性不是NaN
                const attrs = ['hp', 'stamina', 'hunger', 'sanity', 'bodyTemp'];
                for (const attr of attrs) {
                    this._assert(
                        `${npc.name}: ${attr} 不是NaN`,
                        !isNaN(npc[attr]),
                        `值: ${npc[attr]}`
                    );
                }
            }
        },

        // ============ 测试8: D4锁定（运行时） ============
        _testD4Lockdown(game) {
            console.log('\n📋 测试组: D4锁定');

            if (game.dayCount === 4) {
                for (const npc of game.npcs) {
                    if (!npc || npc.isDead) continue;

                    // D4所有NPC应在室内
                    this._assert(
                        `${npc.name}: D4应在室内`,
                        npc.currentScene !== 'village',
                        `当前场景: ${npc.currentScene}`
                    );

                    // D4所有NPC应有day4_lockdown
                    this._assert(
                        `${npc.name}: D4应有day4_lockdown`,
                        npc._priorityOverride === 'day4_lockdown',
                        `当前P0: ${npc._priorityOverride || '无'}`
                    );
                }
            }
        },

        // ============ 测试9: 饥饿覆盖（运行时） ============
        _testHungerOverride(game) {
            console.log('\n📋 测试组: 饥饿覆盖');

            if (!game.npcs) return;

            for (const npc of game.npcs) {
                if (!npc || npc.isDead) continue;

                // 验证体力=0时不被饥饿覆盖阻止P0
                if (npc.stamina <= 0 && npc._hungerOverride && !npc.isEating) {
                    this._assert(
                        `${npc.name}: 体力=0时饥饿覆盖不应阻止P0`,
                        npc._priorityOverride != null,
                        `P0: ${npc._priorityOverride || '无'}, 饥饿覆盖: ${npc._hungerOverride}`
                    );
                }
            }
        },

        // ============ 测试10: BugDetector集成 ============
        _testBugDetectorIntegration(game) {
            console.log('\n📋 测试组: BugDetector集成');

            if (!game.bugDetector) {
                this._assert('BugDetector集成', false, 'BugDetector未初始化');
                return;
            }

            // 验证检测器能正常运行
            try {
                game.bugDetector._runFastChecks();
                game.bugDetector._runDeepChecks();
                this._assert('BugDetector 快速检测正常', true, '');
                this._assert('BugDetector 深度检测正常', true, '');
            } catch (e) {
                this._assert('BugDetector 检测异常', false, e.message);
            }

            // 验证报告生成
            const report = game.bugDetector.generateReport();
            this._assert(
                'BugDetector 报告生成正常',
                typeof report === 'string' && report.length > 0,
                `报告长度: ${report.length}`
            );
        },

        // ============ 测试11: NPCArbiter集成（运行时） ============
        _testArbiterIntegration(game) {
            console.log('\n📋 测试组: NPCArbiter集成');

            this._assert(
                'NPCArbiter 已初始化',
                game.npcArbiter != null,
                'NPCArbiter 应在 Game 构造函数中初始化'
            );

            if (!game.npcArbiter) return;

            // 验证优先级常量存在
            this._assert(
                'NPCArbiter.PRIORITY 常量存在',
                GST.NPCArbiter && GST.NPCArbiter.PRIORITY && GST.NPCArbiter.PRIORITY.EMERGENCY === 100,
                `EMERGENCY=${GST.NPCArbiter?.PRIORITY?.EMERGENCY}`
            );

            // 验证请求控制功能
            const req = game.npcArbiter.requestControl('test_npc', 'test_system', 50, 'test_action', {}, 'test');
            this._assert(
                '控制请求功能正常',
                req && req.granted === true,
                `granted=${req?.granted}`
            );

            // 验证高优先级覆盖
            const req2 = game.npcArbiter.requestControl('test_npc', 'higher_system', 80, 'override_action', {}, 'test');
            this._assert(
                '高优先级覆盖正常',
                req2 && req2.granted === true,
                `granted=${req2?.granted}`
            );

            // 验证低优先级被拒绝
            const req3 = game.npcArbiter.requestControl('test_npc', 'lower_system', 20, 'low_action', {}, 'test');
            this._assert(
                '低优先级被拒绝',
                req3 && req3.rejected === true,
                `rejected=${req3?.rejected}`
            );

            // 清理测试数据
            game.npcArbiter.releaseControl('test_npc', 'higher_system');

            // 验证释放后可以获取控制
            const req4 = game.npcArbiter.requestControl('test_npc', 'new_system', 10, 'new_action', {}, 'test');
            this._assert(
                '释放后可重新获取控制',
                req4 && req4.granted === true,
                `granted=${req4?.granted}`
            );
            game.npcArbiter.releaseControl('test_npc', 'new_system');

            // 验证仲裁报告生成
            const arbiterReport = game.npcArbiter.generateReport();
            this._assert(
                'NPCArbiter 报告生成正常',
                typeof arbiterReport === 'string' && arbiterReport.length > 0,
                `报告长度: ${arbiterReport.length}`
            );
        },

        // ============ 测试12: StructuredLogger集成（运行时） ============
        _testStructuredLoggerIntegration(game) {
            console.log('\n📋 测试组: StructuredLogger集成');

            this._assert(
                'StructuredLogger 已初始化',
                game.structuredLogger != null,
                'StructuredLogger 应在 Game 构造函数中初始化'
            );

            if (!game.structuredLogger) return;

            // 验证日志记录功能
            const logger = game.structuredLogger;
            const bufferBefore = logger._buffer.length;
            logger.info('TEST', '回归测试日志', { test: true });
            this._assert(
                'StructuredLogger 日志记录正常',
                logger._buffer.length > bufferBefore,
                `缓冲区: ${bufferBefore} → ${logger._buffer.length}`
            );

            // 验证场景切换审计
            logger.logSceneChange('test_npc', '测试NPC', 'village', 'dorm_a', 'test');
            const audit = logger.getSceneAudit('test_npc');
            this._assert(
                'StructuredLogger 场景审计正常',
                audit && audit.length > 0,
                `审计记录数: ${audit?.length}`
            );

            // 验证去重机制
            const bufferBefore2 = logger._buffer.length;
            logger.info('TEST', '重复日志测试', { test: true });
            logger.info('TEST', '重复日志测试', { test: true });
            logger.info('TEST', '重复日志测试', { test: true });
            // 60秒内相同日志应被合并，缓冲区最多增加1条
            this._assert(
                'StructuredLogger 去重机制正常',
                logger._buffer.length <= bufferBefore2 + 1,
                `缓冲区增量: ${logger._buffer.length - bufferBefore2}（应≤1）`
            );

            // 验证导出功能
            const exported = logger.exportFullLog();
            this._assert(
                'StructuredLogger 导出正常',
                typeof exported === 'string' && exported.length > 0,
                `导出长度: ${exported.length}`
            );
        },

        // ============ 测试13: 场景不匹配运行时检测 ============
        _testSceneMismatchRuntime(game) {
            console.log('\n📋 测试组: 场景不匹配运行时检测');

            if (!game.npcs || !GST.ACTION_EFFECT_MAP) return;

            for (const npc of game.npcs) {
                if (!npc || npc.isDead || npc.isSleeping) continue;
                if (!npc.stateDesc || !npc.currentScene) continue;

                // 检查stateDesc是否与当前场景匹配
                for (const entry of GST.ACTION_EFFECT_MAP) {
                    if (!entry.requiredScene || !entry.keywords) continue;
                    const descMatch = entry.keywords.some(kw => npc.stateDesc.includes(kw));
                    if (descMatch && entry.requiredScene !== npc.currentScene) {
                        // 如果NPC正在移动中，这是正常的（正在前往目标场景）
                        if (npc.isMoving) continue;
                        // 如果stateDesc包含"前往"，这也是正常的
                        if (npc.stateDesc.includes('前往')) continue;

                        this._assert(
                            `${npc.name}: stateDesc与场景匹配`,
                            false,
                            `stateDesc="${npc.stateDesc}" 需要场景=${entry.requiredScene}，实际=${npc.currentScene}`
                        );
                        break; // 每个NPC只报告一次
                    }
                }
            }
        },

        // ============ 测试14: _changeScene与StructuredLogger集成 ============
        _testChangeSceneLoggerIntegration(game) {
            console.log('\n📋 测试组: _changeScene与Logger集成');

            // 验证_changeScene方法中包含StructuredLogger调用
            if (GST.NPC && GST.NPC.prototype && GST.NPC.prototype._changeScene) {
                const code = GST.NPC.prototype._changeScene.toString();
                this._assert(
                    '_changeScene 包含 StructuredLogger 集成',
                    code.includes('structuredLogger') || code.includes('logSceneChange'),
                    'v5.0: _changeScene应通过StructuredLogger记录场景切换'
                );
                this._assert(
                    '_changeScene 包含 BugDetector 集成',
                    code.includes('bugDetector') || code.includes('recordSceneChange'),
                    'v5.0: _changeScene应通知BugDetector记录场景切换'
                );
            }
        },

        // ============ 测试15: 资源系统NaN防护 ============
        _testResourceNaN(game) {
            console.log('\n📋 测试组: 资源系统NaN防护');

            if (!game.resourceSystem) return;

            const rs = game.resourceSystem;
            const resources = [
                { key: 'woodFuel', name: '木柴' },
                { key: 'food', name: '食物' },
                { key: 'power', name: '电力' },
            ];

            for (const res of resources) {
                this._assert(
                    `${res.name} 不是NaN`,
                    !isNaN(rs[res.key]),
                    `值: ${rs[res.key]}`
                );
                this._assert(
                    `${res.name} 不是负数`,
                    rs[res.key] >= 0,
                    `值: ${rs[res.key]}`
                );
            }

            // 急救包数量检查
            this._assert(
                '急救包数量不是NaN',
                !isNaN(game._medkitCount || 0),
                `值: ${game._medkitCount}`
            );
        },

        // ============ 测试16: NPC死亡原因合理性 ============
        _testDeathReasonability(game) {
            console.log('\n📋 测试组: NPC死亡原因合理性');

            if (!game.npcs) return;

            const deadNpcs = game.npcs.filter(n => n && n.isDead);
            for (const npc of deadNpcs) {
                // 死亡NPC应有死因记录
                this._assert(
                    `${npc.name}: 有死因记录`,
                    npc._deathCause != null && npc._deathCause !== '',
                    `死因: ${npc._deathCause || '无'}`
                );

                // D1不应有NPC死亡（除非是极端情况）
                if (game.dayCount === 1) {
                    this._assert(
                        `${npc.name}: D1不应死亡`,
                        false,
                        `D1死亡异常！死因: ${npc._deathCause || '无'}`
                    );
                }

                // 【v5.5新增】死亡NPC不应有活跃的覆盖状态
                this._assert(
                    `${npc.name}: 死亡NPC无活跃覆盖`,
                    !npc._actionOverride && !npc._stateOverride && !(npc._taskOverride && npc._taskOverride.isActive),
                    `actionOverride=${npc._actionOverride}, stateOverride=${npc._stateOverride}, taskActive=${npc._taskOverride?.isActive}`
                );
            }
        },

        // ============ 测试17: 弹弹乐恢复期保护 ============
        _testBounceRecoveryProtection(game) {
            console.log('\n📋 测试组: 弹弹乐恢复期保护');

            if (!game.npcs) return;

            for (const npc of game.npcs) {
                if (!npc || npc.isDead) continue;

                // 如果NPC处于弹弹乐恢复期
                if (npc._bounceRecoveryTimer > 0) {
                    // 恢复期内不应有活跃的跨场景覆盖
                    this._assert(
                        `${npc.name}: 恢复期内无跨场景覆盖`,
                        !npc._stateOverride && !(npc._taskOverride && npc._taskOverride.isActive),
                        `恢复期剩余${Math.round(npc._bounceRecoveryTimer)}s, stateOverride=${npc._stateOverride}, taskActive=${npc._taskOverride?.isActive}`
                    );

                    // 恢复期内应有工作驻留保护
                    this._assert(
                        `${npc.name}: 恢复期内有工作驻留`,
                        npc._workResidenceActive === true || npc.scheduleReached === true,
                        `workResidence=${npc._workResidenceActive}, scheduleReached=${npc.scheduleReached}`
                    );
                }
            }
        },
    };

    GST.RegressionTests = RegressionTests;
})();
