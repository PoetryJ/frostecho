/**
 * 📊 结构化日志系统 (StructuredLogger)
 * 
 * 增强版日志系统，自动识别 bug 模式并生成修复建议。
 * 与 BugDetector 协同工作，提供完整的问题追踪链路。
 * 
 * 日志层级：
 * - TRACE: 详细追踪（场景切换、属性变化、导航事件）
 * - INFO:  正常事件（行动决策、对话、资源变化）
 * - WARN:  潜在问题（场景不匹配、属性偏低、决策矛盾）
 * - ERROR: 确认bug（弹弹乐、NaN传播、死循环）
 * - FATAL: 致命问题（NPC非正常死亡、游戏崩溃）
 * 
 * 挂载到 GST.StructuredLogger
 */
(function() {
    'use strict';
    const GST = window.GST || (window.GST = {});

    const LOG_LEVEL = {
        TRACE: 0,
        INFO:  1,
        WARN:  2,
        ERROR: 3,
        FATAL: 4,
    };

    class StructuredLogger {
        constructor(game) {
            this.game = game;
            this.minLevel = LOG_LEVEL.INFO; // 默认只记录 INFO 及以上
            this._buffer = [];              // 日志缓冲区
            this._maxBuffer = 5000;         // 最多缓存5000条
            this._lastFlushedIndex = 0;     // 已flush到服务器的位置索引
            this._flushTimer = 0;
            this._flushInterval = 30;       // 每30秒自动flush到服务器
            this._sessionId = this._generateSessionId();
            this._filename = null;

            // 去重机制
            this._dedupeMap = {};           // { key: { count, lastTime, lastEntry } }
            this._dedupeWindow = 60000;     // 60秒内相同日志合并

            // 场景切换审计日志
            this._sceneAuditLog = {};       // { npcId: [{ from, to, reason, time }] }

            // 单例引用
            StructuredLogger.instance = this;

            console.log(`[StructuredLogger] ✅ 结构化日志系统已初始化 (session: ${this._sessionId})`);
        }

        _generateSessionId() {
            const now = new Date();
            return `session_${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}_${String(now.getHours()).padStart(2,'0')}${String(now.getMinutes()).padStart(2,'0')}${String(now.getSeconds()).padStart(2,'0')}`;
        }

        // ============ 核心日志方法 ============

        trace(category, message, data) {
            this._log(LOG_LEVEL.TRACE, category, message, data);
        }

        info(category, message, data) {
            this._log(LOG_LEVEL.INFO, category, message, data);
        }

        warn(category, message, data) {
            this._log(LOG_LEVEL.WARN, category, message, data);
        }

        error(category, message, data) {
            this._log(LOG_LEVEL.ERROR, category, message, data);
        }

        fatal(category, message, data) {
            this._log(LOG_LEVEL.FATAL, category, message, data);
        }

        _log(level, category, message, data) {
            if (level < this.minLevel) return;

            const entry = {
                level: this._levelName(level),
                category,
                message,
                data: data || {},
                gameTime: this.game ? `D${this.game.dayCount} ${this._formatGameTime(this.game.gameTimeSeconds)}` : 'unknown',
                realTime: new Date().toISOString(),
            };

            // 去重检查
            const dedupeKey = `${category}_${message}`;
            const existing = this._dedupeMap[dedupeKey];
            if (existing && Date.now() - existing.lastTime < this._dedupeWindow) {
                existing.count++;
                existing.lastTime = Date.now();
                existing.lastEntry = entry;
                return; // 合并，不重复记录
            }

            // 如果之前有合并的，先输出合并计数
            if (existing && existing.count > 1) {
                this._buffer.push({
                    ...existing.lastEntry,
                    message: `${existing.lastEntry.message} (×${existing.count})`,
                });
            }

            this._dedupeMap[dedupeKey] = { count: 1, lastTime: Date.now(), lastEntry: entry };
            this._buffer.push(entry);

            // 缓冲区满时自动裁剪
            if (this._buffer.length > this._maxBuffer) {
                const trimCount = this._buffer.length - this._maxBuffer;
                this._buffer.splice(0, trimCount);
                // 同步更新已flush索引
                this._lastFlushedIndex = Math.max(0, this._lastFlushedIndex - trimCount);
            }

            // ERROR 和 FATAL 立即输出到控制台
            if (level >= LOG_LEVEL.ERROR) {
                const prefix = level === LOG_LEVEL.FATAL ? '💀' : '❌';
                console.error(`${prefix} [${entry.gameTime}] [${category}] ${message}`, data || '');
            }
        }

        _levelName(level) {
            return ['TRACE', 'INFO', 'WARN', 'ERROR', 'FATAL'][level] || 'UNKNOWN';
        }

        _formatGameTime(seconds) {
            const h = Math.floor(seconds / 3600);
            const m = Math.floor((seconds % 3600) / 60);
            return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
        }

        // ============ 专用日志方法 ============

        /** 记录NPC场景切换（审计日志） */
        logSceneChange(npcId, npcName, fromScene, toScene, reason) {
            if (!this._sceneAuditLog[npcId]) {
                this._sceneAuditLog[npcId] = [];
            }
            const audit = this._sceneAuditLog[npcId];
            audit.push({
                from: fromScene,
                to: toScene,
                reason,
                time: this.game ? this.game.gameTimeSeconds : 0,
                realTime: Date.now(),
            });
            // 只保留最近50条
            if (audit.length > 50) audit.splice(0, audit.length - 50);

            this.trace('SCENE_CHANGE', `${npcName}: ${fromScene} → ${toScene} (${reason})`, {
                npcId, fromScene, toScene, reason,
            });

            // 通知 BugDetector
            if (this.game && this.game.bugDetector) {
                this.game.bugDetector.recordSceneChange(npcId, toScene, reason);
            }
        }

        /** 记录P0优先级变化 */
        logP0Change(npcId, npcName, oldP0, newP0, reason) {
            this.info('P0_CHANGE', `${npcName}: P0 ${oldP0 || '无'} → ${newP0 || '无'} (${reason})`, {
                npcId, oldP0, newP0, reason,
            });
        }

        /** 记录NPC死亡 */
        logDeath(npcId, npcName, cause, attrs) {
            this.fatal('NPC_DEATH', `${npcName} 死亡: ${cause}`, {
                npcId, cause, attrs,
                sceneAudit: this._sceneAuditLog[npcId] ? this._sceneAuditLog[npcId].slice(-10) : [],
            });
        }

        /** 记录BugDetector的检测结果 */
        logBugDetection(result) {
            const level = result.severity.includes('致命') ? LOG_LEVEL.ERROR :
                          result.severity.includes('严重') ? LOG_LEVEL.WARN :
                          LOG_LEVEL.INFO;
            this._log(level, `BUG_DETECT:${result.type}`, result.detail, {
                npcId: result.npcId,
                suggestion: result.suggestion,
                ref: result.ref,
                extra: result.extra,
            });
        }

        /** 记录LLM决策 */
        logDecision(npcId, npcName, decisionType, decision, context) {
            this.info('DECISION', `${npcName} ${decisionType}: ${JSON.stringify(decision).substring(0, 200)}`, {
                npcId, decisionType, decision, context,
            });
        }

        /** 记录资源变化 */
        logResourceChange(resource, oldVal, newVal, reason) {
            if (Math.abs(newVal - oldVal) > 0.5) {
                this.trace('RESOURCE', `${resource}: ${oldVal.toFixed(1)} → ${newVal.toFixed(1)} (${reason})`, {
                    resource, oldVal, newVal, reason,
                });
            }
        }

        // ============ 定时flush ============
        update(realDt) {
            this._flushTimer += realDt;
            if (this._flushTimer >= this._flushInterval) {
                this._flushTimer = 0;
                this._flushToServer();
            }
        }

        async _flushToServer() {
            if (this._buffer.length === 0) return;

            // 【v5.0修复】只发送尚未flush的新日志，而不是整个buffer
            // 根因：每次flush都发送整个_buffer但不清空，导致日志文件中同一条日志重复出现N次
            const toFlush = this._buffer.slice(this._lastFlushedIndex || 0);
            if (toFlush.length === 0) return;

            const content = toFlush.map(entry => {
                const dataStr = entry.data && Object.keys(entry.data).length > 0 
                    ? ` | ${JSON.stringify(entry.data)}` 
                    : '';
                return `[${entry.realTime}] [${entry.gameTime}] [${entry.level}] [${entry.category}] ${entry.message}${dataStr}`;
            }).join('\n');

            // 确定文件名
            if (!this._filename) {
                const now = new Date();
                const dateStr = `${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}`;
                this._filename = `${this._sessionId}.log`;
            }

            try {
                await fetch('/api/append-debug-log', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        filename: this._filename,
                        content,
                    }),
                });
                // flush成功后记录已发送的位置
                this._lastFlushedIndex = this._buffer.length;
            } catch (e) {
                // 静默失败，不影响游戏；下次flush会重试
            }
        }

        // ============ 导出完整日志 ============
        exportFullLog() {
            return this._buffer.map(entry => {
                const dataStr = entry.data && Object.keys(entry.data).length > 0 
                    ? ` | ${JSON.stringify(entry.data)}` 
                    : '';
                return `[${entry.realTime}] [${entry.gameTime}] [${entry.level}] [${entry.category}] ${entry.message}${dataStr}`;
            }).join('\n');
        }

        /** 获取某个NPC的场景切换审计日志 */
        getSceneAudit(npcId) {
            return this._sceneAuditLog[npcId] || [];
        }

        /** 获取所有NPC的场景切换审计日志 */
        getAllSceneAudits() {
            return { ...this._sceneAuditLog };
        }
    }

    GST.StructuredLogger = StructuredLogger;
})();
