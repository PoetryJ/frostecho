/**
 * 福音镇 - NPC 体温系统 Mixin
 * 职责：体温更新、失温判定、体温状态/颜色查询
 * 从 npc-attributes.js 拆分，遵循SRP原则（单一职责）
 * 挂载到 GST.NPC.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;

    /**
     * 每帧更新体温
     * 室外寒冷降温、室内供暖恢复、失温状态判定、严重失温救援倒计时
     */
    proto._updateBodyTemp = function(dt, game) {
        if (this.isDead) return;

        const ws = game.weatherSystem;
        if (!ws) return;

        const toPerHour = 3600;
        const btSrc = [];

        const temp = ws.getEffectiveTemp();
        const isOutdoor = this.currentScene === 'village';

        // ---- 室外：体温下降 ----
        if (isOutdoor && temp < 0) {
            // 体温下降速率【已调整：从0.000167提高到0.00025】
            // -30°C时约0.0075°C/秒=0.45°C/分钟，从36.5降到25需约25分钟
            let dropRate = Math.abs(temp) * 0.00025 * dt;

            // 失温状态下体温下降加速
            if (this.isHypothermic) {
                dropRate *= 1.5;
            }

            // 【新增风寒效应】大雪或极寒暴风雪天气时降温速率×1.5
            if (ws.currentWeather && (
                ws.currentWeather.includes('大雪') ||
                ws.currentWeather.includes('极寒暴风雪') ||
                ws.currentWeather.includes('暴风雪')
            )) {
                dropRate *= 1.5;
            }

            this.bodyTemp = Math.max(25, this.bodyTemp - dropRate);
            btSrc.push({ label: '❄️ 室外寒冷', rate: -(dropRate / dt * toPerHour).toFixed(2) });

            // 累计户外连续时间（游戏秒）
            const _bodyTempGameSec = dt * (game.timeSpeed || 60);
            this._outdoorContinuousTime += _bodyTempGameSec;
        }

        // ---- 室内：体温恢复/降温 ----
        if (!isOutdoor) {
            const fs = game.furnaceSystem;
            const isNearFurnace = fs && fs.isNearActiveFurnace(this);
            // 【修复v4.16】使用室内温度而非室外温度来计算室内降温
            const indoorTemp = (fs && fs.indoorTemp !== undefined) ? fs.indoorTemp : temp;

            if (isNearFurnace) {
                // 供暖有效：恢复体温
                this.bodyTemp = Math.min(36.5, this.bodyTemp + 0.00333 * dt);
                btSrc.push({ label: '🏠 室内供暖', rate: +(0.00333 * toPerHour).toFixed(2) });
            } else if (indoorTemp < 0) {
                // 室内但供暖失效且室内温度<0，缓慢降温
                const indoorDropRate = Math.abs(indoorTemp) * 0.00003 * dt;
                this.bodyTemp = Math.max(25, this.bodyTemp - indoorDropRate);
                btSrc.push({ label: '🏠 室内偏冷', rate: -(Math.abs(indoorTemp) * 0.00003 * toPerHour).toFixed(2) });
            } else {
                // 室内且室内温度≥0，缓慢恢复体温
                this.bodyTemp = Math.min(36.5, this.bodyTemp + 0.001 * dt);
                btSrc.push({ label: '🏠 室内回暖', rate: +(0.001 * toPerHour).toFixed(2) });
            }

            // 室内重置户外连续时间
            this._outdoorContinuousTime = 0;
        }

        // ---- 失温状态判定 ----
        const wasHypothermic = this.isHypothermic;
        const wasSevere = this.isSevereHypothermic;

        if (this.bodyTemp < 30) {
            // 严重失温: 倒地不起，需救援
            this.isSevereHypothermic = true;
            this.isHypothermic = true;
            this._rescueNeeded = true;

            // 严重失温持续伤害
            // 【修复v4.16】室内严重失温伤害减半
            const severeIndoorMult = isOutdoor ? 1.0 : 0.5;
            this.health = Math.max(0, this.health - 0.2 * dt * severeIndoorMult);
            this.stamina = Math.max(0, this.stamina - 0.3 * dt * severeIndoorMult);
            btSrc.push({ label: '🧊 严重失温伤害', rate: 0, note: '健康-' + (0.2 * severeIndoorMult * toPerHour).toFixed(0) + '/h 体力-' + (0.3 * severeIndoorMult * toPerHour).toFixed(0) + '/h' });

            // 救援倒计时
            // 【P0修复】dt是gameDt，需乘以timeSpeed转为游戏秒
            const _rescueGameSec = dt * (game.timeSpeed || 60);
            if (isOutdoor) {
                this._rescueTimer += _rescueGameSec;
                if (this._rescueTimer >= 1800 && this.health > 0) {
                    this.health = 0;
                    this._deathCause = '冻死';
                    console.log(`[BodyTemp] ${this.name} 严重失温无人救援，冻死`);
                }
            } else {
                this._rescueTimer += _rescueGameSec;
                if (this._rescueTimer >= 3600 && this.health > 0) {
                    this.health = 0;
                    this._deathCause = '冻死';
                    console.log(`[BodyTemp] ${this.name} 室内严重失温60分钟无人救援，冻死`);
                }
            }

            if (!wasSevere) {
                this.mood = GST.t('mood.dying');
                this.stateDesc = '严重失温，倒地不起 🧶'; // translateStateDesc handles i18n
                this.expression = GST.t('npc_body.so_cold_help');                this.expressionTimer = 15;
                if (game.addEvent) {
                    game.addEvent(GST.t('body.severe_hypothermia', { name: this.name, temp: this.bodyTemp.toFixed(1) }));
                }
            }
        } else if (this.bodyTemp < 35) {
            // 轻度失温: 移速×0.5、体力消耗×2、无法工作
            this.isHypothermic = true;
            this.isSevereHypothermic = false;
            this._rescueNeeded = false;
            this._rescueTimer = 0;

            // 【P0修复】dt是gameDt，需乘以timeSpeed转为游戏秒
            const _hypoGameSec = dt * (game.timeSpeed || 60);
            if (this.bodyTemp < 33) {
                this._hypothermiaDuration += _hypoGameSec;
            } else {
                this._hypothermiaDuration = Math.max(0, this._hypothermiaDuration - _hypoGameSec * 0.5);
            }

            // 失温持续伤害
            // 【修复v4.16】区分室内室外
            const hypoIndoorMult = isOutdoor ? 1.0 : 0.3;
            this.health = Math.max(0, this.health - 0.05 * dt * hypoIndoorMult);
            this.stamina = Math.max(0, this.stamina - 0.08 * dt * hypoIndoorMult);
            btSrc.push({ label: '🥶 失温伤害', rate: 0, note: '健康-' + (0.05 * hypoIndoorMult * toPerHour).toFixed(0) + '/h 体力-' + (0.08 * hypoIndoorMult * toPerHour).toFixed(0) + '/h' });

            if (!wasHypothermic) {
                this.mood = GST.t('mood.shivering');
                this.stateDesc = '体温过低，瑟瑟发抖 🥶'; // translateStateDesc handles i18n
                this.expression = GST.t('npc_body.so_cold_shivering');
                this.expressionTimer = 10;
                if (game.addEvent) {
                    game.addEvent(GST.t('body.hypothermia_start', { name: this.name, temp: this.bodyTemp.toFixed(1) }));
                }
            }
        } else {
            // 体温正常
            this._hypothermiaDuration = 0;
            if (wasHypothermic) {
                this.isHypothermic = false;
                this.isSevereHypothermic = false;
                this._rescueNeeded = false;
                this._rescueTimer = 0;
                this.expression = GST.t('npc_body.warmed_up');
                this.expressionTimer = 5;
                if (game.addEvent) {
                    game.addEvent(GST.t('body.temp_recovered', { name: this.name, temp: this.bodyTemp.toFixed(1) }));
                }
            }
        }

        // 【v4.34】保存体温来源到_attrRateSources
        if (this._attrRateSources) {
            this._attrRateSources.bodyTemp = btSrc;
        }
    };

    /** 获取体温颜色 (绿→黄→红→紫) */
    proto.getBodyTempColor = function() {
        if (this.bodyTemp >= 36) return '#4ade80';   // 绿
        if (this.bodyTemp >= 35) return '#facc15';   // 黄
        if (this.bodyTemp >= 32) return '#f87171';   // 红
        return '#c084fc';                             // 紫
    };

    /** 获取体温状态描述 */
    proto.getBodyTempStatus = function() {
        if (this.bodyTemp >= 36) return '正常';
        if (this.bodyTemp >= 35) return '偏低';
        if (this.bodyTemp >= 32) return '失温';
        if (this.bodyTemp >= 30) return '严重失温';
        return '濒死';
    };

})();
