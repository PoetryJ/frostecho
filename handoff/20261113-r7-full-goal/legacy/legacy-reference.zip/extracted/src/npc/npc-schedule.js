/**
 * 福音镇 - NPC 日程调度模块
 * 通过 mixin 模式挂载到 NPC.prototype
 * 包含：日程更新、天气调整、睡眠、任务覆盖导航
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;
    // [已拆分到 npc-weather-response.js] _getMyRoomKey
    // [已拆分到 npc-weather-response.js] _notifyEmergency
    // [已拆分到 npc-weather-response.js] canSafelyGoOutdoor
    // [已拆分到 npc-weather-response.js] _getWeatherAdjustedEntry
    // [已拆分到 npc-weather-response.js] _getSanityAdjustedEntry
    // [已拆分到 npc-weather-response.js] _getAdjustedEntry
    // [已拆分到 npc-weather-response.js] _isAtHome
    // [已拆分到 npc-weather-response.js] _isBedtime
    /** 获取NPC自己的床位位置key（宿舍内部） */;

    proto._navigateToScheduleTarget = function(targetKey, game) {
        // 【v5.7新增】P1仲裁暂停期间不接受导航指令，NPC应静止思考
        if (this._arbitrationPaused) {
            this._logDebug && this._logDebug('schedule', `[P1仲裁] 仲裁暂停中，阻止导航到 ${targetKey}`);
            return;
        }
        // 【v4.16】抖动冻结期间不接受导航指令
        if (this._jitterFreezeTimer > 0) return;
        // 【v5.5修复】弹弹乐恢复期内阻止跨场景导航（同场景内导航允许）
        if (this._bounceRecoveryTimer > 0) {
            const loc = GST.SCHEDULE_LOCATIONS[targetKey];
            if (loc && loc.scene !== this.currentScene) {
                this._logDebug && this._logDebug('schedule', `[弹弹乐恢复期] 恢复期剩余${Math.round(this._bounceRecoveryTimer)}游戏秒，阻止跨场景导航到 ${targetKey}`);
                return;
            }
        }
        // 【进屋保护期】NPC刚进入室内时，短暂冻结跨场景导航，防止闪现
        // 【修复】P0紧急状态（健康危急/体力不支）无视保护期，必须立即回家
        const isP0Nav = this._behaviorPriority === 'P0';
        if (this._indoorEntryProtection > 0 && this.currentScene !== 'village' && !isP0Nav) {
            const loc = GST.SCHEDULE_LOCATIONS[targetKey];
            if (loc && loc.scene !== this.currentScene) {
                this._logDebug && this._logDebug('schedule', `[进屋保护] 进屋保护期剩余${this._indoorEntryProtection.toFixed(1)}s，阻止跨场景导航到 ${targetKey}`);
                return;
            }
        }
        // 【出门过程保护】NPC正在走向门口准备出门时，不接受新的导航指令
        // 【修复】P0紧急状态无视出门保护，避免卡在门口循环
        if (this._walkingToDoor && !isP0Nav) {
            this._logDebug && this._logDebug('schedule', `[出门保护] 正在出门中，阻止新导航到 ${targetKey}`);
            return;
        }
        // 【关键修复】对话中不执行任何导航，防止NPC被传送到其他场景导致对话中断
        // 但urgent任务覆盖可以打断聊天
        if (this.state === 'CHATTING') {
            if (this._taskOverride && this._taskOverride.isActive && this._taskOverride.priority === 'urgent') {
                this._logDebug && this._logDebug('schedule', `urgent任务打断聊天，开始导航到 ${targetKey}`);
                this._forceEndChat();
            } else {
                return;
            }
        }

        // 记录导航开始时间和目标，用于超时兜底
        this._navStartTime = Date.now();
        this._scheduleNavTimer = 0;
        this._scheduleNavTarget = targetKey;

        const loc = GST.SCHEDULE_LOCATIONS[targetKey];
        if (!loc) {
            console.warn(`[NPC-${this.name}] SCHEDULE_LOCATIONS中未找到key: "${targetKey}"，跳过导航`);
            return;
        }

        // 判断目标是否是门口（xxx_door 类型）
        const isDoorTarget = targetKey.endsWith('_door');
        // 从门口key推断对应的室内场景名
        const doorToScene = {
            warehouse_door: 'warehouse', medical_door: 'medical',
            dorm_a_door: 'dorm_a', dorm_b_door: 'dorm_b',
            kitchen_door: 'kitchen', workshop_door: 'workshop',
        };

        // 如果需要切换场景（目标是室内）
        if (loc.scene !== this.currentScene) {
            // 【修复】如果目标是门口类且NPC已在对应室内，检查是否到达inside位置
            if (isDoorTarget) {
                const insideScene = doorToScene[targetKey];
                if (insideScene && this.currentScene === insideScene) {
                    // NPC已在目标室内场景中，直接标记到达，不再反复寻路
                    this.scheduleReached = true;
                    this._enterWalkTarget = null;
                    return;
                }
            }

            if (this.currentScene === 'village') {
                // 在村庄 → 如果是门口类目标，走过去再进入（而不是直接传送）
                if (isDoorTarget) {
                    this._pendingEnterScene = doorToScene[targetKey] || null;
                    this._pendingEnterKey = targetKey;
                    this._pathTo(loc.x, loc.y, game);
                } else {
                    // 非门口的室内目标 → 直接传送
                    this._teleportTo(loc.scene, loc.x, loc.y);
                }
            } else {
                // 在其他室内 → 先走到室内门口再出门到村庄
                // 【v4.26b修复】如果P0要求待在室内，不执行跨场景导航（避免虚假的"出门"日志刷屏）
                const _stayIndoorOverrides = ['day4_lockdown', 'hypothermia', 'health_critical', 'stamina_critical', 'sanity_critical', 'crazy_emergency', 'medical_urgent'];
                if (this._priorityOverride && _stayIndoorOverrides.includes(this._priorityOverride)) {
                    this.scheduleReached = true;
                    // 【v4.27修复】阻止跨场景导航时必须清除stateDesc和actionOverride
                    // 否则NPC在宿舍显示"砍柴"等与当前场景不匹配的状态（赵铁柱Bug）
                    if (this._actionOverride) {
                        this._clearActionOverride();
                        this.stateDesc = '';
                    }
                    return;
                }
                // 【v4.7统一】户外安全门控：统一检查属性+天气+冷却，替代之前单独的天气检查
                if (!this.canSafelyGoOutdoor(game)) {
                    // 【v4.37修复】跨场景到室内（如workshop_door、kitchen_door）使用更宽松的门槛
                    // 根因：D2 -55°C时，NPC去工坊/厨房被极寒门槛（STA≥70）阻止，全员被困宿舍→全灭
                    // 跨场景到室内只需短暂经过village（几秒钟），普通门槛（STA≥45）足够安全
                    const _indoorDoors = ['warehouse_door', 'medical_door', 'dorm_a_door', 'dorm_b_door', 'kitchen_door', 'workshop_door'];
                    const _isIndoorTransit = isDoorTarget && _indoorDoors.includes(targetKey);
                    const _canTransit = _isIndoorTransit && this.stamina >= 25 && this.health >= 30 && 
                        (this.bodyTemp === undefined || this.bodyTemp >= 35.5);
                    if (!_canTransit) {
                        console.warn(`[NPC-${this.name}] [户外安全门控] 跨场景导航需经过室外，但属性/天气不满足安全条件，NPC留在室内待命`);
                        this.scheduleReached = true;
                        // 【v5.2修复】改用游戏时间单位，1800游戏秒=游戏30分钟冷却
                        this._scheduleNavBlockCooldown = 1800; // 1800游戏秒冷却
                        // 【v4.27修复】同上：阻止出门时清除不匹配的stateDesc
                        if (this._actionOverride) {
                            this._clearActionOverride();
                            this.stateDesc = '';
                        }
                        return;
                    }
                }
                // 【v4.5诊断】日程跨场景导航需要出门
                if (this.game && this.game.aiModeLogger) {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                    const fullMsg = `${this.name} [日程跨场景]从${this.currentScene}出门→目标${targetKey} | 饥饿覆盖=${this._hungerOverride} | 状态覆盖=${this._stateOverride || '无'} | ${snap}`;
                    this.game.aiModeLogger.logDoor(this.id, this.name, this.currentScene, 'out', fullMsg);
                }
                this._walkToDoorAndExit(game, null, true); // skipSafetyCheck: 上层已做过安全检查
                // 出门后下一帧日程系统会重新触发导航
            }
            return;
        }

        // 同场景
        if (this.currentScene === 'village' && isDoorTarget) {
            // 目标是门口 → 先寻路走到门口，到达后自动进入对应建筑
            this._pendingEnterScene = doorToScene[targetKey] || null;
            this._pendingEnterKey = targetKey;
            this._pathTo(loc.x, loc.y, game);
        } else {
            this._pendingEnterScene = null;
            this._pathTo(loc.x, loc.y, game);
        }
    };

    proto._postArrivalAwareness = function(game, schedItem) {
        // 只在初次到达时触发一次
        if (this._arrivalAwarenessApplied === this.currentScheduleIdx) return;
        this._arrivalAwarenessApplied = this.currentScheduleIdx;

        const desc = schedItem.desc;
        const nearby = this._getNearbyNPCs(game, 64);

        // 【饥饿系统】到达餐饮场所且日程包含吃饭相关关键词时，开始吃饭
        const eatKeywords = /吃|买.*餐|买.*吃|买.*零食|买.*点心|买早餐|买午餐|买晚餐|买面包/;
        const eatScenes = ['kitchen', 'dorm_a', 'dorm_b'];
        if (eatKeywords.test(desc) && eatScenes.includes(this.currentScene) && !this.isEating) {
            this.isEating = true;
            this.eatingTimer = 20; // 吃饭持续 20 真实秒 ≈ 20 游戏分钟
            this.stateDesc = desc;
            this.mood = GST.t('mood.content');
        }

        // 如果日程描述涉及社交（聊天、找人、讨论、探讨、聊聊），但附近没人
        const socialKeywords = /聊天|找人|串门|讨论|探讨|聊聊/;
        const isSocialIntent = socialKeywords.test(desc);
        if (isSocialIntent && nearby.length === 0) {
            this.stateDesc = desc.replace(socialKeywords, '') + '（没找到人）';
            this.mood = GST.t('mood.bored');
            this.expression = GST.t('npc_schedule.no_one_around');
            this.expressionTimer = 6;
            // 【修复】冷却机制：30秒内只触发一次"找不到人→出门游荡"，避免刷屏
            if (this._noOneFoundCooldown <= 0) {
                this._noOneFoundCooldown = 30; // 30秒冷却
                if (game.addEvent) {
                    game.addEvent(GST.t('schedule.no_one_found', { name: this.name }));
                }
                // 在室内场景找不到人时，先离开建筑再去别处
                if (this.currentScene !== 'village') {
                    this._leaveAndWander(game);
                } else {
                    // 在户外找不到人，随机走向附近另一个地标碰碰运气
                    this._wanderToNearbyLandmark(game);
                }
            }
        } else if (isSocialIntent && nearby.length > 0) {
            // 附近有人，更新描述
            const names = nearby.slice(0, 2).map(n => n.name).join('、');
            this.stateDesc = `正在和${names}附近闲逛`;

            // 【修复】所有NPC到达社交目的地后都主动发起对话，不仅限于哲学家
            this._tryProactiveChat(game, nearby);
        } else if (!isSocialIntent && nearby.length > 0) {
            // 【增强】非社交日程，但附近有人时也有概率主动聊天（60%概率）
            if (Math.random() < 0.6 && this.state !== 'CHATTING') {
                this._tryProactiveChat(game, nearby);
            }
        }
    }
    // [已拆分到 npc-weather-response.js] _updateRainResponse
    // ---- 日程系统 ----;

    proto._updateSchedule = function(dt, game) {
        const speedMult = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
        const realDt = speedMult > 0 ? dt / speedMult : dt;

        // ============ 行为优先级系统（v4.40核心原则重构） ============
        // 核心设计原则：系统是情报提供者，不是决策辅助者。废除一切"定死的"规则。
        // 
        // 安全网层（仅保留出门=立即死亡的极端情况）：
        //   - P0-1: D4全天室内锁定（极寒出门=立即死亡）
        //   - P0-2: 体温<34°C+户外 → 传送进最近室内（严重失温=几分钟内死亡）
        //   - P0-3: 健康<15+户外+体温低/体力耗尽 → 传送进宿舍（致命组合）
        //   - P0-4: 体力≤5+体温<34+户外 → 传送进宿舍（致命组合）
        //
        // 情报注入层（所有非致命紧急状态改为情报注入+紧急LLM决策）：
        //   - 体力<20、健康<30、精神<40、发疯、下雨 → _notifyEmergency()
        //   - LLM通过prompt获得完整身体状态信息，自主决定行动
        //
        // P1: 任务驱动（_taskOverride激活时覆盖日程、紧急资源任务、LLM urgent行动）
        // P2: 日程默认（scheduleTemplate日程表、LLM normal行动）
        const ws = game.weatherSystem;
        const currentDay = ws ? ws.currentDay : 1;
        const hour = game.getHour();

        // ========== P0: 生存紧急层 ==========

        // P0-1: 第4天行为锁定 — 全天生效，NPC锁定在室内不得出门
        // 【根治弹弹乐】day4_lockdown 持续整个第4天，不因进入室内而清除
        // 在室外：紧急导航回家；在室内：保持锁定状态，阻止任何出门行为
        if (currentDay === 4) {
            // 设置/维持 day4_lockdown 标记（整个第4天持续生效）
            if (this._priorityOverride !== 'day4_lockdown') {
                // 【v4.27致命修复】D4期间day4_lockdown必须无条件覆盖所有其他P0覆盖
                // v4.26d只修复了village和null的情况，但遗漏了：
                // NPC在室内有medical_urgent/stamina_critical等P0覆盖时，day4_lockdown不设置
                // 导致这些P0清除后NPC没有day4_lockdown保护，LLM决策可以驱动NPC出门
                // 赵铁柱D4就是这样死的：medical_urgent覆盖→day4_lockdown未设置→出门→冻死
                const prevOverride = this._priorityOverride;
                this._priorityOverride = 'day4_lockdown';
                this._logDebug('schedule', `[P0] 第4天全天室内锁定已激活${prevOverride ? `（覆盖${prevOverride}）` : ''}`);
                if (this.game && this.game.aiModeLogger) {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                    this.game.aiModeLogger.logDeduped('EMERGENCY', this.id, 'day4_lockdown', `${this.name} [P0]第4天全天室内锁定${prevOverride ? `（覆盖${prevOverride}）` : ''} | ${snap}`);
                }
            }

            // 暂停所有需要跨场景的任务（第4天跨场景必经village，会触发弹弹乐）
            if (this._taskOverride.isActive) {
                const taskLoc = GST.SCHEDULE_LOCATIONS[this._taskOverride.targetLocation];
                const isCrossScene = taskLoc && taskLoc.scene !== this.currentScene;
                if (isCrossScene) {
                    this._pauseTaskOverride('day4_lockdown', 'priority');
                    this._logDebug('schedule', `[P0] 第4天暂停跨场景任务: ${this._taskOverride.taskId}`);
                }
                // 同场景内的任务允许继续执行（如在warehouse内的任务）
            }

            if (this.currentScene === 'village') {
                // 在室外 → 【v4.32b防弹弹乐修复】强制传送回宿舍，但有防弹弹乐保护
                // 
                // ⚠️ 弹弹乐风险分析（v4.32a的教训）：
                // v4.32a的"立即传送"会导致弹弹乐——如果有某种机制每帧把NPC踢到village，
                // 那么每帧都会触发_enterIndoor，形成"传送回室内→被踢到village→传送回室内"的死循环。
                // 
                // 防弹弹乐策略：
                // 1. 使用_day4IndoorCooldown冷却计时器，传送成功后设置3秒冷却
                // 2. 冷却期间如果NPC又出现在village，说明有弹弹乐，记录ANOMALY日志+调用栈
                // 3. 冷却期间不再传送（避免加速弹弹乐），而是等冷却结束后再传送
                // 4. 非冷却期间检测到在village，立即传送（不等10秒，第四世证明10秒太慢）
                //
                this._behaviorPriority = 'P0';
                const homeScene = this.homeName === 'dorm_a' ? 'dorm_a' : 'dorm_b';
                this.stateDesc = '大极寒！紧急返回室内';
                
                if (!this._day4IndoorCooldown) this._day4IndoorCooldown = 0;
                
                if (this._day4IndoorCooldown > 0) {
                    // 冷却期间又出现在village → 弹弹乐！记录ANOMALY但不传送
                    this._day4IndoorCooldown -= realDt;
                    if (!this._day4BouncingLogged) {
                        this._day4BouncingLogged = true;
                        const _stack = new Error().stack;
                        const _caller = _stack.split('\n').slice(2,5).map(s => s.trim().replace(/^at /, '')).join(' ← ');
                        if (this.game && this.game.aiModeLogger) {
                            const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                            this.game.aiModeLogger.log('ANOMALY', `🏓 ${this.name} D4弹弹乐检测! 刚传送到${homeScene}又出现在village! caller=${_caller} | ${snap}`);
                        }
                    }
                    // 冷却结束后重新传送
                    if (this._day4IndoorCooldown <= 0) {
                        this._day4IndoorCooldown = 0;
                        this._day4BouncingLogged = false;
                    }
                } else {
                    // 非冷却期间 → 立即传送 + 设置冷却
                    this._logDebug('schedule', `[P0] 第4天在village，强制传送到${homeScene}`);
                    if (this.game && this.game.aiModeLogger) {
                        const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                        this.game.aiModeLogger.log('EMERGENCY', `🚨 ${this.name} [P0]第4天在village,强制传送到${homeScene} | ${snap}`);
                        this.game.aiModeLogger.pushNpcEvent(this.id, `[P0]第4天在village,强制传送到${homeScene}`);
                    }
                    this._enterIndoor(homeScene, game);
                    this._day4IndoorCooldown = 3; // 3秒真实时间冷却，防弹弹乐
                    this._day4BouncingLogged = false;
                }
                return; // 在室外时阻止所有其他行为
            } else {
                // 在室内，重置户外计时器和冷却
                this._day4OutdoorTimer = 0;
                this._day4IndoorCooldown = 0;
                this._day4BouncingLogged = false;
            }
            // 在室内 → 不return，允许继续执行后续P1/P2逻辑（但day4_lockdown保持，阻止出门）
            // canSafelyGoOutdoor 和 _navigateToScheduleTarget 中的跨场景检查会阻止NPC出门
        }

        // 【v4.40核心原则修复】P0-2: 体温过低
        // 体温<34°C+户外=真正致命（几分钟内死亡），保留传送安全网
        // 体温34~35°C=有风险但不致命，改为情报注入让LLM自主决策
        if (this.bodyTemp !== undefined && this.bodyTemp < 35 && this.currentScene === 'village') {
            if (this.bodyTemp < 34) {
                // 【安全网】严重失温+户外=致命，强制传送进最近室内
                this._behaviorPriority = 'P0';
                if (this._priorityOverride !== 'hypothermia') {
                    this._priorityOverride = 'hypothermia';
                    this.stateDesc = '严重失温！紧急返回室内';
                    this._logDebug('schedule', `[安全网] 体温${this.bodyTemp.toFixed(1)}°C<34，严重失温，紧急传送`);
                    if (this.game && this.game.aiModeLogger) {
                        const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                        this.game.aiModeLogger.logDeduped('EMERGENCY', this.id, 'hypothermia_lethal',
                            `🚨 ${this.name} [安全网]体温${this.bodyTemp.toFixed(1)}°C<34，严重失温传送 | ${snap}`);
                    }
                    const nearestDoor = this._findNearestIndoorDoor(game);
                    if (nearestDoor) {
                        this._navigateToScheduleTarget(nearestDoor.key, game);
                    } else {
                        this._navigateToScheduleTarget(this.homeName + '_door', game);
                    }
                } else if (!this.isMoving && this.currentPath.length === 0) {
                    const nearestDoor2 = this._findNearestIndoorDoor(game);
                    if (nearestDoor2) {
                        this._navigateToScheduleTarget(nearestDoor2.key, game);
                    } else {
                        this._navigateToScheduleTarget(this.homeName + '_door', game);
                    }
                }
                if (this._taskOverride.isActive) {
                    this._pauseTaskOverride('hypothermia', 'priority');
                }
                return;
            } else {
                // 体温34~35°C：有风险但不致命，注入情报让LLM自主决策
                this._notifyEmergency(`你的体温只有${this.bodyTemp.toFixed(1)}°C，正在失温！你现在在户外，继续待在外面体温会持续下降。最近的室内建筑可以恢复体温，宿舍(${this.homeName}_door)也可以。`);
                this._logDebug('schedule', `[情报注入] 体温${this.bodyTemp.toFixed(1)}°C(34~35)，已注入紧急情报让LLM自主决策`);
            }
        }

        // P0-3: 健康危急 — 使用动态阈值（行为锁下收紧）
        // 【行为锁优化】正在吃饭/睡觉/治疗时，阈值从<20收紧到<10
        const p0t = this._getP0Thresholds();
        // 【v4.5修复】stateOverride=sick时跳过P0-3：NPC已在前往医疗站途中，
        // P0-3会把目标改成宿舍，与stateOverride冲突导致进门出门死循环
        // 【v4.17修复】NPC已在自己宿舍时跳过（已经在家了，正在恢复中）
        const isInHomeDorm = this.currentScene === this.homeName;
        if (this.health < p0t.healthThreshold && this.currentScene !== 'medical' && !isInHomeDorm && this._stateOverride !== 'sick') {
            // 【行为锁】如果当前行为即将完成(5秒内)，等待完成后再触发P0
            if (this.isEating && this.eatingTimer > 0 && this.eatingTimer < 5) {
                this._logDebug('schedule', `[P0] 健康${Math.round(this.health)}但吃饭即将完成(${this.eatingTimer.toFixed(1)}s)，等待完成`);
                return; // 等吃完再触发
            }
            if (this.isSleeping) {
                if (this.health >= 10) {
                    return; // 睡觉中health>=10，不打断睡眠
                }
                console.warn(`[NPC-${this.name}] [异常] NPC在睡觉时段被P0驱动出门 health:${Math.round(this.health)}`);
            }
            // 【v4.17修复】NPC在非village的其他室内场景（如workshop/kitchen）时
            // 【v4.40核心原则修复】室内健康危急改为情报注入，让LLM自主决策
            const isInOtherIndoor = this.currentScene && this.currentScene !== 'village';
            if (isInOtherIndoor) {
                this._notifyEmergency(`你的健康值只有${Math.round(this.health)}/100，身体状况危急。你现在在${this.currentScene}室内，可以原地休息恢复，也可以去宿舍(${this.homeName}_door)或医疗站(medical_door)。`);
                this._logDebug('schedule', `[情报注入] 健康${Math.round(this.health)}，在${this.currentScene}室内，已注入情报`);
                return;
            }
            // 【v4.40核心原则修复】P0-3非致命情况改为情报注入
            // 保留致命传送安全网（健康<15+户外+体温低），其余交给LLM自主决策
            const healthTarget = this.homeName + '_door';
            const healthHomeName = this.homeName || 'dorm_a';

            // 【安全网】健康极低+在village户外+体温低或体力耗尽 → 致命组合，传送进宿舍
            if (this.currentScene === 'village' && this.health < 15 && (this.bodyTemp < 35 || this.stamina <= 5)) {
                this._logDebug('schedule', `[安全网] 🚨健康${Math.round(this.health)}+户外+体温${this.bodyTemp?.toFixed(1)}°C，致命组合，紧急传送`);
                if (this.game && this.game.aiModeLogger) {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                    this.game.aiModeLogger.logDeduped('EMERGENCY', this.id, 'health_lethal_teleport',
                        `🚨 ${this.name} [安全网]健康${Math.round(this.health)}+户外，致命组合传送 | ${snap}`);
                }
                this._enterIndoor(healthHomeName, game);
                if (!this._restCooldownTimer || this._restCooldownTimer <= 0) {
                    this._restCooldownTimer = 120;
                }
                return;
            }
            // 非致命情况：注入情报，让LLM自主决策
            const healthHintParts = [`你的健康值只有${Math.round(this.health)}/100，身体状况危急。`];
            if (this.currentScene === 'village') healthHintParts.push(`你现在在户外，健康低时非常危险。`);
            healthHintParts.push(`宿舍(${this.homeName}_door)可以休息恢复，医疗站(medical_door)可以治疗。`);
            if (this.health < 15) healthHintParts.push(`⚠️ 健康接近死亡边缘！`);
            this._notifyEmergency(healthHintParts.join(''));
            this._logDebug('schedule', `[情报注入] 健康${Math.round(this.health)}，已注入紧急情报让LLM自主决策`);
        }

        // 【v4.40核心原则修复】P0-4a: 发疯处理 — 全部改为情报注入
        // 设计原则：系统是情报提供者，不是决策辅助者。发疯不会立即死亡。
        // 注意：发疯NPC的isCrazy标记仍然保留（影响行为表现），但不再强制控制导航
        if (this.isCrazy && !this.isSleeping && !this._isDying) {
            const crazyHintParts = [`你正在精神崩溃中(San:${Math.round(this.sanity)})！`];
            if (this.currentScene === 'village') {
                crazyHintParts.push(`你现在在户外，精神崩溃状态下在户外很危险。`);
            } else {
                crazyHintParts.push(`你现在在${this.currentScene}室内。`);
            }
            crazyHintParts.push(`宿舍(${this.homeName}_door)可以休息恢复精神，找人聊天也能缓解。`);
            this._notifyEmergency(crazyHintParts.join(''));
            this._logDebug('schedule', `[情报注入] 发疯中(San:${Math.round(this.sanity)})，已注入紧急情报让LLM自主决策`);
        }

        // P0-4: 体力不支时暂停任务覆盖，前往宿舍休息
        // 【复合需求仲裁】极度饥饿时跳过体力不支，让饥饿系统处理
        // 【修复】饱腹<15时无论体力多少都优先吃饭（不能饿着肚子去睡觉）
        // 【修复】睡觉中的NPC不触发体力不足出门（宿舍内本身就在恢复体力）
        if (this.hunger < 15) {
            // 饱腹极低（<15）：优先吃饭，跳过体力不支判断，让饥饿系统处理
            // 不能饿着肚子去睡觉，吃饭只需8秒很快就能完成
        } else if (this.hunger < 35 && this.stamina < 15) {
            // 都比较低时优先吃饭（吃饭只需8秒更快完成）
            // 跳过stamina_critical，让饥饿系统处理
        } else if (this.isSleeping && this.stamina < p0t.staminaThreshold) {
            // 睡觉中体力低不出门，静默跳过（宿舍内睡觉本身就在恢复体力）
            return;
        }
        // 【v4.31修复】正在吃饭时不打断，但前往吃饭途中如果体力=0必须触发P0
        // 根因：之前_hungerOverride也会跳过P0-4，导致NPC体力=0+饥饿覆盖时
        // 完全没有P0保护（清璇第3世D1 23:00的Bug就是这样产生的）
        // 修复：只有isEating（正在吃饭）才跳过，_hungerOverride（前往吃饭途中）不再跳过
        if (this.stamina < p0t.staminaThreshold && this.isEating) {
            // 正在吃饭中，不打断（吃饭很快就能完成）
            return;
        }
        // 【v4.26c致命修复】P0体力不支：移除 _taskOverride.isActive 前置条件
        // 原来只在有taskOverride时才触发P0，导致通过LLM决策go_to到达目标后
        // 执行角色默认行为（如清璇在medical制作草药）时体力=0完全没有P0保护
        // 清璇因此体力=0持续32小时无人处理
        if (this.stamina < p0t.staminaThreshold) {
            // 【行为锁】如果当前行为即将完成(5秒内)，等待完成后再触发P0
            if (this.isEating && this.eatingTimer > 0 && this.eatingTimer < 5) {
                this._logDebug('schedule', `[P0] 体力${Math.round(this.stamina)}但吃饭即将完成(${this.eatingTimer.toFixed(1)}s)，等待完成`);
                return;
            }
            // 【修复v4.17】NPC已在室内场景（非village）时，不踢出室内跑回宿舍
            // 而是暂停任务、原地进入休息状态，避免反复出门→回来→出门的弹弹乐循环
            const isIndoor = this.currentScene && this.currentScene !== 'village';
            if (isIndoor) {
                // 【v4.40核心原则修复】室内体力不支：注入情报，让LLM自主决策
                // 室内不会冻死，体力低也不会立即死亡，完全交给AI
                this._notifyEmergency(`你的体力只有${Math.round(this.stamina)}/100，非常疲惫。你现在在${this.currentScene}室内，可以原地休息恢复体力，也可以去宿舍(${this.homeName}_door)睡觉。`);
                this._logDebug('schedule', `[情报注入] 体力${Math.round(this.stamina)}，在${this.currentScene}室内，已注入情报`);
                return;
            }
            this._behaviorPriority = 'P0';
            if (this._taskOverride.isActive) this._pauseTaskOverride('stamina_critical', 'priority');
            // 【修复】体力不支导航到宿舍而非户外暖炉广场，避免NPC站在户外无法恢复
            const staminaTarget = this.homeName + '_door';
            const staminaHomeName = this.homeName || 'dorm_a';

            // 【v4.40核心原则修复】体力不支改为情报注入+紧急LLM决策
            // 设计原则：系统是情报提供者，不是决策辅助者。体力低不会立即死亡，有时间让LLM决策
            // 唯一例外：体力≤5+体温<34+户外=真正致命（走不动+失温=必死），保留传送安全网
            if (this.currentScene === 'village' && this.stamina <= 5 && this.bodyTemp !== undefined && this.bodyTemp < 34) {
                // 真正致命情况：体力耗尽+严重失温+户外，传送进宿舍（安全网）
                this._logDebug('schedule', `[安全网] 🚨体力${Math.round(this.stamina)}+体温${this.bodyTemp.toFixed(1)}°C+户外，致命组合，紧急传送`);
                if (this.game && this.game.aiModeLogger) {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                    this.game.aiModeLogger.logDeduped('EMERGENCY', this.id, 'stamina_lethal_teleport',
                        `🚨 ${this.name} [安全网]体力${Math.round(this.stamina)}+体温${this.bodyTemp.toFixed(1)}°C+户外，致命组合传送 | ${snap}`);
                }
                this._enterIndoor(staminaHomeName, game);
                if (!this._restCooldownTimer || this._restCooldownTimer <= 0) {
                    this._restCooldownTimer = 120;
                }
                return;
            }
            // 非致命情况：注入情报，让LLM自主决策
            const staminaHintParts = [`你的体力只有${Math.round(this.stamina)}/100，非常疲惫。`];
            if (this.currentScene === 'village') staminaHintParts.push(`你现在在户外，体力低时行动效率很差。`);
            staminaHintParts.push(`宿舍(${this.homeName}_door)可以休息恢复体力。`);
            if (this.stamina <= 5) staminaHintParts.push(`⚠️ 体力接近耗尽，随时可能倒下！`);
            this._notifyEmergency(staminaHintParts.join(''));
            this._logDebug('schedule', `[情报注入] 体力${Math.round(this.stamina)}，已注入紧急情报让LLM自主决策`);
        }

        // 【v4.40核心原则修复】P0-5: 健康<30 — 改为情报注入，让LLM自主决策
        // 设计原则：系统是情报提供者，不是决策辅助者。健康<30不会立即死亡。
        // P0-3已保留健康<15+户外+体温低的致命传送安全网
        if (this.health < 30 && this.currentScene !== 'medical') {
            if (this.isSleeping && this.health >= 10) {
                // 睡觉中health>=10，不打断睡眠
            } else {
                const healthHintParts = [`你的健康值只有${Math.round(this.health)}/100，身体状况很差。`];
                if (this.currentScene === 'village') healthHintParts.push(`你现在在户外，健康低时容易出事。`);
                healthHintParts.push(`医疗站(medical_door)可以治疗，宿舍(${this.homeName}_door)可以休息恢复。`);
                if (this.health < 15) healthHintParts.push(`⚠️ 健康接近死亡边缘！`);
                this._notifyEmergency(healthHintParts.join(''));
                this._logDebug('schedule', `[情报注入] 健康${Math.round(this.health)}，已注入紧急情报让LLM自主决策`);
            }
        }

        // 【v4.40核心原则修复】P0-6 day2_return 已移除
        // 原逻辑：第2天户外超2小时强制返回室内 — 完全硬编码，严重违反AI自主决策原则
        // 户外风险信息已通过LLM prompt中的天气/体温/体力情报传递，由AI自主判断

        // 【v4.40核心原则修复】P0-7: 精神危急 — 改为情报注入，让LLM自主决策
        // 设计原则：系统是情报提供者，不是决策辅助者。San<40不会立即死亡。
        const isSanityCritical = this.sanity !== undefined && this.sanity < 40;
        const isOutdoorScene = this.currentScene === 'village';
        const canInterruptSanity = !this.isEating && !this.isSleeping && !this._isBeingTreated;
        const isAlreadySeekingHelp = this._stateOverride === 'mental' || this._stateOverride === 'sick';
        if (isSanityCritical && canInterruptSanity && !isAlreadySeekingHelp) {
            const sanHintParts = [`你的精神值只有${Math.round(this.sanity)}/100，精神状态很差。`];
            if (isOutdoorScene) sanHintParts.push(`你现在在户外，精神差时容易崩溃。`);
            sanHintParts.push(`宿舍(${this.homeName}_door)可以休息恢复精神，找人聊天也能缓解。`);
            if (this.sanity < 20) sanHintParts.push(`⚠️ 精神接近崩溃边缘！`);
            this._notifyEmergency(sanHintParts.join(''));
            this._logDebug('schedule', `[情报注入] 精神${Math.round(this.sanity)}，已注入紧急情报让LLM自主决策`);
        }

        // 【v4.31】P0-8已提升到P0-4a（在体力不支之前），此处不再重复
        // 原P0-8 crazy_emergency的代码已移至P0-4a位置，确保发疯优先于体力不支

        // P0优先级覆盖清除检测
        if (this._priorityOverride) {
            const canClear = (
                (this._priorityOverride === 'hypothermia' && (this.bodyTemp === undefined || this.bodyTemp >= 35.5)) ||
                (this._priorityOverride === 'medical_urgent' && this.health >= 40) ||
                (this._priorityOverride === 'health_critical' && this.health >= 30) ||
                (this._priorityOverride === 'stamina_critical' && this.stamina >= 40) ||
                // 【v4.40】已废弃的P0类型清理：stamina_critical/medical_urgent/sanity_critical/crazy_emergency/day2_return
                // 这些已改为情报注入，不再设置_priorityOverride，但保留兼容清除以防残留
                (this._priorityOverride === 'sanity_critical') ||
                (this._priorityOverride === 'crazy_emergency') ||
                (this._priorityOverride === 'stamina_critical') ||
                (this._priorityOverride === 'medical_urgent') ||
                (this._priorityOverride === 'day2_return') ||
                (this._priorityOverride === 'day4_lockdown' && currentDay !== 4) // 【根治弹弹乐】第4天结束才清除，不因进入室内而清除
            );
            if (canClear) {
                const clearedType = this._priorityOverride;
                this._priorityOverride = null;
                this._logDebug('schedule', `[P0] 优先级覆盖(${clearedType})已清除，恢复正常行为`);
                // 【v4.26d致命修复】第4天P0清除后立即设置day4_lockdown，消除竞态窗口
                // 原来P0清除后_priorityOverride=null，下一帧才设置day4_lockdown
                // 在这个窗口内P1任务恢复可能导致NPC出门到village，然后被day4_lockdown困在户外致死
                // 苏岩D4 00:04、清璇D4 05:21就是这样死的：crazy_emergency清除→任务恢复出门→卡在village
                if (currentDay === 4) {
                    this._priorityOverride = 'day4_lockdown';
                    this._logDebug('schedule', `[P0恢复] 第4天，${clearedType}清除后立即设置day4_lockdown（消除竞态窗口）`);
                    if (this.currentScene === 'village') {
                        // 已经在户外了，紧急导航回家
                        const homeDoor = this.homeName === 'dorm_a' ? 'dorm_a_door' : 'dorm_b_door';
                        this._navigateToScheduleTarget(homeDoor, game);
                    }
                    return; // 第4天不恢复任何任务，直接return
                }
                // 【v4.7统一】P0清除后设置兜底冷却（30s），主力判断由canSafelyGoOutdoor属性检查承担
                this._outdoorCooldown = 30;
                // 【v4.40】竞态保护简化：只保留真正致命的P0（hypothermia）
                // stamina_critical/crazy_emergency/health_critical已改为情报注入，不再需要竞态保护
                const p0t_race = this._getP0Thresholds();
                if (this.bodyTemp !== undefined && this.bodyTemp < 35 && this.currentScene === 'village') {
                    this._priorityOverride = 'hypothermia';
                    this._logDebug('schedule', `[P0竞态保护] ${clearedType}清除后检测到体温${this.bodyTemp.toFixed(1)}°C<35，立即设置hypothermia`);
                    return;
                }
                // 【行为锁】P0恢复后检查是否仍在就寝时段，如果是则导航回宿舍继续睡觉
                const curHour = game.getHour();
                if (this._isBedtime(curHour) && !this.isSleeping) {
                    this._logDebug('schedule', `[P0恢复] 仍在就寝时段(${curHour}时)，导航回宿舍继续睡觉`);
                    this._navigateToScheduleTarget(this.homeName + '_door', game);
                    return;
                }
                // P0恢复后自动重启被暂停的任务
                // 【v4.7统一】通过canSafelyGoOutdoor判断是否安全出门，不再枚举P0类型
                if (this._taskOverride.targetLocation && this._taskOverride.taskId && !this._taskOverride.isActive) {
                    const taskLoc = GST.SCHEDULE_LOCATIONS[this._taskOverride.targetLocation];
                    const isOutdoorTask = taskLoc && taskLoc.scene === 'village';
                    // 【修复】第4天不恢复需要跨场景的任务（跨场景必经village，会触发P0弹弹乐）
                    const isCrossSceneTask = taskLoc && taskLoc.scene !== this.currentScene;
                    // 【v4.26b修复】极寒天气下也不恢复户外/跨场景任务
                    const _wsRecover = game && game.weatherSystem;
                    const _effTempRecover = _wsRecover ? _wsRecover.getEffectiveTemp() : 0;
                    const _isTooColdRecover = _effTempRecover < -20;
                    const _cannotGoOutRecover = _wsRecover && !_wsRecover.canGoOutside();
                    // 【v4.37修复】区分纯户外和跨场景到室内，极寒天允许恢复跨场景到室内的任务
                    // 【关键】_door目标在SCHEDULE_LOCATIONS中scene='village'，isOutdoorTask为true，
                    // 但_door目标不是真正的纯户外任务，NPC到达门口后会自动进入室内
                    const _isDoorTaskRecover = this._taskOverride.targetLocation && this._taskOverride.targetLocation.endsWith('_door');
                    const _isPureOutdoorRecover = isOutdoorTask && !_isDoorTaskRecover;
                    if ((currentDay === 4 || _isTooColdRecover || _cannotGoOutRecover) && (_isPureOutdoorRecover || (isCrossSceneTask && !_isDoorTaskRecover))) {
                        const reason = currentDay === 4 ? '第4天' : `极寒${_effTempRecover}°C`;
                        this._logDebug('schedule', `[P0恢复] ${reason}禁止恢复${isOutdoorTask ? '户外' : '跨场景'}任务: ${this._taskOverride.taskId} → ${this._taskOverride.targetLocation}`);
                        // 暂停而非取消，天气好转后P1层会重新检查
                    } else if (isOutdoorTask && !this.canSafelyGoOutdoor(game)) {
                        // 属性未达安全阈值，取消户外任务，等待下次会议重新分配
                        this._logDebug('schedule', `[P0恢复] 属性未达安全阈值，取消户外任务: ${this._taskOverride.taskId} → ${this._taskOverride.targetLocation}`);
                        if (this.game && this.game.aiModeLogger) {
                            this.game.aiModeLogger.log('TASK', `${this.name} [P0恢复]取消户外任务${this._taskOverride.taskId}→${this._taskOverride.targetLocation}（属性未达安全阈值）`);
                        }
                        this.deactivateTaskOverride();
                    } else {
                        this._resumeTaskOverride(game, 'p0_recovered', 'priority');
                        this._logDebug('schedule', `[P0恢复] 自动重启被暂停的任务: ${this._taskOverride.taskId} → ${this._taskOverride.targetLocation}`);
                    }
                }
            } else {
                return; // P0行为未完成，继续执行
            }
        }

        // ========== P1: 任务驱动覆盖层 ==========
        // 当_taskOverride激活时，跳过P2日程，导航到任务目标位置

        // 【一致性检查】饥饿覆盖和任务覆盖不能同时存在
        // 【v4.17修复】改为暂停而非完全取消，避免_checkResourceUrgency反复重分配导致刷屏
        if (this._hungerOverride && this._taskOverride && this._taskOverride.isActive) {
            this._logDebug && this._logDebug('schedule', `饥饿覆盖与任务覆盖同时存在，暂停任务覆盖`);
            this._pauseTaskOverride('hunger_override', 'hunger');
        }

        // P1-1: 任务覆盖激活检测
        if (this._taskOverride.isActive && this._taskOverride.targetLocation) {
            this._behaviorPriority = 'P1';

            const targetLoc = GST.SCHEDULE_LOCATIONS[this._taskOverride.targetLocation];
            const isOutdoorTarget = targetLoc && targetLoc.scene === 'village';
            const isCrossScene = targetLoc && targetLoc.scene !== this.currentScene;

            // 【v4.26b修复】极寒天气下禁止户外/跨场景任务（与P2日程层的天气检查保持一致）
            // 赵铁柱D2在-45°C下被P1任务驱动出门砍柴，回家路上体力归零死亡
            const _ws = game && game.weatherSystem;
            const _effectiveTemp = _ws ? _ws.getEffectiveTemp() : 0;
            const _isTooCold = _effectiveTemp < -20;
            const _cannotGoOutside = _ws && !_ws.canGoOutside();

            // 【v4.37修复】区分"纯户外任务"和"跨场景到室内任务"
            // 根因：D2 -55°C时，P1任务层禁止所有跨场景任务（包括去工坊发电、去厨房做饭），
            // 导致全员被困在宿舍，没有人能采集资源→食物/电力耗尽→全灭
            // 修复：极寒天只禁止纯户外任务（目标在village中且不是_door），允许跨场景到室内的任务
            // 跨场景到室内只需短暂经过village（几秒钟），不会长时间暴露在户外
            // 【关键】_door目标（如workshop_door）在SCHEDULE_LOCATIONS中scene='village'（门口坐标在village中），
            // 但NPC到达门口后会自动进入室内，所以_door目标不是真正的纯户外目标！
            const _isDoorTarget = this._taskOverride.targetLocation && this._taskOverride.targetLocation.endsWith('_door');
            const _isPureOutdoor = isOutdoorTarget && !_isDoorTarget; // 真正的纯户外目标（lumber_camp、frozen_lake等）

            // 第4天禁止所有户外和跨场景任务（第4天是最终决战，不能冒险）
            // 极寒天：只禁止纯户外任务，允许_door目标（跨场景到室内）
            if (currentDay === 4 || ((_isTooCold || _cannotGoOutside) && _isPureOutdoor)) {
                if (isOutdoorTarget || isCrossScene) {
                    const reason = currentDay === 4 ? '第4天' : `极寒${_effectiveTemp}°C`;
                    // 暂停而非取消，天气好转后可恢复
                    this._pauseTaskOverride('weather_lockdown', 'priority');
                    this._logDebug('schedule', `[P1] ${reason}禁止${isOutdoorTarget ? '户外' : '跨场景'}任务(${this._taskOverride.targetLocation})，暂停任务覆盖`);
                    if (this.game && this.game.aiModeLogger) {
                        const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                        this.game.aiModeLogger.logDeduped('TASK', this.id, 'weather_block', `${this.name} [P1]${reason}禁止户外任务${this._taskOverride.targetLocation}，暂停 | ${snap}`);
                    }
                    // 继续往下执行P2
                } else {
                    // 室内任务可以执行
                    this._updateTaskOverrideNavigation(dt, game);
                    return;
                }
            } else {
                this._updateTaskOverrideNavigation(dt, game);
                return;
            }
        }

        // ========== P2: 日程默认层 ==========
        const scheduleControl = this._getScheduleControl();
        this._behaviorPriority = scheduleControl.priority;

        // 【修复】睡眠全局保护：NPC在睡觉中时跳过P2层几乎所有逻辑
        // 仅在真正致命情况（体温<33°C、健康<10）才允许P0穿透（已在上面P0层处理）
        if (this.isSleeping && this.health >= 10 && (this.bodyTemp === undefined || this.bodyTemp >= 33)) {
            return; // 睡觉中，跳过日程执行、饥饿检查、状态覆盖等所有P2逻辑
        }

        // 【饥饿系统】检查是否到达吃饭地点（每帧都检测）
        this._checkEatingArrival(dt, game);

        // 【饥饿系统】如果正在吃饭，完全跳过日程
        if (this.isEating) return;

        // 【饥饿系统】饥饿覆盖状态下，完全跳过正常日程调度
        // 【兜底】如果_hungerOverride=true但_hungerTarget为空（说明_triggerHungerBehavior被出门保护/P0保护拦截了），
        // 自动重置_hungerOverride，让饥饿系统在下一帧可以重新触发
        if (this._hungerOverride && !this._hungerTarget && !this.isEating) {
            this._hungerOverride = false;
        }
        if (this._hungerOverride && this._hungerTarget) {
            // 正在移动中 → 继续走，不干预
            if (this.isMoving || this.currentPath.length > 0) return;

            // 已到达目标场景 → _checkEatingArrival 会在上面处理
            const eatingScenes = {
                'kitchen_door': 'kitchen',
                'warehouse_door': 'warehouse',
                'dorm_a_door': 'dorm_a', 'dorm_b_door': 'dorm_b',
            };
            const targetScene = eatingScenes[this._hungerTarget.target];
            if (this.currentScene === targetScene) return; // 等待 _checkEatingArrival 处理

            // 既不在移动，也没到目标场景 → 卡住了，重新导航
            this._hungerStuckTimer = (this._hungerStuckTimer || 0) + 1;
            if (this._hungerStuckTimer > 2) {
                // 卡住超过2帧，强制重新导航
                this._hungerStuckTimer = 0;
                this._navigateToScheduleTarget(this._hungerTarget.target, game);
            }
            return; // 饥饿覆盖期间完全不执行正常日程
        }

        // 统一仲裁：只要当前控制方不是日程，就由高优先级系统继续接管
        if (scheduleControl.blocksSchedule) {
            return;
        }

        // 【v4.14 核心改动】去除白天日常日程，全权交给LLM行动决策
        // P2日程只在以下时段生效：
        // 1. 睡觉时段（22:00~6:00）：NPC必须回宿舍睡觉
        // 2. 白天时段（6:00~22:00）：不再由日程驱动，交给LLM自主决策
        const isBedtime = this._isBedtime(hour);

        // hour 已在函数开头声明
        const sched = this.scheduleTemplate;
        let targetIdx = -1;

        for (let i = 0; i < sched.length; i++) {
            const s = sched[i];
            if (s.start <= s.end) {
                if (hour >= s.start && hour < s.end) { targetIdx = i; break; }
            } else {
                // 跨午夜
                if (hour >= s.start || hour < s.end) { targetIdx = i; break; }
            }
        }

        // 判断当前日程是否为睡觉日程
        const currentEntry = targetIdx >= 0 ? sched[targetIdx] : null;
        const isSleepSchedule = currentEntry && (
            (currentEntry.target && currentEntry.target.includes('_bed_')) ||
            (currentEntry.desc && (currentEntry.desc.includes('睡觉') || currentEntry.desc.includes('休息睡觉')))
        );

        // 【v4.14】白天非睡觉日程 → 跳过P2日程导航，交给LLM自主决策
        if (!isSleepSchedule && !isBedtime) {
            // 更新日程索引（用于LLM prompt中的参考信息），但不导航
            if (targetIdx !== this.currentScheduleIdx) {
                this.currentScheduleIdx = targetIdx;
            }
            // 白天不执行日程导航，直接返回
            return;
        }

        // 【天气影响】如果正在下雨，NPC在户外（village场景），且当前日程原本是户外目标，
        // 强制触发重新导航到室内（即使日程没有切换）
        // 【统一仲裁】日程是否允许改写目标，统一由 scheduleControl 决定
        if (targetIdx >= 0 && game.isRaining() && this.currentScene === 'village' && this.scheduleReached && scheduleControl.canRetargetFromSchedule) {
            const rawTarget = sched[targetIdx].target;
            if (NPC.OUTDOOR_TARGETS.has(rawTarget)) {
                // 原始目标是户外，但下雨了，需要重新导航到室内替代目标
                const adjusted = this._getAdjustedEntry(sched[targetIdx], game);
                this.stateDesc = adjusted.desc;
                this.scheduleReached = false;
                this._navigateToScheduleTarget(adjusted.target, game);
            }
        }

        if (targetIdx !== this.currentScheduleIdx) {
            this.currentScheduleIdx = targetIdx;
            // 【关键修复】高优先级控制期间，日程切换只更新索引，不覆盖状态和导航
            // 否则NPC决定去做B事，日程切换会覆盖stateDesc并重置scheduleReached，
            // 导致NPC走一半转头去执行旧日程
            if (!scheduleControl.canRetargetFromSchedule) {
                // 高优先级控制中，仅记录日程变化，不干预当前行为
                this._logDebug('schedule', `日程切换到#${targetIdx}但当前由${scheduleControl.owner}接管(${scheduleControl.reason})，不干预`);
            } else if (this._chatWalkTarget) {
                // 【修复】社交走路中，仅记录日程变化，不干预（防止日程打断走向聊天目标的路径）
                this._logDebug('schedule', `日程切换到#${targetIdx}但正在走向聊天目标，不干预`);
            } else if (this.isSleeping) {
                // 【修复】NPC正在睡觉时日程切换：判断新日程是否也是睡觉日程
                // 如果是（如22-24点切换到0-6点），只更新索引不打断睡眠
                const newSched = targetIdx >= 0 ? sched[targetIdx] : null;
                const isNewSchedSleep = newSched && (
                    (newSched.action === 'STAY' && newSched.target && newSched.target.includes('_bed_')) ||
                    (newSched.action === 'STAY' && newSched.desc && newSched.desc.includes('休息') && newSched.desc.includes('睡觉'))
                );
                if (isNewSchedSleep) {
                    // 新日程也是睡觉日程，平滑延续睡眠，不重置scheduleReached
                    this.scheduleReached = true; // 标记已到达（NPC已在床上）
                    this.stateDesc = newSched.desc;
                    this._logDebug('schedule', `日程切换到#${targetIdx}:${newSched.desc} 睡眠中平滑过渡，不重新导航`);
                } else {
                    // 新日程不是睡觉日程（如6点以后的起床日程），正常处理
                    this.scheduleReached = false;
                    this._enterWalkTarget = null;
                if (targetIdx >= 0) {
                    const rawS = sched[targetIdx];
                    const s = this._getAdjustedEntry(rawS, game);
                    this.stateDesc = s.desc;
                    this._logDebug('schedule', `日程切换→#${targetIdx}:${s.desc} 目标:${s.target} (睡眠将由_updateSleepState结束)`);
                    }
                }
            } else {
                this.scheduleReached = false;
                this._enterWalkTarget = null; // 清空旧的室内走路目标
                if (targetIdx >= 0) {
                    const rawS = sched[targetIdx];
                    const s = this._getAdjustedEntry(rawS, game);
                    this.stateDesc = s.desc;
                    // 【修复】CHATTING、饥饿覆盖状态下不触发导航
                    if (this.state !== 'CHATTING' && !this._hungerOverride) {
                        this._logDebug('schedule', `日程切换→#${targetIdx}:${s.desc} 目标:${s.target}`);
                        this._navigateToScheduleTarget(s.target, game);
                    }
                }
            }
        }

        // 【任务4】日程导航超时兜底：如果导航超过30秒仍未到达，强制传送
        // 【修复】持有行为锁/吃饭/休息缓冲/前往吃饭途中时跳过超时传送
        // 【决策优先】行动覆盖激活时，P2日程不得再执行自己的超时兜底
        if (targetIdx >= 0 && !this.scheduleReached && this._scheduleNavTarget) {
            this._scheduleNavTimer += realDt;
            // 行为锁保护：持有行为锁时重置计时器，不触发超时传送
            if (this._currentBehaviorLock) {
                this._scheduleNavTimer = 0;
            }
            // 吃饭/休息缓冲期保护
            if (this.isEating || this._restCooldownTimer > 0 || this._isBeingTreated) {
                this._scheduleNavTimer = 0;
            }
            // 前往吃饭途中且正在移动，不触发超时
            if (this._hungerOverride && this.isMoving) {
                this._scheduleNavTimer = 0;
            }
            // 高优先级控制期间，冻结P2自己的超时计时，避免日程反向接管
            if (!scheduleControl.canRecoverTimeout) {
                this._scheduleNavTimer = 0;
            }
            if (this._scheduleNavTimer > 30) {
                const rawST = sched[targetIdx];
                const sT = this._getAdjustedEntry(rawST, game);
                const locT = GST.SCHEDULE_LOCATIONS[sT.target];
                if (locT) {
                    // 【天气保护】超时传送目标为室外且天气禁止外出时，取消传送
                    const wsT = game && game.weatherSystem;
                    if (wsT && !wsT.canGoOutside() && locT.scene === 'village' && this.currentScene !== 'village') {
                        console.warn(`[NPC-${this.name}] [天气保护] 日程导航超时但目标在室外，取消传送，就地待命`);
                        this.scheduleReached = true;
                        this._scheduleNavTimer = 0;
                        this._scheduleNavTarget = null;
                        return;
                    }
                    // 【v4.42修复】不再强制传送，重新导航+触发紧急自我对话
                    console.warn(`[NPC-${this.name}] 日程导航超时30秒，重新导航到 ${sT.target}`);
                    this._navigateToScheduleTarget(sT.target, game);
                    this._scheduleNavTimer = 0;
                    // 触发紧急自我对话，让AI自己决定怎么办
                    const scheduleReason = `【导航受阻】我的日程安排是前往${sT.target}，但30秒内没能到达。我现在在${this.currentScene}，需要重新规划路线或调整计划。`;
                    this._triggerEmergencyDecision(scheduleReason, game);
                    this._logDebug('schedule', `[P2] 日程导航超时，重新导航+触发紧急决策 target=${sT.target}`);
                    return;
                }
                this._scheduleNavTimer = 0; // 目标无效，重置计时器
            }
        }

        // 如果日程未到达，且NPC没在移动中，可能需要重新导航
        // （处理多步传送的情况：酒馆→村庄后，还需从村庄→公寓）
        // 【行为锁保护】当持有resting/sleeping行为锁时，跳过P2日程导航
        const _lockType = this._getBehaviorLockType();
        if (_lockType === 'resting' || _lockType === 'sleeping' || _lockType === 'eating') {
            // 行为锁保护中，跳过P2日程导航
        } else if (this._bounceRecoveryTimer > 0) {
            // 【v5.5修复】弹弹乐恢复期内跳过P2日程导航，防止恢复期内日程系统触发跨场景导航→弹弹乐复发
        } else if (targetIdx >= 0 && !this.scheduleReached && !this.isMoving && this.currentPath.length === 0 && !this.isSleeping && this.state !== 'CHATTING' && !this._hungerOverride && scheduleControl.canRetryScheduleNavigation && !this._chatWalkTarget && !this._walkingToDoor) {
            const rawS = sched[targetIdx];
            const s = this._getAdjustedEntry(rawS, game);
            const loc = GST.SCHEDULE_LOCATIONS[s.target];
            const isDoorTarget = s.target.endsWith('_door');
            const doorToScene = {
                warehouse_door: 'warehouse', medical_door: 'medical',
                dorm_a_door: 'dorm_a', dorm_b_door: 'dorm_b',
                kitchen_door: 'kitchen', workshop_door: 'workshop',
            };

            // 【进屋保护期检查】进屋保护期内阻止跨场景导航，避免无限循环打印日志
            const isP0Nav = this._behaviorPriority === 'P0';
            if (this._indoorEntryProtection > 0 && this.currentScene !== 'village' && !isP0Nav && loc && loc.scene !== this.currentScene) {
                return; // 直接返回，不打印日志也不执行导航
            }

            // 【v4.37修复】安全检查阻止冷却期：防止日程导航型弹弹乐
            // 根因：清璇在kitchen，日程目标是medical_inside，安全检查阻止出门，
            //       但日程系统每帧重新尝试导航→被阻止→下一帧又尝试→5分钟内进出6次
            // 修复：安全检查阻止后设置30秒冷却期，冷却期内不再尝试跨场景导航
            if (this._scheduleNavBlockCooldown > 0 && loc && loc.scene !== this.currentScene && !isP0Nav) {
                return; // 冷却期内，静默跳过跨场景导航
            }

            // 【v4.5诊断】P2日程导航触发时，如果目标场景和当前场景不同，记录到日志
            if (loc && loc.scene !== this.currentScene) {
                const targetIndoorScene = isDoorTarget ? doorToScene[s.target] : null;
                if (!targetIndoorScene || this.currentScene !== targetIndoorScene) {
                    this._logDebug && this._logDebug('schedule', `[P2日程导航] 场景不匹配: 当前=${this.currentScene}, 日程目标=${s.target}(场景${loc.scene}), 将触发跨场景导航`);
                    if (this.game && this.game.aiModeLogger) {
                        const snap = GST.AIModeLogger.npcAttrSnapshot(this);
const fullMsgP2 = `${this.name} [P2日程恢复]需跨场景: 当前=${this.currentScene}→目标=${s.target} | schedIdx=${targetIdx} | ${snap}`;
                    this.game.aiModeLogger.logDoor(this.id, this.name, this.currentScene, 'out', fullMsgP2);
                    }
                }
            }

            // 【修复】如果目标是门口类（xxx_door），NPC已经进入对应室内场景
            if (isDoorTarget) {
                const insideScene = doorToScene[s.target];
                if (insideScene && this.currentScene === insideScene) {
                    // NPC已在目标室内场景中，直接标记到达，不再反复寻路
                    this.scheduleReached = true;
                    this._enterWalkTarget = null;
                    return;
                }
            }

            // 【修复】如果NPC在村庄且已站在门口附近（5格内），直接进入建筑
            if (isDoorTarget && this.currentScene === 'village' && loc) {
                const pos = this.getGridPos();
                const dist = Math.abs(pos.x - loc.x) + Math.abs(pos.y - loc.y);
                if (dist <= 5) {
                    const insideScene = doorToScene[s.target];
                    if (insideScene) {
                        this._enterIndoor(insideScene, game);
                        return;
                    }
                }
            }

            if (loc && loc.scene !== this.currentScene) {
                this._navigateToScheduleTarget(s.target, game);
            } else if (loc && loc.scene === this.currentScene) {
                // 同场景但还没到达，重新导航
                this._navigateToScheduleTarget(s.target, game);
            }
        }

        // 【安全网】如果日程标记为已到达，但目标是门口类（xxx_door）且NPC仍在村庄，说明进入建筑失败，先传送到室内门口再走进去
        // 【休息缓冲期】缓冲期内跳过安全网逻辑，避免把NPC传送出去
        // 【修复】饥饿覆盖/进屋保护期内跳过安全网，避免NPC刚走出门就被传送回去
        // 【统一仲裁】高优先级控制期间，P2日程安全网不得强行进门
        if (this.scheduleReached && targetIdx >= 0 && !this.isSleeping && this.state !== 'CHATTING' && !this.isRestingCooldown
            && !this._currentBehaviorLock && !this.isEating && !this._isBeingTreated
            && !this._hungerOverride && !this._resourceGatherOverride && scheduleControl.canUseDoorSafetyNet && this._indoorEntryProtection <= 0
            && !(this._bounceRecoveryTimer > 0)) {
            const curTarget = this._getAdjustedEntry(sched[targetIdx], game).target;
            if (curTarget.endsWith('_door') && this.currentScene === 'village') {
                const safetyDoorToScene = {
                    warehouse_door: 'warehouse', medical_door: 'medical',
                    dorm_a_door: 'dorm_a', dorm_b_door: 'dorm_b',
                    kitchen_door: 'kitchen', workshop_door: 'workshop',
                };
                const targetScene = safetyDoorToScene[curTarget];
                if (targetScene) {
                    // 【v4.5诊断】安全网触发进门
                    console.warn(`[安全网进门] ${this.name} 日程目标=${curTarget}但仍在village，安全网触发进入${targetScene}`);
                    if (this.game && this.game.aiModeLogger) {
                        const snap = GST.AIModeLogger.npcAttrSnapshot(this);
const fullMsgSafe = `${this.name} [安全网]进门→${targetScene} | 日程目标=${curTarget} | scheduleReached=${this.scheduleReached} | ${snap}`;
                    this.game.aiModeLogger.logDoor(this.id, this.name, targetScene, 'in', fullMsgSafe);
                    }
                    this._enterIndoor(targetScene, game);
                }
            }
        }

        // 已到达目的地后，动态感知环境并调整状态描述
        // 【修复】CHATTING 状态下不触发环境感知，避免把正在聊天的NPC传送走
        // 【位置偏移修正】scheduleReached=true但NPC远离目标时，重新导航
        // 【休息缓冲期】缓冲期内跳过位置偏移修正，避免把NPC导航出去
        // 【统一仲裁】高优先级控制期间，P2日程不得做偏移修正
        if (this.scheduleReached && targetIdx >= 0 && !this.isSleeping && this.state !== 'CHATTING' && !this.isMoving && this.currentPath.length === 0 && !this.isRestingCooldown
            && !this._currentBehaviorLock && !this.isEating && !this._isBeingTreated
            && !this._hungerOverride && !this._stateOverride && scheduleControl.canCorrectArrivalOffset && !this._enterWalkTarget) {
            const rawSCheck = sched[targetIdx];
            const sCheck = this._getAdjustedEntry(rawSCheck, game);
            const locCheck = GST.SCHEDULE_LOCATIONS[sCheck.target];
            if (locCheck && locCheck.scene === this.currentScene) {
                const posCheck = this.getGridPos();
                const distCheck = Math.abs(posCheck.x - locCheck.x) + Math.abs(posCheck.y - locCheck.y);
                if (distCheck > 6) {
                    console.warn(`[NPC-${this.name}] [位置偏移修正] scheduleReached=true但距目标${sCheck.target}距离=${distCheck}格(>6)，重新导航`);
                    if (game && game.addEvent) {
                        game.addEvent(GST.t('schedule.off_course', { name: this.name, target: sCheck.target, dist: distCheck }));
                    }
                    this.scheduleReached = false;
                    this._navigateToScheduleTarget(sCheck.target, game);
                    return;
                }
            }
        }
        if (this.scheduleReached && targetIdx >= 0 && !this.isSleeping && this.state !== 'CHATTING' && scheduleControl.canRunPostArrivalBehavior) {
            this._postArrivalAwareness(game, this._getAdjustedEntry(sched[targetIdx], game));

            // 店主无客外出招揽机制：当在自己店里且连续无客超过30分钟，出门招揽
            if (this.workplaceName === this.currentScene && this.shopAloneMinutes > 30) {
                const hour = game.getHour();
                // 只在正常营业时间触发（不在睡觉时间）
                if (hour >= 7 && hour <= 20 && !this.isMoving && this.currentPath.length === 0) {
                    this.shopAloneMinutes = 0; // 重置计时
                    this.stateDesc = '店里太冷清了，出门转转招揽客人';
                    this.expression = GST.t('npc_schedule.shop_lonely');
                    this.expressionTimer = 6;
                    this.mood = GST.t('mood.bored');
                    if (game.addEvent) {
                        game.addEvent(GST.t('schedule.solicit_business', { name: this.name }));
                    }
                    // 离开店铺去广场/街上
                    this._leaveAndWander(game);
                    this.scheduleReached = false;
                    return;
                }
            }
        }
    }
    // [已拆分到 npc-sleep.js / npc-task-override.js] _getBedLocation
    /**
     * 强制结束当前聊天状态
     * 用于urgent任务打断CHATTING状态
     */;

    proto.getSceneLabel = function() {
        // 优先使用 i18n 翻译，回退到中文硬编码
        const key = 'location.' + this.currentScene;
        const translated = GST.t(key);
        if (translated !== key) return translated;
        // 回退映射（兼容未注册的场景）
        const SCENE_LABELS = {
            village: '据点',
            warehouse: '仓库',
            medical: '医疗站',
            dorm_a: '宿舍A',
            dorm_b: '宿舍B',
            kitchen: '炊事房',
            workshop: '工坊',
        };
        return SCENE_LABELS[this.currentScene] || this.currentScene;
    }

    /**
     * 获取角色状态摘要行（位置 + 当前意图）
     * 用于头顶显示和GLM prompt
     */;

    proto.getStatusLine = function() {
        const loc = this.getSceneLabel();
        let intent = '';
        if (this.isSleeping) {
            intent = '💤 ' + GST.t('npc_state.sleeping');
        } else if (this.state === 'CHATTING') {
            intent = '💬 ' + GST.t('npc_state.chatting');
        } else if (this.isEating) {
            intent = '🍜 ' + GST.t('npc_state.eating');
        } else if (this._isBeingTreated) {
            intent = '🏥 ' + GST.t('npc_state.seeing_doctor');
        } else if (this.isInTherapy) {
            intent = '💆 ' + GST.t('npc_state.counseling');
        } else if (this._isDying) {
            intent = '⚠️ ' + GST.t('npc_state.dying');
        } else if (this.game && this.game.furnaceSystem && this.game.furnaceSystem.isBuildingSecondFurnace && this.game.furnaceSystem.buildWorkers.includes(this.id)) {
            const pct = Math.round(this.game.furnaceSystem.buildProgress * 100);
            intent = `🔨 ${GST.t('npc_state.building_furnace')}${pct}%`;
        } else if (this.isCrazy) {
            intent = '🤯 ' + GST.t('npc_state.going_crazy');
        } else if (this.isSick) {
            intent = '🤒 ' + GST.t('npc_state.sick');
        } else if (this._arbitrationPaused) {
            // 【v5.7新增】P1仲裁暂停中，显示思考状态
            intent = '🤔 ' + GST.t('npc_state.thinking');
        } else if (this.stateDesc) {
            // 【v4.40修复】检查stateDesc对应的行为效果是否与当前场景匹配
            // 根因：NPC在工坊显示"砍柴"/"探索废墟"，但这些行为需要village场景
            // 修复：场景不匹配时显示"🚶 前往XXX"而非行为本身
            let _sceneMatch = true;
            if (GST.ACTION_EFFECT_MAP && this.currentScene) {
                for (const entry of GST.ACTION_EFFECT_MAP) {
                    if (!entry.requiredScene) continue;
                    const _descMatch = entry.keywords.some(kw => this.stateDesc.includes(kw));
                    if (_descMatch && entry.requiredScene !== this.currentScene) {
                        _sceneMatch = false;
                        break;
                    }
                }
            }
            // 【v5.7新增】有决策但没在移动也没有路径 → 还在等待/思考中，显示思考状态
            const _isStandingStill = !this.isMoving && this.currentPath.length === 0 && !this.scheduleReached;
            if (_isStandingStill && !_sceneMatch) {
                // 场景不匹配且原地不动 → 显示思考状态而非"前往"
                intent = '🤔 ' + GST.t('npc_state.thinking_short');
            } else if (!_sceneMatch) {
                // 场景不匹配但在移动中，显示"前往"状态
                // 【v5.9】统一走i18n翻译
                const descTranslated = GST.i18n.translateStateDesc(this.stateDesc);
                if (this.stateDesc.includes('前往') || descTranslated.includes('Heading')) {
                    intent = `🚶 ${descTranslated}`;
                } else {
                    intent = `🚶 ${GST.t('state_desc.heading_to', { target: descTranslated })}`;
                }
            } else {
                // 【v5.9】在显示层翻译stateDesc
                intent = GST.i18n.translateStateDesc(this.stateDesc);
            }
        }
        // 截断过长的描述（英文需要更多空间）
        const maxLen = GST.i18n && GST.i18n.isEn() ? 24 : 16;
        if (intent.length > maxLen) intent = intent.substring(0, maxLen - 1) + '…';

        return `📍${loc}${intent ? ' · ' + intent : ''}`;
    }

    // ---- 下雨避雨 ----;

})();
