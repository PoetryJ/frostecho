/**
 * 福音镇 - NPC 决策冲突解决器 (DecisionConflictResolver)
 * 
 * 【v5.4重写】多P1同时触发时，暂停NPC行为，调用LLM动态仲裁
 * 
 * 核心设计：
 *   多个P1系统（state/hunger/task/action）保持同级，不硬编码优先级。
 *   当检测到2个或以上P1同时激活时：
 *     1. 暂停NPC行为（冻结移动，设置"仲裁中"状态）
 *     2. 收集所有竞争P1的上下文信息
 *     3. 调用LLM，让AI根据当前情境决定哪个P1优先
 *     4. 执行LLM选出的P1，清除其他P1覆盖
 *     5. 如果LLM调用失败，使用规则兜底（生存 > 生理 > 任务 > 个人）
 * 
 * 挂载到 GST.DecisionConflictResolver
 */
(function() {
    'use strict';
    const GST = window.GST || (window.GST = {});

    // ============ P1系统枚举 ============
    const P1_SYSTEMS = {
        STATE:   'state',    // 状态覆盖（exhausted/sick/mental）
        HUNGER:  'hunger',   // 饥饿驱动
        TASK:    'task',     // 议会任务/任务系统
        ACTION:  'action',   // LLM自主决策
    };

    // ============ 仲裁结果 ============
    const ARBITRATION_RESULT = {
        PENDING:  'pending',   // 正在等待LLM仲裁
        RESOLVED: 'resolved',  // 已解决
        FALLBACK: 'fallback',  // LLM失败，使用规则兜底
    };

    class DecisionConflictResolver {
        constructor(game) {
            this.game = game;
            this.enabled = true;

            // 每个NPC的仲裁状态
            // { npcId: { isPaused, activeP1s, winner, llmPending, pauseStartTime, ... } }
            this._npcArbitrationState = {};

            // LLM调用节流
            this._llmCooldowns = {};     // { npcId: gameTimeOfLastCall }
            this._llmCooldownDuration = 120; // 游戏2分钟内不重复调用LLM仲裁

            // 检测间隔
            this._checkInterval = 3;     // 每3秒游戏时间检测一次
            this._checkTimer = 0;

            // 仲裁超时
            this._arbitrationTimeout = 8; // LLM仲裁最多等8真实秒

            // 统计
            this._stats = {
                totalConflicts: 0,
                llmResolved: 0,
                fallbackResolved: 0,
                singleP1: 0,  // 只有1个P1，无需仲裁
            };

            // 冲突历史
            this._conflictHistory = [];

            console.log('[DecisionConflictResolver] ✅ P1冲突LLM仲裁器已初始化（v5.4）');
        }

        // ============ 每帧更新 ============
        update(gameDt) {
            if (!this.enabled) return;

            this._checkTimer += gameDt;
            if (this._checkTimer < this._checkInterval) return;
            this._checkTimer = 0;

            const npcs = this.game.npcs;
            if (!npcs) return;

            for (const npc of npcs) {
                if (npc.isDead) continue;
                // 如果NPC正在被仲裁中，检查超时
                const arbState = this._npcArbitrationState[npc.id];
                if (arbState && arbState.isPaused) {
                    this._checkArbitrationTimeout(npc, arbState);
                    continue; // 仲裁中不重复检测
                }
                // 检测P1冲突
                this._detectP1Conflict(npc);
            }
        }

        // ============ 检测P1冲突 ============
        _detectP1Conflict(npc) {
            // 收集当前所有激活的P1系统
            const activeP1s = this._collectActiveP1s(npc);

            if (activeP1s.length <= 1) {
                // 0或1个P1，无冲突
                if (activeP1s.length === 1) this._stats.singleP1++;
                // 清除之前的仲裁状态
                if (this._npcArbitrationState[npc.id]) {
                    delete this._npcArbitrationState[npc.id];
                }
                return;
            }

            // 多个P1同时激活！需要仲裁
            this._stats.totalConflicts++;

            const conflictDesc = activeP1s.map(p => `${p.system}(${p.reason})`).join(' vs ');
            console.warn(`[P1冲突] ${npc.name}: ${conflictDesc}`);

            if (this.game.structuredLogger) {
                this.game.structuredLogger.warn('P1_CONFLICT',
                    `${npc.name}: ${activeP1s.length}个P1同时激活: ${conflictDesc}`, {
                        npcId: npc.id,
                        systems: activeP1s.map(p => p.system),
                    });
            }

            // 记录冲突历史
            const historyEntry = {
                npcId: npc.id,
                npcName: npc.name,
                activeP1s: activeP1s.map(p => ({ ...p })),
                detectedAt: this._getGameTime(),
                resolved: false,
                resolution: null,
            };
            this._conflictHistory.push(historyEntry);
            if (this._conflictHistory.length > 100) {
                this._conflictHistory.splice(0, this._conflictHistory.length - 100);
            }

            // 暂停NPC行为
            this._pauseNPC(npc, activeP1s);

            // 检查LLM冷却
            const gameTime = this._getGameTime();
            const lastCall = this._llmCooldowns[npc.id] || 0;
            if (gameTime - lastCall < this._llmCooldownDuration) {
                // 冷却中，直接用规则兜底
                console.log(`[P1冲突] ${npc.name}: LLM冷却中，使用规则兜底`);
                this._fallbackResolve(npc, activeP1s, historyEntry);
                return;
            }

            // 调用LLM仲裁
            this._llmCooldowns[npc.id] = gameTime;
            this._requestLLMArbitration(npc, activeP1s, historyEntry);
        }

        // ============ 收集所有激活的P1系统 ============
        _collectActiveP1s(npc) {
            const activeP1s = [];

            // 1. 状态覆盖（exhausted/sick/mental）
            if (npc._stateOverride) {
                activeP1s.push({
                    system: P1_SYSTEMS.STATE,
                    reason: npc._stateOverride,
                    detail: this._getStateDetail(npc),
                    target: npc._stateOverrideTarget?.target || null,
                });
            }

            // 2. 饥饿驱动
            if (npc._hungerOverride) {
                activeP1s.push({
                    system: P1_SYSTEMS.HUNGER,
                    reason: `hunger=${Math.round(npc.hunger)}`,
                    detail: `饥饿值${Math.round(npc.hunger)}，${npc.isEating ? '正在吃饭' : '前往吃饭'}`,
                    target: npc._hungerTarget?.target || 'kitchen_door',
                });
            }

            // 3. 任务覆盖（议会/任务系统）
            if (npc._taskOverride && npc._taskOverride.isActive) {
                activeP1s.push({
                    system: P1_SYSTEMS.TASK,
                    reason: npc._taskOverride.taskId || 'task_override',
                    detail: npc._taskOverride.stateDesc || npc._taskOverride.displayDesc || '执行任务',
                    target: npc._taskOverride.targetLocation || null,
                });
            }

            // 4. LLM行动覆盖
            if (npc._actionOverride) {
                const actionDesc = npc._currentAction
                    ? (npc._currentAction.reason || npc._currentAction.type || 'LLM行动')
                    : 'LLM行动';
                activeP1s.push({
                    system: P1_SYSTEMS.ACTION,
                    reason: actionDesc,
                    detail: npc.stateDesc || actionDesc,
                    target: npc._actionTarget?.target || null,
                });
            }

            return activeP1s;
        }

        // ============ 暂停NPC行为 ============
        _pauseNPC(npc, activeP1s) {
            // 冻结NPC移动
            npc.currentPath = [];
            npc.isMoving = false;
            npc.state = 'IDLE'; // 【v5.7】确保动画停止播放行走帧

            // 设置仲裁状态
            this._npcArbitrationState[npc.id] = {
                isPaused: true,
                activeP1s: activeP1s,
                winner: null,
                llmPending: true,
                pauseStartTime: Date.now(),
                pauseGameTime: this._getGameTime(),
            };

            // 显示仲裁中状态
            npc._arbitrationPaused = true;
            npc.expression = GST.t('npc_decision.thinking');
            npc.expressionTimer = 10;

            // 日志
            npc._logDebug && npc._logDebug('override',
                `[P1仲裁] 暂停行为，等待LLM仲裁 (${activeP1s.length}个P1竞争)`);
        }

        // ============ 恢复NPC行为 ============
        _resumeNPC(npc, winner, activeP1s) {
            // 清除仲裁暂停状态
            npc._arbitrationPaused = false;

            // 清除所有非胜出的P1覆盖
            for (const p1 of activeP1s) {
                if (p1.system === winner.system) continue;
                this._clearP1Override(npc, p1.system);
            }

            // 确保胜出的P1覆盖仍然激活
            this._ensureP1Active(npc, winner);

            // 清除仲裁状态
            const arbState = this._npcArbitrationState[npc.id];
            if (arbState) {
                arbState.isPaused = false;
                arbState.llmPending = false;
                arbState.winner = winner;
            }

            // 日志
            const losers = activeP1s.filter(p => p.system !== winner.system).map(p => p.system).join(',');
            console.log(`[P1仲裁] ${npc.name}: 胜出=${winner.system}(${winner.reason}), 清除=${losers}`);

            if (this.game.structuredLogger) {
                this.game.structuredLogger.info('P1_RESOLVED',
                    `${npc.name}: ${winner.system}胜出, 清除${losers}`, {
                        npcId: npc.id,
                        winner: winner.system,
                        reason: winner.reason,
                        cleared: losers,
                    });
            }

            npc._logDebug && npc._logDebug('override',
                `[P1仲裁] 仲裁完成: ${winner.system}(${winner.reason})胜出, 清除${losers}`);
        }

        // ============ 清除指定P1覆盖 ============
        _clearP1Override(npc, system) {
            switch (system) {
                case P1_SYSTEMS.STATE:
                    if (typeof npc._clearStateOverride === 'function') {
                        npc._clearStateOverride();
                    } else {
                        npc._stateOverride = null;
                        npc._stateOverrideTarget = null;
                    }
                    break;

                case P1_SYSTEMS.HUNGER:
                    npc._hungerOverride = false;
                    npc._hungerTarget = null;
                    npc._hungerStuckTimer = 0;
                    npc._hungerTravelTimer = 0;
                    // 不清除isEating，如果正在吃就让它吃完
                    if (!npc.isEating) {
                        npc._releaseBehaviorLock && npc._releaseBehaviorLock('eating');
                    }
                    break;

                case P1_SYSTEMS.TASK:
                    if (npc._taskOverride) {
                        npc._taskOverride.isActive = false;
                    }
                    break;

                case P1_SYSTEMS.ACTION:
                    if (typeof npc._clearActionOverride === 'function') {
                        npc._clearActionOverride();
                    } else {
                        npc._actionOverride = false;
                        npc._currentAction = null;
                    }
                    break;
            }

            npc._logDebug && npc._logDebug('override',
                `[P1仲裁] 清除P1覆盖: ${system}`);
        }

        // ============ 确保胜出P1仍然激活 ============
        _ensureP1Active(npc, winner) {
            switch (winner.system) {
                case P1_SYSTEMS.STATE:
                    // 状态覆盖应该仍然存在，重新导航
                    if (npc._stateOverrideTarget) {
                        npc._navigateToScheduleTarget &&
                            npc._navigateToScheduleTarget(npc._stateOverrideTarget.target, this.game);
                    }
                    break;

                case P1_SYSTEMS.HUNGER:
                    // 饥饿覆盖应该仍然存在
                    if (!npc.isEating && npc._hungerTarget) {
                        npc._navigateToScheduleTarget &&
                            npc._navigateToScheduleTarget(npc._hungerTarget.target, this.game);
                    }
                    break;

                case P1_SYSTEMS.TASK:
                    // 任务覆盖应该仍然激活
                    if (npc._taskOverride && npc._taskOverride.targetLocation) {
                        npc._taskOverride.isActive = true;
                        npc._navigateToScheduleTarget &&
                            npc._navigateToScheduleTarget(npc._taskOverride.targetLocation, this.game);
                    }
                    break;

                case P1_SYSTEMS.ACTION:
                    // LLM行动覆盖应该仍然存在
                    if (npc._actionTarget) {
                        npc._navigateToScheduleTarget &&
                            npc._navigateToScheduleTarget(npc._actionTarget.target, this.game);
                    }
                    break;
            }
        }

        // ============ LLM仲裁 ============
        async _requestLLMArbitration(npc, activeP1s, historyEntry) {
            const prompt = this._buildArbitrationPrompt(npc, activeP1s);

            try {
                if (this.game.aiService && this.game.aiService.chat) {
                    console.log(`[P1仲裁] ${npc.name}: 调用LLM仲裁 (${activeP1s.length}个P1)...`);

                    const response = await this.game.aiService.chat([
                        { role: 'system', content: prompt.system },
                        { role: 'user', content: prompt.user },
                    ], { temperature: 0.2, max_tokens: 150 });

                    const result = this._parseLLMResponse(response, activeP1s);

                    if (result) {
                        // LLM仲裁成功
                        historyEntry.resolved = true;
                        historyEntry.resolution = `llm:${result.system}`;
                        historyEntry.reasoning = result.reasoning;
                        this._stats.llmResolved++;

                        this._resumeNPC(npc, result, activeP1s);

                        if (this.game.aiModeLogger) {
                            this.game.aiModeLogger.log('P1_ARBITRATION',
                                `${npc.name}: LLM仲裁→${result.system}(${result.reasoning})`);
                        }
                        return;
                    }
                }
            } catch (e) {
                console.warn(`[P1仲裁] ${npc.name}: LLM调用失败: ${e.message}`);
            }

            // LLM失败，使用规则兜底
            this._fallbackResolve(npc, activeP1s, historyEntry);
        }

        // ============ 构建LLM仲裁Prompt ============
        _buildArbitrationPrompt(npc, activeP1s) {
            const system = `你是NPC行为优先级仲裁AI。当NPC同时面临多个同等优先级的行为需求时，你需要根据当前情境决定哪个最紧急。

决策原则：
1. 生命安全第一：如果不立即行动会导致死亡（如体温过低、健康极低），优先保命
2. 不可逆伤害优先：饥饿可以忍一忍，但体力耗尽会倒地、生病不治会恶化
3. 即将完成的行动优先：如果某个行动快完成了（如正在吃饭、快到目的地），让它完成
4. 团队利益：议会分配的任务代表集体决策，但个人生存更重要

只回复JSON：
{"winner": "state|hunger|task|action", "reasoning": "一句话原因"}`;

            const statusLines = [
                `NPC: ${npc.name}`,
                `属性: HP=${Math.round(npc.health)} STA=${Math.round(npc.stamina)} 饥饿=${Math.round(npc.hunger)} San=${Math.round(npc.sanity)} 体温=${npc.bodyTemp !== undefined ? Math.round(npc.bodyTemp * 10) / 10 : '未知'}°C`,
                `位置: ${npc.currentScene}`,
                `状态: ${npc.isSleeping ? '睡觉' : npc.isEating ? '吃饭' : npc.state || 'IDLE'}`,
                '',
                `同时触发的行为需求（${activeP1s.length}个）：`,
            ];

            for (let i = 0; i < activeP1s.length; i++) {
                const p = activeP1s[i];
                statusLines.push(`  ${i + 1}. [${p.system}] ${p.detail} (目标:${p.target || '无'})`);
            }

            statusLines.push('');
            statusLines.push('请决定哪个行为最紧急，应该优先执行。');

            return { system, user: statusLines.join('\n') };
        }

        // ============ 解析LLM响应 ============
        _parseLLMResponse(response, activeP1s) {
            if (!response) return null;
            try {
                let text = response;
                if (typeof text === 'object' && text.content) text = text.content;
                text = String(text).replace(/<think>[\s\S]*?<\/think>/g, '').replace(/```json|```/g, '').trim();
                const match = text.match(/\{[\s\S]*\}/);
                if (!match) return null;

                const parsed = JSON.parse(match[0]);
                const winnerSystem = parsed.winner;

                // 验证winner是否在activeP1s中
                const validP1 = activeP1s.find(p => p.system === winnerSystem);
                if (!validP1) {
                    console.warn(`[P1仲裁] LLM返回的winner "${winnerSystem}" 不在竞争列表中`);
                    return null;
                }

                return {
                    system: winnerSystem,
                    reason: validP1.reason,
                    detail: validP1.detail,
                    target: validP1.target,
                    reasoning: parsed.reasoning || '',
                };
            } catch (e) {
                console.warn('[P1仲裁] LLM响应解析失败:', e.message);
            }
            return null;
        }

        // ============ 规则兜底解决 ============
        _fallbackResolve(npc, activeP1s, historyEntry) {
            // 规则兜底优先级：根据NPC当前属性动态决定
            // 不是硬编码，而是根据"哪个属性最危急"来决定
            const winner = this._ruleBasedPriority(npc, activeP1s);

            historyEntry.resolved = true;
            historyEntry.resolution = `fallback:${winner.system}`;
            historyEntry.reasoning = winner.fallbackReason;
            this._stats.fallbackResolved++;

            this._resumeNPC(npc, winner, activeP1s);

            console.log(`[P1仲裁] ${npc.name}: 规则兜底→${winner.system}(${winner.fallbackReason})`);
        }

        // ============ 规则兜底：根据属性危急程度动态决定 ============
        _ruleBasedPriority(npc, activeP1s) {
            // 为每个P1计算"紧急分数"
            const scores = activeP1s.map(p1 => {
                let score = 0;
                let reason = '';

                switch (p1.system) {
                    case P1_SYSTEMS.STATE:
                        if (p1.reason === 'exhausted') {
                            // 体力越低越紧急
                            score = 100 - npc.stamina; // stamina=0 → score=100
                            reason = `体力${Math.round(npc.stamina)}`;
                        } else if (p1.reason === 'sick') {
                            score = 100 - npc.health;
                            reason = `健康${Math.round(npc.health)}`;
                        } else if (p1.reason === 'mental') {
                            score = 100 - npc.sanity;
                            reason = `理智${Math.round(npc.sanity)}`;
                        }
                        break;

                    case P1_SYSTEMS.HUNGER:
                        // 饥饿越低越紧急
                        score = 100 - npc.hunger; // hunger=0 → score=100
                        // 如果正在吃饭，额外加分（不要打断）
                        if (npc.isEating) score += 30;
                        reason = `饥饿${Math.round(npc.hunger)}${npc.isEating ? '(吃饭中)' : ''}`;
                        break;

                    case P1_SYSTEMS.TASK:
                        // 任务优先级基础分
                        score = 50;
                        if (npc._taskOverride?.priority === 'urgent') score = 75;
                        // 如果已经到达任务目标，加分
                        if (npc._taskOverrideReached) score += 20;
                        reason = `任务${npc._taskOverride?.taskId || ''}`;
                        break;

                    case P1_SYSTEMS.ACTION:
                        // LLM行动基础分较低
                        score = 40;
                        // 如果正在工作驻留，加分
                        if (npc._workResidenceActive) score += 15;
                        reason = `LLM行动`;
                        break;
                }

                return { ...p1, score, fallbackReason: reason };
            });

            // 按分数排序，取最高
            scores.sort((a, b) => b.score - a.score);
            return scores[0];
        }

        // ============ 检查仲裁超时 ============
        _checkArbitrationTimeout(npc, arbState) {
            const elapsed = (Date.now() - arbState.pauseStartTime) / 1000;
            if (elapsed > this._arbitrationTimeout) {
                console.warn(`[P1仲裁] ${npc.name}: LLM仲裁超时(${elapsed.toFixed(1)}s)，使用规则兜底`);

                // 超时，使用规则兜底
                const activeP1s = arbState.activeP1s;
                const winner = this._ruleBasedPriority(npc, activeP1s);

                // 找到对应的历史记录
                const historyEntry = this._conflictHistory.find(h =>
                    h.npcId === npc.id && !h.resolved
                );
                if (historyEntry) {
                    historyEntry.resolved = true;
                    historyEntry.resolution = `timeout_fallback:${winner.system}`;
                }

                this._stats.fallbackResolved++;
                this._resumeNPC(npc, winner, activeP1s);
            }
        }

        // ============ 获取状态覆盖详情 ============
        _getStateDetail(npc) {
            switch (npc._stateOverride) {
                case 'exhausted':
                    return `体力耗尽(${Math.round(npc.stamina)})，需要回${npc.homeName || '宿舍'}休息`;
                case 'sick':
                    return `生病/健康低(HP=${Math.round(npc.health)})，需要去医疗站`;
                case 'mental':
                    return `精神状态差(San=${Math.round(npc.sanity)})，需要心理咨询`;
                default:
                    return `状态覆盖:${npc._stateOverride}`;
            }
        }

        // ============ 工具方法 ============
        _getGameTime() {
            if (this.game) {
                return (this.game.dayCount - 1) * 86400 + (this.game.gameTimeSeconds || 0);
            }
            return Date.now() / 1000;
        }

        // ============ 查询接口 ============

        /** 获取NPC是否正在被仲裁 */
        isArbitrating(npcId) {
            const state = this._npcArbitrationState[npcId];
            return state ? state.isPaused : false;
        }

        /** 获取NPC的仲裁状态 */
        getArbitrationState(npcId) {
            return this._npcArbitrationState[npcId] || null;
        }

        /** 获取指定NPC的冲突状态（供HUD面板使用） */
        getNpcConflictStatus(npcId) {
            const state = this._npcArbitrationState[npcId];
            if (!state) return null;
            if (state.isPaused) {
                return {
                    type: 'arbitrating',
                    systems: state.activeP1s.map(p => p.system),
                    detail: state.activeP1s.map(p => p.detail).join(' vs '),
                };
            }
            if (state.winner) {
                return {
                    type: 'resolved',
                    winner: state.winner.system,
                    detail: state.winner.detail,
                };
            }
            return null;
        }

        getConflicts() {
            return { ...this._npcArbitrationState };
        }

        getConflictHistory() {
            return [...this._conflictHistory];
        }

        getStats() {
            return { ...this._stats };
        }

        /** 生成冲突报告 */
        generateReport() {
            const lines = [
                '═══════════════════════════════════════',
                '  🔀 P1冲突LLM仲裁报告 (v5.4)',
                '═══════════════════════════════════════',
                `  总冲突数: ${this._stats.totalConflicts}`,
                `  LLM解决: ${this._stats.llmResolved}`,
                `  规则兜底: ${this._stats.fallbackResolved}`,
                `  无冲突(单P1): ${this._stats.singleP1}`,
                '',
            ];

            // 当前仲裁状态
            for (const [npcId, state] of Object.entries(this._npcArbitrationState)) {
                const npc = this.game.npcs?.find(n => n.id === npcId);
                const name = npc ? npc.name : npcId;
                if (state.isPaused) {
                    const systems = state.activeP1s.map(p => p.system).join(',');
                    lines.push(`  ⏸️ ${name}: 仲裁中 [${systems}]`);
                } else if (state.winner) {
                    lines.push(`  ✅ ${name}: ${state.winner.system}胜出`);
                }
            }

            // 最近5条冲突历史
            const recent = this._conflictHistory.slice(-5);
            if (recent.length > 0) {
                lines.push('');
                lines.push('  最近冲突:');
                for (const h of recent) {
                    const systems = h.activeP1s.map(p => p.system).join(',');
                    const status = h.resolved ? `✅${h.resolution}` : '❌未解决';
                    lines.push(`    ${h.npcName}: [${systems}] → ${status}`);
                }
            }

            lines.push('═══════════════════════════════════════');
            return lines.join('\n');
        }
    }

    // 导出
    DecisionConflictResolver.P1_SYSTEMS = P1_SYSTEMS;
    DecisionConflictResolver.ARBITRATION_RESULT = ARBITRATION_RESULT;
    GST.DecisionConflictResolver = DecisionConflictResolver;
})();
