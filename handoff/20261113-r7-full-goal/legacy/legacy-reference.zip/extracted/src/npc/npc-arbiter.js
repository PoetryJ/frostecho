/**
 * 🎯 NPC 控制权仲裁器 (NPCArbiter)
 * 
 * 解决"多个系统争夺NPC控制权"的根本问题。
 * 所有系统通过仲裁器请求控制NPC，仲裁器根据优先级决定谁获得控制权。
 * 
 * 核心设计：
 * 1. 所有系统不再直接修改NPC的导航目标/stateDesc/场景
 * 2. 而是向仲裁器提交"控制请求"（ControlRequest）
 * 3. 仲裁器每帧评估所有请求，授权最高优先级的请求
 * 4. 被拒绝的请求会收到通知，可以做出相应调整
 * 
 * 优先级层级（从高到低）：
 * - EMERGENCY (100): 濒死、严重失温、D4锁定
 * - CRITICAL  (80):  健康危急、体力危急、发疯
 * - HIGH      (60):  P1级（state/hunger/task/action 同级，冲突时由LLM动态仲裁）
 * - NORMAL    (40):  日程导航、默认行为
 * - LOW       (20):  同伴跟随、空闲
 * - IDLE      (0):   待命
 * 
 * 挂载到 GST.NPCArbiter
 */
(function() {
    'use strict';
    const GST = window.GST || (window.GST = {});

    // ============ 优先级常量 ============
    // 【v5.4设计】P1级系统（state/hunger/task/action）保持同级
    // 当多个P1同时触发时，暂停NPC行为，调用LLM动态仲裁优先级
    const PRIORITY = {
        EMERGENCY: 100,  // P0: 濒死、严重失温、D4锁定
        CRITICAL:  80,   // P0: 健康危急、体力危急、发疯
        HIGH:      60,   // P1: state/hunger/task/action 同级
        NORMAL:    40,   // P2: 日程导航、默认行为
        LOW:       20,   // P3: 同伴跟随、空闲
        IDLE:      0,    // 待命
    };

    // ============ 控制请求 ============
    class ControlRequest {
        /**
         * @param {string} system      请求来源系统名称
         * @param {number} priority    优先级（使用PRIORITY常量）
         * @param {string} action      请求的行动类型
         * @param {object} params      行动参数
         * @param {string} reason      请求原因（用于日志）
         * @param {boolean} allowSleep 是否允许被睡眠覆盖
         */
        constructor(system, priority, action, params, reason, allowSleep = false) {
            this.system = system;
            this.priority = priority;
            this.action = action;
            this.params = params || {};
            this.reason = reason || '';
            this.allowSleep = allowSleep;
            this.timestamp = Date.now();
            this.granted = false;
            this.rejected = false;
            this.rejectReason = '';
        }
    }

    // ============ 仲裁器 ============
    class NPCArbiter {
        constructor(game) {
            this.game = game;
            this.enabled = true;

            // 每个NPC的当前控制状态
            // { npcId: { currentRequest, pendingRequests: [], history: [] } }
            this._npcStates = {};

            // 仲裁统计
            this._stats = {
                totalRequests: 0,
                granted: 0,
                rejected: 0,
                conflicts: 0,
            };

            // 冲突检测窗口
            this._conflictWindow = 5000; // 5秒内同一NPC收到3+个不同系统的请求视为冲突

            console.log('[NPCArbiter] ✅ NPC控制权仲裁器已初始化');
        }

        // ============ 提交控制请求 ============
        /**
         * 系统向仲裁器提交控制请求
         * @param {string} npcId       目标NPC ID
         * @param {string} system      请求来源系统
         * @param {number} priority    优先级
         * @param {string} action      行动类型
         * @param {object} params      行动参数
         * @param {string} reason      原因
         * @param {boolean} allowSleep 是否允许被睡眠覆盖
         * @returns {ControlRequest}   返回请求对象（可查询是否被授权）
         */
        requestControl(npcId, system, priority, action, params, reason, allowSleep) {
            const request = new ControlRequest(system, priority, action, params, reason, allowSleep);
            this._stats.totalRequests++;

            // 初始化NPC状态
            if (!this._npcStates[npcId]) {
                this._npcStates[npcId] = {
                    currentRequest: null,
                    pendingRequests: [],
                    history: [],
                };
            }

            const state = this._npcStates[npcId];

            // 立即仲裁：与当前控制请求比较
            if (!state.currentRequest || request.priority > state.currentRequest.priority) {
                // 新请求优先级更高，授权
                if (state.currentRequest) {
                    state.currentRequest.rejected = true;
                    state.currentRequest.rejectReason = `被更高优先级请求覆盖: ${system}(${priority})`;
                }
                request.granted = true;
                state.currentRequest = request;
                this._stats.granted++;

                // 记录历史
                state.history.push({
                    system, priority, action, reason,
                    time: Date.now(),
                    result: 'granted',
                });
                if (state.history.length > 20) state.history.splice(0, state.history.length - 20);

                // 日志
                if (GST.StructuredLogger && GST.StructuredLogger.instance) {
                    const npc = this._findNPC(npcId);
                    GST.StructuredLogger.instance.trace('ARBITER', 
                        `${npc ? npc.name : npcId}: 授权 ${system}(P${priority}) → ${action} (${reason})`);
                }
            } else if (request.priority === state.currentRequest.priority && request.system === state.currentRequest.system) {
                // 同系统同优先级，更新请求
                request.granted = true;
                state.currentRequest = request;
            } else {
                // 新请求优先级不够，拒绝
                request.rejected = true;
                request.rejectReason = `当前由 ${state.currentRequest.system}(${state.currentRequest.priority}) 控制`;
                this._stats.rejected++;
            }

            // 冲突检测
            this._detectConflict(npcId, state);

            return request;
        }

        // ============ 释放控制权 ============
        /**
         * 系统释放对NPC的控制权
         * @param {string} npcId   NPC ID
         * @param {string} system  释放控制的系统
         */
        releaseControl(npcId, system) {
            const state = this._npcStates[npcId];
            if (!state || !state.currentRequest) return;

            if (state.currentRequest.system === system) {
                state.currentRequest = null;

                // 日志
                if (GST.StructuredLogger && GST.StructuredLogger.instance) {
                    const npc = this._findNPC(npcId);
                    GST.StructuredLogger.instance.trace('ARBITER', 
                        `${npc ? npc.name : npcId}: ${system} 释放控制权`);
                }
            }
        }

        // ============ 查询当前控制状态 ============
        /**
         * 查询NPC当前被哪个系统控制
         * @param {string} npcId 
         * @returns {{ system, priority, action, reason } | null}
         */
        getCurrentController(npcId) {
            const state = this._npcStates[npcId];
            if (!state || !state.currentRequest) return null;
            const r = state.currentRequest;
            return {
                system: r.system,
                priority: r.priority,
                action: r.action,
                reason: r.reason,
            };
        }

        /**
         * 检查某个系统是否能获得控制权（不实际提交请求）
         * @param {string} npcId 
         * @param {number} priority 
         * @returns {boolean}
         */
        canControl(npcId, priority) {
            const state = this._npcStates[npcId];
            if (!state || !state.currentRequest) return true;
            return priority > state.currentRequest.priority;
        }

        /**
         * 获取NPC的控制权历史
         * @param {string} npcId 
         * @returns {Array}
         */
        getHistory(npcId) {
            const state = this._npcStates[npcId];
            return state ? state.history : [];
        }

        // ============ 冲突检测 ============
        _detectConflict(npcId, state) {
            const now = Date.now();
            const recentHistory = state.history.filter(h => now - h.time < this._conflictWindow);
            const uniqueSystems = new Set(recentHistory.map(h => h.system));

            if (uniqueSystems.size >= 3) {
                this._stats.conflicts++;
                const npc = this._findNPC(npcId);
                const systems = [...uniqueSystems].join(', ');

                if (GST.StructuredLogger && GST.StructuredLogger.instance) {
                    GST.StructuredLogger.instance.warn('ARBITER_CONFLICT', 
                        `${npc ? npc.name : npcId}: 5秒内 ${uniqueSystems.size} 个系统争夺控制权: ${systems}`, {
                            npcId,
                            systems: [...uniqueSystems],
                            recentHistory: recentHistory.map(h => `${h.system}(P${h.priority}):${h.action}`),
                        });
                }

                // 通知 BugDetector
                if (this.game && this.game.bugDetector) {
                    this.game.bugDetector._report({
                        type: 'ARBITER_CONFLICT',
                        severity: '🟠 严重',
                        npcId,
                        npcName: npc ? npc.name : npcId,
                        detail: `${npc ? npc.name : npcId}: 5秒内 ${uniqueSystems.size} 个系统争夺控制权`,
                        extra: { systems: [...uniqueSystems] },
                        suggestion: '检查这些系统的触发条件是否互相矛盾',
                        ref: 'guide/11-recurring-bugs.md#弹弹乐',
                    });
                }
            }
        }

        _findNPC(npcId) {
            if (!this.game || !this.game.npcs) return null;
            return this.game.npcs.find(n => n && n.id === npcId);
        }

        // ============ 每帧更新 ============
        update(realDt) {
            if (!this.enabled) return;

            // 清理过期的控制请求（超过60秒未更新的）
            const now = Date.now();
            for (const npcId in this._npcStates) {
                const state = this._npcStates[npcId];
                if (state.currentRequest && now - state.currentRequest.timestamp > 60000) {
                    // 控制请求超时，自动释放
                    if (GST.StructuredLogger && GST.StructuredLogger.instance) {
                        const npc = this._findNPC(npcId);
                        GST.StructuredLogger.instance.warn('ARBITER', 
                            `${npc ? npc.name : npcId}: ${state.currentRequest.system} 控制请求超时(60s)，自动释放`);
                    }
                    state.currentRequest = null;
                }
            }
        }

        // ============ 统计 ============
        getStats() {
            return { ...this._stats };
        }

        /** 生成仲裁报告 */
        generateReport() {
            const lines = [
                '═══════════════════════════════════════',
                '  🎯 NPC 控制权仲裁报告',
                '═══════════════════════════════════════',
                `  总请求数: ${this._stats.totalRequests}`,
                `  授权数: ${this._stats.granted}`,
                `  拒绝数: ${this._stats.rejected}`,
                `  冲突数: ${this._stats.conflicts}`,
                '',
                '  当前控制状态:',
            ];

            for (const npcId in this._npcStates) {
                const state = this._npcStates[npcId];
                const npc = this._findNPC(npcId);
                const name = npc ? npc.name : npcId;
                if (state.currentRequest) {
                    const r = state.currentRequest;
                    lines.push(`    ${name}: ${r.system}(P${r.priority}) → ${r.action} (${r.reason})`);
                } else {
                    lines.push(`    ${name}: 无控制`);
                }
            }

            lines.push('═══════════════════════════════════════');
            return lines.join('\n');
        }
    }

    // 导出优先级常量
    NPCArbiter.PRIORITY = PRIORITY;
    NPCArbiter.ControlRequest = ControlRequest;

    GST.NPCArbiter = NPCArbiter;
})();
