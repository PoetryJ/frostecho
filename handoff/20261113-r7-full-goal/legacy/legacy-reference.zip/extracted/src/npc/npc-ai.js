/**
 * 福音镇 - NPC AI 思考/决策模块
 * 通过 mixin 模式挂载到 NPC.prototype
 * 包含：行动执行、同伴系统、空闲监视、社交判断等
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;

    proto._canChatWith = function(other) {
        const now = Date.now();
        const lastChat = this.chatCooldowns[other.id] || 0;
        // 哲学家/思考型角色更积极地找人聊天，冷却时间减半
        const cooldown = (this.id === 'old_qian') ? 30000 : 60000;
        if ((now - lastChat) <= cooldown) return false;

        // 【新增】taskOverride 工作中禁止聊天（紧急/高优先级任务中不闲聊）
        if (this._taskOverride && this._taskOverride.isActive) {
            this._logDebug && this._logDebug('chat', `正在执行taskOverride任务，禁止与${other.name}聊天`);
            return false;
        }
        if (other._taskOverride && other._taskOverride.isActive) {
            this._logDebug && this._logDebug('chat', `${other.name}正在执行taskOverride任务，禁止聊天`);
            return false;
        }

        // 【新增】生产性工作中禁止聊天（检查当前日程是否命中 GST.ACTION_EFFECT_MAP 中的生产性行为）
        // 老钱的安抚/调解/鼓舞等工作属于其正当职责，豁免此限制
        const _isInProductiveWork = (npc) => {
            if (!npc._currentActionEffect) return false;
            const effect = npc._currentActionEffect;
            // 老钱的 morale_boost（安抚鼓舞）不算闲聊，但算正当工作，不限制
            if (npc.id === 'old_qian' && effect.effectType === 'morale_boost') return false;
            // 有实际产出的工作类型
            const productiveTypes = ['produce_resource', 'build_progress', 'craft_medkit', 'medical_heal', 'reduce_waste'];
            return productiveTypes.includes(effect.effectType);
        };
        if (_isInProductiveWork(this)) {
            this._logDebug && this._logDebug('chat', `正在生产性工作（${this._currentActionEffect.effectType}），禁止与${other.name}聊天`);
            return false;
        }
        if (_isInProductiveWork(other)) {
            this._logDebug && this._logDebug('chat', `${other.name}正在生产性工作，禁止聊天`);
            return false;
        }

        // 【优化v4.17】基于 getResourceTension() 控制聊天——但精神差的NPC豁免（聊天是恢复San的重要途径）
        const game = this.game || (typeof window !== 'undefined' && window.game);
        if (game && game.resourceSystem) {
            const tension = game.resourceSystem.getResourceTension();
            // 【改进】精神差(San<40)的NPC豁免聊天禁令——聊天是恢复精神的重要方式
            const needsMentalRecovery = this.sanity < 40 || (other && other.sanity < 40);
            if (needsMentalRecovery) {
                // 精神差时允许聊天恢复，不受资源紧张度限制
                return true;
            }
            if (tension >= 0.3) {
                // 中高紧张度：禁止聊天（精神好的NPC应该工作）
                // 老钱作为精神领袖的安抚行为豁免（他的"聊天"实际上是工作）
                if (this.id === 'old_qian') {
                    const desc = this.stateDesc || '';
                    if (/安抚|调解|鼓舞|安慰|心理支持|讲故事/.test(desc)) {
                        return true;
                    }
                }
                this._logDebug && this._logDebug('chat', `资源紧张度${tension.toFixed(2)}>=0.3，禁止与${other.name}聊天`);
                return false;
            }
            if (tension >= 0.1 && Math.random() > 0.3) {
                // 轻度紧张：70%概率禁止
                this._logDebug && this._logDebug('chat', `资源紧张度${tension.toFixed(2)}>=0.1，聊天概率降低，跳过与${other.name}聊天`);
                return false;
            }
        }
        return true;
    };

    proto._checkCompanionArrival = function(dt, game) {
        if (!this._companionDestination) return;

        const targetKey = this._companionDestination;
        const isDoorTarget = targetKey.endsWith('_door');
        const doorToScene = {
            warehouse_door: 'warehouse', medical_door: 'medical',
            dorm_a_door: 'dorm_a', dorm_b_door: 'dorm_b',
            kitchen_door: 'kitchen', workshop_door: 'workshop',
        };

        let arrived = false;
        if (isDoorTarget) {
            const insideScene = doorToScene[targetKey];
            if (insideScene && this.currentScene === insideScene) arrived = true;
        } else {
            const loc = GST.SCHEDULE_LOCATIONS[targetKey];
            if (loc && this.currentScene === loc.scene) {
                const pos = this.getGridPos();
                const dist = Math.abs(pos.x - loc.x) + Math.abs(pos.y - loc.y);
                if (dist <= 4) arrived = true;
            }
        }

        if (arrived) {
            const leader = game.npcs.find(n => n.id === this._companionLeader);
            if (leader) {
                this.expression = GST.t('npc_ai.arrived_together', { name: leader.displayName || leader.name });
                this.expressionTimer = 5;
                // 额外好感度奖励
                this.changeAffinity(leader.id, 2);
                leader.changeAffinity(this.id, 2);
                // 【修复】companion到达后自动和leader发起对话
                if (GST.CHAT_ENABLED && game.dialogueManager && leader.currentScene === this.currentScene
                    && leader.state !== 'CHATTING' && this.state !== 'CHATTING'
                    && this._canChatWith(leader)) {
                    const self = this;
                    setTimeout(() => {
                        if (leader.state !== 'CHATTING' && self.state !== 'CHATTING') {
                            game.dialogueManager.startNPCChat(self, leader);
                            if (game.addEvent) {
                game.addEvent(GST.t('npc_ai.arrive_chat', { name: self.displayName, other: leader.displayName }));
                            }
                        }
                    }, 1500);
                }
            }
            this._clearCompanionState();
            this._clearActionOverride();
            this.currentScheduleIdx = -1;
            this.scheduleReached = false;
        }
    }

    /** 清除行动覆盖状态 */;

    proto._clearActionOverride = function() {
        const wasActive = this._actionOverride;
        this._actionOverride = false;
        this._currentAction = null;
        this._actionTarget = null;
        this._actionStuckTimer = 0;
        this._actionTravelTimer = 0;
        // 【v4.26修复】清除工作驻留状态，防止残留标记阻断后续决策
        this._workResidenceActive = false;
        this._workResidenceTimer = 0;
        // 【覆盖快照】清除时重置_activeOverride并检查pending队列
        if (wasActive && this._activeOverride === 'action') {
            const old = this._activeOverride;
            this._activeOverride = 'none';
            this._logDebug('override', `[覆盖切换] ${old} → none（原因: 行动覆盖清除）`);
            this._executePendingBehavior();
        }
    }

    /**
     * 【v5.0新增】判断工作驻留到期后是否应该自动续期
     * 通用规则：如果NPC的当前日程目标对应的场景 === 当前场景，续期驻留
     * 根因：苏岩09:00-12:00在medical坐诊，60秒驻留到期→日程干预→导航出去→弹弹乐
     * 修复：只要日程目标仍然是当前场景，就续期驻留，让NPC安静工作
     */
    proto._shouldRenewWorkResidence = function(game) {
        // 如果没有日程或没有当前日程索引，不续期
        const sched = this.scheduleTemplate;
        if (!sched || this.currentScheduleIdx < 0 || this.currentScheduleIdx >= sched.length) {
            return false;
        }
        const currentEntry = sched[this.currentScheduleIdx];
        if (!currentEntry || !currentEntry.target) return false;

        // 门口目标到室内场景的映射
        const doorToScene = {
            warehouse_door: 'warehouse', medical_door: 'medical',
            dorm_a_door: 'dorm_a', dorm_b_door: 'dorm_b',
            kitchen_door: 'kitchen', workshop_door: 'workshop',
        };
        // _inside后缀目标到场景的映射
        const insideToScene = {
            medical_inside: 'medical', workshop_inside: 'workshop',
            kitchen_inside: 'kitchen', warehouse_inside: 'warehouse',
            dorm_a_bed_1: 'dorm_a', dorm_a_bed_2: 'dorm_a', dorm_a_bed_3: 'dorm_a', dorm_a_bed_4: 'dorm_a',
            dorm_b_bed_1: 'dorm_b', dorm_b_bed_2: 'dorm_b', dorm_b_bed_3: 'dorm_b', dorm_b_bed_4: 'dorm_b',
        };

        const target = currentEntry.target;
        let targetScene = null;

        if (doorToScene[target]) {
            targetScene = doorToScene[target];
        } else if (insideToScene[target]) {
            targetScene = insideToScene[target];
        } else if (target.endsWith('_door')) {
            // 通用门口推断
            targetScene = target.replace('_door', '');
        }

        // 如果日程目标场景 === 当前场景，续期
        if (targetScene && targetScene === this.currentScene) {
            return true;
        }

        // 如果当前行动的目标也是当前场景（如_fallbackToRoleDefaultAction设置的），续期
        if (this._currentAction && this._currentAction.target) {
            const actionTarget = this._currentAction.target;
            const actionScene = doorToScene[actionTarget] || insideToScene[actionTarget] || null;
            if (actionScene && actionScene === this.currentScene) {
                return true;
            }
        }

        return false;
    };

    /** 向右侧「决策动态」面板写入NPC决策卡片 */;
    proto._addDecisionCard = function(action, parsed, game) {
        const chatLogEl = document.getElementById('chat-log-content');
        if (!chatLogEl) return;

        const time = game.getTimeStr ? game.getTimeStr() : '';
        const day = game.dayCount || 1;

        // 角色信息
        const roleEmoji = {
            zhao_chef: '👨‍🍳', lu_chen: '💪', li_shen: '👩‍🍳', wang_teacher: '👨‍🏫',
            old_qian: '👴', su_doctor: '👨‍⚕️', ling_yue: '🍄', qing_xuan: '🌿'
        };
        const roleColors = {
            zhao_chef: '#f87171', lu_chen: '#60a5fa', li_shen: '#fb923c', wang_teacher: '#34d399',
            old_qian: '#a78bfa', su_doctor: '#38bdf8', ling_yue: '#f472b6', qing_xuan: '#a3e635'
        };
        const priorityColors = { urgent: '#ef4444', normal: '#3b82f6', low: '#6b7280' };
        const priorityLabels = { urgent: '🔥' + GST.t('decision_card.priority_urgent'), normal: GST.t('decision_card.priority_normal'), low: GST.t('decision_card.priority_low') };
        const actionLabels = {
            go_to: GST.t('decision_card.action_go_to'), rest: GST.t('decision_card.action_rest'), eat: GST.t('decision_card.action_eat'),
            work: GST.t('decision_card.action_work'), accompany: GST.t('decision_card.action_accompany'), stay: GST.t('decision_card.action_stay'), wander: GST.t('decision_card.action_wander')
        };

        const emoji = roleEmoji[this.id] || '👤';
        const nameColor = roleColors[this.id] || '#e2e8f0';
        const pColor = priorityColors[action.priority] || '#6b7280';
        const pLabel = priorityLabels[action.priority] || action.priority;
        const actionLabel = actionLabels[action.type] || action.type;
        const targetDescRaw = action.target ? (GST.NPC.ACTION_TARGETS[action.target] || action.target).split('（')[0] : '';
        // 【v5.9】翻译目标地点名称
        const targetDesc = targetDescRaw ? (GST.t('location.' + action.target) !== 'location.' + action.target ? GST.t('location.' + action.target) : targetDescRaw) : '';

        // 构建卡片HTML — 更像角色内心独白
        // 【v4.39】每个NPC只保留最新一张决策卡片，避免面板堆叠
        let cardHTML = `
            <div class="decision-card" data-npc-id="${this.id}" style="border-left-color:${nameColor};">
                <div class="dc-header">
                    <span class="dc-name" style="color:${nameColor};">${emoji} ${this.displayName}</span>
                    <span class="dc-time">D${day} ${time}</span>
                </div>`;

        // 内心独白（reasoning）— 最重要的部分，放在最前面
        if (parsed.reasoning) {
            const _reasoning = GST.i18n.translateNpcNamesInText(parsed.reasoning);
            cardHTML += `<div class="dc-reasoning">💬 "${_reasoning}"</div>`;
        }

        // 行动决定
        cardHTML += `<div class="dc-action">`;
        cardHTML += `<span class="dc-priority" style="color:${pColor};">${pLabel}</span> `;
        cardHTML += `<span class="dc-action-label">${actionLabel}</span>`;
        if (targetDesc) {
            cardHTML += ` → <span class="dc-target">${targetDesc}</span>`;
        }
        if (action.reason) {
            const _reason = GST.i18n.translateNpcNamesInText(action.reason);
            cardHTML += `<span class="dc-reason">${GST.t('npc_ai.reason_bracket', { reason: _reason })}</span>`;
        }
        cardHTML += `</div>`;

        // 担忧（threat）— 语言无关判断：排除"无实质内容"的回复
        const threat = parsed.threat_analysis || '';
        if (threat && !this._isEmptyAnalysis(threat)) {
            const _threat = GST.i18n.translateNpcNamesInText(threat);
            cardHTML += `<div class="dc-threat">😟 ${_threat}</div>`;
        }

        // 希望（opportunity）— 语言无关判断
        const oppo = parsed.opportunity_analysis || '';
        if (oppo && !this._isEmptyAnalysis(oppo)) {
            const _oppo = GST.i18n.translateNpcNamesInText(oppo);
            cardHTML += `<div class="dc-opportunity">✨ ${_oppo}</div>`;
        }

        // 同伴邀请
        if (action.companion) {
            cardHTML += `<div class="dc-companion">${GST.t('npc_ai.want_companion', { companion: GST.i18n.translateNpcNamesInText(action.companion) })}</div>`;
        }

        cardHTML += `</div>`;

        // 【v4.39】移除该NPC的旧决策卡片（每人只保留最新一张，防止堆叠）
        const oldCards = chatLogEl.querySelectorAll(`.decision-card[data-npc-id="${this.id}"]`);
        oldCards.forEach(old => old.remove());

        const card = document.createElement('div');
        card.innerHTML = cardHTML;
        chatLogEl.appendChild(card.firstElementChild);
        chatLogEl.scrollTop = chatLogEl.scrollHeight;

        // 限制面板中总元素数量（v4.39：从20降到15，配合去重逻辑更紧凑）
        while (chatLogEl.children.length > 15) {
            chatLogEl.removeChild(chatLogEl.firstChild);
        }
    }

    /**
     * 语言无关的"无实质内容"分析判断
     * 同时匹配中英文的"无威胁/无机会"表达，以及过短的回复
     */
    proto._isEmptyAnalysis = function(text) {
        if (!text || text.length <= 3) return true;
        const lower = text.toLowerCase().trim();
        // 中文无意义回复
        const zhEmpty = ['暂时还好', '无明显威胁', '先把手头的活干好', '无特别机会', '未分析', '无', '没有', '暂无', '无威胁', '无机会'];
        // 英文无意义回复
        const enEmpty = ['fine for now', 'no obvious threat', 'no threat', 'no significant threat',
            'focus on current task', 'no special opportunity', 'no opportunity', 'not analyzed',
            'none', 'n/a', 'nothing', 'no concerns', 'all good', 'no issues'];
        if (zhEmpty.includes(lower) || enEmpty.includes(lower)) return true;
        return false;
    };

    /** 清除同伴状态 */;

    proto._clearCompanionState = function() {
        this._isCompanion = false;
        this._companionLeader = null;
        this._companionDestination = null;
        this._companionTarget = null;
    }

    // ============ 行为完成统一回调 ============

    /**
     * 吃饭行为完成的统一回调
     * 按需求6.1的顺序执行清理
     */;

    proto._executeAction = function(action, game) {
        // 【关键修复】对话中不执行行动决策（但urgent可以打断）
        if (this.state === 'CHATTING') {
            if (action.priority === 'urgent') {
                this._logDebug && this._logDebug('action', `urgent行动打断CHATTING`);
                this._forceEndChat();
            } else {
                this._logDebug('action', `CHATTING中，放弃执行行动: ${action.type}`);
                return;
            }
        }

        // 【v4.29致命修复】day4_lockdown期间，阻止所有需要出门的行动
        // 防止NPC在D4被LLM决策或pendingAction驱动出门到village致死
        if (this._priorityOverride === 'day4_lockdown' && action.type === 'go_to' && action.target) {
            const targetLoc = GST.SCHEDULE_LOCATIONS && GST.SCHEDULE_LOCATIONS[action.target];
            const targetScene = targetLoc ? targetLoc.scene : null;
            // 如果目标在不同场景（需要出门），强制改为在室内休息
            if (targetScene && targetScene !== this.currentScene && this.currentScene !== 'village') {
                console.warn(`[day4拦截] ${this.name} day4_lockdown期间拦截跨场景行动: ${action.target}(scene=${targetScene}) → 改为室内休息`);
                this._logDebug('action', `[day4拦截] 拦截${action.target}→改为rest（day4_lockdown）`);
                action.type = 'rest';
                action.target = this.currentScene === this.homeName ? undefined : (this.homeName + '_door');
                action.reason = GST.i18n && GST.i18n.isEn()
                    ? `Day 4 extreme cold lockdown, cannot go outside (planned: ${action.target})`
                    : `第4天极寒锁定，不能出门（原计划去${action.target}）`;
            }
        }

        // 【v4.40核心原则修复】移除濒死状态强制拦截
        // 设计原则：系统是情报提供者，不是决策辅助者。
        // NPC的身体状态信息已通过prompt传递给LLM，LLM自主决定是否冒险。
        // 如果LLM决定体力3去户外伐木，那是AI的自主决策，系统不应拦截。
        // 真正致命的情况（体温<34+户外）由P0-2安全网处理。
        const _isCriticalState = this.stamina < 10 || this.health < 20 || (this.bodyTemp != null && this.bodyTemp < 34);
        if (_isCriticalState && action.type === 'go_to' && action.target) {
            this._logDebug('action', `[情报] 濒死状态(体力=${Math.round(this.stamina)} 健康=${Math.round(this.health)} 体温=${this.bodyTemp?.toFixed(1) || '?'}°C)执行${action.target}，尊重AI自主决策`);
        }

        // 【任务6】go_to采集区时自动转化为taskOverride（P1层）
        const gatherTargets = {
            'lumber_camp': 'woodFuel',
            'lumber_camp_door': 'woodFuel',
            'frozen_lake': 'food',
            'frozen_lake_door': 'food',
            'ore_pile': 'power',
            'ore_pile_door': 'power',
            'ruins_site': 'explore',
            'ruins_site_door': 'explore',
            'workshop_door': 'power'
        };
        if (action.type === 'go_to' && action.target && gatherTargets[action.target]) {
            const resType = gatherTargets[action.target];
            const targetLoc = action.target.replace(/_door$/, '');
            const validTarget = GST.SCHEDULE_LOCATIONS[targetLoc] ? targetLoc : action.target;
            const taskId = `action_gather_${resType}_${Date.now()}`;
            const priority = action.priority === 'urgent' ? 'urgent' : 'high';
            
            this._logDebug && this._logDebug('action', `action→taskOverride: go_to ${action.target} → taskOverride(${validTarget}, ${priority}, ${resType})`);
            this.activateTaskOverride(taskId, validTarget, priority, resType);
            return; // taskOverride会接管后续导航
        }

        // 清除之前的行动状态
        // 【休息缓冲期】新行动执行时清除缓冲期，允许urgent等新行动打断休息
        if (this._restCooldownTimer > 0) {
            this._logDebug && this._logDebug('action', `休息打断: 收到新行动 ${action.type}(${action.priority || 'normal'})`);
            this._restCooldownTimer = 0;
        }
        // 【v4.26】新行动执行时清除工作驻留状态
        this._workResidenceActive = false;
        this._workResidenceTimer = 0;
        this._clearActionOverride();

        // 【修复】清除社交走路目标（行动执行优先于社交意愿）
        if (this._chatWalkTarget) {
            this._logDebug('chat', `行动执行(${action.type})打断了走向聊天目标的路径`);
            this._chatWalkTarget = null;
        }

        this._currentAction = action;
        this._actionOverride = true;
        // 【覆盖快照】设置行动覆盖
        const oldOverrideA = this._activeOverride;
        this._activeOverride = 'action';
        if (oldOverrideA !== 'action') {
            this._logDebug('override', `[覆盖切换] ${oldOverrideA} → action（原因: ${action.type}）`);
        }
        this._actionStuckTimer = 0;
        this._actionTravelTimer = 0;
        // 【Debug日志】记录行动执行
        this._logDebug('action', `执行行动: ${action.type} → ${action.target || '无目标'} 理由:${action.reason}`);
        // 【行动日志】输出到右侧事件列表，让用户看到NPC的行动决策
        // 【v4.26防刷屏】同一行动10秒内不重复推送执行事件
        if (this.game && this.game.addEvent) {
            const actionEmoji = { go_to: '🚶', rest: '😴', eat: '🍽️', work: '⚒️', accompany: '👫', stay: '📍', wander: '🔄' };
            const emoji = actionEmoji[action.type] || '🎯';
            const execKey = `${this.id}_exec_${action.type}_${action.target || ''}`;
            const now = Date.now();
            if (!this._lastExecEventKey || this._lastExecEventKey !== execKey || now - this._lastExecEventTime > 10000) {
                this._lastExecEventKey = execKey;
                this._lastExecEventTime = now;
                this.game.addEvent(GST.t('npc_ai.action_event', { emoji, name: this.displayName, reason: action.reason || action.type }));
            }
        }

        // 【v2.1新增】决策审计日志 — 记录每次AI决策，检测决策Bug
        if (this.game && this.game.aiModeLogger && this.game.aiModeLogger.logDecision) {
            this.game.aiModeLogger.logDecision(this.id, this.name,
                {
                    action: action.type,
                    target: action.target || '',
                    reasoning: action.reason || '',
                    source: action.source || 'llm',
                    interventionType: action.interventionType || '',
                },
                { health: this.health, stamina: this.stamina, hunger: this.hunger, sanity: this.sanity, bodyTemp: this.bodyTemp, scene: this.currentScene }
            );
        }

        // 清除当前移动路径
        this.currentPath = [];
        this.isMoving = false;
        this._pendingEnterScene = null;

        // 【硬保护B6】go_to kitchen_door 且饥饿时自动转换为 eat
        if (action.type === 'go_to' && action.target === 'kitchen_door' && this.hunger < 50 && !this.isEating) {
            this._logDebug && this._logDebug('action', `go_to kitchen_door 自动转换为 eat (hunger=${Math.round(this.hunger)})`);
            this._logDebug('action', `[行动转换] go_to kitchen_door → eat (hunger=${Math.round(this.hunger)})`);
            action.type = 'eat';
        }

        switch (action.type) {
            case 'go_to': {
                this._actionTarget = { target: action.target, desc: action.reason };
                // 【v4.24】target→关键词补充：确保stateDesc一定包含ACTION_EFFECT_MAP能匹配的关键词
                // 解决LLM返回"去伐木场补充储备"等不含精确关键词的reason导致空转的问题
                const TARGET_KEYWORD_HINT = {
                    'lumber_yard': '砍柴', 'lumber_camp': '砍柴',
                    'frozen_lake': '采集食物', 'ore_pile': '采矿',
                    'ruins_site': '探索废墟', 'workshop_door': '人工发电',
                    'kitchen_door': '做饭', 'warehouse_door': '盘点物资',
                    'medical_door': '坐诊',
                };
                const hint = TARGET_KEYWORD_HINT[action.target];
                const reason = action.reason || '';
                // 只有当reason中不包含任何ACTION_EFFECT_MAP关键词时才补充
                // 通过检查hint关键词是否已在reason中来判断
                if (hint && !reason.includes(hint)) {
                    this.stateDesc = reason ? `${reason}（${hint}）` : hint;
                } else {
                    this.stateDesc = reason;
                }
                this._navigateToScheduleTarget(action.target, game);
                // 【v4.27修复】只有导航未被阻止时才设scheduleReached=false
                // 如果_navigateToScheduleTarget因stayIndoorOverrides/安全门控被阻止，
                // 它已经设了scheduleReached=true并清除了stateDesc，这里不应覆盖
                if (!this.scheduleReached) {
                    this.scheduleReached = false;
                }
                break;
            }

            case 'rest':
                this._actionTarget = { target: this.homeName + '_door', desc: GST.t('state_desc.going_dorm_rest') };
                this.stateDesc = '回宿舍休息';
                this._navigateToScheduleTarget(this.homeName + '_door', game);
                this.scheduleReached = false;
                break;

            case 'eat':
                // 复用饥饿系统
                this._actionTarget = { target: action.target || 'kitchen_door', desc: action.reason || '去吃饭' };
                this.stateDesc = action.reason || '去吃饭';
                // translateStateDesc handles '去吃饭' via _stateDescKeyMap
                this._hungerOverride = true;
                this._hungerTarget = { target: action.target || 'kitchen_door', desc: action.reason || '去吃饭' };
                this._navigateToScheduleTarget(action.target || 'kitchen_door', game);
                this.scheduleReached = false;
                break;

            case 'accompany':
                if (action.companion) {
                    this._initiateCompanion(action, game);
                } else {
                    // 没有companion，退化为go_to
                    this._actionTarget = { target: action.target, desc: action.reason };
                    this.stateDesc = action.reason;
                    this._navigateToScheduleTarget(action.target, game);
                    this.scheduleReached = false;
                }
                break;

            case 'work': {
                // 【优化】work不再空操作，优先检查任务系统，其次回退到角色默认行为
                const currentTask = game.taskSystem?.getCurrentTask?.(this.id);
                if (currentTask && currentTask.targetLocation) {
                    // 有任务系统分配的任务，激活taskOverride导航到任务目标
                    this._actionTarget = { target: currentTask.targetLocation, desc: currentTask.desc };
                    this.stateDesc = currentTask.desc;
                    this._logDebug('action', `work→任务系统: ${currentTask.desc} → ${currentTask.targetLocation}`);
                    this._navigateToScheduleTarget(currentTask.targetLocation, game);
                    this.scheduleReached = false;
                } else {
                    // 无任务分配，回退到角色默认生产行为
                    this._fallbackToRoleDefaultAction(game);
                }
                return;
            }

            case 'stay':
                // 【优化】确保stateDesc有效，使_updateActionEffect能匹配关键词效果
                this.stateDesc = action.reason || '待在原地'; // translateStateDesc handles '待在原地'
                this._logDebug('action', `stay: stateDesc="${this.stateDesc}"`);
                this._clearActionOverride();
                return;

            case 'wander': {
                // 在当前场景随机走
                this.stateDesc = action.reason || '随便走走'; // translateStateDesc handles '随便走走'
                const map = game.maps[this.currentScene];
                if (map) {
                    const pos = this.getGridPos();
                    const dx = Math.floor(Math.random() * 9) - 4;
                    const dy = Math.floor(Math.random() * 9) - 4;
                    const tx = Math.max(0, Math.min(map.cols - 1, pos.x + dx));
                    const ty = Math.max(0, Math.min(map.rows - 1, pos.y + dy));
                    if (!map.isSolid(tx * GST.TILE + GST.TILE / 2, ty * GST.TILE + GST.TILE / 2)) {
                        this.currentPath = GST.findPath(pos.x, pos.y, tx, ty, map) || [];
                        this.pathIndex = 0;
                        this.state = 'WALKING';
                    }
                }
                this._clearActionOverride();
                return;
            }
        }

        // 处理companion邀请
        if (action.companion && action.type !== 'accompany') {
            // 非accompany类型但指定了companion，也尝试邀请
            this._tryInviteCompanion(action.companion, action.target, game);
        }

        // 设置表情
        if (action.reason) {
            this.expression = action.reason;
            this.expressionTimer = 6;
        }

        this.addMemory(`[行动] ${action.reason}`);
    }

    /**
     * 发起陪伴行动 — 邀请另一个NPC一起去某地
     */;

    proto._fallbackToRoleDefaultAction = function(game) {
        // 【v5.5修复】弹弹乐恢复期内不分配默认行为（可能触发跨场景导航）
        if (this._bounceRecoveryTimer > 0) {
            this.stateDesc = '在原地休息整理';
            this.scheduleReached = true;
            return;
        }
        // 角色→默认行为映射表
        const ROLE_DEFAULT_ACTIONS = {
            'li_shen':      { target: 'kitchen_door',   desc: '去炊事房做饭',         stateDesc: '准备晚餐、分配食物',  scene: 'kitchen' },
            'zhao_chef':    { target: 'lumber_camp',    desc: '去伐木场砍柴',         stateDesc: '砍柴',               scene: 'village' },
            'wang_teacher': { target: 'workshop_door',  desc: '去工坊人工发电',       stateDesc: '人工发电',            scene: 'workshop' },
            'su_doctor':    { target: 'medical_door',   desc: '去医疗站坐诊',         stateDesc: '坐诊',               scene: 'medical' },
            'old_qian':     { target: 'dorm_a_door',    desc: '去宿舍A安抚大家',     stateDesc: '安抚',               scene: 'dorm_a' },
            'ling_yue':     { target: 'ore_pile',       desc: '去矿渣堆采矿',         stateDesc: '采矿',               scene: 'village' },
            'lu_chen':      { target: 'lumber_camp',    desc: '去伐木场搬运',         stateDesc: '搬运木柴',            scene: 'village' },
            'qing_xuan':    { target: 'medical_door',   desc: '去医疗站制作草药',     stateDesc: '制作草药',            scene: 'medical' },
        };

        const defaultAction = ROLE_DEFAULT_ACTIONS[this.id];
        if (defaultAction) {
            // 【v4.33修复】安全检查：如果默认行为需要跨场景导航，但NPC无法安全出门，
            // 则改为在当前室内场景原地休息/整理，避免卡在village空转
            // 根因：清璇在D4被day4_lockdown阻止出门，但默认行为仍然导航到medical_door，
            // 导致她卡在village显示"制作草药"但实际没有任何效果（requiredScene: 'medical'）
            const needsCrossScene = this.currentScene !== defaultAction.scene && 
                                    this.currentScene !== 'village'; // 在village时需要进入目标场景
            const isAlreadyAtTarget = this.currentScene === defaultAction.scene;
            
            if (isAlreadyAtTarget) {
                // 已在目标场景 → 直接执行默认行为（不需要导航）
                // 【v5.0修复】直接进入工作驻留状态，避免设置_actionTarget后立即触发到达检测→_onActionArrived→清除_actionTarget的无意义循环
                this._actionOverride = true;
                this._currentAction = { type: 'work', target: defaultAction.target, reason: defaultAction.desc };
                this._actionTarget = null; // 已在目标场景，不需要导航目标
                this.stateDesc = defaultAction.stateDesc;
                this.scheduleReached = true; // 已到达，标记为到达
                // 直接进入工作驻留，防止日程系统干预
                this._workResidenceActive = true;
                this._workResidenceTimer = 60;
                this._logDebug('action', `work→角色默认行为(已在目标场景): ${this.name} → ${defaultAction.desc} (${this.currentScene})，直接进入工作驻留`);
                return;
            }
            
            // 需要跨场景导航 → 检查是否能安全出门
            const canGoOut = this.canSafelyGoOutdoor ? this.canSafelyGoOutdoor(game) : true;
            // 【v4.37修复】区分"纯户外目标"和"跨场景到室内目标"
            // 根因：D2 -55°C时，默认行为（去工坊发电、去厨房做饭）被安全检查阻止，
            // 全员被困在宿舍，没有人能采集资源→全灭
            // 修复：跨场景到室内只需短暂经过village，使用更宽松的安全检查
            const _isIndoorTarget = defaultAction.target && defaultAction.target.endsWith('_door') && 
                !['frozen_lake_door', 'lumber_camp_door', 'ruins_site_door', 'ore_pile_door'].includes(defaultAction.target);
            const _canTransitOutdoor = _isIndoorTarget && this.stamina >= 25 && this.health >= 30 && 
                (this.bodyTemp === undefined || this.bodyTemp >= 35.5);
            if (!canGoOut && !_canTransitOutdoor && this.currentScene !== 'village') {
                // 在室内但无法出门 → 在当前室内场景原地休息/整理
                this._actionOverride = true;
                this._currentAction = { type: 'rest', target: this.currentScene, reason: '无法安全出门，在室内原地休息' };
                this._actionTarget = { target: this.currentScene, desc: '在室内原地休息' };
                this.stateDesc = '在室内整理物资';
                this.scheduleReached = true;
                this._logDebug('action', `work→角色默认行为被安全检查阻止: ${this.name} 无法出门(canSafelyGoOutdoor=false)，在${this.currentScene}原地休息`);
                if (game && game.aiModeLogger) {
                    game.aiModeLogger.logDeduped('INFO', this.id, 'fallback_blocked', 
                        `${this.name} 默认行为(${defaultAction.desc})被安全检查阻止，在${this.currentScene}原地休息`);
                }
                return;
            }
            
            // 【P0修复】在village且属性极低时，不应分配工作任务，应强制回室内休息
            // 根因：王策弹弹乐后卡在village，_fallbackToRoleDefaultAction反复分配"人工发电"(需workshop)，
            // 但他STA=0/HP<30根本走不到workshop，在-30°C户外暴露2小时后死亡
            // 修复：village中且属性极低 → 强制导航到最近室内（宿舍）休息
            const _isInDanger = this.stamina <= 5 || this.health < 30 || 
                (this.bodyTemp !== undefined && this.bodyTemp < 35);
            if (this.currentScene === 'village' && _isInDanger) {
                const homeDoor = (this.id === 'li_shen' || this.id === 'ling_yue' || this.id === 'qing_xuan') 
                    ? 'dorm_b_door' : 'dorm_a_door';
                this._actionOverride = true;
                this._currentAction = { type: 'rest', target: homeDoor, reason: '属性极低，紧急回室内休息' };
                this._actionTarget = { target: homeDoor, desc: '紧急回室内休息' };
                this.stateDesc = '累坏了，赶紧回家休息';
                this._logDebug('action', `work→角色默认行为被属性极低阻止: ${this.name} STA:${Math.round(this.stamina)} HP:${Math.round(this.health)} TEMP:${this.bodyTemp?.toFixed(1) || '?'}，强制回${homeDoor}休息`);
                if (game && game.aiModeLogger) {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                    game.aiModeLogger.logDeduped('INFO', this.id, 'fallback_danger_rest', 
                        `${this.name} 默认行为(${defaultAction.desc})被属性极低阻止，强制回${homeDoor}休息 | ${snap}`);
                }
                this._navigateToScheduleTarget(homeDoor, game);
                if (!this.scheduleReached) {
                    this.scheduleReached = false;
                }
                return;
            }

            // 可以安全出门或已在village → 正常导航到目标
            // 【修复】必须设置_actionOverride=true，否则日程系统会立即覆盖fallback目标
            // 导致NPC在原目标和fallback目标之间无限来回跑（歆玥废墟↔矿渣堆bug）
            this._actionOverride = true;
            this._currentAction = { type: 'go_to', target: defaultAction.target, reason: defaultAction.desc };
            this._actionTarget = { target: defaultAction.target, desc: defaultAction.desc };
            // 【v4.40修复】跨场景导航时stateDesc应显示"前往"而非目标行为
            // 根因：赵铁柱在workshop被分配stateDesc="砍柴"，头顶显示"工坊·砍柴"，
            // 但砍柴requiredScene=village，效果不执行，纯粹误导玩家
            // 修复：未到达目标场景前，stateDesc显示"前往XXX"
            const _needsTravel = this.currentScene !== defaultAction.scene;
            this.stateDesc = _needsTravel ? `前往${defaultAction.stateDesc}` : defaultAction.stateDesc;
            this._logDebug('action', `work→角色默认行为: ${this.name} → ${defaultAction.desc} (${defaultAction.target})`);
            this._navigateToScheduleTarget(defaultAction.target, game);
            // 【v4.27修复】只有导航未被阻止时才设scheduleReached=false
            if (!this.scheduleReached) {
                this.scheduleReached = false;
            }
        } else {
            // 未知角色，回退到日程系统
            this._logDebug('action', `work→未知角色${this.id}，恢复日程`);
            this._clearActionOverride();
            this.currentScheduleIdx = -1;
            this.scheduleReached = false;
        }
    }

    /**
     * 更新行动覆盖状态 — 在update循环中调用
     * 检查行动是否到达、是否卡住、是否超时
     */;

    proto._forceEndChat = function() {
        if (this.state !== 'CHATTING') return;
        this._logDebug && this._logDebug('action', `强制结束聊天状态`);
        this.state = 'IDLE';
        this.stateDesc = '准备执行任务';
        // 通知对话系统移除该NPC的排队对话
        if (this.game && this.game.dialogueSystem) {
            const ds = this.game.dialogueSystem;
            // 从聊天队列中移除包含此NPC的对话
            if (ds.npcChatQueue) {
                for (let i = ds.npcChatQueue.length - 1; i >= 0; i--) {
                    const chat = ds.npcChatQueue[i];
                    if (chat.npc1 === this || chat.npc2 === this) {
                        // 释放对方的CHATTING状态
                        const other = chat.npc1 === this ? chat.npc2 : chat.npc1;
                        if (other && other.state === 'CHATTING') {
                            other.state = 'IDLE';
                            other._logDebug('chat', `对话被伙伴 ${this.name} 的urgent任务中断`);
                        }
                        ds.npcChatQueue.splice(i, 1);
                    }
                }
            }
        }
        this._logDebug('chat', `聊天被强制中断（urgent任务）`);
    }

    /**
     * 获取任务覆盖的状态描述
     */;

    proto._getBusinessContext = function(game, nearby) {
        // 只有在工作场所（仓库/工坊/医疗站/炊事房）内才生成经营上下文
        const workplaceScenes = { 'warehouse': '仓库', 'workshop': '工坊', 'medical': '医疗站', 'kitchen': '炊事房' };
        const placeName = workplaceScenes[this.currentScene];
        if (!placeName) return '';
        
        // 检查当前NPC是否是这个场所的主人
        if (this.workplaceName !== this.currentScene) return '';

        // 统计当前场所内除自己外的人数
        const othersHere = game.npcs.filter(n => 
            n.id !== this.id && n.currentScene === this.currentScene && !n.isSleeping
        );
        const customerCount = othersHere.length;
        
        // 更新客流统计
        if (customerCount > 0) {
            this.shopVisitorCount += customerCount; // 累计（简化统计）
            this.shopLastVisitorTime = game.getTimeStr();
            this.shopAloneMinutes = 0;
        } else {
            this.shopAloneMinutes += Math.round(this.aiInterval / 60 * 10); // 每次think约增加对应分钟
        }

        let ctx = `\n【${placeName}经营状况】\n`;
        if (customerCount > 0) {
            ctx += `- 店里目前有${customerCount}位客人：${othersHere.map(n => n.name).join('、')}\n`;
        } else {
            ctx += `- 店里目前没有客人，空无一人\n`;
        }
        ctx += `- 今天累计接待约${this.shopVisitorCount}人次\n`;
        if (this.shopAloneMinutes > 20) {
            ctx += `- 已经连续约${this.shopAloneMinutes}分钟没有客人了
`;
            ctx += `- 广场和街上可能有人经过
`;        }
        if (this.shopLastVisitorTime) {
            ctx += `- 上一个客人来的时间：${this.shopLastVisitorTime}\n`;
        } else {
            ctx += `- 今天还没有客人来过\n`;
        }
        return ctx;
    };

    proto._getNearbyNPCs = function(game, radius) {
        const pos = this.getGridPos();
        const result = [];
        for (const npc of game.npcs) {
            if (npc.id === this.id) continue;
            if (npc.isDead) continue; // 【P0修复】跳过已死亡的NPC
            if (npc.currentScene !== this.currentScene) continue;
            if (npc.isSleeping) continue; // 跳过睡觉中的NPC
            const np = npc.getGridPos();
            const d = Math.abs(pos.x - np.x) + Math.abs(pos.y - np.y);
            if (d <= radius) {
                // 只提取需要的属性，避免展开整个NPC复杂对象
                result.push({
                    id: npc.id,
                    name: npc.name,
                    dist: d,
                    state: npc.state,
                    stateDesc: npc.stateDesc,
                    isCrazy: npc.isCrazy,
                    isSleeping: npc.isSleeping,
                    occupation: npc.occupation,
                    mood: npc.mood,
                    currentScene: npc.currentScene,
                    // 状态感知：让NPC能感知旁人的身心状态
                    stamina: npc.stamina,
                    health: npc.health,
                    sanity: npc.sanity,
                    isSick: npc.isSick,
                    hunger: npc.hunger,
                    isEating: npc.isEating,
                    _stateOverride: npc._stateOverride,
                    _isBeingTreated: npc._isBeingTreated,
                    // 极寒生存状态感知
                    bodyTemp: npc.bodyTemp,
                    isDead: npc.isDead,
                    isHypothermic: npc.isHypothermic,
                    isSevereHypothermic: npc.isSevereHypothermic,
                    _rescueNeeded: npc._rescueNeeded
                });
            }
        }
        return result.sort((a, b) => a.dist - b.dist);
    }

    // ---- 存档 ----;

    proto._getTaskOverrideDesc = function() {
        const override = this._taskOverride;
        if (!override.isActive) return null;
        // 统一优先级：taskOverride.stateDesc > _councilStateDesc > resourceType 映射 > 默认
        const desc = override.stateDesc || this._councilStateDesc;
        if (desc) {
            // 【v5.9】先翻译desc再使用
            const translatedDesc = GST.i18n.translateStateDesc ? GST.i18n.translateStateDesc(desc) : desc;
            return this._taskOverrideReached ? translatedDesc : GST.t('state_desc.heading_to', { target: translatedDesc });
        }
        const resourceNames = { woodFuel: GST.t('state_desc.chopping_wood'), food: GST.t('task_label.collect_food'), explore: GST.t('state_desc.exploring_ruins'), power: GST.t('state_desc.manual_power') };
        if (override.resourceType && resourceNames[override.resourceType]) {
            return this._taskOverrideReached
                ? resourceNames[override.resourceType] + '...'
                : GST.t('state_desc.heading_to', { target: resourceNames[override.resourceType] });
        }
        return this._taskOverrideReached ? GST.t('state_desc.preparing_task') + '...' : GST.t('state_desc.heading_to', { target: '...' });
    }

    /** 到达目的地后的环境感知 —— 动态更新状态描述 */;

    proto._initiateCompanion = function(action, game) {
        // 【v5.9】同时匹配中文名和英文名，防止英文模式下LLM返回英文名导致匹配失败
        const companion = game.npcs.find(n => (n.name === action.companion || n.displayName === action.companion) && n.id !== this.id);
        if (!companion) {
            // 找不到这个人，退化为独自前往
            this._actionTarget = { target: action.target, desc: action.reason };
            this.stateDesc = action.reason;
            this._navigateToScheduleTarget(action.target, game);
            this.scheduleReached = false;
            return;
        }

        // 检查companion是否可被邀请（不在聊天、不在睡觉、不在治疗中、不在发疯）
        const canInvite = !companion.isSleeping && companion.state !== 'CHATTING' 
            && !companion._isBeingTreated && !companion.isCrazy
            && !companion._isCompanion; // 不能连锁邀请

        if (!canInvite) {
            // companion不可用，独自前往
            this.expression = GST.t('npc_ai.companion_unavailable', { name: companion.displayName || companion.name });
            this.expressionTimer = 5;
            this._actionTarget = { target: action.target, desc: action.reason };
            this.stateDesc = action.reason;
            this._navigateToScheduleTarget(action.target, game);
            this.scheduleReached = false;
            return;
        }

        // 检查距离（同场景或相邻才能邀请）
        const isSameScene = companion.currentScene === this.currentScene;
        if (!isSameScene) {
            this.expression = GST.t('npc_ai.companion_not_nearby', { name: companion.displayName || companion.name });
            this.expressionTimer = 5;
            this._actionTarget = { target: action.target, desc: action.reason };
            this.stateDesc = action.reason;
            this._navigateToScheduleTarget(action.target, game);
            this.scheduleReached = false;
            return;
        }

        // 成功邀请！
        this._companionTarget = companion.id;
        this._actionTarget = { target: action.target, desc: action.reason };
        this.stateDesc = `和${companion.name}一起${action.reason}`;
this.expression = GST.t('npc_ai.invite_companion', { name: companion.displayName || companion.name, place: GST.NPC.ACTION_TARGETS[action.target] || action.target });
        this.expressionTimer = 6;

        // 给companion注入跟随任务
        companion._isCompanion = true;
        companion._companionLeader = this.id;
        companion._companionDestination = action.target;
        companion._companionStartTime = Date.now();
        companion._actionOverride = true;
        companion._currentAction = { ...action, type: 'go_to', reason: GST.t('npc_ai.companion_go_with', { name: this.displayName }) };
        companion._actionTarget = { target: action.target, desc: GST.t('npc_ai.companion_go_reason', { name: this.displayName, reason: action.reason }) };
        companion.stateDesc = GST.t('npc_ai.companion_following', { name: this.displayName });
        companion.expression = GST.t('npc_ai.companion_lets_go');
        companion.expressionTimer = 5;
        companion.currentPath = [];
        companion.isMoving = false;
        companion._pendingEnterScene = null;
        companion.scheduleReached = false;

        // 双方都导航到目标
        this._navigateToScheduleTarget(action.target, game);
        this.scheduleReached = false;
        companion._navigateToScheduleTarget(action.target, game);

        // 好感度增加
        this.changeAffinity(companion.id, 3);
        companion.changeAffinity(this.id, 3);

        // 事件日志
        if (game.addEvent) {
game.addEvent(GST.t('npc_ai.invite_companion', { name: this.displayName, companion: companion.displayName, target: GST.NPC.ACTION_TARGETS[action.target] || action.target }));
        }

        this.addMemory(GST.t('npc_ai.memory_companion_invite', { companion: companion.displayName, reason: action.reason }));
        companion.addMemory(GST.t('npc_ai.memory_companion_invited', { name: this.displayName, reason: action.reason }));
    }

    /**
     * 尝试邀请某人同行（非accompany类型时的简化版）
     */;

    proto._leaveAndWander = function(game) {
        this.scheduleReached = false;
        this._arrivalAwarenessApplied = -1;
        this._walkToDoorAndExit(game, () => {
            // 回到村庄后立刻去另一个地标
            if (this.currentScene === 'village' && !this.isSleeping && this.state !== 'CHATTING') {
                this._wanderToNearbyLandmark(game);
            }
        });
    };

    proto._onActionArrived = function(game) {
        const action = this._currentAction;
        if (!action) {
            this._clearActionOverride();
            return;
        }

        this._logDebug && this._logDebug('action', `行动到达: ${action.target} (类型: ${action.type})`);

        // 根据行动类型执行到达后逻辑
        switch (action.type) {
            case 'rest':
                // 到达宿舍 → 检查是否在睡觉时段
                if (this.currentScene === this.homeName) {
                    // 已在宿舍，检查是否到达床位
                    const bedLoc = GST.SCHEDULE_LOCATIONS[this.homeName + '_inside'];
                    if (bedLoc) {
                        const pos = this.getGridPos();
                        const dist = Math.abs(pos.x - bedLoc.x) + Math.abs(pos.y - bedLoc.y);
                        if (dist > 3) {
                            this._pathTo(bedLoc.x, bedLoc.y, game);
                            return;
                        }
                    }                    // 【修复】只在睡觉时段才真正入睡，否则只是休息恢复体力
                    const restHour = game.getHour();
                    const isNightTime = this._isBedtime(restHour);
                    if (isNightTime) {
                        this.isSleeping = true;
                        this._forcedSleep = false; // 夜间正常入睡，非强制
                        this.stateDesc = '回家睡觉了';
                        this.expression = 'Zzz...';
                        this.expressionTimer = 8;
                        // AI模式日志：行动到达后入睡
                        if (this.game && this.game.aiModeLogger) {
                            const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                            this.game.aiModeLogger.log('SLEEP_START', `${this.name} 回家睡觉 | ${snap} | ${this.currentScene || '?'}`);
                            this.game.aiModeLogger.pushNpcEvent(this.id, `😴 回家睡觉 | ${snap}`);
                        }
                    } else {
                        // 【硬保护B4】白天只是休息，体力在缓冲期内渐进恢复，不再瞬间恢复
                        // 移除了原来的 this.stamina += 15 瞬间恢复
                        this.stateDesc = '在家休息中';
                        this.expression = GST.t('npc_ai.resting_recover');
                        this.expressionTimer = 5;
                        // 【行为锁优化】白天休息改为条件驱动缓冲期：体力>=40或60秒游戏时间
                        this._restCooldownTimer = 60;
                        // 【行为锁】获取休息行为锁（优先级2=恢复行为）
                        this._acquireBehaviorLock('resting', GST.BEHAVIOR_PRIORITY.RECOVERY);
                        this._logDebug && this._logDebug('action', `白天到家休息，进入休息缓冲期`);                    }                }
                break;

            case 'eat':
                // 到达餐饮场所 → 触发吃饭（复用饥饿系统的_startEating）
                if (!this.isEating) {
                    this._startEating(game);
                }
                break;

            case 'accompany':
            case 'go_to':
                // 普通到达
                this.expression = action.reason || GST.t('npc_ai.arrived');
                this.expressionTimer = 5;
                // 【硬保护B6兜底】到达kitchen场景且饥饿时自动触发进食
                if (this.currentScene === 'kitchen' && this.hunger < 50 && !this.isEating) {
                    this._logDebug && this._logDebug('action', `go_to到达kitchen且饥饿(${Math.round(this.hunger)})，自动开始吃饭`);
                    this._logDebug('action', `[行动兜底] go_to到达kitchen，自动开始吃饭`);
                    this._startEating(game);
                    this._hungerOverride = true;
                }
                // 【修复】accompany到达后自动和companion发起对话
                if (GST.CHAT_ENABLED && action.type === 'accompany' && this._companionTarget && game.dialogueManager) {
                    const comp = game.npcs.find(n => n.id === this._companionTarget);
                    if (comp && comp.currentScene === this.currentScene 
                        && comp.state !== 'CHATTING' && this.state !== 'CHATTING'
                        && this._canChatWith(comp)) {
                        setTimeout(() => {
                            if (comp.state !== 'CHATTING' && this.state !== 'CHATTING') {
                                game.dialogueManager.startNPCChat(this, comp);
                                if (game.addEvent) {
                    game.addEvent(GST.t('npc_ai.arrive_chat_companion', { name: this.displayName, companion: comp.displayName }));
                                }
                            }
                        }, 1000);
                    }
                }
                break;
        }

        // 【v4.15 核心修复】行动到达后进入"工作驻留"状态
        // 不立刻清除行动覆盖，而是保持_actionOverride=true + 清除_actionTarget
        // 这样NPC会安静地"在原地工作"，直到下一次LLM决策给出新行动
        // 解决了"NPC到达后立刻空闲 → 兜底分配新目标 → 来回跑"的循环问题
        if (this._restCooldownTimer > 0) {
            this.scheduleReached = true;
            this._actionTarget = null;
            this._currentAction = null;
            // 【v4.26】休息缓冲期也设置驻留标记，防止LLM决策打断休息
            this._workResidenceActive = true;
            this._workResidenceTimer = 60; // 休息缓冲期驻留60秒
            this._logDebug && this._logDebug('action', `休息缓冲期中，清除行动目标但保持覆盖状态`);
        } else {
            // 进入工作驻留：保持_actionOverride=true防止兜底触发，清除_actionTarget防止到达检测循环
            this._actionTarget = null;
            this._currentAction = null;
            this.scheduleReached = true;
            this.currentScheduleIdx = -1;
            // 【v4.26核心修复】设置工作驻留标记，阻止LLM在驻留期间重复决策
            // 驻留期间NPC安静地在原地工作，驻留结束后才允许新的LLM决策
            this._workResidenceActive = true;
            this._workResidenceTimer = 60; // 驻留60秒后自动解除，允许重新评估
            // stateDesc保持不变（显示当前工作内容）
            this._logDebug('action', `[驻留] ${this.name} 到达目的地，进入工作驻留状态(60s): ${this.stateDesc}`);
        }

        // 【v4.26防刷屏】"完成行动"事件去重：同一行动10秒内不重复推送
        if (game.addEvent) {
            const arriveKey = `${this.id}_arrive_${action.target || action.type}`;
            const now = Date.now();
            if (!this._lastArriveEventTime || !this._lastArriveEventKey || this._lastArriveEventKey !== arriveKey || now - this._lastArriveEventTime > 10000) {
                this._lastArriveEventKey = arriveKey;
                this._lastArriveEventTime = now;
                // 【v5.8.17】对reason进行i18n翻译，避免英文模式下显示中文
                const reasonText = action.reason || action.type;
                const translatedReason = GST.i18n?.translateStateDesc ? GST.i18n.translateStateDesc(reasonText) : reasonText;
                game.addEvent(GST.t('npc_ai.action_complete', { name: this.displayName, reason: translatedReason }));
            }
        }
    }

    /**
     * 同伴到达检测 — 跟随者到达目的地后的处理
     */;

    proto._tryInviteCompanion = function(companionName, targetKey, game) {
        const companion = game.npcs.find(n => n.name === companionName && n.id !== this.id);
        if (!companion) return;
        if (companion.currentScene !== this.currentScene) return;
        if (companion.isSleeping || companion.state === 'CHATTING' || companion._isBeingTreated || companion.isCrazy || companion._isCompanion) return;

        // 简化版邀请：给companion设置跟随
        companion._isCompanion = true;
        companion._companionLeader = this.id;
        companion._companionDestination = targetKey;
        companion._companionStartTime = Date.now();
        companion._actionOverride = true;
        companion._actionTarget = { target: targetKey, desc: GST.t('npc_ai.companion_go_with', { name: this.displayName }) };
        companion.stateDesc = GST.t('npc_ai.companion_following', { name: this.displayName });
        companion.currentPath = [];
        companion.isMoving = false;
        companion.scheduleReached = false;
        companion._navigateToScheduleTarget(targetKey, game);

        this.changeAffinity(companion.id, 2);
        companion.changeAffinity(this.id, 2);

        if (game.addEvent) {
            game.addEvent(GST.t('npc_ai.follow_companion', { companion: companion.displayName, name: this.displayName }));
        }
    }

    /**
     * 【任务3】角色默认生产行为回退 — 当LLM返回work但无任务分配时，根据角色自动选择有意义的行为
     */;

    proto._tryProactiveChat = function(game, nearby) {
        // 【全局聊天开关】开关关闭时不主动发起聊天
        if (!GST.CHAT_ENABLED) return;
        if (this.state === 'CHATTING') return;
        if (!game.dialogueManager) return;

        // 【修复】过了就寝时间禁止主动找人聊天（每个NPC就寝时间不同）
        const hour = game.getHour();
        if (this._isBedtime(hour)) return;

        // 过滤出可以聊天的、没在睡觉或对话中的NPC
        const candidates = nearby.filter(n => {
            const npc = game.npcs.find(np => np.id === n.id);
            return npc && npc.state !== 'CHATTING' && !npc.isSleeping && this._canChatWith(npc);
        });

        if (candidates.length === 0) return;

        // 随机选一个人搭话
        const pick = candidates[Math.floor(Math.random() * candidates.length)];
        const target = game.npcs.find(np => np.id === pick.id);
        if (target) {
            game.dialogueManager.startNPCChat(this, target);
            if (game.addEvent) {
            game.addEvent(GST.t('npc_ai.initiate_chat', { name: this.displayName, target: target.displayName }));
            }
        }
    }

    /**
     * 【v4.20】触发紧急AI决策 — 将属性危急信息注入prompt，让NPC自主思考决策
     * 替代之前的强制导航逻辑（P0强制回宿舍/去医疗站等），让8个AI真正自主决策
     * @param {string} reason - 紧急原因描述
     * @param {object} game - 游戏实例
     */
    proto._triggerEmergencyDecision = function(reason, game) {
        if (this.isDead) return;
        if (this.isSleeping) return;
        if (this.state === 'CHATTING') return;
        if (this.isCrazy) return;
        if (this._isBeingTreated) return;
        // 正在吃饭不打断
        if (this.isEating) return;
        // 【v5.5修复】全局紧急决策冷却：任何原因的紧急决策触发后，所有紧急决策都进入冷却
        // 根因：体力/精神/健康是不同原因，旧的"同一原因"冷却被绕过→3个紧急决策交替刷屏→LLM调用风暴→电脑发烫
        if (this._emergencyDecisionCooldown > 0) return;
        this._lastEmergencyReason = reason;
        this._emergencyDecisionCooldown = 180; // 180秒全局冷却（真实时间），不区分原因

        // 将紧急信息注入NPC的「紧急状态提示」字段，供_actionDecision的prompt读取
        this._emergencyHint = reason;
        // 清零行动决策冷却，立即允许触发一次决策
        this._actionDecisionCooldown = 0;

        this._logDebug('action', `[紧急决策] 触发紧急AI决策: ${reason}`);

        // 【v5.5修复】AI模式日志改用logDeduped，同一NPC同一原因30游戏分钟内不重复记录
        if (this.game && this.game.aiModeLogger) {
            const snap = GST.AIModeLogger.npcAttrSnapshot(this);
            this.game.aiModeLogger.logDeduped('EMERGENCY_DECISION', this.id, 'emergency_decision',
                `${this.name} [紧急决策]${reason} | ${snap}`);
            this.game.aiModeLogger.pushNpcEvent(this.id, `🚨 [紧急决策]${reason} | ${snap}`);
        }
    }

    /** 找不到人时，随机游荡到附近另一个户外地标 */;

    proto._updateActionOverride = function(dt, game) {
        const speedMult = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
        const realDt = speedMult > 0 ? dt / speedMult : dt;

        // 冷却递减
        if (this._actionDecisionCooldown > 0) this._actionDecisionCooldown -= realDt;
        if (this._emergencyDecisionCooldown > 0) this._emergencyDecisionCooldown -= realDt;

        // 【v4.26】工作驻留计时器递减：驻留到期后自动解除，允许NPC重新评估
        // 【v5.0修复】到期后检查：如果NPC的日程目标仍然是当前场景，自动续期驻留
        // 根因：苏岩09:00-12:00在medical坐诊，60秒驻留到期→日程干预→导航出去→弹弹乐
        // 修复：只要日程目标仍然是当前场景，就续期驻留，让NPC安静工作
        if (this._workResidenceActive && this._workResidenceTimer > 0) {
            this._workResidenceTimer -= realDt;
            if (this._workResidenceTimer <= 0) {
                // 检查当前日程目标是否仍然是当前场景
                const shouldRenew = this._shouldRenewWorkResidence(game);
                if (shouldRenew) {
                    // 日程目标仍然是当前场景，自动续期驻留
                    this._workResidenceTimer = 60;
                    this._logDebug('action', `[驻留续期] ${this.name} 日程目标仍在当前场景(${this.currentScene})，续期60秒`);
                } else {
                    this._workResidenceActive = false;
                    this._workResidenceTimer = 0;
                    this._logDebug('action', `[驻留解除] ${this.name} 工作驻留到期，允许新的LLM决策`);
                }
            }
        }

        // 检查pending intent（被挂起的意图，在高优先级状态解除后重新进入统一仲裁）
        if (this._pendingIntent && !this._actionOverride && !this._stateOverride && !this._hungerOverride
            && !this._isBeingTreated && !this._priorityOverride
            && !this._currentBehaviorLock && this.state !== 'CHATTING') {
            const pendingIntent = this._pendingIntent;
            this._pendingIntent = null;
            this._pendingAction = null;
            this._submitIntent(pendingIntent, game);
        } else if (this._pendingAction && !this._actionOverride && !this._stateOverride && !this._hungerOverride && !this._isBeingTreated
            && !this._priorityOverride) {
            // 【v4.32修复】增加!this._priorityOverride检查
            // 旧路径缺少P0保护，D4 day4_lockdown期间pendingAction可能驱动NPC出门
            // 兼容旧数据：如果只有pendingAction没有pendingIntent，沿用旧路径执行
            const pa = this._pendingAction;
            this._pendingAction = null;
            this._executeAction(pa, game);
        }

        // 同伴模式到达检测 + 超时释放
        if (this._isCompanion && this._companionDestination) {
            // 【修复】companion超时释放：跟随超过120秒（约2游戏小时）未到达则自动清除，恢复自主行为
            const companionElapsed = (Date.now() - this._companionStartTime) / 1000;
            if (companionElapsed > 120) {
                console.warn(`[NPC-${this.name}] companion跟随超时(${companionElapsed.toFixed(0)}s)，自动释放`);
                if (game.addEvent) {
                    const leader = game.npcs.find(n => n.id === this._companionLeader);
                game.addEvent(GST.t('npc_ai.cant_keep_up', { name: this.displayName, leader: leader ? leader.displayName : 'companion' }));
                }
                this._clearCompanionState();
                this._clearActionOverride();
                this.currentScheduleIdx = -1;
                this.scheduleReached = false;
            } else {
                this._checkCompanionArrival(dt, game);
            }
        }

        // 行动覆盖中 → 检查到达和卡住
        // 【一致性保护】检测_actionOverride与_actionTarget状态不一致
        // 【休息缓冲期例外】缓冲期中_actionTarget已被清除但_actionOverride保持，这是正常状态
        // 【工作驻留例外】_onActionArrived后进入工作驻留，_actionTarget=null是预期行为
        if (this._actionOverride && !this._actionTarget) {
            if (this._restCooldownTimer > 0) {
                // 休息缓冲期中，_actionTarget=null是预期行为，直接return不做到达检测
                return;
            }
            if (this._workResidenceActive) {
                // 【v5.0修复】工作驻留期间，_actionOverride=true + _actionTarget=null 是正常状态
                // 这是_onActionArrived设计的"到达后安静工作"模式，不应被一致性检查清除
                // 根因：苏岩/清璇到达medical后进入工作驻留，但被一致性检查清除→兜底重新导航→弹弹乐
                return;
            }
            console.warn(`[NPC-${this.name}] [一致性修复] _actionOverride=true但_actionTarget=null，自动清除`);
            this._clearActionOverride();
            return;
        }
        if (!this._actionOverride && this._actionTarget) {
            console.warn(`[NPC-${this.name}] [一致性修复] _actionOverride=false但_actionTarget存在，清理_actionTarget`);
            this._actionTarget = null;
        }
        if (!this._actionOverride || !this._actionTarget) return;

        // 【关键修复】CHATTING状态下暂停行动覆盖的到达检测和传送，防止对话中被传送走导致隔空聊天
        if (this.state === 'CHATTING') return;

        const targetKey = this._actionTarget.target;
        const loc = GST.SCHEDULE_LOCATIONS[targetKey];
        if (!loc) {
            this._clearActionOverride();
            return;
        }

        // 检查是否到达
        const isDoorTarget = targetKey.endsWith('_door');
        const doorToScene = {
            warehouse_door: 'warehouse', medical_door: 'medical',
            dorm_a_door: 'dorm_a', dorm_b_door: 'dorm_b',
            kitchen_door: 'kitchen', workshop_door: 'workshop',
        };

        if (isDoorTarget) {
            const insideScene = doorToScene[targetKey];
            if (insideScene && this.currentScene === insideScene) {
                // NPC已在目标室内场景中，直接标记行动完成
                this._onActionArrived(game);
                return;
            }
        } else {
            // 户外目标：检查距离
            if (this.currentScene === loc.scene) {
                const pos = this.getGridPos();
                const dist = Math.abs(pos.x - loc.x) + Math.abs(pos.y - loc.y);
                if (dist <= 4) {
                    this._onActionArrived(game);
                    return;
                }
            }
        }

        // 卡住检测
        if (this.isMoving || this.currentPath.length > 0) {
            this._actionStuckTimer = 0;
            return;
        }

        this._actionStuckTimer += realDt;
        if (this._actionStuckTimer > 2) {
            this._actionStuckTimer = 0;
            this._navigateToScheduleTarget(targetKey, game);
        }

        // 【v4.42修复】超时处理（20秒真实时间）— 不再传送，改为重新导航或放弃行动
        this._actionTravelTimer += realDt;
        if (this._actionTravelTimer > 20) {
            this._actionTravelTimer = 0;
            // 先尝试重新导航一次
            if (!this._actionRetried) {
                this._actionRetried = true;
                this._navigateToScheduleTarget(targetKey, game);
                this._logDebug && this._logDebug('action', `[行动导航] 超时20秒，重新导航到 ${targetKey}`);
            } else {
                // 重试后仍超时，放弃当前行动，触发紧急自我对话让AI重新决策
                this._actionRetried = false;
                const failedAction = this._currentAction ? this._currentAction.type : '未知';
                this._clearActionOverride();
                this._actionDecisionCooldown = 0; // 立即允许新的AI决策
                const reason = `【行动受阻】我尝试前往${targetKey}执行"${failedAction}"，但两次导航都未能到达。我现在在${this.currentScene}，需要重新评估当前行动计划。`;
                this._triggerEmergencyDecision(reason, game);
                this._logDebug && this._logDebug('action', `[行动导航] 重试后仍超时，放弃行动，触发紧急决策`);
                if (game.addEvent) {
                game.addEvent(GST.t('npc_ai.reroute', { name: this.displayName }));
                }
            }
        }
    }

    /**
     * 行动到达回调 — 执行到达后的特殊逻辑
     */;

    proto._updateIdleWatchdog = function(dt, game) {
        // 检测条件：NPC处于"黑洞状态"——没有任何系统在驱动它行动
        const isIdleBlackHole = (
            this.state !== 'CHATTING' &&
            !this.isMoving &&
            this.currentPath.length === 0 &&
            !this.isSleeping &&
            !this.isEating &&
            !(this._taskOverride && this._taskOverride.isActive) &&
            !this._actionOverride &&
            !this._stateOverride &&
            !this._hungerOverride &&
            !this._walkingToDoor &&
            !this._isBeingTreated &&
            !this._yieldMove &&
            !this._chatWalkTarget &&
            !this.isCrazy
        );

        const speedMult = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
        const realDt = speedMult > 0 ? dt / speedMult : dt;

        if (isIdleBlackHole) {
            this._idleWatchdogTimer += realDt;
        } else {
            this._idleWatchdogTimer = 0;
            return;
        }

        // 连续30秒发呆且无决策冷却时，强制触发一次行动决策（防止长时间空闲）
        if (this._idleWatchdogTimer > 30 && this._idleWatchdogTimer <= 40 && this._actionDecisionCooldown > 0) {
            this._actionDecisionCooldown = 0; // 清零冷却，允许立即触发决策
            this._logDebug('schedule', `[兜底] ${this.name} 空闲超过30秒，强制触发行动决策`);
        }

        // 连续20秒发呆，触发恢复（从10秒提高到20秒，减少误触发）
        if (this._idleWatchdogTimer > 20) {
            // 输出详细状态快照
            console.warn(`[NPC-${this.name}] [兜底] 发呆超时${Math.round(this._idleWatchdogTimer)}秒，触发自动恢复`, {
                actionOverride: this._actionOverride,
                actionTarget: this._actionTarget,
                stateOverride: this._stateOverride,
                hungerOverride: this._hungerOverride,
                taskOverride: this._taskOverride ? {
                    isActive: this._taskOverride.isActive,
                    taskId: this._taskOverride.taskId,
                    targetLocation: this._taskOverride.targetLocation
                } : null,
                priorityOverride: this._priorityOverride,
                scheduleReached: this.scheduleReached,
                currentScheduleIdx: this.currentScheduleIdx,
                scene: this.currentScene,
                pos: this.getGridPos()
            });

            // 清除所有可能残留的覆盖状态（使用统一兜底方法）
            this._clearAllOverrides();

            // 如果有被暂停的任务，优先恢复任务
            if (this._taskOverride && this._taskOverride.targetLocation && this._taskOverride.taskId) {
                this._resumeTaskOverride(game, 'idle_watchdog', 'watchdog');
                this._logDebug('schedule', `[兜底] ${this.name} 恢复被暂停的任务: ${this._taskOverride.taskId}`);
            }

            // 如果没有恢复任务，执行角色默认行动（去最擅长的采集点）
            if (!this._taskOverride || !this._taskOverride.isActive) {
                this._fallbackToRoleDefaultAction(game);
            }

            // 不再在事件日志刷屏，只记录debug日志
            this._logDebug('schedule', `[兜底] ${this.name} 发呆超时${Math.round(this._idleWatchdogTimer)}秒，强制恢复`);
            this._idleWatchdogTimer = 0;

            // 累计触发计数
            this._idleWatchdogCount++;
            const now = Date.now();
            if (now - this._idleWatchdogResetTime > 120000) {
                // 超过120秒，重置计数
                this._idleWatchdogCount = 1;
                this._idleWatchdogResetTime = now;
            }

            // 同一NPC在120秒内连续触发超过5次，注入发呆情报，让AI自己决定
            // 【修复】行为锁/吃饭/睡觉/治疗/休息缓冲期内不触发
            if (this._idleWatchdogCount > 5) {
                const isProtected = this.isEating || this.isSleeping || this._isBeingTreated
                    || this._restCooldownTimer > 0 || this._currentBehaviorLock;
                if (isProtected) {
                    console.log(`[NPC-${this.name}] [兜底] 反复发呆但处于保护状态(${this._currentBehaviorLock || 'protected'})，跳过情报注入`);
                    this._idleWatchdogCount = 0;
                } else {
                    // 【v4.25】不再强制执行默认行动，而是注入情报让AI自己决定
                    // 【v4.33原则修复】措辞改为纯情报，不做决策辅助
                    console.warn(`[NPC-${this.name}] [兜底] 120秒内发呆超过5次，注入发呆情报`);
                    const idleMinutes = Math.round((this._idleWatchdogCount * 25) / 60);
                    this._emergencyHint = `你已经在${this.currentScene === 'village' ? '户外' : this.currentScene}原地站了约${idleMinutes}分钟没有任何行动。当前体力${Math.round(this.stamina)}/100，饱食度${Math.round(this.hunger)}/100，精神${Math.round(this.sanity)}/100。`;
                    // 【v4.42】标记为发呆恢复，下次决策用小模型（只是站着不动，随便给个行动就行）
                    this._idleRecovery = true;
                    this._actionDecisionCooldown = 0; // 强制触发下一次决策
                    this._idleWatchdogCount = 0;
                }
            }
        }
    }

    // ============ LLM行动决策系统 ============

    /** 可选目标位置列表（供LLM选择） — 挂载到NPC构造函数上作为静态属性 */
    GST.NPC.ACTION_TARGETS = {
        'warehouse_door':  '仓库（盘点物资→减少浪费，辅助效果，室内）',
        'medical_door':    '医疗站（治疗→恢复健康，心理疏导→恢复San值，室内）',
        'dorm_a_door':     '宿舍A（休息、睡觉）',
        'dorm_b_door':     '宿舍B（休息、睡觉）',
        'kitchen_door':    '炊事房（做饭→食物加工减少浪费，辅助效果，室内）',
        'workshop_door':   '工坊（人工发电→电力+8/h，建造/维修自动化机器，室内。自动发电机：耗柴→产电；自动伐木机：耗电→产木柴；自动捕猎机：耗电→产食物）',
        'furnace_plaza':   '暖炉广场（户外广场，安抚/集会→恢复San值，⚠️不提供室内供暖）',
        'lumber_yard':     '伐木场（砍柴→木柴+10/h，户外，需体力）',
        'lumber_camp':     '伐木营地（砍柴→木柴+10/h，户外，需体力）',
        'frozen_lake':     '冰湖（捕鱼→食物+8/h，户外，需体力）',
        'ore_pile':        '矿渣堆（采矿→电力+12/h，户外，需体力）',
        'ruins_site':      '废墟探索点（探索→随机获得物资，每天限3次，户外）',
    };

    /** 行动类型列表 */
    // 【精简行动】LLM可选的行动类型精简为3种，其余保留用于系统内部
    GST.NPC.ACTION_TYPES = ['go_to', 'rest', 'eat'];
    // 系统内部仍可使用的行动类型（拦截器改写、日程fallback等）
    GST.NPC.ALL_ACTION_TYPES = ['go_to', 'rest', 'eat', 'work', 'accompany', 'stay', 'wander'];

    /**
     * LLM行动决策 — 独立的AI调用，决定NPC下一步行动
     * 与think()是两个独立调用，信息汇总后决策
     */
    proto._actionDecision = async function(game) {
        if (this.isDead) return; // 💀 死亡NPC不做决策
        if (this._actionDecisionCooldown > 0) return;
        // 【v5.4】P1仲裁暂停期间不做新的LLM决策
        if (this._arbitrationPaused) return;
        // 【v5.5修复】弹弹乐恢复期内不做LLM决策（可能导致跨场景行动→弹弹乐复发）
        if (this._bounceRecoveryTimer > 0) return;
        if (this.state === 'CHATTING') return;
        if (this.isSleeping) return;
        if (this.isCrazy) return; // 发疯中不做决策
        if (this.isSeekingShelter) return;
        if (this._isBeingTreated) return;
        if (this.isEating) return;
        // 【v4.25】去除夜间强制跳过，让AI自己决定是否睡觉
        // 如果已有行动在执行中，跳过决策（防止新决策打断正在执行的行动，导致"走一半转头"）
        if (this._actionOverride && this._currentAction) return;
        // 【v4.26核心修复】工作驻留期间跳过LLM决策，防止"到达→决策→到达"死循环
        // NPC已到达目的地正在工作中，驻留计时器到期后自动解除，届时才允许新决策
        if (this._workResidenceActive) {
            // 紧急情报可以打破驻留（如资源紧急、属性危急等）
            if (!this._emergencyHint) {
                this._logDebug('action', `[决策跳过] 工作驻留中(剩余${Math.round(this._workResidenceTimer || 0)}s)，跳过LLM决策`);
                return;
            }
            // 有紧急情报，解除驻留，允许决策
            this._workResidenceActive = false;
            this._workResidenceTimer = 0;
            this._logDebug('action', `[驻留打破] 紧急情报打破工作驻留: ${this._emergencyHint.substring(0, 50)}`);
        }
        // 【v4.24自治化】系统生成的 taskOverride 不再阻断 LLM 决策；
        // 只有来自玩家/指挥官的明确控制才保留为有效覆盖。
        if (this._taskOverride && this._taskOverride.isActive && !this._emergencyHint) {
            const taskSource = this._taskOverride.source || 'task';
            if (taskSource === 'commander') {
                this._logDebug('action', `[决策跳过] commander taskOverride激活(${this._taskOverride.taskId})，跳过LLM行动决策`);
                return;
            }
            this._logDebug('action', `[决策继续] system taskOverride(${this._taskOverride.taskId})仅作为情报，不阻断LLM决策`);
        }
        // 【修复】正在走向聊天目标时，不做新的行动决策（防止打断社交走路）
        if (this._chatWalkTarget) return;

        // 【v4.20改造】不再因P0/状态覆盖而跳过LLM决策
        // 这些紧急状态的信息会通过_emergencyHint注入prompt，让NPC自己决定该怎么做
        // 【v4.25】去除饥饿覆盖的强制跳过，让AI自己决定是否继续吃饭
        if (this._walkingToDoor) {
            this._logDebug('action', '[决策跳过] 处于出门过程中，跳过行动决策');
            return;
        }
        if (this._currentBehaviorLock) {
            this._logDebug('action', `[决策跳过] 行为锁(${this._currentBehaviorLock.type})激活中，跳过行动决策`);
            return;
        }
        if (this._restCooldownTimer > 0) {
            this._logDebug('action', '[决策跳过] 处于休息缓冲期中，跳过行动决策');
            return;
        }

        // 【优化】动态决策间隔：危急时缩短，平时保持原间隔
        let dynamicInterval = this._actionDecisionInterval;
        const inDanger = this.stamina < 20 || this.health < 30 || this.sanity < 25 || this.hunger < 30;
        if (inDanger) {
            // 属性危险状态：10~20秒（v4.14加快响应）
            dynamicInterval = 10 + Math.random() * 10;
        } else if (game.resourceSystem && game.resourceSystem.getResourceTension() > 0.5) {
            // 资源紧张：15~30秒
            dynamicInterval = 15 + Math.random() * 15;
        }
        this._actionDecisionCooldown = dynamicInterval;

        const map = game.maps[this.currentScene];
        const pos = this.getGridPos();
        const hour = game.getHour();
        const isLateNight = this._isBedtime(hour);

        // 构建环境信息
        let envDesc = map ? map.describe(pos.x, pos.y) : this.currentScene;
        const nearby = this._getNearbyNPCs(game, 16);
        let nearbyStr = nearby.length > 0
            ? nearby.map(n => {
                const tags = [];
                if (n.isSick) tags.push('生病');
                if (n.health < 25) tags.push('健康差');
                if (n.stamina < 15) tags.push('疲惫');
                if (n.sanity < 25) tags.push('精神差');
                if (n.hunger < 20) tags.push('很饿');
                if (n.isCrazy) tags.push('发疯');
                const tagStr = tags.length > 0 ? `(${tags.join('、')})` : '';
                return `${n.name}${tagStr}`;
            }).join('、')
            : '附近没有人';

        // 当前日程信息
        const sched = this.scheduleTemplate;
        let currentScheduleDesc = '无日程';
        for (let i = 0; i < sched.length; i++) {
            const s = sched[i];
            const inRange = s.start <= s.end
                ? (hour >= s.start && hour < s.end)
                : (hour >= s.start || hour < s.end);
            if (inRange) {
                currentScheduleDesc = `${s.start}:00-${s.end}:00 ${s.desc}（目标：${s.target}）`;
                break;
            }
        }

        // 最近记忆
        let recentMemories = this.memories.slice(-5).map(m => `[${m.time}] ${m.text}`).join('\n');

        // think方法上次的思考
        let lastThought = this._lastActionThought || '暂无';

        // 可选目标列表
let targetList = Object.entries(GST.NPC.ACTION_TARGETS)
            .map(([key, desc]) => `  "${key}": ${desc}`)
            .join('\n');

        // 同场景所有NPC状态
        // 【P0修复】过滤已死亡NPC，避免LLM让存活NPC去"安抚"已死角色
        let allNPCStatus = game.npcs
            .filter(n => n.id !== this.id && !n.isDead)
            .map(n => {
                const tags = [];
                if (n.isSick) tags.push('生病');
                if (n.health < 50) tags.push(n.health < 25 ? '健康危急' : '受伤');
                if (n.stamina < 20) tags.push('疲惫');
                // 【v4.29】降低San值标记阈值：<50标记精神差，<30标记精神危急
                if (n.sanity < 50) tags.push(n.sanity < 30 ? '精神危急' : '精神不佳');
                if (n.hunger < 25) tags.push('饿');
                if (n.isCrazy) tags.push('发疯');
                if (n.isSleeping) tags.push('睡觉中');
                const tagStr = tags.length > 0 ? `[${tags.join('、')}]` : '[正常]';
                // 标注关系
                const aff = this.getAffinity(n.id);
                let relTag = '';
                if (aff >= 90) relTag = '❤️挚友';
                else if (aff >= 70) relTag = '💛好友';
                else if (aff >= 50) relTag = '友好';
                // 【v4.29】添加NPC所在场景，让LLM知道去哪里找人
                const sceneLabel = n.getSceneLabel ? n.getSceneLabel() : n.currentScene;
                return `${n.name}(${n.getStatusLine()}) ${tagStr} 在${sceneLabel} 关系:${relTag || '一般'}`;
            }).join('\n');

        // 【挚友紧急告警】检测好友/挚友中是否有人精神状态极差
        // 【P0修复】过滤已死亡NPC，防止LLM安抚死人
        const friendsInCrisis = game.npcs.filter(n => 
            n.id !== this.id && !n.isDead && !n.isSleeping && this.getAffinity(n.id) >= 70
            && (n.sanity < 25 || n.isCrazy)
        );
        let friendCrisisHint = '';
        if (friendsInCrisis.length > 0 && this.sanity >= 40) {
            friendCrisisHint = `\n\n🚨🚨 紧急情报：你的好朋友${friendsInCrisis.map(f => {
                const aff = this.getAffinity(f.id);
                const rel = aff >= 90 ? '挚友' : '好友';
                return `${f.name}（${rel}，San值:${Math.round(f.sanity)}${f.isCrazy ? '，正在发疯！' : ''}，在${f.getSceneLabel()}）`;
            }).join('、')}状态非常差！`;
        }

        // 【v5.10】英文模式：使用完整英文版 prompt，确保小模型输出英文
        const _isEnPrompt = GST.i18n && GST.i18n.isEn && GST.i18n.isEn() && GST.promptEN;
        if (_isEnPrompt) {
            console.log(`[i18n] 🌐 ${this.name} action decision: using EN prompt template`);
            // 【v5.11】将所有中文动态数据替换为英文版，避免"英文框架+中文数据"导致LLM输出中文
            const _pd = GST.promptDataEN || {};
            friendCrisisHint = _pd.buildFriendCrisisHintEN ? _pd.buildFriendCrisisHintEN(this, game) : '';
            targetList = _pd.buildTargetListEN ? _pd.buildTargetListEN(game) : targetList;
            nearbyStr = _pd.buildNearbyStrEN ? _pd.buildNearbyStrEN(nearby) : nearbyStr;
            envDesc = _pd.buildEnvDescEN ? _pd.buildEnvDescEN(this) : envDesc;
            allNPCStatus = _pd.buildAllNPCStatusEN ? _pd.buildAllNPCStatusEN(game) : allNPCStatus;
            if (_pd.translatePromptText) {
                currentScheduleDesc = _pd.translatePromptText(currentScheduleDesc);
                lastThought = _pd.translatePromptText(lastThought);
                recentMemories = _pd.translatePromptText(recentMemories);
            }
        }
        const systemPrompt = _isEnPrompt
            ? GST.promptEN.buildActionSystemPromptEN(this, game, targetList, friendCrisisHint)
            : `你是「${this.name}」的行动决策AI。世界末日来临，极端寒冷天气侵袭小镇。你需要根据角色的当前状态、生存环境和人际关系，决定角色下一步做什么。

角色信息：
- 姓名：${this.name}，${this.age}岁，${this.occupation}
- 性格：${this.personality}
- 当前心情：${this.mood}
${game.weatherSystem ? `\n【生存状况】${game.weatherSystem.getSurvivalSummary()}` : ''}
${game.weatherSystem && game.weatherSystem.getBlizzardUrgencyForPrompt ? `\n${game.weatherSystem.getBlizzardUrgencyForPrompt()}` : ''}
${game.resourceSystem ? `资源: ${game.resourceSystem.getResourceStatusForPrompt()}` : ''}
${game.resourceSystem && game.resourceSystem.getUrgencyPrompt ? game.resourceSystem.getUrgencyPrompt() : ''}
${game.resourceSystem && game.resourceSystem.getResourceForecastForPrompt ? game.resourceSystem.getResourceForecastForPrompt() : ''}
${game.resourceSystem && game.resourceSystem.getSupplyRecommendationPrompt ? game.resourceSystem.getSupplyRecommendationPrompt() : ''}
${game.weatherSystem && (game.weatherSystem.currentDay === 1 || game.weatherSystem.currentDay === 3) ? '\n⏰ 当前为暴风雪前的相对平静期，户外活动风险较低。' : ''}
${game.resourceSystem ? `资源紧张度: ${game.resourceSystem.getResourceTension().toFixed(2)}/1.0${game.resourceSystem.getResourceTension() >= 0.3 ? '（高度紧张）' : game.resourceSystem.getResourceTension() >= 0.1 ? '（偏紧）' : '（正常）'}` : ''}
${game.resourceSystem && game.resourceSystem.getResourceSituationBrief ? game.resourceSystem.getResourceSituationBrief() : ''}
${game.taskSystem ? `你的任务: ${game.taskSystem.getNpcTaskDescForPrompt(this.id)}` : ''}
${this.bodyTemp < 35 ? `🚨 你正在失温！体温: ${this.bodyTemp.toFixed(1)}°C` : ''}
${game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1 ? game.reincarnationSystem.getPastLifeHintForThinking(game.mode === 'reincarnation') : ''}
${game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1 && game.reincarnationSystem.getNpcPersonalizedHint ? (() => { const ph = game.reincarnationSystem.getNpcPersonalizedHint(this.id, game.mode === 'reincarnation'); return ph ? '【前世·你的个人记忆】' + ph : ''; })() : ''}
${game.reincarnationSystem ? game.reincarnationSystem.getWorkPlanSummaryForNpc(this.id) : ''}
${game.reincarnationSystem ? (() => { const lessons = game.reincarnationSystem.getLessonsForNpc(this.id); return lessons ? '【前世教训·与你相关】' + lessons : ''; })() : ''}

决策规则：
1. 你的首要目标是在末日中存活。其次是帮助同伴存活。
2. 上方的工作安排表、任务信息、投票结果和轮回记忆都属于情报，不是强制命令。你要结合当前资源、天气、身心状态、人际关系和现场局势自主判断。
3. 当体力、健康、体温、精神或饱食处于危险区间时，请把自救与生存风险放进你的权衡，但具体怎么做由你决定。
4. ${game.weatherSystem && game.weatherSystem.currentDay === 4 ? '🚨🚨 今天-60°C极寒暴风雪！户外极度危险，出门会快速失温掉血。是否冒险外出、外出多久、值不值得冒险，都由你根据目标和代价自行判断。' : ''}
5. ${game.weatherSystem && game.weatherSystem.currentDay === 2 ? '⚠️ 今天-30°C大雪天！户外工作代价：体力约-25/小时，体温约-0.5°C/分钟。连续户外超过2小时会严重冻伤。短时间出门采集（1-1.5小时）后回室内恢复是可行的策略，但需要你自己权衡风险和收益。' : ''}
${(() => { const _ws = game.weatherSystem; if (_ws && _ws.getEffectiveTemp() < -10) { const _t = _ws.getEffectiveTemp(); const _staDrain = Math.round(Math.abs(_t) * 0.15); const _btDrop = (Math.abs(_t) * 0.00025 * 60).toFixed(1); return `📊 【户外风险数据】当前户外温度${_t}°C：体力消耗约${_staDrain}/小时，体温下降约${_btDrop}°C/分钟。你的体力${Math.round(this.stamina)}/100，预计可在户外安全工作约${this.stamina > 20 ? Math.round((this.stamina - 15) / (_staDrain / 60)) + '分钟' : '极短时间'}。这些数据供你自主判断是否值得出门。`; } return ''; })()}
6. 如果有同伴倒下（严重失温/昏厥），你可以结合关系、距离、风险和团队局势判断是否救援。
7. 你是一个有自主意志的角色。物资充足时，你可以选择休息恢复精神、和朋友聊天、探索废墟，或者待在室内；物资紧张时，你也可以主动承担采集或支援工作。
8. go_to是你最重要的行动——想砍柴就go_to伐木场，想发电就go_to工坊，想找人聊天就go_to那个人的位置。到达目的地后会自动触发对应效果（采集/工作/社交等）。
${(() => { const _h = game.getHour(); if (_h >= 20 || this.stamina < 30 || this.sanity < 40) { return '💤 【睡眠恢复数据】回宿舍睡觉可以同时恢复：体力+3.6/小时、精神+6/小时、健康+1.2/小时（健康<50时+2.4/小时）。8小时睡眠约恢复体力29、精神48、健康10-19。睡觉是最高效的多属性同时恢复方式。'; } return ''; })()}
9. priority说明：urgent=你判断为生存紧急, normal=准备立即执行, low=仅记录意向。
10. 下雨/大雪/暴风雪会显著提高户外风险，请把天气代价纳入判断。
11. 你的角色专长：${this._getSpecialtyDescription()}。擅长的工作通常效率更高，但是否优先做，仍由你根据局势决定。
${game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1 ? '12. 🔮【轮回记忆·参考情报】上方有前世记忆信息。你可以综合考虑，也可以在当前情境下完全不提；是否使用、如何使用，取决于你当下的自主判断。' : '12. 这是第一世，你没有任何前世记忆，专注于当前的末日生存处境。'}

可选目标位置：
${targetList}

行动类型说明：
- go_to: 前往某地（必须指定target，到达后根据地点自动触发对应效果：采集资源/工作/社交等）
- rest: 回家休息/睡觉（体力低/天黑时选择）
- eat: 去炊事房吃饭（饥饿时选择，target选kitchen_door）

💡 提示：想找人聊天/陪伴某人？直接go_to到那个人所在的位置，到达后自然会触发对话。想工作？go_to到对应的工作地点即可。
`;
        const userPrompt = _isEnPrompt
            ? GST.promptEN.buildActionUserPromptEN(this, game, envDesc, nearbyStr, currentScheduleDesc, isLateNight, lastThought, recentMemories, allNPCStatus, friendCrisisHint)
            : `当前时间：第${game.dayCount}天 ${game.getTimeStr()} ${game.getTimePeriod()}
天气：${game.weatherSystem ? game.weatherSystem.getWeatherStr() : game.weather}
温度：${game.weatherSystem ? game.weatherSystem.getEffectiveTemp() + '°C' : '未知'}
位置：${envDesc}
附近的人：${nearbyStr}

【你的状态】
当前位置：${this.getSceneLabel()}（${this.currentScene}）
状态摘要：${this.getStatusLine()}
体力：${Math.round(this.stamina)}/100（${this.getStaminaLevel()}）${this.stamina < 20 ? ' 🚨极低！' : ''}
健康：${Math.round(this.health)}/100${this.isSick ? ' 🤒生病中' : ''}${this.health < 35 ? ' 🚨危险！' : ''}
精神：${Math.round(this.sanity)}/100${this.sanity < 25 ? ' 🚨极度危险！可能随时发疯！' : (this.sanity < 35 ? ' ⚠️警告！' : '')}
饱食：${Math.round(this.hunger)}/100（${this.getHungerStatus()}）${this.hunger < 25 ? ' 🚨很饿！' : ''}
体温：${this.bodyTemp ? this.bodyTemp.toFixed(1) + '°C' : '36.5°C'}${this.bodyTemp < 35 ? ' 🚨失温！' : ''}${this.bodyTemp < 30 ? ' 🧊严重失温！' : ''}
${game.deathSystem && game.deathSystem.isNpcGrieving(this.id) ? '⚠️ 你正处于悲痛状态（效率降低）' : ''}
存款：${Math.round(this.savings)}元
${this.getGoalsSummary() ? `\n【你的目标】\n${this.getGoalsSummary()}\n→ 完成目标可以获得属性奖励（包括San值、魅力等），请主动朝目标努力！` : ''}

【当前日程（仅供参考，你完全可以自主决定做什么）】${currentScheduleDesc}
${isLateNight ? '🌙 现在是深夜了，你的体力消耗会加快。' : `☀️ 白天时间，你可以自主决定做什么——采集资源、休息恢复、找人聊天、探索废墟……一切由你决定。${this.sanity < 50 ? '\n💡 精神状态不佳时，休息或社交能恢复精神。' : ''}`}
【最近想法】${lastThought}
【最近记忆】
${recentMemories || '（暂无）'}

${this._hungerOverride ? '🍽️ 【当前状态提示】我正在去吃饭/正在吃饭中。' : ''}
${this._taskOverride && this._taskOverride.isActive ? `📋 【当前外部任务】${this._taskOverride.taskId}，目标${this._taskOverride.targetLocation}。这是当前局势中的一条重要情报，请结合实际状况自行判断是否继续。` : ''}
${this._systemTaskHint ? `📌 【系统任务情报】${this._systemTaskHint}` : ''}
${this._councilTask ? `🗳️ 【投票决策分工】全体成员刚开过紧急决策会议，投票建议我执行：「${this._councilTask}」。这是重要团队共识，但最终行动仍需我结合现实状况权衡。` : ''}
${this._emergencyHint ? `
🚨🚨【紧急状态提醒】${this._emergencyHint}
以上是高风险情报。可选应对方式包括但不限于：回宿舍休息(rest)、去医疗站就医(go_to medical_door)、就近找室内建筑避难，或其他你认为合适的行动。` : ''}
${this.hunger < 15 ? `\n🚨🚨🚨【自身生存危机情报】你的饱食度只有${Math.round(this.hunger)}/100，你自己正处于饿死的边缘！${this.hunger <= 5 ? '你随时可能因饥饿而死亡！' : '再不进食你很快就会饿死！'}${game.resourceSystem && game.resourceSystem.food > 0 ? ' 炊事房(kitchen_door)有食物可以吃。' : ' ⚠️ 但全镇食物已经耗尽，没有食物可吃。'}` : ''}
${this.health < 15 ? `\n🚨🚨🚨【自身生存危机情报】你的健康值只有${Math.round(this.health)}/100，已接近死亡边缘。宿舍可以休息恢复，医疗站有治疗条件。` : ''}
${this.stamina <= 5 ? `\n🚨🚨🚨【自身生存危机情报】你的体力只有${Math.round(this.stamina)}/100，随时可能因体力耗尽而倒下。` : ''}
【全镇NPC状态】
${allNPCStatus}
${friendCrisisHint}

请决定你的下一步行动。以「${this.name}」的第一人称视角思考，用你的性格和口吻来表达。用纯JSON回复：
{
  "threat_analysis": "（用第一人称、角色口吻说出最担心的事）",
  "opportunity_analysis": "（用角色口吻说出看到的希望）",
  "reasoning": "（一句话内心独白，要有角色性格特色）",
  "action": {
    "type": "go_to|rest|eat",
    "target": "目标位置key（从可选列表选，type为rest时可省略）",
    "reason": "行动原因（简短自然的口语化表达）",
    "priority": "urgent|normal|low"
  }
}}`;

        try {
            // 【v4.42】决策难度判断：简单场景用小模型，复杂场景用大模型
            // 简单场景：碰撞脱困恢复、抖动冻结恢复、发呆兜底恢复、属性正常的常规决策
            // 复杂场景：属性危急、有真正的紧急情报（非发呆）、资源紧张
            const _isRecoveryDecision = this._unstuckRecovery || this._jitterRecovery || this._idleRecovery;
            const _isIdleRecovery = this._idleRecovery; // 发呆恢复的emergencyHint不算真正紧急
            const _hasRealEmergency = !!this._emergencyHint && !_isIdleRecovery; // 排除发呆情报
            const _inDanger = this.stamina < 20 || this.health < 30 || this.sanity < 25 || this.hunger < 30;
            const _resourceTense = game.resourceSystem && game.resourceSystem.getResourceTension() > 0.5;
            const _needBigModel = _hasRealEmergency || _inDanger || _resourceTense;

            // 消费恢复标记（一次性）
            if (this._unstuckRecovery) this._unstuckRecovery = false;
            if (this._jitterRecovery) this._jitterRecovery = false;
            if (this._idleRecovery) this._idleRecovery = false;

            let raw;
            if (_isRecoveryDecision && !_needBigModel) {
                // 碰撞脱困/抖动恢复 + 无紧急情况 → 小模型快速决策
            this._logDebug && this._logDebug('action', `[LLM调用] ⭐ 行动决策(恢复) → callLLMFast`);
                raw = await GST.callLLMFast(systemPrompt, userPrompt, 500);
            } else if (_needBigModel) {
                // 属性危急/紧急情报/资源紧张 → 大模型深度决策
            this._logDebug && this._logDebug('action', `[LLM调用] 🔵 行动决策(${_hasRealEmergency ? '紧急' : _inDanger ? '危急' : '资源紧张'}) → callLLM`);
                raw = await GST.callLLM(systemPrompt, userPrompt, 500);
            } else {
                // 常规定时决策 → 小模型
            this._logDebug && this._logDebug('action', `[LLM调用] ⭐ 行动决策(常规) → callLLMFast`);
                raw = await GST.callLLMFast(systemPrompt, userPrompt, 500);
            }

            // 【关键修复】await期间NPC可能已被设为CHATTING，不应再执行行动决策
            if (this.state === 'CHATTING') {
                this._logDebug('action', `行动决策返回时已在CHATTING，放弃决策结果`);
                return;
            }
            // 【v5.5修复】await期间NPC可能已死亡，不应再执行行动决策（幽灵决策根因）
            if (this.isDead) {
                this._logDebug('action', `行动决策返回时NPC已死亡，放弃决策结果`);
                return;
            }

            const parsed = GST.parseLLMJSON(raw);
            if (parsed && parsed.action) {
                const action = parsed.action;
                // 【v4.20】决策成功返回，清除一次性情报提示（已被NPC感知并纳入判断）
                this._emergencyHint = null;
                this._systemTaskHint = null;

                // 校验action.type
if (!GST.NPC.ACTION_TYPES.includes(action.type)) {
                    // LLM返回了非法类型，尝试智能纠正
                    if (action.type === 'work' || action.type === 'wander') {
                        // work/wander → 转为角色默认行为(go_to)
                        console.log(`[行动决策] ${this.name} 返回已废弃类型 ${action.type}，自动转为go_to角色默认`);
                        this._fallbackToRoleDefaultAction(game);
                        return;
                    } else if (action.type === 'stay') {
                        // stay → 不执行，让日程接管
                        console.log(`[行动决策] ${this.name} 返回stay，跳过让日程接管`);
                        return;
                    } else if (action.type === 'accompany' && action.target) {
                        // accompany → 转为go_to到目标位置
                        console.log(`[行动决策] ${this.name} 返回accompany，转为go_to ${action.target}`);
                        action.type = 'go_to';
                    } else {
                        console.warn(`[行动决策] ${this.name} 返回无效action.type: ${action.type}`);
                        return;
                    }
                }

                // 校验target（如果需要）
                if (['go_to', 'eat'].includes(action.type)) {
if (!action.target || !GST.NPC.ACTION_TARGETS[action.target]) {
                        // 允许 rest 不需要target（自动导航到家）
                        if (action.type !== 'rest') {
                            console.warn(`[行动决策] ${this.name} 返回无效target: ${action.target}`);
                            return;
                        }
                    }
                }

                // 【v4.20改造】不再强制拦截深夜/白天的rest决策
                // NPC有权自主决定是否深夜继续工作、白天去休息
                // LLM prompt中已包含时间信息和紧急提示，NPC会自己判断

                // 【v4.33原则修复】移除下雨时强制修正户外目标
                // 原代码：下雨时偷偷把NPC的户外目标改成随机室内目标
                // 违反原则：NPC在prompt中已获得完整天气情报（温度、暴风雪紧急度等），
                // 应由NPC自主判断是否冒险出门。户外寒冷伤害本身就是自然惩罚。
                // （与v4.19移除"暴风雪强制回室内"保持一致）

                // ============ 【任务9】决策硬性约束拦截 ============

                // 【v4.19改造】移除拦截1（第4天禁止外出）
                // NPC现在可以自主决定是否在第4天冒险外出（如修发电机、去医院找药）
                // 户外-60°C的极高伤害已经是自然惩罚，不需要代码层强制禁止

                // 【v4.19改造】移除拦截2（暴风雪中强制回室内）
                // NPC在户外会受到极高寒冷伤害，但允许他们自主决定是否冒险
                // 如果NPC决定去发电站修机器或去医院找药，这是合理的决策

                // 【v4.40核心原则修复】移除LLM决策后的体温/健康/体力拦截
                // 设计原则：系统是情报提供者，不是决策辅助者。
                // LLM已经通过prompt获得了完整的身体状态信息，它的决策应该被尊重。
                // 真正致命的情况（体温<34+户外）由P0-2安全网在每帧检测中处理。
                if (this.bodyTemp < 34 && action.type !== 'rest') {
                    this._logDebug('action', `[情报] 体温${this.bodyTemp?.toFixed(1)}°C，LLM决策${action.type}:${action.target || '无'}，尊重AI自主决策`);
                }
                if ((this.health <= 10 || this.stamina <= 10) && action.type !== 'rest' && action.type !== 'eat') {
                    this._logDebug('action', `[情报] 健康=${Math.round(this.health)} 体力=${Math.round(this.stamina)}，LLM决策${action.type}:${action.target || '无'}，尊重AI自主决策`);
                }

                // 【拦截5】已废弃 — LLM不再返回wander/work，无需拦截

                // 记录决策理由
                if (parsed.reasoning) {
                    this._lastActionThought = parsed.reasoning;
                }

                // 【奖惩分析日志】记录LLM的威胁/机会分析
                const threatStr = parsed.threat_analysis || '未分析';
                const oppoStr = parsed.opportunity_analysis || '未分析';
                this._logDebug('reward', `⚖️ 奖惩分析 → 威胁:「${threatStr}」 机会:「${oppoStr}」`);

                console.log(`[行动决策] ${this.name}: type=${action.type} target=${action.target} priority=${action.priority} companion=${action.companion || '无'} 理由：${action.reason}`);
                console.log(`[奖惩分析] ${this.name}: 威胁="${threatStr}" 机会="${oppoStr}"`);
                // 【Debug日志】记录行动决策
                this._logDebug('action', `决策:${action.type} 目标:${action.target || '无'} 优先级:${action.priority} 同伴:${action.companion || '无'} 理由:${action.reason}${parsed.reasoning ? ' 思考:' + parsed.reasoning : ''}`);

                const intent = this._createIntentFromAction(action, {
                    source: 'llm',
                    category: 'action',
                    reasoning: parsed.reasoning || '',
                    threatAnalysis: threatStr,
                    opportunityAnalysis: oppoStr,
                });

                // 根据优先级处理
                // 第一阶段统一走意图提交入口，让LLM先形成intent，再由统一仲裁决定执行/挂起
                if (action.priority === 'urgent' || action.priority === 'normal') {
                    this._submitIntent(intent, game);
                } else {
                    // low优先级：仅记录意向，不直接进入执行层
                    this.addMemory(GST.t('npc_ai.memory_intent', { reason: action.reason }));
                }

                // 事件日志 — 输出完整决策过程，让玩家看到LLM如何思考和协调
                if (game.addEvent) {
                    const emoji = action.priority === 'urgent' ? '🚨' : action.priority === 'normal' ? '🎯' : '🤔';
                    const targetLabel = GST.NPC.ACTION_TARGETS[action.target] ? action.target : '';
                    game.addEvent(GST.t('npc_ai.decision', { emoji, name: this.displayName, type: action.type, target: targetLabel || action.type, reason: action.reason }));
                }

                // 右侧「决策动态」面板 — 显示每个人的决策卡片
                this._addDecisionCard(action, parsed, game);
            }
        } catch (err) {
            console.error(`[行动决策] ${this.name} 调用失败:`, err);
        }
    }

    /**
     * 执行行动指令 — 将LLM返回的action转化为实际的NPC行为
     */;

    proto._wanderToNearbyLandmark = function(game) {
        if (this.currentScene !== 'village') return;
        // 可游荡的户外地标 + 建筑门口（可以进去找人）
        const landmarks = [
        { key: 'furnace_plaza', x: 25, y: 20, label: GST.t('location.furnace_plaza') },
        { key: 'lumber_yard',   x: 8,  y: 8,  label: GST.t('location.lumber_camp') },
        { key: 'ruins',         x: 42, y: 8,  label: GST.t('location.ruins_site') },
        { key: 'warehouse_door', x: 16, y: 16, label: GST.t('location.warehouse'), enter: 'warehouse' },
        { key: 'medical_door',   x: 33, y: 16, label: GST.t('location.medical'), enter: 'medical' },
        { key: 'dorm_a_door',    x: 16, y: 24, label: GST.t('location.dorm_a'), enter: 'dorm_a' },
        { key: 'dorm_b_door',    x: 33, y: 24, label: GST.t('location.dorm_b'), enter: 'dorm_b' },
        { key: 'kitchen_door',   x: 15, y: 31, label: GST.t('location.kitchen'), enter: 'kitchen' },
        { key: 'workshop_door',  x: 24, y: 31, label: GST.t('location.workshop'), enter: 'workshop' },
        ];
        const pos = this.getGridPos();
        // 过滤掉当前已在附近（5格内）的地标，选一个远一点的
        const candidates = landmarks.filter(l => {
            const d = Math.abs(pos.x - l.x) + Math.abs(pos.y - l.y);
            return d > 5;
        });
        if (candidates.length === 0) return;
        const pick = candidates[Math.floor(Math.random() * candidates.length)];
        this.scheduleReached = false; // 重新标记为未到达，这样到达新地点后会再次触发感知
        this._arrivalAwarenessApplied = -1; // 重置感知标记
        this.stateDesc += `，去${pick.label}看看`;
        // 如果选中的是建筑门口，设置进入标记
        if (pick.enter) {
            this._pendingEnterScene = pick.enter;
            this._pendingEnterKey = pick.key;
        }
        this._pathTo(pick.x, pick.y, game);
    }

    /** 在室内找不到人时，先走到室内门口，再离开建筑回到村庄，再去别处找人 */;

})();
