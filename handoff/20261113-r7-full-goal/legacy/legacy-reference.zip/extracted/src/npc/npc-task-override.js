/**
 * 福音镇 - NPC 任务覆盖系统 Mixin
 * 职责：任务覆盖的激活/暂停/恢复/导航/取消
 * 从 npc-schedule.js 拆分，遵循SRP原则（单一职责）
 * 挂载到 GST.NPC.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;

    proto._updateTaskOverrideNavigation = function(dt, game) {
        const override = this._taskOverride;
        if (!override.isActive || !override.targetLocation) return;
        // 【v5.4】P1仲裁暂停期间不执行任务导航
        if (this._arbitrationPaused) return;
        // 【v5.5修复】弹弹乐恢复期内取消任务（任务导航可能触发跨场景→弹弹乐复发）
        if (this._bounceRecoveryTimer > 0) {
            this._logDebug && this._logDebug('schedule', `[弹弹乐恢复期] 恢复期中，取消任务 ${override.taskId}`);
            this.deactivateTaskOverride();
            return;
        }
        if (this._walkingToDoor) return;
        if (this._hungerOverride) {
            this._logDebug && this._logDebug('schedule', `[饥饿优先] 正在进食/前往进食，取消任务导航 ${override.taskId}`);
            this.deactivateTaskOverride();
            return;
        }
        if (this.hunger < 15) {
            this._logDebug && this._logDebug('schedule', `[极度饥饿] hunger=${Math.round(this.hunger)}<15，强制取消任务 ${override.taskId}`);
            this.deactivateTaskOverride();
            return;
        }
        if (this._stateOverride) return;
        if (!this.canSafelyGoOutdoor(game)) {
            const checkLoc = GST.SCHEDULE_LOCATIONS[override.targetLocation];
            if (checkLoc && checkLoc.scene === 'village' && this.currentScene !== 'village') {
                this._logDebug('schedule', `[户外安全门控] 取消户外任务 ${override.taskId}（属性未达安全阈值）`);
                this.deactivateTaskOverride();
                return;
            }
        }

        let targetLoc = GST.SCHEDULE_LOCATIONS[override.targetLocation];
        if (!targetLoc) {
            const stripped = override.targetLocation.replace(/_enter$/, '');
            if (GST.SCHEDULE_LOCATIONS[stripped]) {
                override.targetLocation = stripped;
                targetLoc = GST.SCHEDULE_LOCATIONS[stripped];
                console.warn(`[NPC-${this.name}] 自动修正任务目标: "${override.targetLocation}" → "${stripped}"`);
            } else {
                const fallbackMap = { woodFuel: 'lumber_camp', food: 'frozen_lake', explore: 'ruins_site', power: 'workshop_door' };
                const fallbackKey = (override.resourceType && fallbackMap[override.resourceType]) || 'dorm_a_door';
                targetLoc = GST.SCHEDULE_LOCATIONS[fallbackKey];
                if (targetLoc) {
                    override.targetLocation = fallbackKey;
                    console.warn(`[NPC-${this.name}] 任务覆盖目标无效，回退到 "${fallbackKey}"`);
                } else {
                    console.warn(`[NPC-${this.name}] 任务覆盖目标 "${override.targetLocation}" 无法修正，取消任务`);
                    override.isActive = false;
                    return;
                }
            }
        }

        if (this.isEating || this._isBeingTreated) return;
        if (this.state === 'CHATTING') {
            if (override.priority === 'urgent') {
                this._logDebug && this._logDebug('schedule', `urgent任务打断聊天导航`);
                this._forceEndChat();
            } else { return; }
        }

        const isDoorTarget = override.targetLocation.endsWith('_door');
        const doorToSceneMap = {
            warehouse_door: 'warehouse', medical_door: 'medical',
            dorm_a_door: 'dorm_a', dorm_b_door: 'dorm_b',
            kitchen_door: 'kitchen', workshop_door: 'workshop',
        };
        const targetIndoorScene = isDoorTarget ? doorToSceneMap[override.targetLocation] : null;

        if (targetIndoorScene && this.currentScene === targetIndoorScene) {
            if (!this._taskOverrideReached) {
                this._taskOverrideReached = true;
                this._taskOverrideStuckTimer = 0;
                this._taskOverrideTravelTimer = 0;
                this._logDebug('schedule', `[P1] 已进入室内${targetIndoorScene}，任务目标到达 ${override.targetLocation}`);
                if (this.game && this.game.aiModeLogger) {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                    this.game.aiModeLogger.log('WORK', `${this.name} 到达任务目标(室内) ${override.targetLocation} | 任务:${override.taskId || '?'} | ${snap}`);
                }
            }
            const taskDesc = this._getTaskOverrideDesc();
            if (taskDesc) this.stateDesc = taskDesc;
            this.scheduleReached = true;
            return;
        }

        if (targetIndoorScene && this.currentScene === 'village' && this.currentScene === targetLoc.scene) {
            const pos = this.getGridPos();
            const dist = Math.abs(pos.x - targetLoc.x) + Math.abs(pos.y - targetLoc.y);
            if (dist <= 4) {
                if (!this.isMoving && this.currentPath.length === 0) {
                    this._logDebug && this._logDebug('schedule', `[任务导航] 到达${override.targetLocation}门口(dist=${dist})，触发进入室内${targetIndoorScene}`);
                    this._logDebug('schedule', `[P1] 到达门口，触发进入室内 ${targetIndoorScene}`);
                    this._pendingEnterScene = targetIndoorScene;
                    this._pendingEnterKey = override.targetLocation;
                    this._pathTo(targetLoc.x, targetLoc.y, game);
                }
                return;
            }
            if (!this.isMoving && this.currentPath.length === 0) {
                this._navigateToScheduleTarget(override.targetLocation, game);
            }
        } else if (this.currentScene === targetLoc.scene) {
            const pos = this.getGridPos();
            const dist = Math.abs(pos.x - targetLoc.x) + Math.abs(pos.y - targetLoc.y);
            if (dist <= 4) {
                if (!this._taskOverrideReached) {
                    this._taskOverrideReached = true;
                    this._taskOverrideStuckTimer = 0;
                    this._taskOverrideTravelTimer = 0;
                    this._logDebug('schedule', `[P1] 已到达任务目标位置 ${override.targetLocation}`);
                    if (this.game && this.game.aiModeLogger) {
                        const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                        this.game.aiModeLogger.log('WORK', `${this.name} 到达任务目标 ${override.targetLocation} | 任务:${override.taskId || '?'} | ${snap}`);
                    }
                }
                this.scheduleReached = true;
                return;
            }
            if (!this.isMoving && this.currentPath.length === 0) {
                this._pathTo(targetLoc.x, targetLoc.y, game);
            }
        } else {
            this._taskOverrideReached = false;
            if (!this.isMoving && this.currentPath.length === 0) {
                this._navigateToScheduleTarget(override.targetLocation, game);
            }
        }

        const taskDesc = this._getTaskOverrideDesc();
        if (taskDesc) this.stateDesc = taskDesc;

        // 卡住检测
        const speedMult = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
        const realDt = speedMult > 0 ? dt / speedMult : dt;
        this._taskOverrideTravelTimer += realDt;
        if (this._taskOverrideTravelTimer > 60) {
            if (this._hungerOverride || this._stateOverride) {
                this._logDebug && this._logDebug('schedule', `[超时保护] 任务超时但处于${this._hungerOverride ? '饥饿' : '状态'}覆盖中，取消任务而非传送`);
                this.deactivateTaskOverride();
                return;
            }
            if (!this._taskOverrideRetried) {
                this._taskOverrideRetried = true;
                this._taskOverrideTravelTimer = 0;
                if (targetIndoorScene) {
                    const doorKey = targetIndoorScene + '_door';
                    this._navigateToScheduleTarget(doorKey, game);
                } else {
                    this._navigateToScheduleTarget(override.targetLocation, game);
                }
                this._logDebug && this._logDebug('schedule', `[任务超时] 任务导航超时60秒，重新导航到 ${override.targetLocation}`);
                this._logDebug('schedule', `[P1] 任务导航超时，重新导航到 ${override.targetLocation}（不传送）`);
            } else {
                this._taskOverrideRetried = false;
                this._taskOverrideTravelTimer = 0;
                const failedTask = override.taskId || '未知任务';
                const failedTarget = override.targetLocation || '未知目标';
                this.deactivateTaskOverride();
                this._actionDecisionCooldown = 0;
                const taskReason = `【任务受阻】我尝试执行任务"${failedTask}"前往${failedTarget}，但两次导航都未能到达。我现在在${this.currentScene}，需要重新评估任务计划或选择其他行动。`;
                this._triggerEmergencyDecision(taskReason, game);
                console.log(`[任务放弃] ${this.name} 任务重试后仍超时`);
                this._logDebug('schedule', `[P1] 任务重试后仍超时，取消任务+触发紧急决策`);
            }
        }
    };

    proto._pauseTaskOverride = function(reason = 'system_pause', source = 'system') {
        if (!this._taskOverride || !this._taskOverride.taskId || !this._taskOverride.targetLocation) return false;
        const wasActive = !!this._taskOverride.isActive;
        this._taskOverride.isActive = false;
        this._taskOverride.pausedReason = reason;
        this._taskOverride.pausedBy = source;
        this._taskOverrideReached = false;
        this._taskOverrideStuckTimer = 0;
        this._taskOverrideTravelTimer = 0;
        if (wasActive) {
            this._logDebug('schedule', `[P1] 暂停任务覆盖: ${this._taskOverride.taskId} (${reason})`);
        }
        return true;
    };

    proto._resumeTaskOverride = function(game, reason = 'resume', source = 'system') {
        if (!this._taskOverride || !this._taskOverride.taskId || !this._taskOverride.targetLocation) return false;
        this._taskOverride.isActive = true;
        this._taskOverride.pausedReason = null;
        this._taskOverride.pausedBy = source;
        this._taskOverrideReached = false;
        this._taskOverrideStuckTimer = 0;
        this._taskOverrideTravelTimer = 0;
        this._logDebug('schedule', `[P1] 恢复任务覆盖: ${this._taskOverride.taskId} (${reason})`);
        if (game) { this._navigateToScheduleTarget(this._taskOverride.targetLocation, game); }
        return true;
    };

    proto._resetTaskOverrideState = function() {
        this._taskOverride.taskId = null;
        this._taskOverride.source = 'task';
        this._taskOverride.targetLocation = null;
        this._taskOverride.isActive = false;
        this._taskOverride.priority = 'normal';
        this._taskOverride.resourceType = null;
        this._taskOverride.stateDesc = null;
        this._taskOverride.displayDesc = null;
        this._taskOverride.effectKey = null;
        this._taskOverride.intentId = null;
        this._taskOverride.pausedBy = null;
        this._taskOverride.pausedReason = null;
        this._taskOverrideReached = false;
        this._taskOverrideStuckTimer = 0;
        this._taskOverrideTravelTimer = 0;
    };

    proto.activateTaskOverride = function(taskId, targetLocation, priority, resourceType, stateDesc, options = {}) {
        const meta = (options && typeof options === 'object') ? options : {};
        const shouldActivateNow = meta.deferActivation !== true;
        const scheduleControl = this._getScheduleControl();

        // 【v5.5修复】弹弹乐恢复期内拒绝新任务
        if (this._bounceRecoveryTimer > 0 && priority !== 'urgent') {
            this._logDebug('schedule', `[P1] 拒绝任务 ${taskId}：弹弹乐恢复期中`);
            return false;
        }

        if (shouldActivateNow && scheduleControl.priority === 'P0') {
            this._logDebug('schedule', `[P1] 拒绝任务 ${taskId}：当前处于P0状态(${scheduleControl.reason})，等待恢复后再接受`);
            return false;
        }
        if (shouldActivateNow && this.hunger < 25 && priority !== 'urgent') {
            this._logDebug('schedule', `[P1] 拒绝任务 ${taskId}：NPC饥饿(hunger=${Math.round(this.hunger)})`);
            this._logDebug && this._logDebug('schedule', `[P1拒绝] 饥饿(${Math.round(this.hunger)})<25，拒绝非urgent任务 ${taskId}`);
            return false;
        }
        if (shouldActivateNow && this._hungerOverride === true && priority !== 'urgent') {
            this._logDebug('schedule', `[P1] 拒绝任务 ${taskId}：NPC正在进食/前往进食`);
            this._logDebug && this._logDebug('schedule', `[P1拒绝] 正在进食/前往进食，拒绝非urgent任务 ${taskId}`);
            return false;
        }
        if (shouldActivateNow && this._stateOverride) {
            this._logDebug('schedule', `[P1] 拒绝任务 ${taskId}：NPC处于状态覆盖(${this._stateOverride})`);
            this._logDebug && this._logDebug('schedule', `[P1拒绝] 处于状态覆盖(${this._stateOverride})，拒绝任务 ${taskId}`);
            return false;
        }

        let validLocation = targetLocation;
        if (!GST.SCHEDULE_LOCATIONS[validLocation]) {
            const stripped = validLocation.replace(/_enter$/, '');
            if (GST.SCHEDULE_LOCATIONS[stripped]) {
                console.warn(`[NPC-${this.name}] 位置key "${validLocation}" 不存在，自动修正为 "${stripped}"`);
                validLocation = stripped;
            } else {
                const fallbackMap = { woodFuel: 'lumber_camp', food: 'frozen_lake', explore: 'ruins_site', power: 'workshop_door' };
                const fallback = (resourceType && fallbackMap[resourceType]) || 'dorm_a_door';
                console.warn(`[NPC-${this.name}] 位置key "${validLocation}" 无效，回退到 "${fallback}"`);
                validLocation = fallback;
            }
        }

        if (shouldActivateNow && priority === 'urgent' && this.state === 'CHATTING') {
            this._logDebug && this._logDebug('schedule', `urgent任务打断聊天状态`);
            this._forceEndChat();
        }

        this._taskOverride.taskId = taskId;
        this._taskOverride.source = meta.source || 'task';
        this._taskOverride.targetLocation = validLocation;
        this._taskOverride.isActive = shouldActivateNow;
        this._taskOverride.priority = priority || 'normal';
        this._taskOverride.resourceType = resourceType || null;
        this._taskOverride.stateDesc = stateDesc || null;
        this._taskOverride.displayDesc = meta.displayDesc || stateDesc || null;
        this._taskOverride.effectKey = meta.effectKey || null;
        this._taskOverride.intentId = meta.intentId || null;
        this._taskOverride.pausedBy = shouldActivateNow ? null : (meta.source || 'system');
        this._taskOverride.pausedReason = shouldActivateNow ? null : (meta.deferReason || 'intent_pending');
        this._taskOverrideReached = false;
        this._taskOverrideStuckTimer = 0;
        this._taskOverrideTravelTimer = 0;

        if (shouldActivateNow) {
            const oldOverrideT = this._activeOverride;
            this._activeOverride = 'task';
            if (oldOverrideT !== 'task') {
                this._logDebug('override', `[覆盖切换] ${oldOverrideT} → task（原因: 任务${taskId}）`);
            }
            this._navStartTime = Date.now();
            this.scheduleReached = false;
            if (stateDesc) {
                this.stateDesc = `前往${stateDesc}`;
            } else {
                const resourceNames = { woodFuel: '砍柴', food: '采集食物', explore: '探索废墟', power: '维护电力' };
                const actionName = (resourceType && resourceNames[resourceType]) || '执行任务';
                this.stateDesc = priority === 'urgent' ? `紧急前往${actionName}` : `前往${actionName}`;
            }
            this._logDebug('schedule', `[P1] 激活任务覆盖: ${taskId} → ${validLocation} (${priority})`);
        } else {
            this._logDebug('schedule', `[P1] 挂起任务覆盖: ${taskId} → ${validLocation} (${priority})`);
        }
        return true;
    };

    proto.deactivateTaskOverride = function() {
        if (this._taskOverride.isActive) {
            this._logDebug('schedule', `[P1] 取消任务覆盖: ${this._taskOverride.taskId}`);
        }
        this._taskOverride.taskId = null;
        this._taskOverride.source = 'task';
        this._taskOverride.targetLocation = null;
        this._taskOverride.isActive = false;
        this._taskOverride.priority = 'normal';
        this._taskOverride.resourceType = null;
        this._taskOverride.stateDesc = null;
        this._taskOverride.displayDesc = null;
        this._taskOverride.effectKey = null;
        this._taskOverride.intentId = null;
        this._taskOverrideReached = false;
        this._taskOverrideStuckTimer = 0;
        this._taskOverrideTravelTimer = 0;
    };

})();
