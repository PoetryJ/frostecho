/**
 * 福音镇 - NPC 核心类
 * NPC 类的核心框架：构造函数、update主循环、状态管理、移动/碰撞、序列化
 * 挂载到 GST.NPC
 */
(function() {
    'use strict';
    const GST = window.GST;

    class NPC {
    constructor(config, game) {
        this.id = config.id;
        this.name = config.name;
        this.nameKey = config.nameKey || config.id; // i18n 显示名 key
        this.age = config.age;
        this.occupation = config.occupation;
        this.personality = config.personality;
        this.homeName = config.home;
        this.workplaceName = config.workplace;
        this.color = config.color || GST.C.NPC;
        this.scheduleTemplate = config.schedule;
        this.config = config; // 保存完整配置（含bedtime等）

        // 位置状态
        this.currentScene = config.spawnScene;
        this.x = config.spawnX * GST.TILE;
        this.y = config.spawnY * GST.TILE;
        this.width = GST.TILE;
        this.height = GST.TILE;

        // 移动
        this.speed = 100 + Math.random() * 40; // 每个 NPC 速度稍有不同
        this.facing = 0; // 0=down,1=left,2=right,3=up
        this.isMoving = false;
        this.currentPath = [];
        this.pathIndex = 0;
        this.moveTarget = null; // { x, y } 当前路点像素
        this.stuckTimer = 0;
        this.collisionStallTimer = 0;  // 被碰撞持续阻挡的累计时间
        this._yieldMove = null;         // 让路临时目标 { x, y }（格子坐标）
        this._yieldTimer = 0;           // 让路等待计时

        // 【v4.16】坐标抖动检测器 — 检测NPC在同一场景内频繁来回跑
        this._jitterSamples = [];        // 环形缓冲区：[{x, y, scene, t}]，最多保留12个采样
        this._jitterSampleTimer = 0;     // 采样计时器（每0.3秒采样一次）
        this._jitterFreezeTimer = 0;     // 抖动冻结倒计时（被冻结时不执行移动）
        this._jitterDetectCount = 0;     // 累计检测到抖动的次数（用于日志）
        this._bounceRecoveryTimer = 0;   // 【v5.1】弹弹乐恢复期（游戏秒），期间action-effects不触发自动纠正

        // 动画
        this.animFrame = 0;
        this.animTimer = 0;

        // Sprite（先设onload再设src，避免浏览器缓存命中时onload事件丢失）
        this.sprite = new Image();
        this.spriteLoaded = false;
        this.sprite.onload = () => { this.spriteLoaded = true; };
        this.sprite.onerror = () => { console.warn(`[NPC] ${this.name} sprite加载失败: ${config.spriteDir}/texture.png`); };
        this.sprite.src = config.spriteDir + '/texture.png';
        // 缓存兜底：如果图片已在浏览器缓存中同步完成加载
        if (this.sprite.complete && this.sprite.naturalWidth > 0) {
            this.spriteLoaded = true;
        }

        this.portrait = new Image();
        this._portraitLoaded = false;
        this.portrait.onload = () => { this._portraitLoaded = true; };
        this.portrait.src = config.spriteDir + '/portrait.png';

        // AI 状态
        this.state = 'IDLE'; // IDLE, WALKING, BUSY, CHATTING, SLEEPING
        this.stateDesc = config.schedule[0]?.desc || '闲逛';
        this.mood = GST.t('mood.calm');
        this.expression = '';
        this.expressionTimer = 0;
        this.workBubble = '';      // 【v4.35】工作效果气泡（独立通道，不与expression竞争）
        this.workBubbleTimer = 0;

        // 记忆
        this.memories = [];
        this.maxMemories = 20;

        // 好感度 (对其他 NPC)
        this.affinity = {}; // { npcId: number }

        // AI 思考节流
        this.aiCooldown = 0;
        this.aiInterval = 15 + Math.random() * 15; // 15~30 秒思考一次

        // 社交冷却
        this.chatCooldowns = {}; // { npcId: timestamp }

        // 哲学家/思考型角色特殊设定：更积极地找人聊天
        if (config.id === 'old_qian') {
            this.aiInterval = 10 + Math.random() * 10; // 10~20 秒思考一次
        }

        // 【轮回系统】世数>=2时，AI思考间隔缩短10%（NPC更"警觉"）
        if (game && game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() >= 2) {
            this.aiInterval = Math.round(this.aiInterval * 0.9);
        }

        // 性别
        this.gender = config.gender || '男';

        // 初始化情感关系好感度（非对称）
        if (config.id === 'zhao_chef') {
            this.affinity = { li_shen: 75 };
        } else if (config.id === 'li_shen') {
            this.affinity = { zhao_chef: 65 };
        } else if (config.id === 'su_doctor') {
            this.affinity = { ling_yue: 70 };
        } else if (config.id === 'wang_teacher') {
            this.affinity = { ling_yue: 68 };
        } else if (config.id === 'ling_yue') {
            this.affinity = { su_doctor: 60, wang_teacher: 62 };
        } else if (config.id === 'lu_chen') {
this.affinity = { qing_xuan: 72 };
        } else if (config.id === 'qing_xuan') {
            this.affinity = { lu_chen: 65 };
        }

        // 【轮回系统】应用前世记忆加成
        this._applyReincarnationBonus(game);

        // 日程追踪
        this.currentScheduleIdx = -1;
        this.scheduleReached = false;
        this._pendingEnterScene = null;  // 到达门口后自动进入的室内场景
        this._pendingEnterKey = null;    // 对应的门口key

        // 睡眠系统
        this.isSleeping = false;
        this.sleepZTimer = 0; // "Zzz" 动画计时器

        // 【休息缓冲期】白天rest到达宿舍后，保持停留一段时间再让日程系统接管
        this._restCooldownTimer = 0; // 单位：秒（游戏时间），>0 表示正在休息缓冲期中

        // 【强制睡眠标记】区分日程睡眠和体力不支/白天休息强制入睡
        this._forcedSleep = false;       // 是否为强制睡眠（非日程驱动）
        this._forcedSleepTimer = 0;      // 强制睡眠已持续的游戏时间（秒）

        // 下雨避雨
        this.isSeekingShelter = false;
        this.hasUmbrella = Math.random() > 0.6; // 40% 概率有伞

        // 场所经营统计（店主角色使用）
        this.shopVisitorCount = 0;       // 今天来过的客人数
        this.shopLastVisitorTime = null; // 上一个客人来的时间
        this.shopAloneMinutes = 0;       // 连续没客人的分钟数
        this.shopOutRecruitingUntil = 0; // 外出招揽截止时间（小时）

        // 饥饿系统
        this.hunger = 100;              // 饱腹值 0~100, 100=饱, 0=饿极了
        this.hungerDecayTimer = 0;      // 饥饿递减计时器
        this.isEating = false;          // 正在吃饭中
        this.eatingTimer = 0;           // 吃饭持续时间
        this._hungerOverride = false;   // 饥饿临时日程覆盖中
        this._hungerTarget = null;      // 饥饿驱动的目标场所
        this._hungerTriggerCooldown = 0; // 饥饿触发冷却计时器

        // ============ 资源采集覆盖系统（参考饥饿覆盖模式） ============
        this._resourceGatherOverride = false;  // 资源采集覆盖激活中
        this._resourceGatherTarget = null;     // 采集目标位置key（如'lumber_camp'/'frozen_lake'）
        this._resourceGatherType = null;       // 采集资源类型: 'wood'|'food'|null
        this._resourceGatherTravelTimer = 0;   // 采集超时兜底计时（秒）
        this._resourceGatherCooldown = 0;      // 采集触发冷却计时器（秒）

        // ============ 状态驱动行为覆盖系统 ============
        // 类似饥饿覆盖，当NPC状态极差时打断日程执行紧急行为
        this._stateOverride = null;     // 当前状态覆盖类型: 'exhausted'|'sick'|'mental'|null
        this._stateOverrideTarget = null; // 状态覆盖的导航目标 (同hungerTarget格式)
        this._stateOverrideCooldown = 0;  // 状态覆盖触发冷却（秒），避免反复触发
        this._stateOverrideStuckTimer = 0; // 卡住检测计时
        this._stateOverrideTravelTimer = 0; // 超时兜底计时
        this._stateOverrideMaxTimer = 0;   // 状态覆盖最大持续时间计时（超时保护）
        this._isBeingTreated = false;   // 正在被治疗中（看病）
        this._treatmentTimer = 0;       // 治疗持续时间

        // 社交找不到人冷却
        this._noOneFoundCooldown = 0;   // 找不到人后的冷却计时（秒）

        // 进出门过渡系统
        this._walkingToDoor = false;    // 正在走向室内门口准备出门
this._indoorEntryProtection = 0; // 进屋保护期计时器（秒），进入室内后短暂冻结跨场景导航防止闪现
        this._sceneChangeHistory = [];   // 【v4.38】场景切换审计历史（弹弹乐自动检测）
        this._scheduleNavBlockCooldown = 0; // 【v5.2】安全检查阻止冷却期（游戏秒），防止日程导航型弹弹乐
        this._outdoorCooldown = 0;       // 户外冷却期（秒），P0体温避险清除后短暂阻止导航到户外
        this._exitDoorTarget = null;    // 出门后的目标 {scene, x, y}
        this._enterWalkTarget = null;   // 进门后需要走到的室内目标位置

        // 社交走路系统：wantChat走向目标NPC后自动发起对话
        this._chatWalkTarget = null;    // 正在走向的聊天目标NPC id

        // ============ 发呆兜底检测系统 ============
        this._idleWatchdogTimer = 0;      // 发呆计时器（秒）
        this._idleWatchdogCount = 0;      // 兜底触发次数
        this._idleWatchdogResetTime = 0;  // 兜底触发计数重置时间

        // ============ 核心属性系统（v2.2）============
        const a = config.attrs || {};
        this.stamina  = a.stamina  ?? 50;  // 💪 体力 (0~100) 每天工作消耗，休息恢复
        this.health   = a.health   ?? 50;  // 🫀 健康 (0~100) 身体状况，低了会生病

        // San值系统（精神值，类似《饥荒》的san值）
        this.sanity = a.sanity ?? 70; // 🧠 San值 (0~100) 精神状态，通宵/劳累降低，社交/娱乐/睡眠恢复

        // 【v2.2】废弃属性保留但不再参与计算
        this.savings  = 0;
        this.charisma = 50;
        this.wisdom   = 50;
        this.empathy  = 50;

        // 属性变化计时器（缓慢变化，每游戏小时触发一次检查）
        this._attrUpdateTimer = 0;
        // 生病状态
        this.isSick = false;
        this.sickTimer = 0; // 生病持续时间（游戏小时）

        // 发疯状态（San值过低触发）
        this.isCrazy = false;
        this.crazyTimer = 0; // 发疯持续时间

        // ============ 极寒生存属性 ============
        this.bodyTemp = 36.5;           // 🌡️ 体温 (25°C~36.5°C)，低于35失温，低于30严重失温
        this.isDead = false;            // 💀 是否死亡
        this._deathCause = null;        // 死亡原因: '冻死'|'饿死'|'精神崩溃致死'|null
        this._deathTime = null;         // 死亡时间
        this.isHypothermic = false;     // 🥶 失温状态（体温<35°C）
        this.isSevereHypothermic = false; // 🧊 严重失温（体温<30°C，倒地不起）
        this.isFrostbitten = false;     // 冻伤状态
        this._outdoorContinuousTime = 0; // 连续户外时间（秒）
        this._rescueNeeded = false;     // 是否需要救援（严重失温倒地）
        this._rescueTimer = 0;          // 救援倒计时（秒），超时冻死

        // ============ 极端状态持续计时器（用于死亡判定）============
        this._zeroStaminaDuration = 0;  // 体力=0的持续秒数
        this._zeroHungerDuration = 0;   // 饱腹=0的持续秒数
        this._zeroCrazyDuration = 0;    // San=0且发疯的持续秒数
        this._hypothermiaDuration = 0;  // 【v2.0】体温<33°C的持续秒数（用于失温致死判定）
        this._isDying = false;          // 【v2.0】濒死状态
        this._dyingTimer = 0;           // 【v2.0】濒死状态计时器（秒）

        // ============ 户外工作时间追踪 ============
        this._outdoorWorkDuration = 0;  // 当前户外连续工作秒数
        this._outdoorForceReturn = false; // 是否已触发强制回室内

        // 看演出/心理咨询状态
        this.isWatchingShow = false;  // 正在看歆玥演出
        this.isInTherapy = false;     // 正在接受苏医生心理咨询

        // ============ 任务驱动覆盖系统（三层优先级P1层） ============
        this._taskOverride = {
            taskId: null,           // 当前覆盖的任务ID
            source: 'task',         // 外部来源：task/council/action/system
            targetLocation: null,   // 目标位置key（SCHEDULE_LOCATIONS中的key）
            isActive: false,        // 是否激活
            priority: 'normal',     // 优先级: 'urgent'|'high'|'normal'
            resourceType: null,     // 关联的资源类型（用于采集任务）
            stateDesc: null,        // 展示/兼容文案
            displayDesc: null,      // 显式展示文案（不承担业务语义）
            effectKey: null,        // 显式行为效果键，优先于stateDesc关键词匹配
            intentId: null,         // 关联的外部意图ID
            pausedBy: null,         // 最近一次暂停来源
            pausedReason: null,     // 最近一次暂停原因
        };
        this._taskOverrideStuckTimer = 0;  // 任务覆盖卡住检测
        this._taskOverrideTravelTimer = 0; // 任务覆盖超时兜底
        this._behaviorPriority = 'P2';     // 当前行为层级标记: 'P0'|'P1'|'P2'
        this._behaviorOwner = 'schedule';  // 当前行为控制方: 'priority'|'task'|'hunger'|'state'|'resource'|'action'|'schedule'
        this._behaviorReason = 'default_schedule'; // 当前行为控制原因（调试/仲裁输出）

        // ============ 日程导航超时兜底 ============
        this._navStartTime = 0;            // 导航开始时间（Date.now()）
        this._scheduleNavTimer = 0;        // 日程导航累计时间（秒）
        this._scheduleNavTarget = null;    // 当前日程导航目标key

        // ============ LLM行动决策系统 ============
        this._actionDecisionCooldown = 0;       // 行动决策冷却计时器（秒）
        this._actionDecisionInterval = 25 + Math.random() * 20; // 【v4.14】25~45秒做一次行动决策（白天行为的唯一驱动力，从45~75秒缩短）
        this._unstuckRecovery = false;          // 【v4.42】碰撞脱困恢复标记（下次决策用小模型）
        this._jitterRecovery = false;           // 【v4.42】抖动冻结恢复标记（下次决策用小模型）
        this._idleRecovery = false;             // 【v4.42】发呆兜底恢复标记（下次决策用小模型）
        this._emergencyHint = null;             // 【v4.20】紧急状态提示（注入LLM prompt让NPC自主决策）
        this._emergencyDecisionCooldown = 0;    // 【v4.20】紧急决策冷却（防止同一紧急原因10秒内重复触发）
        this._lastEmergencyReason = null;       // 【v4.20】上次紧急决策原因
        this._systemTaskHint = null;            // 【v4.24】系统只提供的任务情报，不直接接管行动
        this._systemTaskHintTime = 0;           // 【v4.24】最近一次系统任务情报注入时间
        this._intentSeq = 0;                    // 统一意图序号（第一阶段骨架）
        this._pendingIntent = null;             // 待仲裁/待恢复执行的意图对象
        this._currentIntent = null;             // 当前生效中的意图对象
        this._lastIntentArbitration = null;     // 最近一次意图仲裁结果（调试/观测用）
        this._pendingAction = null;             // 待执行的行动 { type, target, reason, priority, companion }
        this._currentAction = null;             // 正在执行的行动
        this._actionOverride = false;           // 是否正在覆盖日程
        this._actionTarget = null;              // 行动覆盖的导航目标
        this._actionStuckTimer = 0;             // 行动卡住检测
        this._actionTravelTimer = 0;            // 行动超时兜底
        this._companionTarget = null;           // 被邀请一起走的目标NPC id
        this._isCompanion = false;              // 当前是否作为同伴跟随中
        this._companionLeader = null;           // 正在跟随的领导者NPC id
        this._companionDestination = null;      // 同伴模式的目标位置key
        this._companionStartTime = 0;           // 同伴模式开始时间（用于超时释放）
        this._lastActionThought = '';           // 上一次行动决策的思考记录（供think参考）

        // ============ Debug日志系统 ============
        this._debugLog = [];            // 行动轨迹日志 [{time, type, detail}]
        this._debugDialogueLog = [];    // 对话记录日志 [{time, partner, lines}]
        this._maxDebugLog = 100;        // 最多保留100条行动日志
        this._maxDebugDialogue = 20;    // 最多保留20条对话记录
        this._lastLoggedState = '';     // 上一次记录的状态（避免重复记录相同状态）

        // ============ 目标系统 ============
        // 从config中加载目标模板，初始化每个目标的运行时状态
        this.goals = (config.goals || []).map(g => ({
            ...g,
            completed: false,       // 是否已完成
            progress: 0,            // 当前进度（0~targetValue）
            rewarded: false,        // 是否已领取奖励
            completedDay: -1,       // 完成的天数（用于daily目标重置）
        }));
        // 每日追踪计数器（每天重置）
        this._goalTrackers = {
            chatCount: 0,       // 今天聊了几个不同的人
            chatPartners: [],   // 今天聊过的人id列表（用于去重）
            workHours: 0,       // 今天工作了多少小时
            studyHours: 0,      // 今天学习了多少小时
            performCount: 0,    // 今天演出了几次
            // 【任务10】末日生存目标追踪
            mealsToday: 0,      // 今天吃了几顿
            woodChopped: 0,     // 今天砍了多少木柴
                gatherCount: 0,     // 今天采集了多少次（食物/电力/探索）
            frostbiteSaved: 0,  // 今天治疗了几人冻伤
            rareItemsFound: 0,  // 今天发现了几个稀有物品
            patrolCount: 0,     // 今天巡逻了几次
            conflictsResolved: 0, // 今天调解了几次冲突
            medkitsCrafted: 0,  // 今天制作了几个急救包
        };
        this._goalCheckTimer = 0;    // 目标检测计时器
        this._lastGoalDay = -1;      // 上次重置目标的天数

        // ============ 统一行为锁系统（BehaviorLock） ============
        // 防止多个覆盖系统互相打断，确保吃饭/休息/睡觉等行为完整执行
        this._currentBehaviorLock = null;   // 当前行为锁 { type: string, priority: number, startTime: number } 或 null
        this._pendingBehaviors = [];         // 待执行行为队列（最多3个）[{ type, priority, callback }]
        this._activeOverride = 'none';       // 当前覆盖系统快照: 'none'|'hunger'|'state'|'action'|'resource'|'task'

        // 游戏引用
        this.game = game;
    }

    // ============ Debug日志方法 ============
    /**
     * 记录debug行动日志
     * @param {string} type - 日志类型: 'think'|'action'|'schedule'|'state'|'override'|'chat'|'move'|'eat'|'sleep'
     * @param {string} detail - 日志详情
     */

    _logDebug(type, detail) {
        // collision类型在所有模式下都记录（调试碰撞卡死问题）
        if (type !== 'collision' && (!this.game || this.game.mode !== 'debug')) return;
        const time = this.game ? this.game.getTimeStr() : '??:??';
        const day = (this.game && this.game.dayCount) || 0;
        const realTime = new Date().toLocaleString('zh-CN', { hour12: false });
        const entry = { time, day, realTime, type, detail, timestamp: Date.now() };
        this._debugLog.unshift(entry);
        if (this._debugLog.length > this._maxDebugLog) this._debugLog.pop();
        // 【v4.22】节流console.log输出，同类型日志每2秒最多输出1次，防止内存溢出
        if (!this._debugLogThrottle) this._debugLogThrottle = {};
        const throttleKey = type;
        const now = Date.now();
        if (!this._debugLogThrottle[throttleKey] || now - this._debugLogThrottle[throttleKey] > 10000) {
            this._debugLogThrottle[throttleKey] = now;
            console.log(`[DEBUG·${this.name}] [D${day} ${time}] [${realTime}] [${type}] ${detail}`);
        }
    }

    /**
     * 记录debug对话日志
     * @param {string} partner - 对话对象
     * @param {Array} lines - 对话内容 [{speaker, text}]
     */

    _logDebugDialogue(partner, lines) {
        if (!this.game || this.game.mode !== 'debug') return;
        const time = this.game.getTimeStr();
        const day = this.game.dayCount || 0;
        const realTime = new Date().toLocaleString('zh-CN', { hour12: false });
        const entry = { time, day, realTime, partner, lines, timestamp: Date.now() };
        this._debugDialogueLog.unshift(entry);
        if (this._debugDialogueLog.length > this._maxDebugDialogue) this._debugDialogueLog.pop();
    }

    /**
     * 获取格式化的debug日志（供UI面板显示）
     */

    getDebugLogText() {
        if (this._debugLog.length === 0) return '暂无行动记录';
        return this._debugLog.slice(0, 50).map(e => {
            const icon = {
                'think': '💭', 'action': '🎯', 'schedule': '📅', 'state': '⚡',
                'override': '🔄', 'chat': '💬', 'move': '🚶', 'eat': '🍜',
                'sleep': '😴', 'sanity': '🧠', 'hunger': '🍽️', 'health': '🏥',
                'goal': '🎯', 'reward': '⚖️', 'penalty': '⚠️'
            }[e.type] || '📝';
            const dayStr = e.day !== undefined ? `D${e.day} ` : '';
            return `[${dayStr}${e.time}] ${icon} ${e.detail}`;
        }).join('\n');
    }

    /**
     * 获取格式化的debug对话日志
     */

    getDebugDialogueText() {
        if (this._debugDialogueLog.length === 0) return '暂无对话记录';
        return this._debugDialogueLog.map(d => {
            const dayStr = d.day !== undefined ? `D${d.day} ` : '';
            const realTimeStr = d.realTime ? ` (${d.realTime})` : '';
            const header = `=== [${dayStr}${d.time}]${realTimeStr} 与 ${d.partner} 的对话 ===`;
            const body = d.lines.map(l => `  ${l.speaker}: ${l.text}`).join('\n');
            return header + '\n' + body;
        }).join('\n\n');
    }
    // [已拆分到 npc-movement.js / npc-intent.js] _releaseBehaviorLock
    // [已拆分到 npc-movement.js / npc-intent.js] _hasBehaviorLock
    // [已拆分到 npc-movement.js / npc-intent.js] _getBehaviorLockType
    // [已拆分到 npc-movement.js / npc-intent.js] _arbitrateIntent
    // [已拆分到 npc-movement.js / npc-intent.js] _submitExternalIntent
    // [已拆分到 npc-movement.js / npc-intent.js] _resolveBehaviorControl
    // [已拆分到 npc-movement.js / npc-intent.js] _getScheduleControl
    // [已拆分到 npc-movement.js / npc-intent.js] _getP0Thresholds
    // [已拆分到 npc-movement.js / npc-intent.js] _checkBehaviorLockTimeout
    getSortY() { return this.y + GST.TILE - 2; }

    getGridPos() {
        return {
            x: Math.floor((this.x + this.width / 2) / GST.TILE),
            y: Math.floor((this.y + this.height / 2) / GST.TILE)
        };
    }

    /**
     * 获取NPC当前位置的中文标签（通用，基于坐标就近匹配）
     * 室内场景直接返回场景名，户外场景通过就近匹配SCHEDULE_LOCATIONS地标
     */
    /** 获取 i18n 显示名（英文模式返回英文名，中文模式返回中文名） */
    get displayName() {
        return GST.i18n.translateNpcName(this.nameKey || this.id) || this.name;
    }

    /** 获取 i18n 显示职业 */
    get displayOccupation() {
        return GST.i18n.translateOccupation(this.id) || this.occupation;
    }

    getLocationLabel() {
        const t = GST.t;
        const SCENE_LABELS = {
            warehouse: t('location.warehouse') || 'Warehouse',
            medical: t('location.medical') || 'Medical',
            dorm_a: t('location.dorm_a') || 'Dorm A',
            dorm_b: t('location.dorm_b') || 'Dorm B',
            kitchen: t('location.kitchen') || 'Kitchen',
            workshop: t('location.workshop') || 'Workshop'
        };
        if (this.currentScene !== 'village') {
            return SCENE_LABELS[this.currentScene] || this.currentScene;
        }
        // 户外：就近匹配已知地标
        const OUTDOOR_LABELS = {
            furnace_plaza: t('location.furnace_plaza') || 'Furnace Plaza',
            lumber_camp: t('location.lumber_camp') || 'Lumber Camp',
            frozen_lake: t('location.frozen_lake') || 'Frozen Lake',
            ruins_site: t('location.ruins_site') || 'Ruins',
            ore_pile: t('location.ore_pile') || 'Ore Pile',
            north_gate: t('location.north_gate') || 'North Gate',
            south_gate: t('location.south_gate') || 'South Gate',
            warehouse_door: t('location.warehouse_door') || 'Warehouse Entrance',
            medical_door: t('location.medical_door') || 'Medical Entrance',
            dorm_a_door: t('location.dorm_a_door') || 'Dorm A Entrance',
            dorm_b_door: t('location.dorm_b_door') || 'Dorm B Entrance',
            kitchen_door: t('location.kitchen_door') || 'Kitchen Entrance',
            workshop_door: t('location.workshop_door') || 'Workshop Entrance'
        };
        const pos = this.getGridPos();
        let bestKey = null, bestDist = Infinity;
        const locs = GST.SCHEDULE_LOCATIONS;
        for (const key in OUTDOOR_LABELS) {
            const loc = locs[key];
            if (!loc || loc.scene !== 'village') continue;
            const d = Math.abs(pos.x - loc.x) + Math.abs(pos.y - loc.y);
            if (d < bestDist) { bestDist = d; bestKey = key; }
        }
        if (bestKey && bestDist <= 8) return OUTDOOR_LABELS[bestKey];
        return t('location.village_outdoor') || 'Village Outdoor';
    }

    addMemory(data) {
        const time = this.game ? this.game.getTimeStr() : '';
        // 支持结构化数据和纯文本两种格式
        if (typeof data === 'string') {
            // 兼容旧格式：纯文本
            let type = 'event';
            if (data.startsWith('[想法]')) type = 'thought';
            else if (data.startsWith('和') && data.includes('聊天')) type = 'chat';
            this.memories.push({ time, text: data, type });
        } else {
            // 新格式：结构化对象 { type, text, lines?, partner? }
            this.memories.push({ time, ...data });
        }
        if (this.memories.length > this.maxMemories) this.memories.shift();
    }

    getAffinity(otherId) {
        return this.affinity[otherId] ?? 50;
    }

    changeAffinity(otherId, delta) {
        const cur = this.getAffinity(otherId);
        this.affinity[otherId] = Math.max(0, Math.min(100, cur + delta));
    }

    /** 【轮回系统】应用前世记忆加成 */

    _applyReincarnationBonus(game) {
        if (!game || !game.reincarnationSystem) return;
        const rs = game.reincarnationSystem;
        const lifeNum = rs.getLifeNumber();
        if (lifeNum <= 1) return; // 第1世无加成

        console.log(`[NPC-轮回] ${this.name} 应用第${lifeNum}世轮回加成`);

        // 【难度系统】获取轮回Buff强度倍率
        const reincBuffMult = (game.getDifficultyMult) ? game.getDifficultyMult('reincarnationBuffMult') : 1.0;

        // 1. San值加成：min(100, 基础值 + 5 × 世数 × 难度倍率)
        if (this.sanity !== undefined) {
            const bonus = Math.round(5 * lifeNum * reincBuffMult);
            this.sanity = Math.min(100, this.sanity + bonus);
            console.log(`  San值加成: +${bonus} (×${reincBuffMult}) → ${Math.round(this.sanity)}`);
        }

        // 2. 上一世死亡同伴好感度+10（×难度倍率）
        const deathRecords = rs.getLastLifeDeathRecords();
        for (const record of deathRecords) {
            // 通过名字匹配NPC ID
            const deadNpc = (typeof GST.NPC_CONFIGS !== 'undefined') 
                ? GST.NPC_CONFIGS.find(c => c.name === record.name)
                : null;
            if (deadNpc && deadNpc.id !== this.id) {
                const cur = this.getAffinity(deadNpc.id);
                const affinityBonus = Math.round(10 * reincBuffMult);
                this.affinity[deadNpc.id] = Math.min(100, cur + affinityBonus);
                console.log(`  好感度加成: 对${record.name}(上世死亡) +${affinityBonus} → ${this.affinity[deadNpc.id]}`);
            }
        }

        // 3. 上一世冲突对象好感度-5
        const conflicts = rs.getLastLifeConflictEvents();
        for (const event of conflicts) {
            // 尝试从事件文本中提取NPC名字
            if (typeof GST.NPC_CONFIGS !== 'undefined') {
                for (const cfg of GST.NPC_CONFIGS) {
                    if (cfg.id !== this.id && event.text && event.text.includes(cfg.name) && event.text.includes(this.name)) {
                        const cur = this.getAffinity(cfg.id);
                        this.affinity[cfg.id] = Math.max(0, cur - 5);
                        console.log(`  好感度惩罚: 对${cfg.name}(上世冲突) -5 → ${this.affinity[cfg.id]}`);
                    }
                }
            }
        }

        // 4. 如果自己上一世死亡，添加初始记忆
        if (rs.wasNpcDeadLastLife(this.id)) {
            const deathCause = rs.getNpcDeathCauseLastLife(this.id);
            if (lifeNum === 2) {
                // 第二世（首次轮回）：更强烈的重生震惊
                this.addMemory(`[重生震惊] 你清楚地记得自己${deathCause === '冻死' ? '在极度寒冷中失去了意识' : deathCause === '饿死' ? '在饥饿中慢慢闭上了眼' : '经历了死亡'}……然后你突然醒来，发现自己又回到了第1天，所有人都活着。你不知道发生了什么。`, 'reincarnation');
            } else {
                this.addMemory(`[前世残影] 你隐约记得自己曾经${deathCause === '冻死' ? '在极度寒冷中失去意识' : deathCause === '饿死' ? '在饥饿中慢慢衰弱' : '经历了可怕的事情'}…那种恐惧至今挥之不去。`, 'reincarnation');
            }
        } else if (lifeNum === 2) {
            // 第二世（首次轮回）：上一世没死的NPC也有重生记忆
            const lastEnding = rs.getLastLifeEndingType();
            const endingDesc = lastEnding === 'extinction' ? '所有人都死了' : lastEnding === 'bleak' ? '大部分人没能活下来' : '经历了那场灾难';
            this.addMemory(`[重生困惑] 你清楚地记得上一世${endingDesc}，然后一切突然重置——你又回到了第1天的起点，所有人都好好的站在面前。这到底是怎么回事？`, 'reincarnation');
        }
    }

    /** 是否正处于休息缓冲期 */
    get isRestingCooldown() { return this._restCooldownTimer > 0; }

    // ---- 更新 ----

    update(dt, game) {
        // 【死亡短路】死亡NPC跳过全部行为逻辑
        if (this.isDead) return;

        // 【行为锁超时安全网】防止因bug导致NPC永久卡在某个行为中
        this._checkBehaviorLockTimeout();

        // 【场景一致性校验】确保NPC的currentScene在已知场景列表中，否则重置
        if (game && game.maps) {
            if (!game.maps[this.currentScene]) {
                // 【v4.32b修复】D4期间不重置到village（会触发弹弹乐），重置到宿舍
                const ws = game.weatherSystem;
                const isD4 = ws && ws.currentDay === 4;
                const resetScene = isD4 ? (this.homeName || 'dorm_a') : 'village';
                console.warn(`[场景修正] ${this.name} 的currentScene="${this.currentScene}" 不在已知场景中，重置到${resetScene}${isD4 ? '(D4保护)' : ''}`);
                if (isD4) {
                    // D4期间用_enterIndoor安全传送到宿舍
                    this._enterIndoor(resetScene, game);
                } else {
                    // 【v4.38】统一场景切换入口
                    this._changeScene('village', 'scene_correction');
                    this.x = 15 * GST.TILE;
                    this.y = 15 * GST.TILE;
                    this.currentPath = [];
                    this.pathIndex = 0;
                    this.isMoving = false;
                }
            } else {
                // 【坐标边界校验】确保NPC坐标在当前场景地图范围内
                const curMap = game.maps[this.currentScene];
                const maxPx = (curMap.width - 1) * GST.TILE;
                const maxPy = (curMap.height - 1) * GST.TILE;
                if (this.x < 0 || this.x > maxPx || this.y < 0 || this.y > maxPy) {
                    console.warn(`[坐标修正] ${this.name} 坐标(${(this.x/GST.TILE).toFixed(1)},${(this.y/GST.TILE).toFixed(1)})超出${this.currentScene}边界(${curMap.width}x${curMap.height})，钳制到有效范围`);
                    this.x = Math.max(0, Math.min(this.x, maxPx));
                    this.y = Math.max(0, Math.min(this.y, maxPy));
                }
            }
        }

        // 表情计时器
        if (this.expressionTimer > 0) {
            this.expressionTimer -= dt;
            if (this.expressionTimer <= 0) this.expression = '';
        }
        // 【v4.35】工作气泡计时器（独立通道）
        if (this.workBubbleTimer > 0) {
            this.workBubbleTimer -= dt;
            if (this.workBubbleTimer <= 0) this.workBubble = '';
        }

        // 冷却计时器递减（使用真实时间，不受倍速影响，避免5倍速下冷却太快导致行为抖动）
        const _speedMult = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
        const _realDt = _speedMult > 0 ? dt / _speedMult : dt;
        if (this._noOneFoundCooldown > 0) this._noOneFoundCooldown -= _realDt;
        if (this._hungerTriggerCooldown > 0) this._hungerTriggerCooldown -= _realDt;
        // 【进屋保护期递减】使用真实时间，避免5倍速下保护期秒过
if (this._indoorEntryProtection > 0) this._indoorEntryProtection -= _realDt;
        // 【v5.2修复】_scheduleNavBlockCooldown改用游戏时间递减
        // 旧方案用真实时间30秒，5×速度下=游戏2.5小时（NPC被卡住太久）
        // 新方案：用游戏时间递减，冷却值=1800游戏秒（=游戏30分钟），所有速度下一致
        const _gameSecondsForCooldown = dt * (game.timeSpeed || 60);
        if (this._scheduleNavBlockCooldown > 0) this._scheduleNavBlockCooldown -= _gameSecondsForCooldown;
        // 【v5.5修复】弹弹乐恢复期递减（使用游戏时间），确保在所有状态下都能正常递减
        if (this._bounceRecoveryTimer > 0) this._bounceRecoveryTimer -= _gameSecondsForCooldown;
        // 【户外冷却期递减】P0体温避险清除后的保护，使用真实时间
        if (this._outdoorCooldown > 0) this._outdoorCooldown -= _realDt;

        // 【休息缓冲期递减】缓冲期结束时恢复日程接管
        // 【行为锁优化】改为条件驱动：体力>=40或经过60秒真实时间
        if (this._restCooldownTimer > 0) {
            this._restCooldownTimer -= _realDt;
            // 【硬保护B4】缓冲期内渐进恢复体力（按游戏时间恢复，保证高倍速恢复效率同步提升）
            this.stamina = Math.min(100, this.stamina + 2 * dt);
            // 【v4.7修复】白天休息也恢复San值（之前只有isSleeping=true才恢复，白天rest完全不回San）
            this.sanity = Math.min(100, this.sanity + 0.06 * dt);
            // 【边界保护】极度饥饿(hunger<10)可以穿透休息缓冲期
            // 【v4.36修复】增加!_hungerOverride检查，避免饥饿覆盖已生效时每帧重复触发导致刷屏死循环
            // 根因：李婶在kitchen中P0休息+极度饥饿→每帧穿透缓冲期→重复调用_triggerHungerBehavior
            //       →反复设置_hungerOverride覆盖导航→_checkEatingArrival永远无法执行_startEating
            // 【v4.37修复】增加食物>0检查，食物=0时穿透只会导致刷屏死循环（吃不到东西）
            const _hasFoodForPenetrate = game.resourceSystem && game.resourceSystem.food > 0;
            if (this.hunger < 10 && !this._hungerOverride && !this.isEating && _hasFoodForPenetrate) {
                this._logDebug && this._logDebug('hunger', `[饥饿穿透] 休息缓冲期中极度饥饿(${Math.round(this.hunger)})，穿透缓冲期去吃饭`);
                this._logDebug('override', `[饥饿穿透] 极度饥饿(${Math.round(this.hunger)})穿透休息缓冲期`);
                this._restCooldownTimer = 0;
                this._clearActionOverride();
                this._releaseBehaviorLock('resting');
                this._triggerHungerBehavior(game);
            }
            const restDone = this._restCooldownTimer <= 0 || this.stamina >= 40;
            if (restDone) {
                const reason = this.stamina >= 40 ? `体力恢复到${Math.round(this.stamina)}` : `缓冲期到期`;
                this._restCooldownTimer = 0;
                this._logDebug && this._logDebug('schedule', `[休息结束] ${reason}，检查后续行为`);
                this._logDebug('override', `[休息完毕] ${reason}`);
                this.stateDesc = '休息完毕';
                this._clearActionOverride();
                this._releaseBehaviorLock('resting'); // 释放休息行为锁
                // 【硬保护B4】缓冲期结束后自动检查饥饿状态
                if (this.hunger < 35) {
                    this._logDebug && this._logDebug('hunger', `[休息→吃饭] 休息完毕但饥饿(${Math.round(this.hunger)})，自动触发饮食行为`);
                    this._logDebug('override', `[休息→吃饭] 休息后饥饿(${Math.round(this.hunger)})，触发饮食`);
                    this._triggerHungerBehavior(game);
                } else {
                    this.currentScheduleIdx = -1;
                    this.scheduleReached = false;
                    this._logDebug && this._logDebug('schedule', `[休息结束] 体力充足且不饥，日程系统恢复接管`);
                }
            }
        }

        // 【吵架冷淡期递减】冷淡期内不会被动增加好感度
        if (this._affinityCooldown) {
            for (const id in this._affinityCooldown) {
                if (this._affinityCooldown[id] > 0) {
                    this._affinityCooldown[id] -= _realDt;
                }
            }
        }

        // 【老钱被动光环】镇长讲话 - 当老钱在室内且同场景存活NPC≥3人时，自动为在场NPC恢复San值
        if (this.id === 'old_qian' && !this.isDead && game && game.npcs) {
            // 【修复v4.16】老钱光环改为室内触发（暖炉广场是露天的，不合理）
            const fs = game.furnaceSystem;
            const isIndoor = fs && fs.isIndoorScene(this.currentScene);
            if (isIndoor) {
                const sameSceneAlive = game.npcs.filter(n => 
                    n.id !== this.id && !n.isDead && n.currentScene === this.currentScene
                );
                if (sameSceneAlive.length >= 3) {
                    // 每秒为在场NPC恢复+0.03 San值（纯被动，不依赖安抚工作状态）
                    for (const npc of sameSceneAlive) {
                        if (npc.sanity < 100) {
                            npc.sanity = Math.min(100, npc.sanity + 0.03 * dt);
                        }
                    }
                }
            }
        }

        // 【v2.0】濒死状态：停止所有活动，仅更新属性和体温
        if (this._isDying) {
            this._updateAttributes(dt, game);
            this._updateBodyTemp(dt, game);
            return; // 濒死NPC不执行任何行动逻辑
        }

        // 【进出门过渡】如果正在走向室内门口准备出门
        if (this._walkingToDoor) {
            this._updateDoorWalk(dt, game);
            return; // 出门过渡期间不执行其他逻辑
        }

        // 六大属性系统更新
        this._updateAttributes(dt, game);

        // 行动实效性系统更新（让日程行为产生实际效果）
        this._updateActionEffect(dt, game);

        // 【新增】全局急救包自动使用检查（独立于medical_heal，每帧执行）
        this._checkAutoMedkit(dt, game);

        // 饥饿系统更新
        // 【修复】睡眠状态必须在饥饿之前更新，避免竞争条件：
        // 旧顺序：_updateHunger(饿醒) → _updateSleepState(立刻重新入睡) → 无限循环
        // 新顺序：_updateSleepState(稳定入睡/起床) → _updateHunger(在确定的清醒状态下检查饥饿)
        this._updateSleepState(game);

        this._updateHunger(dt, game);
        // 如果在睡觉，只更新 Zzz 动画，不做其他事
        if (this.isSleeping) {
            this.sleepZTimer += dt;
            this.isMoving = false;
            this.animFrame = 0;
            // 【强制睡眠计时】累加强制睡眠持续时间（游戏秒）
            if (this._forcedSleep) {
                // 【P0修复】dt是gameDt，需乘以timeSpeed转为游戏秒，阈值7200是游戏秒
                this._forcedSleepTimer += dt * (game.timeSpeed || 60);
            }
            // 【行为锁保护】睡眠期间仅致命紧急(health<10 || bodyTemp<33)才允许唤醒
            // P0层穿透检查：如果有致命紧急情况，不返回，让后续逻辑处理
            const fatalDuringSleep = (this.health < 10) || (this.bodyTemp !== undefined && this.bodyTemp < 33);
            if (!fatalDuringSleep) {
                return; // 非致命情况，继续睡觉
            }
            // 致命紧急，允许穿透到后续逻辑（不返回），同时清除强制睡眠标记
            if (this._forcedSleep) {
                this._forcedSleep = false;
                this._forcedSleepTimer = 0;
                this._logDebug('sleep', `[强制睡眠] 致命紧急穿透强制睡眠`);
            }
            this._logDebug('override', `[行为锁] 睡眠中触发致命紧急(健康${Math.round(this.health)},体温${this.bodyTemp?.toFixed(1)})，允许唤醒`);
        }

        // 状态驱动行为覆盖（疲劳回家、生病看病、精神差求助）
        this._updateStateOverride(dt, game);

        // 资源采集覆盖（木柴/食物紧缺时自动派去采集）
        this._checkResourceGatherNeed(game);
        this._updateResourceGatherOverride(dt, game);

        // 统一行为仲裁快照：在进入AI/日程前收敛当前控制权
        this._refreshBehaviorControl();

        // 【v2.0-优化】资源紧张时强制结束聊天（基于 tension 统一判断）
        if (this.state === 'CHATTING' && game && game.resourceSystem) {
            if (!this._chatUrgencyCheckTimer) this._chatUrgencyCheckTimer = 0;
            this._chatUrgencyCheckTimer += _realDt;
            if (this._chatUrgencyCheckTimer >= 5) { // 每5秒检查一次
                this._chatUrgencyCheckTimer = 0;
                const tension = game.resourceSystem.getResourceTension();
                if (tension >= 0.5) {
                    this._forceEndChat();
                    if (game.addEvent) {
                        game.addEvent(GST.t('social.stop_chat_resource', { name: this.name, tension: (tension * 100).toFixed(0) }));
                    }
                    this._logDebug('chat', `资源紧张度${tension.toFixed(2)}>=0.5，强制结束聊天`);
                }
            }
        }

        // LLM行动决策系统更新（覆盖检测、同伴到达检测等）
        this._updateActionOverride(dt, game);

        // 下雨避雨检查
        this._updateRainResponse(game);

        // 日程检查（P0紧急+P1任务+睡觉日程，白天不再驱动导航）
        this._updateSchedule(dt, game);

        // 【v4.14】LLM行动决策定时调用（冷却到0时自动触发，白天NPC行为的唯一驱动力）
        if (this._actionDecisionCooldown <= 0 && !this.isDead) {
            this._actionDecision(game);
        }

        // 【兜底】发呆检测与自动恢复
        this._updateIdleWatchdog(dt, game);

        // 【增强】让路逻辑处理：如果被碰撞系统指派了让路目标，优先执行让路移动
        if (this._yieldMove) {
            this._yieldTimer = (this._yieldTimer || 0) + _realDt;
            const ytx = this._yieldMove.x * GST.TILE;
            const yty = this._yieldMove.y * GST.TILE;
            const ydx = ytx - this.x;
            const ydy = yty - this.y;
            const ydist = Math.sqrt(ydx * ydx + ydy * ydy);

            if (ydist < 3 || this._yieldTimer > 2.0) {
                // 让路完成或超时，清除让路状态
                if (ydist < 3) {
                    this.x = ytx;
                    this.y = yty;
                }
                this._yieldMove = null;
                this._yieldTimer = 0;
                this.collisionStallTimer = 0;
                // 恢复之前保存的路径
                if (this._savedPath) {
                    this.currentPath = this._savedPath.path;
                    this.pathIndex = this._savedPath.index;
                    this._savedPath = null;
                    // 重新寻路到原目标（因为位置变了）
                    if (this.currentPath.length > 0) {
                        const finalTarget = this.currentPath[this.currentPath.length - 1];
                        this.currentPath = [];
                        this.pathIndex = 0;
                        this._pathTo(finalTarget.x, finalTarget.y, game);
                    }
                }
                this.isMoving = false;
            } else {
                // 朝让路目标移动
                const ynx = ydx / ydist;
                const yny = ydy / ydist;
                const yStep = Math.min(this.speed * dt, ydist - 1);
                const yOldX = this.x, yOldY = this.y;
                this.x += ynx * yStep;
                this.y += yny * yStep;
                // 【v5.4修复】让路移动后检查碰撞框是否嵌入实体区域
                const yMap = game.maps && game.maps[this.currentScene];
                if (yMap) {
                    const m = 2;
                    const ycx = this.x + m, ycy = this.y + m;
                    const ycw = (this.width || GST.TILE) - m * 2;
                    const ych = (this.height || GST.TILE) - m * 2;
                    if (yMap.isSolid(ycx, ycy) || yMap.isSolid(ycx + ycw, ycy) ||
                        yMap.isSolid(ycx, ycy + ych) || yMap.isSolid(ycx + ycw, ycy + ych)) {
                        // 让路目标在实体区域内，回退并取消让路
                        this.x = yOldX;
                        this.y = yOldY;
                        this._yieldMove = null;
                        this._yieldTimer = 0;
                        this.collisionStallTimer = 0;
                        if (this._savedPath) {
                            const finalTarget = this._savedPath.path[this._savedPath.path.length - 1];
                            this._savedPath = null;
                            this.currentPath = [];
                            this.pathIndex = 0;
                            this._pathTo(finalTarget.x, finalTarget.y, game);
                        }
                        this.isMoving = false;
                        return; // 跳过后续移动逻辑
                    }
                }
                this.isMoving = true;
                // 面向方向
                if (Math.abs(ydx) >= Math.abs(ydy)) {
                    this.facing = ydx < 0 ? 1 : 2;
                } else {
                    this.facing = ydy < 0 ? 3 : 0;
                }
            }
        }
        // 移动
        else if (this.currentPath.length > 0) {
            if (this.pathIndex < this.currentPath.length) {
                this._followPath(dt, game);
                // 【增强】走向聊天目标途中：持续检测距离和目标状态
                if (this._chatWalkTarget) {
                    const chatTarget = game.npcs.find(n => n.id === this._chatWalkTarget);
                    if (!chatTarget || chatTarget.currentScene !== this.currentScene) {
                        // 目标已离开同场景，放弃走路
                        this._chatWalkTarget = null;
                        this.currentPath = [];
                        this.pathIndex = 0;
                        this.isMoving = false;
                        this.state = 'IDLE';
                        this.expression = chatTarget ? GST.t('npc_social.chat_target_left', { name: chatTarget.displayName || chatTarget.name }) : '';
                        this.expressionTimer = 4;
                        this._logDebug('chat', `聊天目标已离开同场景，放弃追踪`);
                    } else {
                        // 目标还在，检测距离——足够近时提前发起对话
                        const myPos = this.getGridPos();
                        const tPos = chatTarget.getGridPos();
                        const dist = Math.abs(myPos.x - tPos.x) + Math.abs(myPos.y - tPos.y);
                        if (dist <= 4 && chatTarget.state !== 'CHATTING' && this.state !== 'CHATTING' && this._canChatWith(chatTarget)) {
                            // 已经走到足够近，提前发起对话
                            const chatTargetId = this._chatWalkTarget;
                            this._chatWalkTarget = null;
                            this.currentPath = [];
                            this.pathIndex = 0;
                            this.isMoving = false;
                            this.state = 'IDLE';
                            game.dialogueManager && game.dialogueManager.startNPCChat(this, chatTarget);
                            if (game.addEvent) {
                                game.addEvent(GST.t('social.walk_to_chat', { name: this.name, target: chatTarget.name }));
                            }
                            this._logDebug('chat', `途中检测到距离${dist}格，提前发起对话`);
                        }
                    }
                }
            } else {
                // 路径走完了（pathIndex >= length），检查是否需要进入建筑
                this.currentPath = [];
                this.pathIndex = 0;
                this.isMoving = false;
                this.state = 'IDLE';

                if (this._pendingEnterScene) {
                    // 【进门流程】到达建筑门口，直接传送到室内座位（不经门口中转）
                    this._enterIndoor(this._pendingEnterScene, game);
                } else if (this._enterWalkTarget) {
                    // 【修复】进门后走向室内目标的路径走完了，检查是否真正到达
                    const pos = this.getGridPos();
                    const ewt = this._enterWalkTarget;
                    const distToTarget = Math.abs(pos.x - ewt.x) + Math.abs(pos.y - ewt.y);
                    if (distToTarget <= 3) {
                        // 已到达室内目标
                        this._enterWalkTarget = null;
                        this.scheduleReached = true;
                    } else {
                        // 还没到达，可能寻路走了一段但没到位，直接传送过去
                        console.log(`[进门修复] ${this.name} 路径走完但离室内目标(${ewt.x},${ewt.y})还有${distToTarget}格，直接传送`);
                        this.x = ewt.x * GST.TILE;
                        this.y = ewt.y * GST.TILE;
                        this._enterWalkTarget = null;
                        this.scheduleReached = true;
                    }
                } else if (this._chatWalkTarget) {
                    // 【修复】wantChat走路到达目标附近，自动发起对话
                    const chatTargetId = this._chatWalkTarget;
                    this._chatWalkTarget = null;
                    const target = game.npcs.find(n => n.id === chatTargetId);
                    // 【关键修复】到达后再次验证同场景，防止目标已离开导致隔空对话
                    if (target && target.currentScene === this.currentScene
                        && target.state !== 'CHATTING' && this.state !== 'CHATTING' && this._canChatWith(target)) {
                        game.dialogueManager && game.dialogueManager.startNPCChat(this, target);
                        if (game.addEvent) {
                            game.addEvent(GST.t('social.walk_to_chat', { name: this.name, target: target.name }));
                        }
                    } else if (target && target.currentScene !== this.currentScene) {
                        this.expression = GST.t('npc_social.target_left', { name: target.displayName || target.name });
                        this.expressionTimer = 4;
                    }
                    // 走完社交路径后恢复日程已到达状态（不影响日程）
                    // scheduleReached 保持之前的值不变
                } else {
                    // 普通路径走完
                    this.scheduleReached = true;
                }
            }
        } else {
            this.isMoving = false;
            // 静止时逐渐衰减碰撞累积计时器
            if (this.collisionStallTimer > 0) {
                this.collisionStallTimer = Math.max(0, this.collisionStallTimer - _realDt * 0.3);
            }
        }

        // 【v5.4增强】位置合法性检测：检查NPC碰撞框4个角点是否嵌入实体区域
        // 只在静止时检测，移动中由_followPath自行处理碰撞回退
        if (!this._posFixCooldown) this._posFixCooldown = 0;
        this._posFixCooldown = Math.max(0, this._posFixCooldown - dt);
        if (!this.isMoving && this.currentPath.length === 0 && this._posFixCooldown <= 0) {
            const map = game.maps[this.currentScene];
            if (map) {
                const margin = 2;
                const cx = this.x + margin, cy = this.y + margin;
                const cw = (this.width || GST.TILE) - margin * 2;
                const ch = (this.height || GST.TILE) - margin * 2;
                const inSolid = map.isSolid(cx, cy) || map.isSolid(cx + cw, cy) ||
                                map.isSolid(cx, cy + ch) || map.isSolid(cx + cw, cy + ch) ||
                                map.isSolid(this.x + GST.TILE / 2, this.y + GST.TILE / 2);
                if (inSolid) {
                    this._posFixCooldown = 5; // 5秒冷却
                    // NPC碰撞框嵌入实体区域，搜索最近1-3格的可通行位置
                    let found = false;
                    for (let r = 1; r <= 3 && !found; r++) {
                        for (let dy = -r; dy <= r && !found; dy++) {
                            for (let dx = -r; dx <= r && !found; dx++) {
                                if (Math.abs(dx) !== r && Math.abs(dy) !== r) continue;
                                const testX = this.x + dx * GST.TILE;
                                const testY = this.y + dy * GST.TILE;
                                // 检查目标位置的4个角点都不在实体区域
                                const tcx = testX + margin, tcy = testY + margin;
                                if (!map.isSolid(tcx, tcy) && !map.isSolid(tcx + cw, tcy) &&
                                    !map.isSolid(tcx, tcy + ch) && !map.isSolid(tcx + cw, tcy + ch) &&
                                    !map.isSolid(testX + GST.TILE / 2, testY + GST.TILE / 2)) {
                                    console.log(`[位置修复] ${this.name} 碰撞框嵌入墙壁，从(${Math.floor(this.x/GST.TILE)},${Math.floor(this.y/GST.TILE)})恢复到(${Math.floor(testX/GST.TILE)},${Math.floor(testY/GST.TILE)})`);
                                    this.x = testX;
                                    this.y = testY;
                                    found = true;
                                }
                            }
                        }
                    }
                }
            }
        }

        // AI 思考冷却（真实时间，避免高倍速下思考频率暴涨）
        this.aiCooldown -= _realDt;

        // 动画
        if (this.isMoving) {
            this.animTimer += dt * 5;
            this.animFrame = Math.floor(this.animTimer) % 3;
        } else {
            this.animFrame = 0;
            this.animTimer = 0;
        }

        // 【v4.16】坐标抖动检测 — 检测NPC在同一场景内频繁来回跑
        this._updateJitterDetection(dt, game);
    }
    // [已拆分到 npc-movement.js / npc-intent.js] _updateJitterDetection
    // ---- 天气影响日程 ----
    // 户外目标集合
    static get OUTDOOR_TARGETS() {
        // 【Bug修复v4.4.3】加入户外资源采集区，之前缺失导致-30°C大雪天NPC照常去冰湖/伐木场
        return new Set([
            'furnace_plaza', 'lumber_yard', 'ruins', 'north_gate', 'south_gate',
            'frozen_lake', 'lumber_camp', 'ruins_site', 'ore_pile'  // 户外资源采集区
        ]);
    }
    // 雨天室内替代目标池（随机选一个）
    static get RAIN_INDOOR_ALTERNATIVES() {
        return [
            { target: 'dorm_a_door',   desc: '暴风雪来了，回宿舍A躲避' },
            { target: 'dorm_b_door',   desc: '暴风雪来了，回宿舍B躲避' },
            { target: 'kitchen_door',  desc: '太冷了，去炊事房取暖' },
            { target: 'workshop_door', desc: '太冷了，去工坊取暖' },
            { target: 'warehouse_door', desc: '太冷了，去仓库躲避' },
            { target: 'medical_door',  desc: '太冷了，去医疗站取暖' },
        ];
    }
    // [已拆分到 npc-movement.js / npc-intent.js] _findNearestIndoorDoor
    // [已拆分到 npc-movement.js / npc-intent.js] _enterIndoor
    // [已拆分到 npc-movement.js / npc-intent.js] _walkToDoorAndExit
    // [已拆分到 npc-movement.js / npc-intent.js] _teleportTo
    // [已拆分到 npc-movement.js / npc-intent.js] _followPath
    // [已拆分到 npc-movement.js / npc-intent.js] _clearAllOverrides
    /** 构建经营上下文信息（店主角色专用） */

    serialize() {
        return {
            id: this.id,
            scene: this.currentScene,
            x: this.x,
            y: this.y,
            mood: this.mood,
            memories: this.memories.slice(-10),
            affinity: this.affinity,
            // 核心属性 + San值
            stamina: this.stamina,
            health: this.health,
            sanity: this.sanity,
            isSick: this.isSick,
            isCrazy: this.isCrazy,
            crazyTimer: this.crazyTimer,
            // 极寒生存属性
            bodyTemp: this.bodyTemp,
            isDead: this.isDead,
            _deathCause: this._deathCause,
            _deathTime: this._deathTime,
            isHypothermic: this.isHypothermic,
            isSevereHypothermic: this.isSevereHypothermic,
            hunger: this.hunger,
            // 极端状态持续计时器
            _zeroStaminaDuration: this._zeroStaminaDuration,
            _zeroHungerDuration: this._zeroHungerDuration,
            _zeroCrazyDuration: this._zeroCrazyDuration,
            _hypothermiaDuration: this._hypothermiaDuration,
            _isDying: this._isDying,
            _dyingTimer: this._dyingTimer,
            // 强制睡眠状态
            _forcedSleep: this._forcedSleep,
            _forcedSleepTimer: this._forcedSleepTimer,
            // 【v4.38 存档完善】P0 优先级覆盖状态
            _priorityOverride: this._priorityOverride || null,
            // 【v4.38 存档完善】睡眠状态
            isSleeping: this.isSleeping,
            state: this.state,
            stateDesc: this.stateDesc,
            // 【v4.38 存档完善】饥饿覆盖状态
            _hungerOverride: this._hungerOverride || false,
            isEating: this.isEating,
            eatingTimer: this.eatingTimer,
            // 【v4.38 存档完善】状态覆盖
            _stateOverride: this._stateOverride || null,
            // 【v4.38 存档完善】休息缓冲计时器
            _restCooldownTimer: this._restCooldownTimer || 0,
            // 【v4.38 存档完善】户外冷却期
            _outdoorCooldown: this._outdoorCooldown || 0,
            // 任务驱动覆盖系统
            _taskOverride: { ...this._taskOverride },
            _pendingIntent: this._pendingIntent ? { ...this._pendingIntent, action: this._pendingIntent.action ? { ...this._pendingIntent.action } : null } : null,
            _currentIntent: this._currentIntent ? { ...this._currentIntent, action: this._currentIntent.action ? { ...this._currentIntent.action } : null } : null,
            _lastIntentArbitration: this._lastIntentArbitration ? { ...this._lastIntentArbitration } : null,
            _behaviorPriority: this._behaviorPriority,
            // 统一行为锁系统
            _currentBehaviorLock: this._currentBehaviorLock ? { ...this._currentBehaviorLock } : null,
            _pendingBehaviors: this._pendingBehaviors ? this._pendingBehaviors.map(b => ({ type: b.type, priority: b.priority })) : [],
            _activeOverride: this._activeOverride || 'none',
        };
    }

    deserialize(data) {
        if (!data) return;
        this.currentScene = data.scene || this.currentScene;
        this.x = data.x ?? this.x;
        this.y = data.y ?? this.y;
        this.mood = data.mood || this.mood;
        if (data.memories) this.memories = data.memories;
        if (data.affinity) this.affinity = data.affinity;
        // 核心属性 + San值恢复
        if (data.stamina !== undefined) this.stamina = data.stamina;
        if (data.health !== undefined) this.health = data.health;
        if (data.sanity !== undefined) this.sanity = data.sanity;
        if (data.isSick !== undefined) this.isSick = data.isSick;
        if (data.isCrazy !== undefined) this.isCrazy = data.isCrazy;
        if (data.crazyTimer !== undefined) this.crazyTimer = data.crazyTimer;
        // 极寒生存属性恢复
        if (data.bodyTemp !== undefined) this.bodyTemp = data.bodyTemp;
        if (data.isDead !== undefined) this.isDead = data.isDead;
        if (data._deathCause !== undefined) this._deathCause = data._deathCause;
        if (data._deathTime !== undefined) this._deathTime = data._deathTime;
        if (data.isHypothermic !== undefined) this.isHypothermic = data.isHypothermic;
        if (data.isSevereHypothermic !== undefined) this.isSevereHypothermic = data.isSevereHypothermic;
        if (data.hunger !== undefined) this.hunger = data.hunger;
        // 极端状态持续计时器恢复
        if (data._zeroStaminaDuration !== undefined) this._zeroStaminaDuration = data._zeroStaminaDuration;
        if (data._zeroHungerDuration !== undefined) this._zeroHungerDuration = data._zeroHungerDuration;
        if (data._zeroCrazyDuration !== undefined) this._zeroCrazyDuration = data._zeroCrazyDuration;
        if (data._hypothermiaDuration !== undefined) this._hypothermiaDuration = data._hypothermiaDuration;
        if (data._isDying !== undefined) this._isDying = data._isDying;
        if (data._dyingTimer !== undefined) this._dyingTimer = data._dyingTimer;
        // 强制睡眠状态恢复
        if (data._forcedSleep !== undefined) this._forcedSleep = data._forcedSleep;
        if (data._forcedSleepTimer !== undefined) this._forcedSleepTimer = data._forcedSleepTimer;
        // 任务驱动覆盖系统恢复
        if (data._taskOverride) {
            this._taskOverride = { ...this._taskOverride, ...data._taskOverride };
        }
        this._pendingIntent = data._pendingIntent ? { ...data._pendingIntent, action: data._pendingIntent.action ? { ...data._pendingIntent.action } : null } : null;
        this._currentIntent = data._currentIntent ? { ...data._currentIntent, action: data._currentIntent.action ? { ...data._currentIntent.action } : null } : null;
        this._lastIntentArbitration = data._lastIntentArbitration ? { ...data._lastIntentArbitration } : null;
        if (data._behaviorPriority) this._behaviorPriority = data._behaviorPriority;
        // 统一行为锁系统恢复
        if (data._currentBehaviorLock) {
            // 格式校验：确保有必要字段
            if (data._currentBehaviorLock.type && typeof data._currentBehaviorLock.priority === 'number' && typeof data._currentBehaviorLock.startTime === 'number') {
                // 安全网检查：如果锁持续时间超过120秒真实时间，自动释放
                const lockAge = (Date.now() - data._currentBehaviorLock.startTime) / 1000;
                if (lockAge > 120) {
                    console.warn(`[反序列化] ${this.name} 行为锁 ${data._currentBehaviorLock.type} 已过期(${lockAge.toFixed(0)}秒)，自动释放`);
                    this._currentBehaviorLock = null;
                } else {
                    this._currentBehaviorLock = { ...data._currentBehaviorLock };
                }
            } else {
                console.warn(`[反序列化] ${this.name} 行为锁数据格式异常，忽略`);
                this._currentBehaviorLock = null;
            }
        }
        if (data._pendingBehaviors && Array.isArray(data._pendingBehaviors)) {
            // pending队列仅恢复type和priority，callback不可序列化
            this._pendingBehaviors = data._pendingBehaviors
                .filter(b => b && b.type && typeof b.priority === 'number')
                .slice(0, 3);
        }
        if (data._activeOverride) this._activeOverride = data._activeOverride;
        // 【v4.38 存档完善】P0 优先级覆盖状态恢复
        if (data._priorityOverride !== undefined) this._priorityOverride = data._priorityOverride;
        // 【v4.38 存档完善】睡眠状态恢复
        if (data.isSleeping !== undefined) this.isSleeping = data.isSleeping;
        if (data.state) this.state = data.state;
        if (data.stateDesc) this.stateDesc = data.stateDesc;
        // 【v4.38 存档完善】饥饿覆盖状态恢复
        if (data._hungerOverride !== undefined) this._hungerOverride = data._hungerOverride;
        if (data.isEating !== undefined) this.isEating = data.isEating;
        if (data.eatingTimer !== undefined) this.eatingTimer = data.eatingTimer;
        // 【v4.38 存档完善】状态覆盖恢复
        if (data._stateOverride !== undefined) this._stateOverride = data._stateOverride;
        // 【v4.38 存档完善】休息缓冲计时器恢复
        if (data._restCooldownTimer !== undefined) this._restCooldownTimer = data._restCooldownTimer;
        // 【v4.38 存档完善】户外冷却期恢复
        if (data._outdoorCooldown !== undefined) this._outdoorCooldown = data._outdoorCooldown;
    }

    }

    GST.NPC = NPC;
})();
