/**
 * 福音镇 - NPC 移动系统 Mixin
 * 职责：移动/碰撞/路径跟随、室内外切换、传送、抖动检测
 * 从 npc.js 拆分，遵循SRP原则（单一职责）
 * 挂载到 GST.NPC.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;

    /**
     * 【v4.16】坐标抖动检测器 — 检测NPC在同一场景内频繁来回跑
     */
    proto._updateJitterDetection = function(dt, game) {
        // 冻结期间：倒计时并跳过采样
        if (this._jitterFreezeTimer > 0) {
            const speedMult = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
            const realDt = speedMult > 0 ? dt / speedMult : dt;
            this._jitterFreezeTimer -= realDt;
            if (this._jitterFreezeTimer <= 0) {
                this._jitterFreezeTimer = 0;
                this._jitterSamples = [];
                // 【v5.5修复】冻结恢复时，无论在哪个场景都留在原地
                // 旧方案：在village时导航回宿舍→触发跨场景→弹弹乐复发
                // 新方案：留在当前场景，设置工作驻留，等bounceRecoveryTimer到期后再恢复正常
                this._actionOverride = false;
                this.scheduleReached = true;
                this._workResidenceActive = true;
                this._workResidenceTimer = 120;
                // 【v5.7修复】抖动冻结解除时，如果体力低，强制就地入睡（与弹弹乐冻结同理）
                if (this.stamina < 20) {
                    this.isSleeping = true;
                    this._forcedSleep = true;
                    this._forcedSleepTimer = 0;
                    this.stateDesc = '累坏了，就地休息 💤'; // translateStateDesc handles i18n
                    this.state = 'SLEEPING';
                    this.mood = GST.t('mood.exhausted');
                    this.currentScheduleIdx = -1;
                    this._logDebug && this._logDebug('movement', `[抖动检测] 冻结解除+体力${Math.round(this.stamina)}<20，强制就地入睡`);
                } else {
                    this.stateDesc = '在原地休息整理';
                    this._logDebug && this._logDebug('movement', `[抖动检测] 冻结解除，留在${this.currentScene}休息，工作驻留120秒`);
                }
            }
            return;
        }

        // 采样间隔：每0.3真实秒采样一次
        const speedMult = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
        const realDt = speedMult > 0 ? dt / speedMult : dt;
        this._jitterSampleTimer = (this._jitterSampleTimer || 0) + realDt;
        if (this._jitterSampleTimer < 0.3) return;
        this._jitterSampleTimer = 0;

        // 只在移动中采样
        if (!this.isMoving) return;

        const pos = this.getGridPos();
        if (!this._jitterSamples) this._jitterSamples = [];
        this._jitterSamples.push({ x: pos.x, y: pos.y, scene: this.currentScene, t: Date.now() });

        // 保留最近12个采样（约3.6秒的数据）
        if (this._jitterSamples.length > 12) {
            this._jitterSamples.shift();
        }

        // 至少需要8个采样才能判断
        if (this._jitterSamples.length < 8) return;

        // 检测模式：在同一场景内，X或Y坐标频繁来回变化
        const samples = this._jitterSamples;
        const sameScene = samples.every(s => s.scene === samples[0].scene);
        if (!sameScene) return; // 跨场景的移动不算抖动

        // 计算X和Y方向的方向变化次数
        let xDirChanges = 0, yDirChanges = 0;
        for (let i = 2; i < samples.length; i++) {
            const dx1 = samples[i-1].x - samples[i-2].x;
            const dx2 = samples[i].x - samples[i-1].x;
            if (dx1 !== 0 && dx2 !== 0 && Math.sign(dx1) !== Math.sign(dx2)) xDirChanges++;
            const dy1 = samples[i-1].y - samples[i-2].y;
            const dy2 = samples[i].y - samples[i-1].y;
            if (dy1 !== 0 && dy2 !== 0 && Math.sign(dy1) !== Math.sign(dy2)) yDirChanges++;
        }

        // 如果方向变化次数超过阈值（8个采样中变化5次以上），判定为抖动
        const totalChanges = xDirChanges + yDirChanges;
        if (totalChanges >= 5) {
            this._jitterDetectCount = (this._jitterDetectCount || 0) + 1;
            const trail = samples.map(s => `(${s.x},${s.y})`).join('→');
            console.warn(`⚠️ [坐标抖动] ${this.name} 在${this.currentScene}内频繁来回跑! 方向变化${totalChanges}次 累计第${this._jitterDetectCount}次 轨迹: ${trail}`);
            if (game && game.aiModeLogger) {
                game.aiModeLogger.log('ANOMALY', `🔄 ${this.name} 坐标抖动! 场景=${this.currentScene} 方向变化${totalChanges}次 累计第${this._jitterDetectCount}次`);
            }

            // 冻结NPC 15秒
            this._jitterFreezeTimer = 15;
            this.currentPath = [];
            this.isMoving = false;
            this.state = 'IDLE';
            // 清除可能导致抖动的覆盖状态
            if (this._actionOverride && !this._priorityOverride) {
                this._clearActionOverride();
            }
            this._jitterSamples = [];
        }
    };

    /** 获取当前室内场景的门口外坐标（村庄侧） */
    proto._getDoorPos = function() {
        const doorKey = this.currentScene + '_door';
        const doorLoc = GST.SCHEDULE_LOCATIONS[doorKey];
        if (doorLoc) {
            return {
                x: doorLoc.x + Math.floor(Math.random() * 3) - 1,
                y: doorLoc.y + Math.floor(Math.random() * 2)
            };
        }
        return { x: 25, y: 22 };
    };

    /** 查找距离NPC最近的室内建筑门口 */
    proto._findNearestIndoorDoor = function(game) {
        if (this.currentScene !== 'village') return null;
        const pos = this.getGridPos();
        const doorTargets = [
            'warehouse_door', 'medical_door', 'dorm_a_door', 'dorm_b_door',
            'kitchen_door', 'workshop_door'
        ];
        let nearest = null;
        let minDist = Infinity;
        for (const key of doorTargets) {
            const loc = GST.SCHEDULE_LOCATIONS[key];
            if (!loc) continue;
            const dist = Math.abs(pos.x - loc.x) + Math.abs(pos.y - loc.y);
            if (dist < minDist) {
                minDist = dist;
                nearest = { key, dist };
            }
        }
        return nearest;
    };

    /** 从室内多座位中随机选择一个未被其他NPC占用的位置 */
    proto._pickIndoorSeat = function(scene, game) {
        const seats = GST.INDOOR_SEATS[scene];
        if (!seats || seats.length === 0) return null;

        const occupied = new Set();
        if (game && game.npcs) {
            for (const other of game.npcs) {
                if (other === this) continue;
                if (other.currentScene !== scene) continue;
                const pos = other.getGridPos();
                occupied.add(`${pos.x},${pos.y}`);
                if (other._enterWalkTarget) {
                    occupied.add(`${other._enterWalkTarget.x},${other._enterWalkTarget.y}`);
                }
            }
        }

        const available = seats.filter(s => !occupied.has(`${s.x},${s.y}`));
        if (available.length > 0) {
            const pick = available[Math.floor(Math.random() * available.length)];
            return { x: pick.x, y: pick.y };
        }

        const pick = seats[Math.floor(Math.random() * seats.length)];
        return { x: pick.x, y: pick.y };
    };

    /** 统一进门方法：直接传送到室内座位位置 */
    proto._enterIndoor = function(targetScene, game) {
        game = game || this.game;
        if (this.currentScene === targetScene) {
            this._pendingEnterScene = null;
            this._pendingEnterKey = null;
            this.scheduleReached = true;
            return true;
        }
        const _stack = new Error().stack;
        const _callerLine = _stack.split('\n').slice(2,4).map(s => s.trim().replace(/^at /, '')).join(' ← ');
        const _reason = this._hungerOverride ? '饥饿覆盖' : (this._taskOverride?.isActive ? `任务${this._taskOverride.taskId}` : (this._stateOverride || '日程导航'));
        console.log(`[进门追踪] ${this.name} → ${targetScene}, 当前=${this.currentScene}, 原因=${_reason}, caller=${_callerLine}`);
        if (game && game.aiModeLogger) {
            const snap = GST.AIModeLogger.npcAttrSnapshot(this);
            const fullMsg = `${this.name} 进门→${targetScene} | 从=${this.currentScene} | 原因=${_reason} | ${snap} | caller=${_callerLine}`;
            game.aiModeLogger.logDoor(this.id, this.name, targetScene, 'in', fullMsg);
        }
        const insideKey = targetScene + '_inside';
        let insideLoc = GST.SCHEDULE_LOCATIONS[insideKey];
        const seatLoc = this._pickIndoorSeat(targetScene, game);
        if (seatLoc) insideLoc = { scene: targetScene, x: seatLoc.x, y: seatLoc.y };

        if (insideLoc) {
            if (!this._changeScene(insideLoc.scene, 'enterIndoor')) return false;
            this.x = insideLoc.x * GST.TILE;
            this.y = insideLoc.y * GST.TILE;
            this.currentPath = [];
            this.pathIndex = 0;
            this.isMoving = false;
            this._enterWalkTarget = null;
            this._arrivalAwarenessApplied = -1;
            this.scheduleReached = true;
            this._pendingEnterScene = null;
            this._pendingEnterKey = null;
            this._indoorEntryProtection = 10; // 【v5.1修复】从3秒增加到10秒，防止弹弹乐
            return true;
        }

        if (!this._changeScene(targetScene, 'enterIndoor_fallback')) return false;
        this.x = 5 * GST.TILE;
        this.y = 4 * GST.TILE;
        this.currentPath = [];
        this.pathIndex = 0;
        this.isMoving = false;
        this._enterWalkTarget = null;
        this._arrivalAwarenessApplied = -1;
        this.scheduleReached = true;
        this._pendingEnterScene = null;
        this._pendingEnterKey = null;
        this._indoorEntryProtection = 10; // 【v5.1修复】从3秒增加到10秒，防止弹弹乐
        return true;
    };

    /** 获取当前室内场景的门口坐标（室内侧） */
    proto._getIndoorDoorPos = function() {
        const key = this.currentScene + '_indoor_door';
        const loc = GST.SCHEDULE_LOCATIONS[key];
        if (loc) return { x: loc.x, y: loc.y };
        const sizeMap = {
            warehouse: { w: 10, h: 8 }, medical: { w: 10, h: 8 },
            dorm_a: { w: 12, h: 8 }, dorm_b: { w: 12, h: 8 },
            kitchen: { w: 8, h: 8 }, workshop: { w: 12, h: 8 },
        };
        const size = sizeMap[this.currentScene];
        if (size) return { x: Math.floor(size.w / 2), y: size.h - 1 };
        return { x: 5, y: 8 };
    };

    /** 出门过渡：先走到室内门口，到达后再传送到村庄 */
    proto._walkToDoorAndExit = function(game, onExitCallback, skipSafetyCheck) {
        // 【v5.5修复】弹弹乐恢复期内阻止出门
        if (this._bounceRecoveryTimer > 0) {
            this._logDebug && this._logDebug('movement', `[弹弹乐恢复期] 恢复期中，阻止出门`);
            return;
        }
        const stayIndoorOverrides = ['day4_lockdown', 'hypothermia', 'health_critical', 'stamina_critical', 'sanity_critical', 'crazy_emergency', 'medical_urgent'];
        if (this._priorityOverride && stayIndoorOverrides.includes(this._priorityOverride) && this.currentScene !== 'village') {
            console.warn(`[决策-行动冲突] ${this.name} 决策=${this._priorityOverride}(应待在室内) 但尝试出门! 已阻止`);
            if (game && game.aiModeLogger) {
                const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                game.aiModeLogger.log('ANOMALY', `⚠️ ${this.name} 决策-行动冲突! 决策=${this._priorityOverride}(应待在室内) 但尝试出门 | ${snap}`);
            }
            if (this._actionOverride) {
                this._clearActionOverride();
                this.stateDesc = '';
            }
            return;
        }
        const _stack2 = new Error().stack;
        const _callerLine2 = _stack2.split('\n').slice(2,4).map(s => s.trim().replace(/^at /, '')).join(' ← ');
        const _reason2 = this._hungerOverride ? '饥饿覆盖' : (this._taskOverride?.isActive ? `任务${this._taskOverride.taskId}` : (this._stateOverride || (this._priorityOverride || '日程导航')));
        console.log(`[出门追踪] ${this.name} 当前场景=${this.currentScene}, 原因=${_reason2}, caller=${_callerLine2}`);
        if (game && game.aiModeLogger) {
            const snap = GST.AIModeLogger.npcAttrSnapshot(this);
            const fullMsg = `${this.name} 出门←${this.currentScene} | 原因=${_reason2} | ${snap} | caller=${_callerLine2}`;
            game.aiModeLogger.logDoor(this.id, this.name, this.currentScene, 'out', fullMsg);
        }
        if (this.currentScene === 'village') {
            if (onExitCallback) onExitCallback();
            return;
        }

        const ws = game && game.weatherSystem;
        if (!skipSafetyCheck && !this.canSafelyGoOutdoor(game)) {
            console.warn(`[NPC-${this.name}] [户外安全门控] 属性/天气不满足安全条件，取消出门`);
            this._logDebug('schedule', `[户外安全门控] ${this.name} 属性/天气不满足安全条件，取消出门`);
            return;
        }

        const indoorDoor = this._getIndoorDoorPos();
        const pos = this.getGridPos();
        const dist = Math.abs(pos.x - indoorDoor.x) + Math.abs(pos.y - indoorDoor.y);

        if (ws) {
            const outdoorTemp = ws.getEffectiveTemp();
            if (outdoorTemp < -30 && this.bodyTemp < 36) {
                if (game && game.addEvent) {
                    game.addEvent(GST.t('movement.brave_cold', { name: this.name, outdoorTemp, bodyTemp: this.bodyTemp.toFixed(1) }));
                }
                this._logDebug('schedule', `[体温警告] ${this.name} 在${outdoorTemp}°C下出门，体温${this.bodyTemp.toFixed(1)}°C`);
            }
        }

        if (dist <= 2) {
            const doorPos = this._getDoorPos();
            this._teleportTo('village', doorPos.x, doorPos.y);
            this._indoorEntryProtection = 5;
            this._pendingEnterScene = null;
            if (onExitCallback) onExitCallback();
            return;
        }

        this._walkingToDoor = true;
        this._exitDoorCallback = onExitCallback;
        this._exitDoorTimer = 0;
        this._pendingEnterScene = null;
        this.currentPath = [];
        this.isMoving = false;
        this._pathTo(indoorDoor.x, indoorDoor.y, game);
    };

    /** 出门过渡期间的更新逻辑 */
    proto._updateDoorWalk = function(dt, game) {
        const stayIndoorOverrides = ['day4_lockdown', 'hypothermia', 'health_critical', 'stamina_critical', 'sanity_critical', 'crazy_emergency', 'medical_urgent'];
        if (this._priorityOverride && stayIndoorOverrides.includes(this._priorityOverride)) {
            console.warn(`[决策-行动冲突] ${this.name} 出门过渡中但决策=${this._priorityOverride}(应待在室内)，取消出门`);
            this._walkingToDoor = false;
            this._exitDoorCallback = null;
            this.currentPath = [];
            this.isMoving = false;
            if (game && game.aiModeLogger) {
                game.aiModeLogger.log('ANOMALY', `⚠️ ${this.name} 出门过渡中决策变更为${this._priorityOverride},取消出门`);
            }
            return;
        }
        if (this.state === 'CHATTING') return;

        const _speedMultDoor = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
        const _realDtDoor = _speedMultDoor > 0 ? dt / _speedMultDoor : dt;
        this._exitDoorTimer = (this._exitDoorTimer || 0) + _realDtDoor;
        if (this._exitDoorTimer > 3) {
            this._walkingToDoor = false;
            const doorPos = this._getDoorPos();
            this._teleportTo('village', doorPos.x, doorPos.y);
            this._indoorEntryProtection = 5;
            if (this._exitDoorCallback) {
                const cb = this._exitDoorCallback;
                this._exitDoorCallback = null;
                cb();
            }
            return;
        }

        if (this.currentPath.length > 0 && this.pathIndex < this.currentPath.length) {
            this._followPath(dt, game);
        } else if (this.currentPath.length > 0 && this.pathIndex >= this.currentPath.length) {
            this.currentPath = [];
            this.pathIndex = 0;
            this.isMoving = false;
            this._walkingToDoor = false;
            const doorPos = this._getDoorPos();
            this._teleportTo('village', doorPos.x, doorPos.y);
            this._indoorEntryProtection = 5;
            if (this._exitDoorCallback) {
                const cb = this._exitDoorCallback;
                this._exitDoorCallback = null;
                cb();
            }
        } else {
            this._walkingToDoor = false;
            const doorPos = this._getDoorPos();
            this._teleportTo('village', doorPos.x, doorPos.y);
            this._indoorEntryProtection = 5;
            if (this._exitDoorCallback) {
                const cb = this._exitDoorCallback;
                this._exitDoorCallback = null;
                cb();
            }
        }
    };

    /** 传送NPC到指定场景和坐标 */
    proto._teleportTo = function(scene, gx, gy, precise) {
        if (this.state === 'CHATTING' && scene !== this.currentScene) {
            console.warn(`[传送阻止] ${this.name}正在CHATTING，阻止传送到${scene}`);
            return;
        }

        if (scene === 'village' && this.currentScene !== 'village') {
            const ws = this.game && this.game.weatherSystem;
            if (ws && ws.currentDay === 4) {
                const homeScene = this.homeName || 'dorm_a';
                console.warn(`[D4传送拦截] ${this.name} 试图从${this.currentScene}传送到village，D4期间拦截！重定向到${homeScene}`);
                if (this.game && this.game.aiModeLogger) {
                    const snap = GST.AIModeLogger ? GST.AIModeLogger.npcAttrSnapshot(this) : '';
                    const _stack = new Error().stack;
                    const _caller = _stack.split('\n').slice(2,4).map(s => s.trim().replace(/^at /, '')).join(' ← ');
                    this.game.aiModeLogger.log('ANOMALY', `🚨 ${this.name} D4传送拦截! 从${this.currentScene}→village被拦截,重定向到${homeScene} | caller=${_caller} | ${snap}`);
                }
                this._enterIndoor(homeScene, this.game);
                return;
            }
        }

        const validScenes = this.game && this.game.maps ? Object.keys(this.game.maps) : null;
        if (validScenes && !validScenes.includes(scene)) {
            console.warn(`[传送修正] ${this.name} 目标场景 ${scene} 不存在，回退到 village`);
            scene = 'village';
        }

        if (!this._changeScene(scene, 'teleportTo')) return;
        const map = this.game && this.game.maps ? this.game.maps[scene] : null;

        const mapW = map ? map.width : 30;
        const mapH = map ? map.height : 30;
        gx = Math.max(0, Math.min(gx, mapW - 1));
        gy = Math.max(0, Math.min(gy, mapH - 1));

        if (precise === true) {
            const jitter = 0.6;
            let finalX = gx, finalY = gy;
            for (let attempt = 0; attempt < 5; attempt++) {
                const ox = (Math.random() - 0.5) * jitter * 2;
                const oy = (Math.random() - 0.5) * jitter * 2;
                const testX = Math.floor(gx + ox);
                const testY = Math.floor(gy + oy);
                if (!map || !map.isSolid(testX * GST.TILE + GST.TILE / 2, testY * GST.TILE + GST.TILE / 2)) {
                    finalX = gx + ox;
                    finalY = gy + oy;
                    break;
                }
            }
            finalX = Math.max(0, Math.min(finalX, mapW - 1));
            finalY = Math.max(0, Math.min(finalY, mapH - 1));
            this.x = finalX * GST.TILE;
            this.y = finalY * GST.TILE;
        } else {
            let finalX = gx, finalY = gy;
            for (let attempt = 0; attempt < 5; attempt++) {
                const ox = (Math.random() - 0.5) * 3;
                const oy = (Math.random() - 0.5) * 3;
                const testX = Math.floor(gx + ox);
                const testY = Math.floor(gy + oy);
                if (!map || !map.isSolid(testX * GST.TILE + GST.TILE / 2, testY * GST.TILE + GST.TILE / 2)) {
                    finalX = gx + ox;
                    finalY = gy + oy;
                    break;
                }
            }
            finalX = Math.max(0, Math.min(finalX, mapW - 1));
            finalY = Math.max(0, Math.min(finalY, mapH - 1));
            this.x = finalX * GST.TILE;
            this.y = finalY * GST.TILE;
        }
        this.currentPath = [];
        this.pathIndex = 0;
        this.isMoving = false;
        this._pendingEnterScene = null;
        this._pendingEnterKey = null;

        if (scene !== 'village') {
            this._indoorEntryProtection = 10; // 【v5.1修复】从3秒增加到10秒
        }
    };

    /** A*寻路并设置路径 */
    proto._pathTo = function(gx, gy, game) {
        if (this._jitterFreezeTimer > 0) return;
        const map = game.maps[this.currentScene];
        if (!map) return;
        const pos = this.getGridPos();
        const dist = Math.abs(pos.x - gx) + Math.abs(pos.y - gy);

        if (dist <= 4 && this._pendingEnterScene) {
            this._enterIndoor(this._pendingEnterScene, game);
            return;
        }

        let extraBlocked = null;
        if (this.collisionStallTimer > 0.5 && game.npcs) {
            extraBlocked = new Set();
            for (const other of game.npcs) {
                if (other === this) continue;
                if (other.currentScene !== this.currentScene) continue;
                const ogp = other.getGridPos();
                extraBlocked.add(`${ogp.x},${ogp.y}`);
            }
        }

        const path = GST.findPath(pos.x, pos.y, gx, gy, map, extraBlocked);
        const finalPath = path || (extraBlocked ? GST.findPath(pos.x, pos.y, gx, gy, map) : null);
        if (finalPath && finalPath.length > 1) {
            this.currentPath = finalPath;
            this.pathIndex = 1;
            this.state = 'WALKING';
        } else if (finalPath && finalPath.length === 1 && this._pendingEnterScene) {
            this._enterIndoor(this._pendingEnterScene, game);
        } else if (!finalPath && this._pendingEnterScene) {
            if (dist <= 8) {
                this._enterIndoor(this._pendingEnterScene, game);
            } else {
                this._pendingEnterScene = null;
                this._pendingEnterKey = null;
            }
        } else if (!path && this.currentScene !== 'village') {
            console.log(`[寻路兜底] ${this.name} 在 ${this.currentScene} 室内寻路失败(${pos.x},${pos.y})->(${gx},${gy})，直接传送`);
            this.x = gx * GST.TILE;
            this.y = gy * GST.TILE;
            this.scheduleReached = true;
            this._arrivalAwarenessApplied = -1;
            this.state = 'IDLE';
        } else if (!finalPath && this.currentScene === 'village' && !this._pendingEnterScene) {
            console.warn(`[寻路兜底] ${this.name} 在村庄寻路失败(${pos.x},${pos.y})->(${gx},${gy})，直接传送`);
            this.x = gx * GST.TILE;
            this.y = gy * GST.TILE;
            this.scheduleReached = true;
            this._arrivalAwarenessApplied = -1;
            this.state = 'IDLE';
        }
    };

    /** 沿路径移动 */
    proto._followPath = function(dt, game) {
        if (this.state === 'CHATTING') return;
        if (this._jitterFreezeTimer > 0) {
            this.isMoving = false;
            return;
        }
        if (this.pathIndex >= this.currentPath.length) {
            this.currentPath = [];
            this.isMoving = false;
            this.state = 'IDLE';

            if (this._pendingEnterScene) {
                this._enterIndoor(this._pendingEnterScene, this.game);
            } else if (this._enterWalkTarget) {
                const pos = this.getGridPos();
                const ewt = this._enterWalkTarget;
                const distToTarget = Math.abs(pos.x - ewt.x) + Math.abs(pos.y - ewt.y);
                if (distToTarget <= 3) {
                    this._enterWalkTarget = null;
                    this.scheduleReached = true;
                } else {
                    console.log(`[进门修复] ${this.name} followPath走完但离室内目标(${ewt.x},${ewt.y})还有${distToTarget}格，直接传送`);
                    this.x = ewt.x * GST.TILE;
                    this.y = ewt.y * GST.TILE;
                    this._enterWalkTarget = null;
                    this.scheduleReached = true;
                }
            } else {
                this.scheduleReached = true;
            }
            return;
        }

        const target = this.currentPath[this.pathIndex];
        const tx = target.x * GST.TILE + GST.TILE / 2 - this.width / 2;
        const ty = target.y * GST.TILE + GST.TILE / 2 - this.height / 2;
        const dx = tx - this.x;
        const dy = ty - this.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 2) {
            this.x = tx;
            this.y = ty;
            this.pathIndex++;
            return;
        }

        const nx = dx / dist;
        const ny = dy / dist;
        const maxStep = dist - 1;
        const step = Math.min(this.speed * dt, maxStep);
        const oldX = this.x, oldY = this.y;
        this.x += nx * step;
        this.y += ny * step;
        this.isMoving = true;

        // 【v5.4修复】移动后检查碰撞框是否嵌入实体区域
        const map = game.maps && game.maps[this.currentScene];
        if (map) {
            const margin = 2;
            const cx = this.x + margin, cy = this.y + margin;
            const cw = (this.width || GST.TILE) - margin * 2;
            const ch = (this.height || GST.TILE) - margin * 2;
            if (map.isSolid(cx, cy) || map.isSolid(cx + cw, cy) ||
                map.isSolid(cx, cy + ch) || map.isSolid(cx + cw, cy + ch)) {
                // 嵌入了实体区域，回退到旧位置
                this.x = oldX;
                this.y = oldY;
                // 【v5.8.14修复】碰撞回退后关闭走路动画，防止"原地踏步"
                this.isMoving = false;
                // 累计连续碰撞回退次数
                this._collisionRetreatCount = (this._collisionRetreatCount || 0) + 1;
                if (this._collisionRetreatCount >= 5) {
                    // 连续5次碰撞回退，路径被严重阻挡，直接放弃路径进入IDLE
                    // 不重新寻路（重新寻路到同一目标会走同样的路，导致无限循环）
                    this._collisionRetreatCount = 0;
                    this.currentPath = [];
                    this.pathIndex = 0;
                    this.stuckTimer = 0;
                    this.state = 'IDLE';
                    this.scheduleReached = true; // 视为已到达，让日程系统重新分配
                    return;
                }
                // 跳过当前路径点，尝试下一个
                this.pathIndex++;
                return; // 碰撞回退后直接返回，不执行后续的facing/stuckTimer逻辑
            } else {
                // 移动成功，重置连续碰撞回退计数
                this._collisionRetreatCount = 0;
            }
        }

        const _speedMultPath = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
        const _realDtPath = _speedMultPath > 0 ? dt / _speedMultPath : dt;

        if (this.collisionStallTimer > 0) {
            this.collisionStallTimer = Math.max(0, this.collisionStallTimer - _realDtPath * 0.5);
        }

        if (Math.abs(dx) >= Math.abs(dy)) {
            this.facing = dx < 0 ? 1 : 2;
        } else {
            this.facing = dy < 0 ? 3 : 0;
        }

        const stuckThreshold = this.collisionStallTimer > 0.5 ? 0.8 : 1.5;
        this.stuckTimer += _realDtPath;
        if (this.stuckTimer > stuckThreshold) {
            this.stuckTimer = 0;
            if (this.pathIndex < this.currentPath.length) {
                const nextPt = this.currentPath[this.pathIndex];
                const offX = Math.abs(this.x - (nextPt.x * GST.TILE)) / GST.TILE;
                const offY = Math.abs(this.y - (nextPt.y * GST.TILE)) / GST.TILE;
                if (offX > 2 || offY > 2) {
                    const finalTarget = this.currentPath[this.currentPath.length - 1];
                    this.currentPath = [];
                    this.pathIndex = 0;
                    this.isMoving = false;
                    this._pathTo(finalTarget.x, finalTarget.y, this.game);
                    this.collisionStallTimer = 0;
                    return;
                }
            }
            this.pathIndex++;
        }
    };

})();
