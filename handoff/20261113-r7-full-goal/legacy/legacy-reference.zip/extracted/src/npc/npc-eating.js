/**
 * 福音镇 - NPC进食系统
 * 从 npc-attributes.js 拆分，遵循SRP原则
 * 挂载到 GST.NPC.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;


    /** 到达医院后开始治疗 */;

    proto._chooseEatTarget = function(hour) {
        // 【修复】如果NPC已在某个可用餐的室内场景，优先就地吃饭，避免来回跑
        const sceneToTarget = {
            kitchen: { target: 'kitchen_door', desc: '在炊事房吃饭' },
            warehouse: { target: 'warehouse_door', desc: '去仓库拿干粮' },
            dorm_a: { target: 'dorm_a_door', desc: '在宿舍吃点东西' },
            dorm_b: { target: 'dorm_b_door', desc: '在宿舍吃点东西' },
        };
        if (this.currentScene !== 'village' && sceneToTarget[this.currentScene]) {
            return sceneToTarget[this.currentScene];
        }

        // 在村庄/户外时加权随机选择
        const options = [];
        // 炊事房（主要餐饮场所）
        options.push({ target: 'kitchen_door', desc: '去炊事房吃饭', weight: hour >= 11 ? 3 : 2 });
        // 仓库（拿干粮）
        options.push({ target: 'warehouse_door', desc: '去仓库拿干粮', weight: 1 });
        // 回宿舍做饭（万能选项）
        options.push({ target: this.homeName + '_door', desc: '回宿舍做饭', weight: 1 });
        // 加权随机选择
        const totalWeight = options.reduce((sum, o) => sum + o.weight, 0);
        let rand = Math.random() * totalWeight;
        for (const opt of options) {
            rand -= opt.weight;
            if (rand <= 0) return opt;
        }
        return options[options.length - 1];
    }


    /** 检查是否到达吃饭地点并开始吃饭 */
    proto._checkEatingArrival = function(dt, game) {
        if (!this._hungerOverride || !this._hungerTarget) return;
        if (this.isEating) return;

        // 【关键修复】CHATTING状态下暂停饥饿覆盖的到达检测和传送，防止对话中被传送走导致隔空聊天
        if (this.state === 'CHATTING') return;

        // 判断是否到达了吃饭目标的场景
        const eatingScenes = {
            'kitchen_door': 'kitchen',
            'warehouse_door': 'warehouse',
            'dorm_a_door': 'dorm_a', 'dorm_b_door': 'dorm_b',
        };
        const targetScene = eatingScenes[this._hungerTarget.target];

        // 已经在目标室内场景中 → 直接开始吃饭
        if (this.currentScene === targetScene) {
            this._startEating(game);
            return;
        }

        // 【兜底】在村庄中已走到门口附近（5格内）但还没进入 → 强制传送进入
        if (this.currentScene === 'village' && !this.isMoving && this.currentPath.length === 0) {
            const loc = GST.SCHEDULE_LOCATIONS[this._hungerTarget.target];
            if (loc) {
                const pos = this.getGridPos();
                const dist = Math.abs(pos.x - loc.x) + Math.abs(pos.y - loc.y);
                if (dist <= 6) {
                    // 在门口附近了，直接进入室内座位
                    this._enterIndoor(targetScene, game);
                    // 不立即开始吃饭，等下一帧检测到 currentScene === targetScene 再开始
                    return;
                }
            }
        }

        // 【v4.42修复】超时处理：不再传送，重新导航+触发紧急自我对话
        const _speedMultH = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
        const _realDtH = _speedMultH > 0 ? dt / _speedMultH : dt;
        this._hungerTravelTimer = (this._hungerTravelTimer || 0) + _realDtH;
        if (this._hungerTravelTimer > 15) {
            this._hungerTravelTimer = 0;
            // 重新导航到吃饭目标，而非传送
            if (this._hungerTarget && this._hungerTarget.target) {
                this._navigateToScheduleTarget(this._hungerTarget.target, game);
                // 触发紧急自我对话，让AI自己决定怎么办
                const hungerReason = `【紧急】我非常饥饿(hunger:${Math.round(this.hunger)})，需要去${this._hungerTarget.desc || '吃饭'}，但15秒内没能到达。我现在在${this.currentScene}，需要重新规划路线。`;
                this._triggerEmergencyDecision(hungerReason, game);
                this._logDebug && this._logDebug('hunger', `[饥饿覆盖] 超时15秒，重新导航+触发紧急决策 target=${this._hungerTarget.target}`);
            }
        }
    }


    /**
     * 清除所有覆盖状态的兜底方法
     * 在极端情况下（NPC卡死>60秒）一键清除所有状态并恢复日程控制
     */;

    proto._startEating = function(game) {
        if (!this._hungerTarget) return; // 防御：饥饿目标已被清除
        // 【行为锁】获取吃饭行为锁（优先级3=基本需求），防止被低优先级系统打断
        this._acquireBehaviorLock('eating', GST.BEHAVIOR_PRIORITY.BASIC_NEED);
        this.isEating = true;
        this.eatingTimer = 20; // 吃饭持续 20 真实秒 ≈ 20 游戏分钟（dt 已含倍速，倍速下会更快吃完）
        this.stateDesc = `正在${this._hungerTarget.desc}`; // translateStateDesc handles dynamic patterns
        this.expression = GST.t('npc_eating.lets_eat');
        this.expressionTimer = 4;
        this.mood = GST.t('mood.hopeful');
        this._hungerStuckTimer = 0;
        this._hungerTravelTimer = 0;
        this.currentPath = []; // 停止移动
        this.isMoving = false;
        if (game.addEvent) {
            game.addEvent(GST.t('eating.start_eating', { name: this.name }));
        }
    }

    // [已拆分到 npc-body.js / npc-goals.js] _grantGoalReward
    /** 记录一次聊天（用于目标追踪） */;

    proto._onEatingComplete = function() {
        this._logDebug('override', `[行为完成] 吃饭完成`);
        // 【v4.5诊断】记录吃完饭后的日程恢复
        if (this.game && this.game.aiModeLogger) {
            const snap = GST.AIModeLogger.npcAttrSnapshot(this);
            this.game.aiModeLogger.log('EAT_DONE', `${this.name} 吃饭完成 | 场景=${this.currentScene} | 接下来日程恢复 | ${snap}`);
        }
        // 1. 恢复饱腹值已在调用前处理
        // 2. 清除所有饥饿相关状态
        this.isEating = false;
        this._hungerOverride = false;
        this._hungerTarget = null;
        this._hungerStuckTimer = 0;
        this._hungerTravelTimer = 0;
        // 3. 重置覆盖快照
        if (this._activeOverride === 'hunger') {
            this._activeOverride = 'none';
        }
        // 4. 释放行为锁（内部会检查pending队列）
        this._releaseBehaviorLock('eating');
        // 5. 如果pending队列为空，交还日程系统
        if (this._pendingBehaviors.length === 0) {
            this.currentScheduleIdx = -1;
            this.scheduleReached = false;
        }
    }


    /** 治疗结束 */;

    proto._triggerHungerBehavior = function(game) {
        // 【v4.37修复】食物=0时不触发饥饿行为——吃不到东西，触发只会导致刷屏死循环
        // 根因：D2食物耗尽后，hunger=0的NPC反复触发饥饿导航→短路吃饭→吃不到→又触发，每次双重日志
        const _foodAvail = game.resourceSystem && game.resourceSystem.food > 0;
        if (!_foodAvail) {
            // 食物=0，静默跳过，不设置任何覆盖
            return;
        }
        // 【出门过程保护】NPC正在出门时不触发饥饿行为（致命紧急除外）
        if (this._walkingToDoor) {
            if (this.health >= 10 && (this.bodyTemp === undefined || this.bodyTemp >= 33)) {
                console.log(`[出门保护] ${this.name} 正在出门中，延迟饥饿行为触发`);
                return;
            }
        }
        // 【P0保护】P0紧急状态中且非极度饥饿时，不触发饥饿覆盖（让P0先完成）
        if (this._priorityOverride && this.hunger >= 10) {
            console.log(`[P0保护] ${this.name} 处于P0状态(${this._priorityOverride})，hunger=${Math.round(this.hunger)}>=10，跳过饥饿触发`);
            return;
        }
        // 【覆盖快照】设置饥饿覆盖
        const oldOverride = this._activeOverride;
        this._activeOverride = 'hunger';
        if (oldOverride !== 'hunger') {
            this._logDebug('override', `[覆盖切换] ${oldOverride} → hunger（原因: 饥饿触发）`);
        }
        this._hungerOverride = true;
        this._hungerStuckTimer = 0;
        this._logDebug('hunger', `触发饥饿行为 饱食度:${Math.round(this.hunger)}/100`);

        // 【任务4】饥饿触发时暂停/取消任务覆盖
        if (this._taskOverride && this._taskOverride.isActive) {
            if (this.hunger < 15) {
                // 极度饥饿：彻底取消任务
                console.log(`[饥饿优先] ${this.name} 极度饥饿(${Math.round(this.hunger)})，取消任务 ${this._taskOverride.taskId}`);
                this.deactivateTaskOverride();
            } else {
                // 一般饥饿：暂停任务
                console.log(`[饥饿优先] ${this.name} 饥饿(${Math.round(this.hunger)})，暂停任务 ${this._taskOverride.taskId} 先去吃饭`);
                this._taskOverride.isActive = false;
            }
        }

        // 根据角色和时间选择去哪吃
        const hour = game.getHour();
        const eatTargets = this._chooseEatTarget(hour);
        this._hungerTarget = eatTargets;

        this.stateDesc = `肚子饿了，去${eatTargets.desc}`; // translateStateDesc handles dynamic patterns
        this.mood = GST.t('mood.irritated');
        this.expression = this.hunger < 15 ? GST.t('npc_eating.starving') : GST.t('npc_eating.need_food');
        this.expressionTimer = 6;

        if (game.addEvent) {
            game.addEvent(GST.t('eating.hungry_go_eat', { name: this.name, hunger: Math.round(this.hunger), dest: eatTargets.desc }));
        }

        // 【v4.36修复】短路检查：如果NPC已经在目标吃饭场景中，直接开始吃饭，不需要导航
        // 根因：李婶在kitchen中饥饿触发→_chooseEatTarget返回kitchen_door→导航到village门口坐标
        //       →导航无效→每帧重复触发→刷屏死循环，HUN从5降到2却吃不到东西
        const _eatSceneMap = {
            'kitchen_door': 'kitchen', 'warehouse_door': 'warehouse',
            'dorm_a_door': 'dorm_a', 'dorm_b_door': 'dorm_b',
        };
        const _targetEatScene = _eatSceneMap[eatTargets.target];
        if (_targetEatScene && this.currentScene === _targetEatScene) {
            // 已在目标场景中，直接开始吃饭
            console.log(`[饥饿短路] ${this.name} 已在${_targetEatScene}中，直接开始吃饭`);
            if (game && game.aiModeLogger) {
                const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                game.aiModeLogger.log('HUNGER', `${this.name} 已在${_targetEatScene}中直接吃饭 | hunger=${Math.round(this.hunger)} | ${snap}`);
            }
            this._startEating(game);
            return;
        }

        // 清除当前移动路径，确保新导航不会被旧路径干扰
        this.currentPath = [];
        this.isMoving = false;
        this._pendingEnterScene = null;

        // 导航到目标
        // 【修复】先设 scheduleReached=false，再调用导航（导航内部可能把它改回 true，不能被覆盖）
        this.scheduleReached = false;
        // 【v4.5诊断】记录饥饿覆盖导航到aiModeLogger
        if (game && game.aiModeLogger) {
            const snap = GST.AIModeLogger.npcAttrSnapshot(this);
            game.aiModeLogger.log('HUNGER', `${this.name} 饥饿导航→${eatTargets.target}(${eatTargets.desc}) | 当前场景=${this.currentScene} | hunger=${Math.round(this.hunger)} | ${snap}`);
            game.aiModeLogger.pushNpcEvent(this.id, `🍽️ 饥饿导航→${eatTargets.desc} | hunger=${Math.round(this.hunger)} | ${snap}`);
        }
        this._navigateToScheduleTarget(eatTargets.target, game);
    }

})();
