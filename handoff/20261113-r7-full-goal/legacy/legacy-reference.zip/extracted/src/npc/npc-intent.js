/**
 * 福音镇 - NPC 意图系统 Mixin
 * 职责：意图创建/仲裁/提交、行为锁、行为控制解析、场景切换统一入口
 * 从 npc.js 拆分，遵循SRP原则（单一职责）
 * 挂载到 GST.NPC.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;

    // ---- 行为锁系统 ----

    /**
     * 获取行为锁
     * @param {string} type - 行为类型
     * @param {number} priority - 行为优先级
     * @param {Function} [callback] - pending队列回调
     * @returns {boolean}
     */
    proto._acquireBehaviorLock = function(type, priority, callback) {
        const lockStartTime = Date.now();
        if (!this._currentBehaviorLock) {
            this._currentBehaviorLock = { type, priority, startTime: lockStartTime };
            this._logDebug('override', `[行为锁] 获取锁: ${type}(优先级${priority})`);
            return true;
        }
        if (priority > this._currentBehaviorLock.priority) {
            const oldType = this._currentBehaviorLock.type;
            const oldPriority = this._currentBehaviorLock.priority;
            this._logDebug('override', `[行为锁] 抢占: ${type}(${priority}) 替换 ${oldType}(${oldPriority})`);
            this._currentBehaviorLock = { type, priority, startTime: lockStartTime };
            return true;
        }
        if (callback) {
            const existing = this._pendingBehaviors.findIndex(b => b.type === type);
            if (existing >= 0) {
                this._pendingBehaviors[existing] = { type, priority, callback };
            } else {
                this._pendingBehaviors.push({ type, priority, callback });
                if (this._pendingBehaviors.length > 3) {
                    this._pendingBehaviors.sort((a, b) => b.priority - a.priority);
                    const dropped = this._pendingBehaviors.pop();
                    this._logDebug('override', `[行为锁] pending队列满，丢弃: ${dropped.type}(${dropped.priority})`);
                }
            }
            this._logDebug('override', `[行为锁] 拒绝 ${type}(${priority})，当前锁: ${this._currentBehaviorLock.type}(${this._currentBehaviorLock.priority})，放入pending`);
        } else {
            this._logDebug('override', `[行为锁] 拒绝 ${type}(${priority})，当前锁: ${this._currentBehaviorLock.type}(${this._currentBehaviorLock.priority})`);
        }
        return false;
    };

    proto._releaseBehaviorLock = function(expectedType) {
        if (!this._currentBehaviorLock) return false;
        if (expectedType && this._currentBehaviorLock.type !== expectedType) {
            this._logDebug('override', `[行为锁] 释放失败: 期望${expectedType}，实际${this._currentBehaviorLock.type}`);
            return false;
        }
        const releasedType = this._currentBehaviorLock.type;
        this._currentBehaviorLock = null;
        this._logDebug('override', `[行为锁] 释放锁: ${releasedType}`);
        this._executePendingBehavior();
        return true;
    };

    proto._executePendingBehavior = function() {
        if (this._pendingBehaviors.length === 0) return;
        this._pendingBehaviors.sort((a, b) => b.priority - a.priority);
        const next = this._pendingBehaviors.shift();
        this._logDebug('override', `[行为锁] 从pending队列执行: ${next.type}(${next.priority})`);
        if (next.callback && typeof next.callback === 'function') {
            try { next.callback(); } catch (e) {
                console.warn(`[行为锁] pending回调执行失败: ${next.type}`, e);
            }
        }
    };

    proto._hasBehaviorLock = function() {
        return this._currentBehaviorLock !== null;
    };

    proto._getBehaviorLockPriority = function() {
        return this._currentBehaviorLock ? this._currentBehaviorLock.priority : -1;
    };

    proto._getBehaviorLockType = function() {
        return this._currentBehaviorLock ? this._currentBehaviorLock.type : null;
    };

    // ---- 意图创建/仲裁/提交 ----

    proto._createIntentFromAction = function(action, options = {}) {
        this._intentSeq = (this._intentSeq || 0) + 1;
        const normalizedAction = action ? {
            ...action,
            displayDesc: action.displayDesc || action.reason || '',
            effectKey: action.effectKey || null,
            sourceTaskId: action.sourceTaskId || null,
        } : null;
        return {
            id: `${this.id}_intent_${this._intentSeq}`,
            source: options.source || 'llm',
            category: options.category || 'action',
            priority: normalizedAction?.priority || 'normal',
            action: normalizedAction,
            reasoning: options.reasoning || '',
            threatAnalysis: options.threatAnalysis || '',
            opportunityAnalysis: options.opportunityAnalysis || '',
            metadata: options.metadata ? { ...options.metadata } : {},
            createdAt: this.game ? this.game.gameTime : Date.now(),
        };
    };

    proto._arbitrateIntent = function(intent) {
        const control = this._refreshBehaviorControl();
        if (!intent || !intent.action) return { decision: 'reject', reason: 'invalid_intent', control };
        if (this.isDead) return { decision: 'reject', reason: 'dead', control };
        if (this.state === 'CHATTING') return { decision: 'reject', reason: 'chatting', control };
        if (this._currentBehaviorLock) return { decision: 'pending', reason: `behavior_lock:${this._currentBehaviorLock.type}`, control };
        if (control.priority === 'P0') return { decision: 'pending', reason: `blocked_by_${control.owner}:${control.reason}`, control };
        if (intent.priority === 'urgent') return { decision: 'execute', reason: 'urgent_intent', control };
        if (this._stateOverride || this._hungerOverride || this._isBeingTreated) {
            return { decision: 'pending', reason: this._stateOverride || (this._hungerOverride ? 'hunger_override' : 'being_treated'), control };
        }
        if (this._taskOverride && this._taskOverride.isActive) {
            if (intent.category === 'external_task') {
                const priorityOrder = { low: 0, normal: 1, high: 2, urgent: 3 };
                const currentPriority = priorityOrder[this._taskOverride.priority || 'normal'] ?? 1;
                const incomingPriority = priorityOrder[intent.priority || intent.action?.priority || 'normal'] ?? 1;
                if (incomingPriority < currentPriority) {
                    return { decision: 'pending', reason: `task_override:${this._taskOverride.taskId || 'active'}`, control };
                }
            }
            return { decision: 'execute', reason: `task_preemptible:${this._taskOverride.taskId || 'active'}`, control };
        }
        return { decision: 'execute', reason: 'intent_allowed', control };
    };

    proto._submitIntent = function(intent, game) {
        const arbitration = this._arbitrateIntent(intent);
        this._lastIntentArbitration = {
            ...arbitration, intentId: intent ? intent.id : null,
            time: game ? game.gameTime : Date.now(),
        };
        const isExternalTask = intent?.category === 'external_task';
        const externalMeta = isExternalTask ? (intent.metadata || {}) : null;
        const applyExternalTaskOverride = deferActivation => {
            const targetLocation = externalMeta?.targetLocation || intent?.action?.target || null;
            if (!targetLocation || typeof this.activateTaskOverride !== 'function') return false;
            return this.activateTaskOverride(
                externalMeta?.taskId || intent.id, targetLocation,
                intent.priority || intent?.action?.priority || 'normal',
                externalMeta?.resourceType || null,
                externalMeta?.stateDesc || externalMeta?.displayDesc || intent?.action?.reason || '执行任务',
                {
                    source: intent.source || 'system',
                    displayDesc: externalMeta?.displayDesc || externalMeta?.stateDesc || intent?.action?.reason || '执行任务',
                    effectKey: externalMeta?.effectKey || intent?.action?.effectKey || null,
                    intentId: intent.id, deferActivation,
                }
            );
        };
        if (arbitration.decision === 'execute') {
            this._pendingIntent = null;
            this._pendingAction = null;
            if (isExternalTask) {
                const accepted = applyExternalTaskOverride(false);
                if (!accepted) {
                    this._logDebug('schedule', `[外部意图执行失败] ${intent?.source || 'system'}:${externalMeta?.taskId || intent?.id || 'no_task'}`);
                    return 'reject';
                }
                this._currentIntent = intent;
                return 'execute';
            }
            this._currentIntent = intent;
            this._executeAction(intent.action, game);
            return 'execute';
        }
        if (arbitration.decision === 'pending') {
            if (isExternalTask) {
                const accepted = applyExternalTaskOverride(true);
                if (!accepted) {
                    this._logDebug('schedule', `[外部意图挂起失败] ${intent?.source || 'system'}:${externalMeta?.taskId || intent?.id || 'no_task'}`);
                    return 'reject';
                }
            }
            this._pendingIntent = intent;
            this._pendingAction = isExternalTask ? null : intent.action;
            this._logDebug('action', `[意图挂起] ${intent.source}:${intent.action?.type || intent.category || 'unknown'} 原因:${arbitration.reason}`);
            return 'pending';
        }
        this._logDebug('action', `[意图拒绝] ${intent?.source || 'unknown'}:${intent?.action?.type || intent?.category || 'unknown'} 原因:${arbitration.reason}`);
        return 'reject';
    };

    proto._submitExternalIntent = function(request = {}) {
        const action = {
            type: 'go_to', target: request.targetLocation || null,
            reason: request.displayDesc || request.stateDesc || '执行任务',
            priority: request.priority || 'normal',
            displayDesc: request.displayDesc || request.stateDesc || '执行任务',
            effectKey: request.effectKey || null,
            sourceTaskId: request.taskId || null,
        };
        const intent = this._createIntentFromAction(action, {
            source: request.source || 'system', category: 'external_task',
            metadata: {
                taskId: request.taskId || null, targetLocation: request.targetLocation || null,
                resourceType: request.resourceType || null, stateDesc: request.stateDesc || null,
                displayDesc: request.displayDesc || null, effectKey: request.effectKey || null,
            },
        });
        const result = this._submitIntent(intent, this.game);
        if (result === 'reject') {
            this._logDebug('schedule', `[外部意图拒绝] ${request.source || 'system'}:${request.taskId || 'no_task'}`);
            return false;
        }
        return true;
    };

    // ---- 场景切换统一入口 ----

    proto._changeScene = function(targetScene, reason) {
        const prevScene = this.currentScene;
        if (prevScene === targetScene) return true;
        // D4 保护
        const ws = this.game && this.game.weatherSystem;
        const isD4 = ws && ws.currentDay === 4;
        if (isD4 && targetScene === 'village' && this._priorityOverride === 'day4_lockdown') {
            console.warn(`[场景切换拦截] ${this.name} D4禁止切换到village, reason=${reason}`);
            if (this.game && this.game.aiModeLogger) {
                const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                this.game.aiModeLogger.log('ANOMALY', `🚫 ${this.name} D4场景切换拦截: ${prevScene}→village, reason=${reason} | ${snap}`);
            }
            if (this.game && this.game.structuredLogger) {
                this.game.structuredLogger.warn('D4_BLOCK', `${this.name} D4场景切换被拦截: ${prevScene}→village`, {
                    npcId: this.id, fromScene: prevScene, toScene: targetScene, reason,
                });
            }
            return false;
        }
        // 弹弹乐自动检测 — 【v5.2修复】改用游戏时间，确保所有播放速度下行为一致
        // 旧方案用Date.now()现实10秒，5×速度下=游戏50分钟（太宽松），1×速度下=游戏10分钟
        // 新方案：统一用游戏时间600秒（=游戏10分钟），无论播放速度如何都是同一个游戏时间窗口
        const gameNow = this.game ? ((this.game.dayCount - 1) * 86400 + this.game.gameTimeSeconds) : Date.now() / 1000;
        if (!this._sceneChangeHistory) this._sceneChangeHistory = [];
        this._sceneChangeHistory.push({ from: prevScene, to: targetScene, t: gameNow, reason });
        // 600游戏秒 = 游戏10分钟窗口
        this._sceneChangeHistory = this._sceneChangeHistory.filter(h => gameNow - h.t < 600);
        // 【v5.8修复】弹弹乐冻结条件优化：
        // 1. 阈值从6提高到8（正常日常作息10分钟内约6次场景切换）
        // 2. 必须检测到A→B→A→B来回弹跳模式才触发冻结
        if (this._sceneChangeHistory.length >= 8) {
            // 检测A→B→A→B来回弹跳模式
            const scenes = this._sceneChangeHistory.map(h => h.to);
            let bouncePatternCount = 0;
            for (let i = 0; i < scenes.length - 3; i++) {
                if (scenes[i] === scenes[i+2] && scenes[i+1] === scenes[i+3] && scenes[i] !== scenes[i+1]) {
                    bouncePatternCount++;
                }
            }
            // 只有检测到至少2次A→B→A→B模式，或者切换次数≥12次（极端情况），才触发冻结
            if (bouncePatternCount >= 2 || this._sceneChangeHistory.length >= 12) {
            const trail = this._sceneChangeHistory.map(h => `${h.from}→${h.to}(${h.reason})`).join(', ');
            console.warn(`⚠️ [弹弹乐检测] ${this.name} 游戏10分钟内场景切换${this._sceneChangeHistory.length}次! 弹跳模式${bouncePatternCount}次! ${trail}`);
            if (this.game && this.game.aiModeLogger) {
                this.game.aiModeLogger.log('ANOMALY', `🏓 ${this.name} 弹弹乐! 游戏10min内${this._sceneChangeHistory.length}次场景切换(弹跳${bouncePatternCount}次): ${trail}`);
            }
            if (this.game && this.game.structuredLogger) {
                this.game.structuredLogger.error('BOUNCE', `${this.name} 弹弹乐! 游戏10min内${this._sceneChangeHistory.length}次场景切换`, {
                    npcId: this.id, trail, count: this._sceneChangeHistory.length, bouncePatternCount,
                });
            }
            this._jitterFreezeTimer = 15;
            this.currentPath = [];
            this.isMoving = false;
            this.state = 'IDLE';
            this._sceneChangeHistory = [];
            // 【v5.5修复】弹弹乐冻结时必须清除**所有**覆盖状态，彻底切断循环
            // 根因链：多个P1系统（actionOverride/stateOverride/taskOverride/hungerOverride）
            // 互相冲突，一个系统把NPC拉到A场景，另一个系统把NPC拉到B场景→弹弹乐
            // 修复：冻结时清除所有覆盖，让NPC在当前场景安静下来
            if (this._actionOverride) {
                this._clearActionOverride();
            }
            if (this._stateOverride) {
                this._clearStateOverride();
            }
            if (this._hungerOverride && !this.isEating) {
                this._hungerOverride = false;
                this._hungerTarget = null;
                this._hungerStuckTimer = 0;
                this._hungerTravelTimer = 0;
            }
            if (this._taskOverride && this._taskOverride.isActive) {
                this.deactivateTaskOverride();
            }
            this._wrongSceneTimer = 0;
            this._pendingEnterScene = null;
            this._pendingEnterKey = null;
            this._walkingToDoor = false;
            this._exitDoorCallback = null;
            // 【v5.5修复】增加恢复期到180秒游戏时间（=3游戏小时），覆盖action-effects和日程系统
            this._bounceRecoveryTimer = 180;
            this.scheduleReached = true;
            // 进入工作驻留状态，阻止日程系统干预
            this._workResidenceActive = true;
            this._workResidenceTimer = 180; // 180秒游戏时间的驻留
            // 【v5.7修复】弹弹乐冻结时，如果NPC体力低，直接强制就地入睡
            // 根因：之前只设置"在原地休息整理"但不入睡→体力不恢复→恢复期结束后exhausted再次触发→弹弹乐复发
            // 这是460个bug（224弹弹乐+242属性卡零）的共同根因
            if (this.stamina < 20) {
                this.isSleeping = true;
                this._forcedSleep = true;
                this._forcedSleepTimer = 0;
                this.stateDesc = '累坏了，就地休息 💤'; // translateStateDesc handles i18n
                this.state = 'SLEEPING';
                this.expression = GST.t('npc_intent.too_tired_rest');
                this.expressionTimer = 6;
                this.mood = GST.t('mood.exhausted');                // 重置日程索引，防止日程系统干预睡眠
                this.currentScheduleIdx = -1;
                this._logDebug && this._logDebug('movement', `[弹弹乐修复] 体力${Math.round(this.stamina)}<20，强制就地入睡，恢复期180秒`);
                if (this.game && this.game.addEvent) {
                    this.game.addEvent(GST.t('sleep.force_sleep', { name: this.name, stamina: Math.round(this.stamina) }));
                }
            } else {
                // 体力充足时，只是留在原地休息
                this.stateDesc = '在原地休息整理';
                this._logDebug && this._logDebug('movement', `[弹弹乐修复] 弹弹乐冻结，已清除所有覆盖状态，进入180秒恢复期+工作驻留`);
            }
            return false;
            } // 闭合 if (bouncePatternCount >= 2 || this._sceneChangeHistory.length >= 12)
        }
        // 审计日志
        if (this.game && this.game.aiModeLogger) {
            this.game.aiModeLogger.logDoor(this.id, this.name, prevScene,
                targetScene === 'village' ? 'out' : 'in',
                `${this.name} 场景切换: ${prevScene}→${targetScene} reason=${reason}`);
        }
        if (this.game && this.game.structuredLogger) {
            this.game.structuredLogger.logSceneChange(this.id, this.name, prevScene, targetScene, reason);
        } else if (this.game && this.game.bugDetector) {
            this.game.bugDetector.recordSceneChange(this.id, targetScene, reason);
        }
        this.currentScene = targetScene;
        return true;
    };

    // ---- 行为控制解析 ----

    proto._resolveBehaviorControl = function() {
        // 【v5.4】P1冲突仲裁暂停：当多个P1同时触发且LLM正在仲裁时，冻结所有行为
        if (this._arbitrationPaused) {
            return { owner: 'arbitration', priority: 'P1_ARBITRATING', reason: 'llm_arbitrating', blocksSchedule: true };
        }
        if (this._priorityOverride) {
            if (this.game && this.game.npcArbiter) {
                const PRIORITY = GST.NPCArbiter.PRIORITY;
                const p0Map = {
                    'day4_lockdown': PRIORITY.EMERGENCY, 'dying': PRIORITY.EMERGENCY,
                    'crazy_emergency': PRIORITY.CRITICAL, 'stamina_critical': PRIORITY.CRITICAL,
                    'health_critical': PRIORITY.CRITICAL, 'medical_urgent': PRIORITY.HIGH,
                    'hunger_critical': PRIORITY.HIGH, 'sleep_urgent': PRIORITY.HIGH,
                };
                const arbiterPriority = p0Map[this._priorityOverride] || PRIORITY.CRITICAL;
                this.game.npcArbiter.requestControl(
                    this.id, `P0:${this._priorityOverride}`, arbiterPriority,
                    this._priorityOverride, {}, `P0优先级覆盖`
                );
            }
            return { owner: 'priority', priority: 'P0', reason: this._priorityOverride, blocksSchedule: true };
        }
        if (this._taskOverride && this._taskOverride.isActive && this._taskOverride.targetLocation) {
            if (this.game && this.game.npcArbiter) {
                this.game.npcArbiter.requestControl(
                    this.id, 'task_system', GST.NPCArbiter.PRIORITY.NORMAL,
                    'task_override', { taskId: this._taskOverride.taskId },
                    `任务系统: ${this._taskOverride.taskId}`
                );
            }
            return { owner: 'task', priority: 'P1', reason: this._taskOverride.taskId || 'task_override', blocksSchedule: true };
        }
        if (this._stateOverride || this._isBeingTreated) {
            return { owner: 'state', priority: 'P1', reason: this._stateOverride || 'being_treated', blocksSchedule: true };
        }
        if (this._hungerOverride && (this._hungerTarget || this.isEating)) {
            return { owner: 'hunger', priority: 'P1', reason: this._hungerTarget ? this._hungerTarget.target : 'eating', blocksSchedule: true };
        }
        if (this._actionOverride) {
            // 【v4.44修复】_actionOverride=true时无条件阻止P2日程接管
            // 根因：v4.43只保护了室内NPC（currentScene!=='village'），但NPC从workshop出门
            // 到village过渡时，currentScene='village'导致条件失效，P2日程接管→导航到dorm→
            // NPC又被_actionOverride拉回workshop→弹弹乐（李婶19次场景切换的根因）
            // 修复：_actionOverride本身就代表"正在执行LLM决策的行动"，无论在哪个场景都不应被P2日程打断
            // _actionOverride有明确的清除机制（行动完成/超时/新决策），不会永久卡住
            return { owner: 'action', priority: 'P1', reason: this._actionTarget ? this._actionTarget.target : (this._workResidenceActive ? 'work_residence' : (this._currentAction?.type || 'action_override')), blocksSchedule: true };
        }
        if (this._isCompanion && this._companionDestination) {
            return { owner: 'action', priority: 'P1', reason: `companion:${this._companionDestination}`, blocksSchedule: true };
        }
        // 无高优先级控制时，释放仲裁器控制权
        if (this.game && this.game.npcArbiter) {
            const current = this.game.npcArbiter.getCurrentController(this.id);
            if (current && current.system.startsWith('P0:')) {
                this.game.npcArbiter.releaseControl(this.id, current.system);
            }
        }
        return { owner: 'schedule', priority: 'P2', reason: 'default_schedule', blocksSchedule: false };
    };

    proto._refreshBehaviorControl = function() {
        const control = this._resolveBehaviorControl();
        this._behaviorOwner = control.owner;
        this._behaviorPriority = control.priority;
        this._behaviorReason = control.reason;
        return control;
    };

    proto._getScheduleControl = function() {
        const control = this._refreshBehaviorControl();
        const canScheduleAct = !control.blocksSchedule;
        return {
            ...control,
            canRetargetFromSchedule: canScheduleAct, canRecoverTimeout: canScheduleAct,
            canRetryScheduleNavigation: canScheduleAct, canUseDoorSafetyNet: canScheduleAct,
            canCorrectArrivalOffset: canScheduleAct, canRunPostArrivalBehavior: canScheduleAct,
        };
    };

    proto._isScheduleBlocked = function() {
        return this._getScheduleControl().blocksSchedule;
    };

    proto._getP0Thresholds = function() {
        const lockPriority = this._getBehaviorLockPriority();
        if (lockPriority >= GST.BEHAVIOR_PRIORITY.BASIC_NEED) {
            return { healthThreshold: 10, staminaThreshold: 5, tempThreshold: 35 };
        }
        return { healthThreshold: 20, staminaThreshold: 20, tempThreshold: 35 };
    };

    proto._checkBehaviorLockTimeout = function() {
        if (!this._currentBehaviorLock) return;
        const elapsed = (Date.now() - this._currentBehaviorLock.startTime) / 1000;
        if (elapsed > 120) {
            const lockType = this._currentBehaviorLock.type;
            const lockPriority = this._currentBehaviorLock.priority;
            console.warn(`[行为锁超时] ${this.name} 行为锁 ${lockType}(${lockPriority}) 持续${elapsed.toFixed(0)}秒真实时间，强制释放`);
            this._logDebug('override', `[行为锁超时] ${lockType}(${lockPriority}) 持续${elapsed.toFixed(0)}秒，强制释放`);
            this._currentBehaviorLock = null;
            this._pendingBehaviors = [];
        }
    };

    // ---- 清除所有覆盖 ----

    proto._clearAllOverrides = function() {
        console.warn(`[${this.name}] _clearAllOverrides() 执行，清除所有覆盖状态`);
        this._logDebug('override', `[兜底] _clearAllOverrides 清除所有覆盖状态`);
        this._hungerOverride = false;
        this._hungerTarget = null;
        this._hungerStuckTimer = 0;
        this._hungerTravelTimer = 0;
        this.isEating = false;
        this.eatingTimer = 0;
        this._clearStateOverride();
        this._clearActionOverride();
        this._resourceGatherOverride = false;
        this._resourceGatherTarget = null;
        this._resourceGatherType = null;
        this._resourceGatherTravelTimer = 0;
        if (this._taskOverride) { this._taskOverride.isActive = false; }
        this._currentBehaviorLock = null;
        this._pendingBehaviors = [];
        this._activeOverride = 'none';
        this.currentScheduleIdx = -1;
        this.scheduleReached = false;
    };

})();
