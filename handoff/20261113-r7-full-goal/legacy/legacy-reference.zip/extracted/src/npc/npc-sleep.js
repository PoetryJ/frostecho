/**
 * 福音镇 - NPC 睡眠系统 Mixin
 * 职责：睡眠状态管理、床位分配、入睡/起床逻辑
 * 从 npc-schedule.js 拆分，遵循SRP原则（单一职责）
 * 挂载到 GST.NPC.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;

    /**
     * 获取NPC专属床位坐标
     * @returns {{ x: number, y: number, scene: string }|null}
     */
    proto._getBedLocation = function() {
        const sched = this.scheduleTemplate;
        if (sched) {
            for (const s of sched) {
                if (s.action === 'STAY' && s.target && s.target.includes('_bed_')) {
                    const loc = GST.SCHEDULE_LOCATIONS[s.target];
                    if (loc) return loc;
                }
            }
        }
        const dormMap = this.game && this.game.mapRegistry && this.game.mapRegistry.maps[this.homeName];
        if (dormMap && dormMap.getRoomForNPC) {
            const room = dormMap.getRoomForNPC(this.name);
            if (room) return { x: room.x, y: room.y, scene: this.homeName };
        }
        return GST.SCHEDULE_LOCATIONS[this.homeName + '_inside'] || null;
    };

    proto._updateSleepState = function(game) {
        const hour = game.getHour();

        // 【兜底硬保护】NPC在village(户外)绝对不能处于睡眠状态
        if (this.isSleeping && this.currentScene === 'village') {
            console.warn(`[户外睡觉兜底] ${this.name} 在village处于isSleeping状态，强制清除并导航回家`);
            this.isSleeping = false;
            this.state = 'IDLE';
            this._forcedSleep = false;
            const homeDoorKey = this.homeName + '_door';
            const homeDoorLoc = GST.SCHEDULE_LOCATIONS[homeDoorKey];
            if (homeDoorLoc && !this.isMoving && this.currentPath.length === 0) {
                this._pendingEnterScene = this.homeName;
                this._pendingEnterKey = homeDoorKey;
                this._pathTo(homeDoorLoc.x, homeDoorLoc.y, this.game);
            }
            return;
        }

        // 找到当前时段的日程
        const sched = this.scheduleTemplate;
        let currentAction = null;
        for (const s of sched) {
            if (s.start <= s.end) {
                if (hour >= s.start && hour < s.end) { currentAction = s; break; }
            } else {
                if (hour >= s.start || hour < s.end) { currentAction = s; break; }
            }
        }

        const isSleepAction = currentAction && (
            (currentAction.action === 'STAY' && currentAction.target && currentAction.target.includes('_bed_')) ||
            (currentAction.action === 'STAY' && currentAction.desc && currentAction.desc.includes('休息') && currentAction.desc.includes('睡觉'))
        );
        const isBedtimeNow = this._isBedtime(hour);
        const shouldSleep = (isSleepAction || isBedtimeNow) && this._isAtHome();

        // 深夜饥饿覆盖清除
        if (isBedtimeNow && !this._isAtHome() && this._hungerOverride) {
            this._hungerOverride = false;
            this._hungerTarget = null;
            this._hungerStuckTimer = 0;
            this._hungerTravelTimer = 0;
            this.isEating = false;
            this.currentPath = [];
            this.isMoving = false;
            this.currentScheduleIdx = -1;
            this.scheduleReached = false;
        }

        // 就寝时间回宿舍导航
        const _sleepBlockingOverrides = ['medical_urgent', 'health_critical', 'hypothermia', 'day4_lockdown'];
        const hasBlockingSleepPriority = (this._priorityOverride && _sleepBlockingOverrides.includes(this._priorityOverride))
            || (this._taskOverride && this._taskOverride.isActive);

        if (isBedtimeNow && !this._isAtHome() && !this.isSleeping && this.state !== 'CHATTING' && !hasBlockingSleepPriority) {
            if (!this.isMoving && this.currentPath.length === 0) {
                if (this.currentScene === 'village') {
                    const homeDoorKey = this.homeName + '_door';
                    const homeDoorLoc = GST.SCHEDULE_LOCATIONS[homeDoorKey];
                    if (homeDoorLoc) {
                        this._pendingEnterScene = this.homeName;
                        this._pendingEnterKey = homeDoorKey;
                        this._pathTo(homeDoorLoc.x, homeDoorLoc.y, this.game);
                    }
                } else if (this.currentScene !== this.homeName && !hasBlockingSleepPriority) {
                    const bedLoc = this._getBedLocation();
                    if (bedLoc) {
                        const reason = this._priorityOverride ? `清除${this._priorityOverride}` : '就寝时间';
                        console.log(`[就寝传送] ${this.name} 从${this.currentScene}直接传送到宿舍${this.homeName}（${reason}）`);
                        if (this.game && this.game.aiModeLogger) {
                            this.game.aiModeLogger.pushNpcEvent(this.id, `就寝时间到，从${this.currentScene}直接传送回宿舍（${reason}）`);
                        }
                        if (this._priorityOverride && !_sleepBlockingOverrides.includes(this._priorityOverride)) {
                            this._priorityOverride = null;
                            this._behaviorPriority = null;
                        }
                        this._restCooldownTimer = 0;
                        this._teleportTo(this.homeName, bedLoc.x * GST.TILE, bedLoc.y * GST.TILE);
                    }
                }
            }
        }

        // 入睡逻辑
        if (shouldSleep && !this.isSleeping && this.state !== 'CHATTING' && !this._hungerOverride) {
            if (this.currentScene === 'village') {
                console.warn(`[户外入睡阻止] ${this.name} 在village(户外)触发入睡条件但被阻止，强制导航回家`);
                const homeDoorKey = this.homeName + '_door';
                const homeDoorLoc = GST.SCHEDULE_LOCATIONS[homeDoorKey];
                if (homeDoorLoc && !this.isMoving && this.currentPath.length === 0) {
                    this._pendingEnterScene = this.homeName;
                    this._pendingEnterKey = homeDoorKey;
                    this._pathTo(homeDoorLoc.x, homeDoorLoc.y, this.game);
                }
                return;
            }
            const bedLoc = this._getBedLocation();
            if (bedLoc) {
                this.x = bedLoc.x * GST.TILE;
                this.y = bedLoc.y * GST.TILE;
                this._logDebug('sleep', `入睡传送到床位(${bedLoc.x},${bedLoc.y})`);
            }
            this.isSleeping = true;
            this.state = 'SLEEPING';
            this.stateDesc = '正在睡觉 💤';
            this.currentPath = [];
            this.isMoving = false;
            this.expression = '';
            this._logDebug('sleep', `开始睡觉(日程) 体力:${Math.round(this.stamina)} San:${Math.round(this.sanity)}`);
            if (this.game && this.game.aiModeLogger) {
                const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                this.game.aiModeLogger.log('SLEEP_START', `${this.name} 开始睡觉(日程) | ${snap} | ${this.currentScene || '?'}`);
                this.game.aiModeLogger.pushNpcEvent(this.id, `开始睡觉(日程) | ${snap}`);
            }
        } else if (!shouldSleep && this.isSleeping) {
            // 防震荡保护
            const wakeHour = game.getHour();
            if (this._dayChangeWhileSleeping && wakeHour >= 0 && wakeHour < 6 && this._isAtHome()) {
                this._logDebug('sleep', `[防震荡] 日切换后0-6点仍在家中，忽略起床信号 hour:${wakeHour}`);
                this._dayChangeWhileSleeping = false;
                return;
            }
            if (!this._forcedSleep && this.stamina < 20 && this._isAtHome()) {
                this._forcedSleep = true;
                this._logDebug('sleep', `[防震荡] 体力仍低(${Math.round(this.stamina)})且在宿舍，维持睡眠`);
                return;
            }
            // 强制睡眠保护
            if (this._forcedSleep) {
                const staminaOk = this.stamina >= 40;
                const timeoutOk = this._forcedSleepTimer > 7200;
                const fatalOverride = (this.bodyTemp !== undefined && this.bodyTemp < 33);
                if (!staminaOk && !timeoutOk && !fatalOverride) {
                    this._logDebug('sleep', `[强制睡眠] 阻止起床 体力:${Math.round(this.stamina)} 健康:${Math.round(this.health)} 已睡:${Math.round(this._forcedSleepTimer)}s`);
                    return;
                }
                const reason = fatalOverride ? '严重失温紧急穿透' : staminaOk ? `体力恢复到${Math.round(this.stamina)}` : `安全超时(${Math.round(this._forcedSleepTimer)}s)`;
                this._logDebug('sleep', `[强制睡眠结束] ${reason}`);
                this._forcedSleep = false;
                this._forcedSleepTimer = 0;
                this._wasForcedSleep = true;
            }
            // 正常起床
            this._dayChangeWhileSleeping = false;
            const wakeReason = this._wasForcedSleep ? '强制睡眠恢复' :
                (!isSleepAction && !isBedtimeNow) ? '就寝时段结束' :
                !this._isAtHome() ? '不在家中' : '未知原因';
            if (this.game && this.game.aiModeLogger) {
                const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                this.game.aiModeLogger.log('SLEEP_END', `${this.name} 醒来(${wakeReason}) | ${snap} | ${this.currentScene || '?'}`);
                this.game.aiModeLogger.pushNpcEvent(this.id, `醒来(${wakeReason}) | ${snap}`);
            }
            this.isSleeping = false;
            this.state = 'IDLE';
            this.mood = GST.t('mood.calm');
            if (this._wasForcedSleep) {
                this.stateDesc = '休息好了'; // translateStateDesc handles i18n
                this.expression = GST.t('npc_sleep.feel_refreshed');
                this._wasForcedSleep = false;
            } else if (wakeHour >= 5 && wakeHour < 9) {
                this.stateDesc = '刚起床'; // translateStateDesc handles i18n
                this.expression = GST.t('npc_sleep.new_day');
            } else if (wakeHour >= 9 && wakeHour < 18) {
                this.stateDesc = '小憩醒来'; // translateStateDesc handles i18n
                this.expression = GST.t('npc_sleep.feel_bit_better');
            } else {
                this.stateDesc = '醒了过来'; // translateStateDesc handles i18n
                this.expression = GST.t('npc_sleep.woke_up');
            }
            this.expressionTimer = 5;
            this.sleepZTimer = 0;
            if (game.addEvent) {
                game.addEvent(GST.t('sleep.woke_up', { name: this.name, stateDesc: this.stateDesc }));
            }
            // 睡醒后恢复会议情报
            if (this._councilTask && this._councilTaskTime) {
                const EXPIRY_MS = 10 * 60 * 1000;
                if (Date.now() - this._councilTaskTime < EXPIRY_MS && this._councilStateDesc) {
                    this._actionDecisionCooldown = 0;
                    console.log(`[Council恢复] ${this.name} 睡醒后重新看见会议分工情报: ${this._councilTask}`);
                }
            }
        }
    };

})();
