/**
 * 福音镇 - NPC天气响应与安全检查
 * 从 npc-schedule.js 拆分，遵循SRP原则
 * 挂载到 GST.NPC.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;


    /** 场景名 → 中文标签 */;

    proto._getWeatherAdjustedEntry = function(entry, game) {
        if (!entry) return entry;
        if (!NPC.OUTDOOR_TARGETS.has(entry.target)) return entry;

        // 【v2.0修复】不仅检查下雨，还要检查极端天气禁止外出
        // 【v3.0修复】增加极端低温检查：大雪天虽然canGoOutside=true，但实际温度极低时也不应去户外
        const ws = game.weatherSystem;
        const isRaining = game.isRaining();
        const cannotGoOutside = ws && !ws.canGoOutside();
        // 室外有效温度低于-20°C时，也视为不宜外出（覆盖大雪天等场景）
        const effectiveTemp = ws ? ws.getEffectiveTemp() : 0;
        const isTooCold = effectiveTemp < -20;

        if (!isRaining && !cannotGoOutside && !isTooCold) return entry;

        // 下雨或极端天气 + 户外目标 → 替换为室内
        // 用 NPC id + 时段 start 做种子，保证同一时段内替代目标稳定不变
        const seed = (this.id.charCodeAt(0) + entry.start) % NPC.RAIN_INDOOR_ALTERNATIVES.length;
        const alt = NPC.RAIN_INDOOR_ALTERNATIVES[seed];
        return {
            ...entry,
            target: alt.target,
            desc: alt.desc,
            _rainAdjusted: true, // 标记为雨天替换
        };
    }


    /**
     * 根据精神状态调整日程
     * 当NPC精神状态较差时，将户外日程替换为室内日程
     * 【v4.2修复】让苏岩等NPC能自主意识到精神状态差，避免去户外工作
     */
    proto._getSanityAdjustedEntry = function(entry, game) {
        if (!entry) return entry;
        if (!NPC.OUTDOOR_TARGETS.has(entry.target)) return entry;

        // 精神状态检查：San<40时不应去户外工作
        if (this.sanity === undefined || this.sanity >= 40) return entry;

        // 精神状态差 + 户外目标 → 替换为室内休息
        const sanityDesc = this.sanity < 25 
            ? `精神濒临崩溃(San:${Math.round(this.sanity)})，留在室内休养`
            : `精神状态不佳(San:${Math.round(this.sanity)})，留在室内休息`;
        
        return {
            ...entry,
            target: this.homeName + '_door',
            desc: sanityDesc,
            _sanityAdjusted: true, // 标记为精神状态替换
        };
    }


    /**
     * 组合调整函数：依次应用天气调整和精神状态调整
     * 【v4.2新增】统一入口，确保所有日程都经过完整的调整流程
     */
    proto._getAdjustedEntry = function(entry, game) {
        if (!entry) return entry;
        // 先应用天气调整
        let adjusted = this._getWeatherAdjustedEntry(entry, game);
        // 再应用精神状态调整（如果天气没有替换，或者替换后仍是户外）
        adjusted = this._getSanityAdjustedEntry(adjusted, game);
        return adjusted;
    }


    /** 哲学家/思考型角色主动发起对话 */;

    proto._updateRainResponse = function(game) {
        if (!game.isRaining()) {
            this.isSeekingShelter = false;
            return;
        }

        // 【v4.40核心原则修复】下雨避雨改为情报注入，让LLM自主决策
        // 设计原则：系统是情报提供者，不是决策辅助者。
        // 下雨不会立即致命，NPC可以自己决定是否避雨、去哪避雨
        if (this.currentScene === 'village' && !this.hasUmbrella && !this.isSeekingShelter) {
            this.isSeekingShelter = true; // 标记已通知，防止重复通知
            this._notifyEmergency(`外面正在下雨！你没有伞，淋雨会降低体温和健康。可以去最近的室内建筑避雨，也可以选择冒雨继续当前任务。`);
            this._logDebug('schedule', `[情报注入] 下雨中，已注入避雨情报让LLM自主决策`);
        }
    };


    /**
     * 统一户外安全门控 — 所有出门路径必须经过此检查
     * 基于实际属性值判断，而非定时器/P0类型枚举
     * 阈值设计：P0触发阈值 < P0清除阈值 < 安全出门阈值（三级缓冲）
     */
    proto.canSafelyGoOutdoor = function(game) {
        // 【根治弹弹乐】第4天全天锁定期间，绝对不允许出门（最高优先级检查）
        if (this._priorityOverride === 'day4_lockdown') return false;
        // P0紧急状态自身的导航不受限（如hypothermia需出门去最近室内）
        if (this._behaviorPriority === 'P0') return true;
        // 【v4.40核心原则修复】只在出门=立即死亡时才硬性阻止
        // 设计原则：系统是情报提供者，不是决策辅助者。
        // 户外风险信息通过prompt传递给LLM，由LLM自主判断是否出门。
        if (this.bodyTemp !== undefined && this.bodyTemp < 34) return false; // 严重失温，出门必死
        // 天气检查（暴风雪等极端天气）
        const ws = game && game.weatherSystem;
        if (ws && !ws.canGoOutside()) return false;
        // 户外冷却兜底
        if (this._outdoorCooldown > 0) return false;
        return true;
    };


    // ---- 睡眠状态管理 ----;

    proto._isAtHome = function() {
        // NPC必须真正在公寓/家的室内场景才算"在家"，不能在村庄路上就睡
        // NPC在自己宿舍中即为在家
        if (this.currentScene === this.homeName) {
            return true;
        }
        return false;
    }


    /**
     * 判断当前时间是否已经过了这个NPC的就寝时间
     * 使用NPC配置中的bedtime字段（如老钱21点、陆辰0:30）
     * @param {number} hour - 当前游戏小时（整数，getHour()返回值）
     * @returns {boolean}
     */;

    proto._isBedtime = function(hour) {
        const bedtime = this.config.bedtime || 23; // 默认23点
        // bedtime可能跨午夜：如bedtime=0表示0:00, bedtime=1表示1:00
        if (bedtime >= 12) {
            // 睡觉时间在当天晚上（如21、22、23）
            return hour >= bedtime || hour < 6;
        } else {
            // 睡觉时间在凌晨（如0、1）
            return (hour >= bedtime && hour < 6) || hour >= 23; // 23点后肯定该往回走了
        }
    }


    proto._getMyRoomKey = function() {
        // 新系统下直接返回宿舍内部位置
        return this.homeName + '_inside';
    }


    /**
     * 紧急情报注入便捷方法 — 包装 _triggerEmergencyDecision
     * 用于日程模块中只需传递消息、不需要显式传game的场景
     */
    proto._notifyEmergency = function(message) {
        if (typeof this._triggerEmergencyDecision === 'function') {
            this._triggerEmergencyDecision(message, this.game);
        }
    };

})();
