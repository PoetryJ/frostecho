/**
 * 福音镇 - NPC状态覆盖与治疗
 * 从 npc-attributes.js 拆分，遵循SRP原则
 * 挂载到 GST.NPC.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;


    // ============ 目标系统：进度检测 + 奖励发放 ============;

    proto._checkStateOverrideArrival = function(dt, game) {
        if (!this._stateOverride || !this._stateOverrideTarget) return;

        // 【关键修复】CHATTING状态下暂停状态覆盖的到达检测和传送，防止对话中被传送走导致隔空聊天
        if (this.state === 'CHATTING') return;

        const targetKey = this._stateOverrideTarget.target;

        // 根据覆盖类型决定到达后的行为
        if (this._stateOverride === 'exhausted') {
            // 目标：回宿舍 → 到达后直接入睡
            if (this.currentScene === this.homeName) {
                // 检查是否到达了床位（使用NPC专属床位坐标）
                const bedLoc = this._getBedLocation ? this._getBedLocation() : GST.SCHEDULE_LOCATIONS[this.homeName + '_inside'];
                if (bedLoc) {
                    const pos = this.getGridPos();
                    const dist = Math.abs(pos.x - bedLoc.x) + Math.abs(pos.y - bedLoc.y);
                    if (dist <= 3) {
                        // 到达房间 → 强制入睡，并修正坐标到精确床位
                        this._clearStateOverride();
                        // 【修复】修正坐标到精确床位位置
                        this.x = bedLoc.x * GST.TILE;
                        this.y = bedLoc.y * GST.TILE;
                        this.isSleeping = true;
                        this._forcedSleep = true;  // 【标记强制睡眠】防止被日程起床逻辑误唤醒
                        this._forcedSleepTimer = 0;
                        this.stateDesc = '累坏了，倒头就睡';
                        this._logDebug('sleep', `累坏倒头就睡 体力:${Math.round(this.stamina)} San:${Math.round(this.sanity)}`);
                        // AI模式日志：累坏入睡
                        if (this.game && this.game.aiModeLogger) {
                            const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                            this.game.aiModeLogger.log('SLEEP_START', `${this.name} 累坏倒头就睡 | ${snap} | ${this.currentScene || '?'}`);
                            this.game.aiModeLogger.pushNpcEvent(this.id, `😴 累坏倒头就睡 | ${snap}`);
                        }
                        this.expression = 'Zzz...';
                        this.expressionTimer = 8;
                        this.mood = GST.t('mood.exhausted');
                        // 重置日程索引
                        this.scheduleReached = false;
                        if (game.addEvent) {
                            game.addEvent(GST.t('npc_state.exhausted_sleep', { name: this.name, stamina: Math.round(this.stamina) }));
                        }
                        return;
                    }
                }
                // 在宿舍但还没到床位 → 导航到NPC专属床位
                if (!this.isMoving && this.currentPath.length === 0) {
                    const bedLoc2 = this._getBedLocation ? this._getBedLocation() : GST.SCHEDULE_LOCATIONS[this.homeName + '_inside'];
                    if (bedLoc2) {
                        this._pathTo(bedLoc2.x, bedLoc2.y, game);
                    }
                }
                return;
            }
        } else if (this._stateOverride === 'sick' || this._stateOverride === 'mental') {
            // 目标：去医疗站 → 到达后开始治疗
            if (this.currentScene === 'medical') {
                // 【v4.1修复】心理咨询需要苏医生在场才能开始
                if (this._stateOverride === 'mental') {
                    const suDoc = game.npcs.find(n => n.id === 'su_doctor');
                    const suDocHere = suDoc && suDoc.currentScene === 'medical' && !suDoc.isDead && !suDoc.isSleeping;
                    if (!suDocHere) {
                        // 苏医生不在 → 取消咨询，等下次再来
                        this.expression = GST.t('npc_state.doctor_not_here');
                        this.expressionTimer = 6;
                        this.mood = GST.t('mood.disappointed');
                        this._clearStateOverride();
                        this.currentScheduleIdx = -1;
                        this.scheduleReached = false;
                        if (game.addEvent) {
                            game.addEvent(GST.t('npc_state.doctor_absent', { name: this.name }));
                        }
                        return;
                    }
                }
                this._startTreatment(game);
                return;
            }
        }

        // 还在路上：检查是否卡住
        if (this.isMoving || this.currentPath.length > 0 || this._walkingToDoor) {
            this._stateOverrideStuckTimer = 0;
            return;
        }

        // 【v4.5修复】出门保护期内不重新导航，防止刚出门就被重新导航→进错门→死循环
        if (this._indoorEntryProtection > 0) {
            return;
        }

        // 不在移动也没到目标 → 可能卡住了
        const speedMult = (game && game.speedOptions) ? game.speedOptions[game.speedIdx] : 1;
        const realDt = speedMult > 0 ? dt / speedMult : dt;
        this._stateOverrideStuckTimer += realDt;
        if (this._stateOverrideStuckTimer > 3) {
            this._stateOverrideStuckTimer = 0;
            this._navigateToScheduleTarget(targetKey, game);
        }

        // 【v4.42修复】超时处理：绝不传送，触发紧急自我对话让AI自主决策
        this._stateOverrideTravelTimer += realDt;
        if (this._stateOverrideTravelTimer > 15) {
            this._stateOverrideTravelTimer = 0;
            // 重新导航一次
            this._navigateToScheduleTarget(targetKey, game);
            // 触发紧急自我对话，让AI自己决定怎么办
            const overrideType = this._stateOverride;
            const healthInfo = `health:${Math.round(this.health)}, stamina:${Math.round(this.stamina)}, bodyTemp:${this.bodyTemp !== undefined ? Math.round(this.bodyTemp) : '未知'}`;
            const reason = overrideType === 'exhausted'
                ? `【紧急】我体力严重不足(${healthInfo})，需要回${this.homeName}休息，但15秒内没能到达目的地。我现在在${this.currentScene}，需要重新规划路线或寻求帮助。`
                : `【紧急】我身体状况危急(${healthInfo})，需要去医疗站治疗，但15秒内没能到达。我现在在${this.currentScene}，需要重新规划路线或寻求帮助。`;
            this._triggerEmergencyDecision(reason, game);
            this._logDebug && this._logDebug('override', `[状态覆盖] 超时15秒，重新导航+触发紧急决策 target=${targetKey}`);
        }
    }


    // ============ 状态驱动行为覆盖系统 ============
    // 当NPC状态极差时，打断日程执行紧急行为（类似饥饿覆盖机制）

    /** 每帧检查是否需要触发状态覆盖行为 */;

    proto._clearStateOverride = function() {
        const wasType = this._stateOverride;
        this._stateOverride = null;
        this._stateOverrideTarget = null;
        this._stateOverrideStuckTimer = 0;
        this._stateOverrideTravelTimer = 0;
        this._stateOverrideMaxTimer = 0;
        // 【覆盖快照】清除时重置_activeOverride并检查pending队列
        if (wasType && this._activeOverride === 'state') {
            const old = this._activeOverride;
            this._activeOverride = 'none';
            this._logDebug('override', `[覆盖切换] ${old} → none（原因: 状态覆盖(${wasType})清除）`);
            this._executePendingBehavior();
        }
    }


    /**
     * 状态覆盖行为完成的统一回调
     * 按需求6.3的顺序执行清理
     */;

    proto._onStateOverrideComplete = function() {
        const type = this._stateOverride;
        this._logDebug('override', `[行为完成] 状态覆盖(${type})完成`);
        // 清除所有stateOverride相关字段
        this._clearStateOverride();
        // 重置日程
        this.currentScheduleIdx = -1;
        this.scheduleReached = false;
    }

    // [已拆分到 npc-eating.js] _triggerHungerBehavior
    /** 根据时间和偏好选择吃饭地点 */;

    proto._triggerStateOverride = function(type, game) {
        // 【v5.5修复】弹弹乐恢复期内不触发新的状态覆盖
        // 根因：恢复期内触发sick/exhausted→导航到medical/dorm→跨场景→弹弹乐复发
        if (this._bounceRecoveryTimer > 0) {
            this._logDebug && this._logDebug('override', `[弹弹乐恢复期] 恢复期中，延迟状态覆盖(${type})触发`);
            return;
        }
        // 【出门过程保护】NPC正在出门时不触发状态覆盖（致命紧急除外）
        if (this._walkingToDoor) {
            if (this.health >= 10 && (this.bodyTemp === undefined || this.bodyTemp >= 33)) {
                this._logDebug && this._logDebug('override', `[出门保护] 正在出门中，延迟状态覆盖(${type})触发`);
                return;
            }
        }
        // 【覆盖快照】设置_activeOverride
        const oldOverride = this._activeOverride;
        this._activeOverride = 'state';
        if (oldOverride !== 'state') {
            this._logDebug('override', `[覆盖切换] ${oldOverride} → state（原因: ${type}）`);
        }
        this._stateOverride = type;
        this._stateOverrideStuckTimer = 0;
        this._stateOverrideTravelTimer = 0;
        this._stateOverrideMaxTimer = 0; // 超时保护计时器
        this._stateOverrideCooldown = 30; // 30秒冷却，避免反复触发

        // 【修复】清除社交走路目标（状态覆盖优先于社交意愿）
        if (this._chatWalkTarget) {
            this._logDebug('chat', `状态覆盖(${type})打断了走向聊天目标的路径`);
            this._chatWalkTarget = null;
        }

        // 【v5.4重构】不再直接清除其他P1覆盖（actionOverride/hungerOverride/taskOverride）
        // 而是让DecisionConflictResolver在下一个检测周期发现多P1冲突，
        // 暂停NPC行为，调用LLM动态仲裁哪个P1优先
        // 只清除工作驻留（这不是P1级别的覆盖，只是行动的附属状态）
        if (this._workResidenceActive) {
            this._workResidenceActive = false;
            this._workResidenceTimer = 0;
            this._logDebug('override', `[状态覆盖] ${type}触发，清除工作驻留`);
        }

        // 清除当前移动路径
        this.currentPath = [];
        this.isMoving = false;
        this._pendingEnterScene = null;

        let target, desc, expr, moodStr;
        switch (type) {
            case 'exhausted':
                target = { target: this.homeName + '_door', desc: '回宿舍休息' };
                desc = '累坏了，赶紧回家休息';
                expr = this.stamina < 5 ? '快…快撑不住了…' : '太累了，得回去歇歇…';
                moodStr = '疲惫';
                break;
            case 'sick':
                target = { target: 'medical_door', desc: '去医疗站看病' };
                desc = '身体不舒服，去医疗站看看';
                expr = this.health < 15 ? '难受…得赶紧看医生…' : '有点不舒服，去医疗站检查一下';
                moodStr = '难受';
                break;
            case 'mental':
                target = { target: 'medical_door', desc: '去医疗站看心理' };
                desc = '精神状态不好，去找医官聊聊';
                expr = '脑子里乱糟糟的…去找苏岩聊聊吧';
                moodStr = '焦虑';
                break;
            default:
                this._stateOverride = null;
                return;
        }

        this._stateOverrideTarget = target;
        this.stateDesc = desc;
        this.mood = moodStr;
        this.expression = expr;
        this.expressionTimer = 6;

        const emojiMap = { exhausted: '😴', sick: '🤒', mental: '😰' };
        if (game.addEvent) {
            // 【v5.8.17】对desc进行i18n翻译，避免英文模式下显示中文
            const translatedDesc = GST.i18n?.translateStateDesc ? GST.i18n.translateStateDesc(desc) : desc;
            game.addEvent(GST.t('npc_state.state_override', { emoji: emojiMap[type], name: this.displayName || this.name, desc: translatedDesc, stamina: Math.round(this.stamina), health: Math.round(this.health), san: Math.round(this.sanity) }));
        }

        // 【Debug日志】记录状态覆盖触发
        this._logDebug('override', `触发状态覆盖:${type} → ${desc} (体力:${Math.round(this.stamina)} 健康:${Math.round(this.health)} San:${Math.round(this.sanity)})`);

        // 导航到目标
        this._navigateToScheduleTarget(target.target, game);
        this.scheduleReached = false;
    }


    proto._checkAutoMedkit = function(dt, game) {
        const gameSeconds = dt * (game.timeSpeed || 60);

        // 更新当前NPC的急救包使用个人冷却（确保非medical_heal分支的NPC冷却也能递减）
        if (this._medkitUseCooldown > 0) this._medkitUseCooldown -= gameSeconds;

        // 更新检查冷却计时
        if (this._medkitCheckCooldown > 0) {
            this._medkitCheckCooldown -= gameSeconds;
            return;
        }

        // 无急救包则跳过
        if (!game._medkitCount || game._medkitCount <= 0) {
            return;
        }

        // 遍历所有存活NPC，找到健康<60且无个人冷却的NPC
        const criticalNpcs = game.npcs.filter(n =>
            !n.isDead && n.health < 60 && !(n._medkitUseCooldown > 0)
        ).sort((a, b) => a.health - b.health);

        if (criticalNpcs.length === 0) return;

        const target = criticalNpcs[0];

        // 消耗急救包
        game._medkitCount--;

        // 使用者为苏岩（medical_treatment专长）时恢复翻倍
        const isMedicalExpert = !!(this.config.specialties && this.config.specialties.medical_treatment);
        const healAmount = isMedicalExpert ? 50 : 25;
        target.health = Math.min(100, target.health + healAmount);

        // 设置目标NPC的个人冷却（防止连续消耗）
        target._medkitUseCooldown = 30;
        // 设置检查者的全局检查冷却
        this._medkitCheckCooldown = 10;

        // 生成事件日志和气泡文本
        if (game.addEvent) {
            game.addEvent(GST.t('npc_state.medkit_used', { name: this.name, target: target.name, amount: healAmount, health: Math.round(target.health), remaining: game._medkitCount }));
        }
        this.expression = GST.t('npc_state.used_medkit', { name: target.displayName || target.name });
        this.expressionTimer = 3;
        this._logDebug('action', `[急救包] 全局检查：为${target.name}使用急救包，恢复+${healAmount}，剩余${game._medkitCount}`);

        // 急救包耗尽且有重伤NPC时发出警告
        if (game._medkitCount <= 0) {
            const severeNpcs = game.npcs.filter(n => !n.isDead && n.health < 30);
            if (severeNpcs.length > 0 && game.addEvent) {
                game.addEvent(GST.t('npc_state.medkit_shortage'));
            }
        }
    }

    // [已拆分到 npc-eating.js] _startEating
    // ============ 资源采集覆盖系统 ============
    // 参考饥饿覆盖(_hungerOverride)模式：资源紧缺时自动派NPC去采集

    /** 检查是否需要触发资源采集覆盖 */;

    proto._startTreatment = function(game) {
        this._isBeingTreated = true;
        this._treatmentTimer = 15; // 治疗持续15真实秒
        this.currentPath = [];
        this.isMoving = false;

        const isMental = (this._stateOverride === 'mental');
        this.stateDesc = isMental ? '正在接受心理咨询' : '正在看病治疗'; // translateStateDesc handles i18n
        // 【v4.1修复】根据苏医生是否在场显示不同文本，苏岩自己不说"跟自己聊"
        if (isMental) {
            const suDoc = game.npcs.find(n => n.id === 'su_doctor');
            const suDocHere = suDoc && suDoc.currentScene === this.currentScene && !suDoc.isDead;
            this.expression = suDocHere ? GST.t('npc_state.chatting_with_doctor') : GST.t('npc_state.resting_at_medical');
        } else {
            this.expression = GST.t('npc_state.receiving_treatment');
        }
        this.expressionTimer = 8;
        this.mood = GST.t('mood.hopeful');

        if (game.addEvent) {
            game.addEvent(GST.t('npc_state.start_treatment', { name: this.name, treatType: isMental ? GST.t('npc_state.consult') : GST.t('npc_state.medical') }));
        }
    }


    // ============ 发呆兜底检测系统 ============

    /**
     * 全局发呆兜底检测与自动恢复
     * 当NPC连续10秒处于"无任何系统驱动"的空闲状态时，强制恢复行为
     */;

    proto._finishTreatment = function(game) {
        const isMental = (this._stateOverride === 'mental');

        if (isMental) {
            // 心理咨询：恢复San值
            const sanBefore = this.sanity;
            this.sanity = Math.min(100, this.sanity + 30);
            this.mood = GST.t('mood.calm');
            this.expression = this.id === 'su_doctor' ? GST.t('npc_state.self_adjusted') : GST.t('npc_state.feel_better_thanks');
            this.stateDesc = '咨询结束，精神好多了';
            this._logDebug('sanity', `💊 心理咨询结束! San: ${Math.round(sanBefore)}→${Math.round(this.sanity)} (+${Math.round(this.sanity - sanBefore)})`);
        } else {
            // 看病：恢复健康值，治愈疾病
            this.health = Math.min(100, this.health + 35);
            this.isSick = false;
            this.sickTimer = 0;
            this.mood = GST.t('mood.content');
            this.expression = GST.t('npc_state.feel_better_after_doctor');
            this.stateDesc = '看完病了，感觉好多了';
        }

        this.expressionTimer = 6;
        this._isBeingTreated = false;
        this._treatmentTimer = 0;

        // 找到苏医生（如果在同一场景），双方关系加成
        const doctor = game.npcs.find(n => n.id === 'su_doctor' && n.currentScene === this.currentScene);
        if (doctor && doctor.id !== this.id) {
            this.changeAffinity(doctor.id, 5);
            doctor.changeAffinity(this.id, 3);
            if (game.addEvent) {
                game.addEvent(GST.t('npc_state.doctor_relationship', { name: this.name, treatType: isMental ? GST.t('npc_state.consult') : GST.t('npc_state.medical') }));
            }
        }

        if (game.addEvent) {
            game.addEvent(GST.t('npc_state.treatment_done', { name: this.name, treatType: isMental ? GST.t('npc_state.consult') : GST.t('npc_state.treat'), health: Math.round(this.health), san: Math.round(this.sanity) }));
        }

        this._clearStateOverride();
        // 重置日程索引，让日程系统重新接管
        this.currentScheduleIdx = -1;
        this.scheduleReached = false;
    }

    // [已拆分到 npc-eating.js] _onEatingComplete
    /**
     * 休息行为完成的统一回调
     * 按需求6.2的顺序执行清理
     */;

    proto._onRestComplete = function() {
        this._logDebug('override', `[行为完成] 休息完成，体力${Math.round(this.stamina)}`);
        // 1. 清除行动覆盖相关状态
        this._clearActionOverride();
        // 2. 释放行为锁
        this._releaseBehaviorLock('resting');
        // 3. 重置日程索引，强制日程重新匹配
        this.currentScheduleIdx = -1;
        this.scheduleReached = false;
        // 4. pending队列已在_releaseBehaviorLock中检查
    }


    /**
     * 获取NPC在特定行为上的专长倍率
     */;

    // 【v4.42废除】_checkResourceGatherNeed 已废除
    // 原因：强制控制NPC去采集资源，严重违背"情报提供者，不做决策辅助者"的核心设计原则
    // 替代方案：资源紧缺通过 task-system.js 的 _triggerEmergencyDecision 情报注入机制通知AI自主决策
    proto._checkResourceGatherNeed = function(game) {
        // 【废除】不再强制控制NPC行为，资源紧缺由task-system的情报注入机制处理
        // 清理残留状态（兼容性保护）
        if (this._resourceGatherOverride) {
            this._clearResourceGatherOverride();
        }
    }

    // [已拆分到 npc-eating.js] _chooseEatTarget
    // [已拆分到 npc-eating.js] _checkEatingArrival
    /** 开始吃饭 */;

    proto._clearResourceGatherOverride = function() {
        this._resourceGatherOverride = false;
        this._resourceGatherTarget = null;
        this._resourceGatherType = null;
        this._resourceGatherTravelTimer = 0;
        this._resourceGatherCooldown = 120; // 120秒冷却，避免反复触发
        // 【覆盖快照】清除时重置_activeOverride
        if (this._activeOverride === 'resource') {
            this._activeOverride = 'none';
            this._logDebug('override', `[覆盖切换] resource → none（原因: 资源采集覆盖清除）`);
            this._executePendingBehavior();
        }
        // 重置日程索引，让日程系统重新接管
        this.currentScheduleIdx = -1;
        this.scheduleReached = false;
    }


    /** 更新资源采集覆盖状态（每帧调用） */;

    proto._checkSharedActivityBonus = function(game) {
        const companions = game.npcs.filter(n =>
            n.id !== this.id && n.currentScene === this.currentScene && !n.isSleeping && !n.isCrazy
        );
        if (companions.length === 0) return;

        for (const other of companions) {
            let bonusReason = null;
            let bonus = 0;

            // 一起吃饭（双方都在炊事房且至少一方在吃饭）
            if (this.currentScene === 'kitchen' &&
                (this.isEating || other.isEating)) {
                bonus = 1;
                bonusReason = '一起吃饭';
            }
            // 一起在医疗站（陪伴看病）
            else if (this.currentScene === 'medical') {
                if (this._isBeingTreated || other._isBeingTreated) {
                    bonus = 1.5;
                    bonusReason = '陪伴看病';
                } else {
                    bonus = 0.5;
                    bonusReason = '在医疗站偶遇';
                }
            }
            // 一起在工坊工作
            else if (this.currentScene === 'workshop') {
                bonus = 0.5;
                bonusReason = '一起在工坊';
            }
            // 一起在宿舍（邻居关系）
            else if (this.currentScene === 'dorm_a' || this.currentScene === 'dorm_b') {
                bonus = 0.5;
                bonusReason = '宿舍邻居';
            }
            // 一起在公园散步
            else if (this.currentScene === 'village') {
                // 两人都在公园区域（y>50）
                const myPos = this.getGridPos();
                const otherPos = other.getGridPos();
                if (myPos.y > 50 && otherPos.y > 50 &&
                    Math.abs(myPos.x - otherPos.x) + Math.abs(myPos.y - otherPos.y) < 10) {
                    bonus = 0.3;
                    bonusReason = '一起在公园散步';
                }
            }

            if (bonus > 0 && bonusReason) {
                // 【修复】冷淡期检测：吵架后一段时间内不会被动增加好感
                if (this._affinityCooldown && this._affinityCooldown[other.id] > 0) continue;
                if (other._affinityCooldown && other._affinityCooldown[this.id] > 0) continue;

                // 【修复】好感度越高，被动增长越慢（衰减因子）
                const currentAff = this.getAffinity(other.id);
                const diminishing = currentAff >= 80 ? 0.1 : (currentAff >= 60 ? 0.3 : (currentAff >= 40 ? 0.6 : 1.0));
                const finalBonus = bonus * diminishing;
                // 太小的增量忽略（防止无意义的高精度浮点累加）
                if (finalBonus < 0.05) continue;
                this.changeAffinity(other.id, finalBonus);
                // 双向关系：对方也获得加成（但稍弱一些）
                other.changeAffinity(this.id, finalBonus * 0.7);
            }
        }
    }

})();
