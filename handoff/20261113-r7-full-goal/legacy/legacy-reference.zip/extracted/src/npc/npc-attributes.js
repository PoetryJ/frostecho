/**
 * 福音镇 - NPC 属性更新模块
 * 通过 mixin 模式挂载到 NPC.prototype
 * 包含：属性衰减/恢复、饥饿、体温、目标追踪、医疗、资源采集
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;
    // [已拆分到 npc-state-override.js] _checkAutoMedkit
    // [已拆分到 npc-state-override.js] _checkResourceGatherNeed
    // [已拆分到 npc-state-override.js] _checkSharedActivityBonus
    // [已拆分到 npc-state-override.js] _checkStateOverrideArrival
    // [已拆分到 npc-state-override.js] _clearResourceGatherOverride
    // [已拆分到 npc-state-override.js] _clearStateOverride
    // [已拆分到 npc-state-override.js] _finishTreatment
    // [已拆分到 npc-state-override.js] _onRestComplete
    // [已拆分到 npc-state-override.js] _onStateOverrideComplete
    // [已拆分到 npc-state-override.js] _startTreatment
    // [已拆分到 npc-state-override.js] _triggerStateOverride
    /** 检查状态覆盖的到达逻辑（类似_checkEatingArrival） */;

    proto._updateAttributes = function(dt, game) {
        // 【v4.34】属性变化来源追踪系统 — 供HUD详情面板展示
        // 每帧收集所有属性的增减来源，转换为 /h 速率存储到 _attrRateSources
        const timeSpeed = game.timeSpeed || 60;
        // 速率转换：代码中的 rate*dt 是每帧变化量，转为每游戏小时 = rate * timeSpeed * 3600 / timeSpeed = rate * 3600
        // 但实际上 rate 的单位是 /游戏秒，所以每游戏小时 = rate * 3600
        const toPerHour = 3600; // 乘以此值将 /游戏秒 速率转为 /游戏小时
        const staSrc = [];  // 体力来源
        const sanSrc = [];  // San来源
        const hpSrc = [];   // 健康来源
        const hunSrc = [];  // 饱腹来源
        const btSrc = [];   // 体温来源

        if (this.isSleeping) {
            // 睡觉时：体力恢复，San值恢复，健康恢复（不消耗体力、不会饿醒）
            const sleepSanBefore = this.sanity;
            this.stamina = Math.min(100, this.stamina + 0.06 * dt);  // 体力恢复【已调整：从0.12降为0.06】
            this.sanity = Math.min(100, this.sanity + 0.10 * dt);    // 睡觉是恢复精神的主要途径【v4.6增强：0.04→0.10，8h睡眠约恢复48San】
            // 【v4.21修复】移除health<80限制，让NPC能睡到满血；健康<50时加速恢复
            const sleepHealthRate = this.health < 50 ? 0.04 : 0.02;
            this.health = Math.min(100, this.health + sleepHealthRate * dt);
            // 【v4.34】睡眠来源追踪
            staSrc.push({ label: GST.t('attr_src.sleep_recover'), rate: +(0.06 * toPerHour).toFixed(1) });
            sanSrc.push({ label: GST.t('attr_src.sleep_recover'), rate: +(0.10 * toPerHour).toFixed(1) });
            hpSrc.push({ label: GST.t('attr_src.sleep_recover'), rate: +(sleepHealthRate * toPerHour).toFixed(1) });
            this._attrRateSources = { stamina: staSrc, sanity: sanSrc, health: hpSrc, hunger: hunSrc, bodyTemp: btSrc };
            // 【Debug】睡眠San恢复日志
            if (game.mode === 'debug') {
                if (!this._sanLogCounter) this._sanLogCounter = 0;
                this._sanLogCounter += dt;
                if (this._sanLogCounter >= 60) {
                    this._sanLogCounter = 0;
                    const d = this.sanity - sleepSanBefore;
                    if (Math.abs(d) > 0.1) {
                        this._logDebug('sanity', `San: ${Math.round(sleepSanBefore)}→${Math.round(this.sanity)} (+${d.toFixed(1)}) 来源:[睡眠恢复]`);
                    }
                }
            }
            return;
        }

        const hour = game.getHour();

        // ---- 饥饿自然衰减 ----
        // 【v4.16修复】饥饿衰减已统一在 _updateHunger() 中处理，此处不再重复扣减
        // 原来此处有 hungerDecayRate = 0.000139/s 的微量衰减，与 _updateHunger 的主力衰减重复

        // ---- 体力消耗（清醒时持续缓慢下降）----
        // 工作中消耗更快（在工作场所时）【体力变化快】
        const isWorking = this.workplaceName && this.currentScene === this.workplaceName;
        // 【增强】健康低时体力消耗加快（身体虚弱更容易累）
        const healthPenalty = this.health < 30 ? 1.5 : (this.health < 50 ? 1.2 : 1.0);
        const baseStaminaDrain = (isWorking ? 0.10 : 0.05) * healthPenalty;
        // 【难度系统】体力衰减乘以难度倍率
        const _diffStaminaMult = game.getDifficultyMult ? game.getDifficultyMult('staminaDrainMult') : 1.0;
        const staminaDrain = baseStaminaDrain * _diffStaminaMult;
        this.stamina = Math.max(0, this.stamina - staminaDrain * dt);
        // 【v4.34】体力来源追踪
        const staLabel = isWorking ? GST.t('attr_src.work_sta') : GST.t('attr_src.daily_drain');
        staSrc.push({ label: staLabel + (healthPenalty > 1 ? `(${GST.t('attr_src.health_penalty')}×${healthPenalty})` : ''), rate: -(staminaDrain * toPerHour).toFixed(1) });

        // 【v2.2】吃饭恢复体力/San/健康改为吃完后一次性给（见_updateHunger吃完逻辑）

        // 【v2.2】已删除：存款/魅力/智慧/情商变化（v1.0遗留，末日生存不需要）

        // ---- 健康变化【变化慢】----
        // ============ 【任务6】生命系统升级：饥饿/体力→健康→死亡链路 ============

        // 6-1: 饱腹=0 → 每秒扣健康（【v2.0】提升为0.15/秒 → 约11分钟从100降到0）
        if (this.hunger <= 0) {
            this.health = Math.max(0, this.health - 0.15 * dt);
            hpSrc.push({ label: GST.t('attr_src.hunger_zero'), rate: -(0.15 * toPerHour).toFixed(1) });
        }

        // 6-2: 体力=0且非睡眠 → 每秒扣健康（0.025/秒）
        if (this.stamina <= 0 && !this.isSleeping) {
            this.health = Math.max(0, this.health - 0.025 * dt);
            hpSrc.push({ label: GST.t('attr_src.stamina_depleted'), rate: -(0.025 * toPerHour).toFixed(1) });
        }

        // 6-3: 生病状态 → 每秒额外扣健康（0.033/秒）
        if (this.isSick) {
            this.health = Math.max(0, this.health - 0.033 * dt);
            hpSrc.push({ label: GST.t('attr_src.sick'), rate: -(0.033 * toPerHour).toFixed(1) });
        }

        // 6-4: 多条件叠加——饱腹=0 + 体力=0 = 双重惩罚，上面的三个条件是独立计算的

        // 6-5: 健康自然恢复——仅在室内 + 饱腹>0 时以低速率恢复
        const isInIndoor = this.currentScene !== 'village'; // 室内场景均有集中供暖覆盖
        if (isInIndoor && this.hunger > 0 && this.health < 100 && !this.isSick) {
            this.health = Math.min(100, this.health + 0.01 * dt);
            hpSrc.push({ label: GST.t('attr_src.indoor_recover'), rate: +(0.01 * toPerHour).toFixed(1) });
        }

        // 正常作息维持健康（保留原有逻辑但降低恢复量，避免与上面重复恢复过多）
        if (hour >= 6 && hour <= 22 && this.stamina >= 30 && this.hunger > 20) {
            this.health = Math.min(100, this.health + 0.003 * dt);
            hpSrc.push({ label: GST.t('attr_src.normal_routine'), rate: +(0.003 * toPerHour).toFixed(1) });
        }
        // 体力过低伤害健康
        if (this.stamina < 10) {
            this.health = Math.max(0, this.health - 0.02 * dt);
            hpSrc.push({ label: GST.t('attr_src.stamina_low'), rate: -(0.02 * toPerHour).toFixed(1) });
        }
        // 【v2.2】吃饭恢复健康改为吃完后一次性给（见_updateHunger吃完逻辑）
        // 淋雨伤害健康
        if (this.currentScene === 'village' && game.isRaining() && !this.hasUmbrella) {
            this.health = Math.max(0, this.health - 0.03 * dt);
            hpSrc.push({ label: GST.t('attr_src.rain'), rate: -(0.03 * toPerHour).toFixed(1) });
        }
        // 老年人健康缓慢下降
        if (this.age >= 60) {
            this.health = Math.max(0, this.health - 0.003 * dt);
            hpSrc.push({ label: GST.t('attr_src.elderly'), rate: -(0.003 * toPerHour).toFixed(1) });
        }
        // 【增强】San值低时健康加速下降（精神差导致免疫力低下）
        if (this.sanity < 30) {
            this.health = Math.max(0, this.health - 0.015 * dt);
            hpSrc.push({ label: GST.t('attr_src.low_sanity'), rate: -(0.015 * toPerHour).toFixed(1) });
        }
        // 【增强】San值极低+健康不满时随机触发生病（身心俱疲容易发病）
        if (!this.isSick && this.sanity < 25 && this.health < 50 && Math.random() < 0.0005 * dt) {
            this.isSick = true;
            this.sickTimer = 300; // 生病持续一段时间
            this.mood = GST.t('mood.uncomfortable');
            this.expression = GST.t('npc_attr.sudden_sick_expr');
            this.expressionTimer = 6;
            if (game.addEvent) {
                game.addEvent(GST.t('npc_event.stress_sick', { name: this.name, san: Math.round(this.sanity), health: Math.round(this.health) }));
            }
            this._logDebug('health', `精神压力导致生病! San:${Math.round(this.sanity)} 健康:${Math.round(this.health)}`);
        }
        // 深夜不睡觉伤害健康 + San值急剧下降（通宵惩罚）
        if ((hour >= 23 || hour < 5) && !this.isSleeping) {
            this.health = Math.max(0, this.health - 0.01 * dt);
            hpSrc.push({ label: GST.t('attr_src.allnighter'), rate: -(0.01 * toPerHour).toFixed(1) });
            const nightSanMult = (game.mode === 'debug') ? 5 : 1;
            const nightSanBefore = this.sanity;
            this.sanity = Math.max(0, this.sanity - 0.15 * nightSanMult * dt); // 通宵不睡精神崩溃
            sanSrc.push({ label: GST.t('attr_src.allnighter_penalty'), rate: -(0.15 * nightSanMult * toPerHour).toFixed(1) });
            // 【v4.21增强】通宵惩罚日志：不仅debug模式，正常模式也记录，方便排查NPC死亡原因
            if (!this._nightSanLogged) {
                this._nightSanLogged = true;
                this._logDebug('sanity', `通宵惩罚开始! San:${Math.round(this.sanity)} 健康:${Math.round(this.health)} 场景:${this.currentScene} 状态:${this.stateDesc || this.state}`);
                // AI模式日志
                if (this.game && this.game.aiModeLogger) {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                    this.game.aiModeLogger.log('NIGHT_PENALTY', `${this.name} 通宵惩罚开始! 场景:${this.currentScene} 状态:${this.stateDesc || this.state} | ${snap}`);
                    this.game.aiModeLogger.pushNpcEvent(this.id, `🌙 通宵惩罚开始! 场景:${this.currentScene} | ${snap}`);
                }
            }
        } else {
            this._nightSanLogged = false;
        }

        // 【v2.2】已删除：情商变化（v1.0遗留，末日生存不需要）

        // ---- San值变化【变化快】----
        // debug模式下San值下降加速，方便测试低San值效果
        const baseSanDropMult = (game.mode === 'debug') ? 5 : 1;
        // 【难度系统】San值衰减乘以难度倍率
        const _diffSanMult = game.getDifficultyMult ? game.getDifficultyMult('sanDecayMult') : 1.0;
        const sanDropMult = baseSanDropMult * _diffSanMult;
        const sanBefore = this.sanity; // 【Debug】记录变化前的San值
        const sanSources = [];         // 【Debug】记录所有变化来源

        // 工作时San值下降（劳累消耗精神）
        if (isWorking) {
            this.sanity = Math.max(0, this.sanity - 0.08 * sanDropMult * dt);
            sanSources.push(`工作-${(0.08 * sanDropMult * dt).toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.work_san'), rate: -(0.08 * sanDropMult * toPerHour).toFixed(1) });
        }
        // 社交恢复San值
        if (this.state === 'CHATTING') {
            this.sanity = Math.min(100, this.sanity + 0.12 * dt);
            sanSources.push(`社交+${(0.12 * dt).toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.social'), rate: +(0.12 * toPerHour).toFixed(1) });
        }
        // 是否处于休息缓冲期
        const isRestingAtHome = this._restCooldownTimer > 0;
        // 【v4.34】休息缓冲期来源追踪（实际恢复在npc.js中，此处仅记录来源供HUD展示）
        if (isRestingAtHome) {
            staSrc.push({ label: GST.t('attr_src.rest_recover'), rate: +(2 * toPerHour).toFixed(1) });
            sanSrc.push({ label: GST.t('attr_src.rest_recover'), rate: +(0.06 * toPerHour).toFixed(1) });
        }

        // 【增强】San值低时额外加速下降        // 【修复】添加保底机制：物资充足时恶性循环速率减半，San不会因纯粹的心理因素快速致死
        if (this.sanity < 30 && this.sanity > 0 && !isRestingAtHome) {
            // 物资充足判定：食物>30且非饥饿状态，给予减缓
            const resourceOk = this.hunger > 30 && this.health > 30;
            const spiralMult = resourceOk ? 0.5 : 1.0; // 物资充足时恶性循环减半
            const spiralRate = 0.03 * sanDropMult * dt * spiralMult;
            // 保底：San不会因恶性循环降到5以下（需要其他致命因素才会继续降）
            if (this.sanity - spiralRate >= 5 || !resourceOk) {
                this.sanity = Math.max(0, this.sanity - spiralRate);
            } else {
                this.sanity = Math.max(5, this.sanity - spiralRate);
            }
            sanSources.push(`恶性循环-${spiralRate.toFixed(2)}${resourceOk ? '(减缓)' : ''}`);
            sanSrc.push({ label: GST.t('attr_src.spiral') + (resourceOk ? GST.t('attr_src.spiral_slow') : ''), rate: -(0.03 * sanDropMult * spiralMult * toPerHour).toFixed(1) });
        }
        // 【增强】健康低时也拖累San值（身体不好影响心情）
        if (this.health < 35) {
            const healthSanDrain = 0.03 * sanDropMult * dt;
            this.sanity = Math.max(0, this.sanity - healthSanDrain);
            sanSources.push(`健康差-${healthSanDrain.toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.poor_health'), rate: -(0.03 * sanDropMult * toPerHour).toFixed(1) });
        }
        // 【v2.2】吃饭恢复San改为吃完后一次性给（见_updateHunger吃完逻辑）
        // 在公园/广场散步恢复San值
        if (this.currentScene === 'village' && !isWorking) {
            this.sanity = Math.min(100, this.sanity + 0.02 * dt);
            sanSources.push(`散步+${(0.02 * dt).toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.walk'), rate: +(0.02 * toPerHour).toFixed(1) });
        }
        // 体力极低时San值下降（疲惫导致精神差）
        if (this.stamina < 20) {
            this.sanity = Math.max(0, this.sanity - 0.06 * sanDropMult * dt);
            sanSources.push(`疲惫-${(0.06 * sanDropMult * dt).toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.fatigue'), rate: -(0.06 * sanDropMult * toPerHour).toFixed(1) });
        }
        // 生病时San值下降
        if (this.isSick) {
            this.sanity = Math.max(0, this.sanity - 0.05 * sanDropMult * dt);
            sanSources.push(`生病-${(0.05 * sanDropMult * dt).toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.sick_san'), rate: -(0.05 * sanDropMult * toPerHour).toFixed(1) });
        }
        // 饥饿时San值下降
        if (this.hunger < 30) {
            this.sanity = Math.max(0, this.sanity - 0.04 * sanDropMult * dt);
            sanSources.push(`饥饿-${(0.04 * sanDropMult * dt).toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.hunger_san'), rate: -(0.04 * sanDropMult * toPerHour).toFixed(1) });
        }
        // ---- 歆玥鼓舞效果（基于morale_inspire专长）----
        // 【修复v4.15】移除写死的"演出时间/场所"逻辑。歆玥的角色是侦察员/急救兵，
        // 她的morale_inspire专长让她在同场景时自然带来精神恢复，不需要写死的"14:00广场演出"
        const linYue = game.npcs.find(n => n.id === 'ling_yue');
        const linYueAlive = linYue && !linYue.isDead && !linYue.isSleeping;
        const linYueSameScene = linYueAlive && linYue.currentScene === this.currentScene && this.id !== 'ling_yue';
        if (linYueSameScene) {
            // 与歆玥同场景时，获得微量San恢复（氛围加成，基于morale_inspire专长1.3倍）
            const inspireRate = 0.03 * (linYue.config?.specialties?.morale_inspire || 1.0);
            this.sanity = Math.min(100, this.sanity + inspireRate * dt);
            sanSources.push(`歆玥鼓舞+${(inspireRate * dt).toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.inspire'), rate: +(inspireRate * toPerHour).toFixed(1) });
            this.isWatchingShow = true; // 复用现有状态标记
        } else {
            this.isWatchingShow = false;
        }

        // ---- 找苏医生心理咨询恢复San值（大量花钱）----
        // 必须通过正式治疗流程（_isBeingTreated && _stateOverride === 'mental'）才有大幅恢复
        // 纯粹因为"碰巧在医院"不再自动触发高额恢复
        const suDoctor = game.npcs.find(n => n.id === 'su_doctor');
        const suDoctorAvailable = suDoctor && suDoctor.currentScene === 'medical' && !suDoctor.isSleeping;
        if (this._isBeingTreated && this._stateOverride === 'mental' && suDoctorAvailable) {
            // 正在进行正式心理咨询
            this.isInTherapy = true;
            this.sanity = Math.min(100, this.sanity + 0.30 * dt);  // 心理咨询大幅恢复San值
            sanSources.push(`心理咨询+${(0.30 * dt).toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.therapy'), rate: +(0.30 * toPerHour).toFixed(1) });
        } else if (this.id !== 'su_doctor' && this.currentScene === 'medical' && suDoctorAvailable) {
            // 碰巧在医疗站但没有正式咨询——微量恢复（安心氛围）
            this.isInTherapy = false;
            this.sanity = Math.min(100, this.sanity + 0.03 * dt);
            sanSources.push(`医疗站氛围+${(0.03 * dt).toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.medical_aura'), rate: +(0.03 * toPerHour).toFixed(1) });
        } else {
            this.isInTherapy = false;
        }

        // 【v4.39新增】苏岩"医者安心感"——当团队整体精神状态正常时，苏岩的San加速恢复
        // 设计原理：苏岩作为唯一医生，压力来源是"每个人的命都压在他肩上"。
        // 当大家San都还不错时，苏岩的心理负担减轻，San自然恢复更快。
        // 这是一个被动机制，不需要任何人主动安抚苏岩，符合"情报提供者"原则。
        if (this.id === 'su_doctor' && !this.isSleeping) {
            const aliveNpcs = game.npcs.filter(n => !n.isDead && n.id !== 'su_doctor');
            if (aliveNpcs.length > 0) {
                const avgSan = aliveNpcs.reduce((sum, n) => sum + n.sanity, 0) / aliveNpcs.length;
                if (avgSan >= 50) {
                    // 团队精神状态良好，苏岩获得安心感San恢复
                    const reliefRate = 0.05 * dt; // 约+3/小时，与社交聊天(+0.12)相当但低于睡觉(+0.10)
                    this.sanity = Math.min(100, this.sanity + reliefRate);
                    sanSources.push(`医者安心感+${reliefRate.toFixed(2)}`);
                    sanSrc.push({ label: GST.t('attr_src.doctor_relief'), rate: +(0.05 * toPerHour).toFixed(1) });
                } else if (avgSan >= 30) {
                    // 团队精神状态一般，苏岩获得微量安心感
                    const reliefRate = 0.02 * dt; // 约+1.2/小时
                    this.sanity = Math.min(100, this.sanity + reliefRate);
                    sanSources.push(`医者安心感(微)+${reliefRate.toFixed(2)}`);
                    sanSrc.push({ label: GST.t('attr_src.doctor_relief'), rate: +(0.02 * toPerHour).toFixed(1), note: GST.t('attr_src.doctor_relief_mild') });
                }
                // avgSan < 30时无安心感——团队精神崩溃，苏岩压力最大
            }
        }

        // 清醒时San值自然缓慢下降（需要持续获取情绪价值/休息）
        // 【修复v4.7】物资充足时保底San=5，避免纯心理因素快速致死
        // 【修复v4.7】白天休息缓冲期中不再扣自然衰减（否则休息时也在掉San，休息无法有效恢复精神）
        if (!isRestingAtHome) {
            const naturalDecay = 0.02 * sanDropMult * dt;
            const _resourceSufficient = this.hunger > 30 && this.health > 30 && this.stamina > 15;
            if (_resourceSufficient && this.sanity - naturalDecay < 5) {
                this.sanity = Math.max(5, this.sanity);
            } else {
                this.sanity = Math.max(0, this.sanity - naturalDecay);
            }
            sanSources.push(`自然衰减-${naturalDecay.toFixed(2)}`);
            sanSrc.push({ label: GST.t('attr_src.san_natural'), rate: -(0.02 * sanDropMult * toPerHour).toFixed(1) });
        } else {
            sanSources.push(`休息中(跳过自然衰减)`);
            sanSrc.push({ label: GST.t('attr_src.resting_skip'), rate: 0, note: GST.t('attr_src.skip_natural') });
        }

        // 【Debug】周期性记录San值变化（每60帧约2秒记录一次，避免刷屏）
        if (game.mode === 'debug') {
            if (!this._sanLogCounter) this._sanLogCounter = 0;
            this._sanLogCounter += dt;
            if (this._sanLogCounter >= 60) { // 约每2秒记录一次
                this._sanLogCounter = 0;
                const sanAfter = this.sanity;
                const delta = sanAfter - sanBefore;
                if (Math.abs(delta) > 0.1) { // 只有变化超过0.1才记录
                    this._logDebug('sanity', `San: ${Math.round(sanBefore)}→${Math.round(sanAfter)} (${delta > 0 ? '+' : ''}${delta.toFixed(1)}) 来源:[${sanSources.join(', ')}]`);
                }
                // 【奖惩日志】记录当前生效的连锁惩罚
                const penalties = [];
                if (this.health < 30) penalties.push(`健康差(${Math.round(this.health)}):体力消耗×1.5`);
                else if (this.health < 50) penalties.push(`亚健康(${Math.round(this.health)}):体力消耗×1.2`);
                if (this.sanity < 25) penalties.push(`精神极差(${Math.round(this.sanity)}):食欲-50%/工效-70%`);
                else if (this.sanity < 40) penalties.push(`精神差(${Math.round(this.sanity)}):食欲-30%/工效-40%`);
                if (this.sanity < 30 && !this.isSleeping) penalties.push(`San恶性循环加速中`);
                if (this.health < 35) penalties.push(`健康→San拖累中`);
                if (this.sanity < 30) penalties.push(`社交质量-50%/魅力持续↓`);
                if (this.sanity < 25) penalties.push(`情商持续↓`);
                if (this.health < 25) penalties.push(`移速×0.6`);
                else if (this.health < 40) penalties.push(`移速×0.8`);
                if (this.sanity < 20) penalties.push(`移速×0.7/可能发疯!`);
                if (penalties.length > 0) {
                    this._logDebug('penalty', `⚠️ 连锁惩罚生效中: ${penalties.join(' | ')}`);
                }
                // 【目标进度日志】记录当前目标进度快照
                const activeGoals = this.goals.filter(g => !g.completed);
                if (activeGoals.length > 0) {
                    const goalSnap = activeGoals.map(g => {
                        const pct = g.targetValue > 0 ? Math.round((g.progress / g.targetValue) * 100) : 0;
                        return `${g.desc}:${pct}%`;
                    }).join(' | ');
                    this._logDebug('goal', `📊 目标进度: ${goalSnap}`);
                }
            }
        }

        // 【v3.0重构】属性阈值告警 — 只在首次跌破阈值时记录一次，恢复后重置
        // 修复前：每10游戏分钟重复一次 → 清璇"体力=0"记录60+次刷屏
        // 修复后：首次跌破记录1次，恢复到安全值后才能再次触发
        if (this.game && this.game.aiModeLogger) {
            const _logger = this.game.aiModeLogger;
            if (!this._attrAlertFired) this._attrAlertFired = {};
            const alerts = [
                { key: 'san_0',     cond: this.sanity <= 0,   recover: this.sanity > 5,   msg: `San归零!精神崩溃` },
                { key: 'san_low',   cond: this.sanity < 15 && this.sanity > 0, recover: this.sanity >= 20, msg: `San极低(${Math.round(this.sanity)})` },
                { key: 'hp_crit',   cond: this.health < 10 && this.health > 0, recover: this.health >= 20, msg: `HP极低(${Math.round(this.health)})濒死` },
                { key: 'sta_0',     cond: this.stamina <= 0,  recover: this.stamina > 10, msg: `体力归零` },
                { key: 'hunger_0',  cond: this.hunger < 10,   recover: this.hunger >= 20, msg: `饱腹极低(${Math.round(this.hunger)})` },
            ];
            for (const a of alerts) {
                if (a.cond && !this._attrAlertFired[a.key]) {
                    // 首次跌破阈值 → 记录一次
                    this._attrAlertFired[a.key] = true;
                    const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                    _logger.log('ALERT', `⚠️ ${this.name} ${a.msg} | ${this.currentScene} ${this.stateDesc || ''} | ${snap}`);
                    _logger.pushNpcEvent(this.id, `⚠️ ${a.msg} | ${snap}`);
                } else if (a.recover && this._attrAlertFired[a.key]) {
                    // 恢复到安全值 → 重置标记，下次跌破可再触发
                    this._attrAlertFired[a.key] = false;
                }
            }
        }

        // ---- 发疯机制（San值过低）----
        // 【增强】发疯阈值提高到<20，概率加大，让低San的后果更严重
        if (!this.isCrazy && this.sanity < 20) {
            // San值越低，发疯概率越高
            const crazyChance = this.sanity < 10 ? 0.003 : (this.sanity < 15 ? 0.002 : 0.001);
            if (Math.random() < crazyChance * dt) {
                this.isCrazy = true;
                this.crazyTimer = 180; // 发疯持续约3游戏小时
                this.mood = GST.t('mood.crazy');
                this.stateDesc = GST.t('state_desc.mental_breakdown');
                this.expression = GST.t('npc_attr.crazy_expressions')[Math.floor(Math.random() * 5)] || 'I can\'t take it anymore!';
                this.expressionTimer = 10;
                if (game.addEvent) {
                    game.addEvent(GST.t('npc_event.mental_breakdown', { name: this.name, san: Math.round(this.sanity) }));
                }
                // 【事件驱动镜头】通知镜头系统：NPC发疯
                if (game.onNPCEvent) {
                    game.onNPCEvent(this, 'crazy');
                }
            }
        }
        // 发疯中：随机乱走、说胡话、无法正常工作
        if (this.isCrazy) {
            this.crazyTimer -= dt;
            this.stamina = Math.max(0, this.stamina - 0.08 * dt); // 发疯大幅消耗体力
            this.health = Math.max(0, this.health - 0.03 * dt);   // 发疯大幅伤害健康

            // 【极寒生存】San<10 精神崩溃物理攻击：随机攻击附近NPC
            if (this.sanity < 10 && Math.random() < 0.005 * dt) {
                const attackTargets = game.npcs.filter(n =>
                    n.id !== this.id && n.currentScene === this.currentScene && !n.isSleeping && !n.isDead
                );
                if (attackTargets.length > 0) {
                    const victim = attackTargets[Math.floor(Math.random() * attackTargets.length)];
                    // 造成伤害：体力-10、健康-5、San-5、双方好感-20
                    victim.stamina = Math.max(0, victim.stamina - 10);
                    victim.health = Math.max(0, victim.health - 5);
                    victim.sanity = Math.max(0, victim.sanity - 5);
                    this.stamina = Math.max(0, this.stamina - 5); // 自己也消耗体力
                    // 双方好感大幅下降
                    const myAff = this.getAffinity(victim.id);
                    this.affinity[victim.id] = Math.max(0, myAff - 20);
                    const theirAff = victim.getAffinity(this.id);
                    victim.affinity[this.id] = Math.max(0, theirAff - 20);
                    // 事件通知
                    const violenceLines = [
                        `${this.name} 精神崩溃，猛推了 ${victim.name}！`,
                        `${this.name} 失控攻击了 ${victim.name}！`,
                        `${this.name} 对 ${victim.name} 动手了！`,
                    ];
                    const line = violenceLines[Math.floor(Math.random() * violenceLines.length)];
                    if (game.addEvent) {
                        game.addEvent(GST.t('npc_event.crazy_attack', { line, victim: victim.name }));
                    }
                    this.expression = GST.t('npc_attr.crazy_violence');
                    this.expressionTimer = 8;
                    victim.expression = GST.t('npc_attr.crazy_victim_pain');
                    victim.expressionTimer = 8;
                    console.log(`[Violence] ${this.name} 攻击了 ${victim.name}`);
                }
            }

            // 随机说胡话 或 语言攻击周围的人
            if (Math.random() < 0.003 * dt) {
                const nearbyVictims = game.npcs.filter(n => 
                    n.id !== this.id && n.currentScene === this.currentScene && !n.isSleeping
                );
                if (nearbyVictims.length > 0 && Math.random() < 0.6) {
                    // 【语言攻击】发疯NPC对周围的人进行语言攻击
                    const victim = nearbyVictims[Math.floor(Math.random() * nearbyVictims.length)];
                    const affinity = this.getAffinity(victim.id);
                    // 攻击性台词——根据关系亲密度不同，攻击方式也不同
                    const _vn = victim.displayName || victim.name;
                    let attackLines;
                    if (affinity >= 70) {
                        // 对亲密的人：更刺心的话（最伤人）
                        attackLines = [
                            GST.t('crazy_attack.close1', { name: _vn }),
                            GST.t('crazy_attack.close2', { name: _vn }),
                            GST.t('crazy_attack.close3', { name: _vn }),
                            GST.t('crazy_attack.close4', { name: _vn }),
                            GST.t('crazy_attack.close5', { name: _vn }),
                            GST.t('crazy_attack.close6', { name: _vn }),
                        ];
                    } else if (affinity >= 40) {
                        // 对普通关系的人：敌意和指责
                        attackLines = [
                            GST.t('crazy_attack.normal1', { name: _vn }),
                            GST.t('crazy_attack.normal2', { name: _vn }),
                            GST.t('crazy_attack.normal3', { name: _vn }),
                            GST.t('crazy_attack.normal4', { name: _vn }),
                            GST.t('crazy_attack.normal5', { name: _vn }),
                        ];
                    } else {
                        // 对关系冷淡的人：恶意和攻击
                        attackLines = [
                            GST.t('crazy_attack.cold1', { name: _vn }),
                            GST.t('crazy_attack.cold2', { name: _vn }),
                            GST.t('crazy_attack.cold3', { name: _vn }),
                            GST.t('crazy_attack.cold4', { name: _vn }),
                        ];
                    }
                    this.expression = attackLines[Math.floor(Math.random() * attackLines.length)];
                    this.expressionTimer = 8;
                    
                    // 【核心】语言攻击降低受害者的San值——关系越亲近伤害越大
                    const intimacyMultiplier = affinity >= 70 ? 3.0 : (affinity >= 40 ? 1.5 : 1.0);
                    const sanDamage = 2.5 * intimacyMultiplier; // 基础2.5，挚友受到7.5点伤害
                    victim.sanity = Math.max(0, victim.sanity - sanDamage);
                    
                    // 受害者产生负面情绪反应
                    if (affinity >= 70) {
                        // 来自亲密的人的攻击，伤害更深，情绪影响更大
                        victim.mood = GST.t('mood.heartbroken');
                        victim.expression = GST.t('npc_attr.verbal_victim_close', { name: this.displayName || this.name });
                        victim.expressionTimer = 6;
                    } else {
                        victim.mood = GST.t('mood.anxious');
                    }
                    
                    if (game.addEvent) {
                        game.addEvent(GST.t('npc_event.verbal_attack', { name: this.name, victim: victim.name, damage: sanDamage.toFixed(1) }));
                    }
                } else {
                    // 普通胡话
                    const crazyLines = ['嘿嘿嘿…', '别过来！', '我看到了…', '为什么…为什么…', '哈哈哈哈！', '好黑…好冷…', '谁在说话？！'];
                    this.expression = crazyLines[Math.floor(Math.random() * crazyLines.length)];
                    this.expressionTimer = 6;
                }
            }
            // 发疯持续影响周围人的San值（被动氛围压迫）——附近的人每秒缓慢掉San
            const crazyWitnesses = game.npcs.filter(n => 
                n.id !== this.id && n.currentScene === this.currentScene && !n.isSleeping
            );
            for (const witness of crazyWitnesses) {
                const aff = witness.getAffinity(this.id);
                // 关系越好，看到对方发疯越痛苦，San下降越快
                const witnessSanLoss = aff >= 70 ? 0.08 : (aff >= 40 ? 0.04 : 0.02);
                witness.sanity = Math.max(0, witness.sanity - witnessSanLoss * dt);
            }
            // 发疯影响与周围人的关系——附近目睹发疯的NPC好感度下降
            if (Math.random() < 0.003 * dt) {
                for (const witness of crazyWitnesses) {
                    // 目击者对发疯者好感度下降
                    const currentAff = witness.getAffinity(this.id);
                    witness.affinity[this.id] = Math.max(5, currentAff - 2);
                    // 发疯者对目击者好感度也下降（精神混乱导致敌意）
                    const myAff = this.getAffinity(witness.id);
                    this.affinity[witness.id] = Math.max(5, myAff - 1);
                }
                if (crazyWitnesses.length > 0 && game.addEvent) {
                    game.addEvent(GST.t('npc_event.crazy_witnessed', { witnesses: crazyWitnesses.map(w => w.name).join(', '), name: this.name }));
                }
            }
            // 恢复条件：San值回到30以上 或 计时结束
            if (this.sanity >= 30 || this.crazyTimer <= 0) {
                this.isCrazy = false;
                this.crazyTimer = 0;
                this.mood = GST.t('mood.weak');
                this.expression = GST.t('npc_attr.crazy_recover_expr');
                this.expressionTimer = 8;
                if (game.addEvent) {
                    game.addEvent(GST.t('npc_event.sanity_recovered', { name: this.name, san: Math.round(this.sanity) }));
                }
            }
        }

        // ---- 精神不稳定行为（San 15~30，未发疯但状态很差）----
        // 阴阳怪气、负面情绪传染——偶尔说尖酸刻薄的话影响周围人
        if (!this.isCrazy && this.sanity >= 15 && this.sanity < 30) {
            if (Math.random() < 0.001 * dt) {
                const nearbyPeople = game.npcs.filter(n =>
                    n.id !== this.id && n.currentScene === this.currentScene && !n.isSleeping
                );
                if (nearbyPeople.length > 0) {
                    const target = nearbyPeople[Math.floor(Math.random() * nearbyPeople.length)];
                    const aff = this.getAffinity(target.id);
                    // 阴阳怪气的台词
                    const bitterLines = aff >= 70
                        ? [
                            `哼…${target.name}你今天看起来倒是挺开心的啊…`,
                            `${target.name}，你知道被人无视是什么感觉吗？算了你不会懂。`,
                            `我还以为我们是朋友呢…${target.name}。`,
                            `${target.name}，别假装关心我了，你忙你的吧。`
                        ]
                        : [
                            `真吵…能不能安静点…`,
                            `你们都好开心啊…真好。`,
                            `哈…算了，说了你也不懂。`,
                            `别看我…我没事…`,
                            `这破地方待着真没意思…`
                        ];
                    this.expression = bitterLines[Math.floor(Math.random() * bitterLines.length)];
                    this.expressionTimer = 6;
                    // 轻微影响周围人的San值（比发疯弱得多）
                    for (const person of nearbyPeople) {
                        const personAff = person.getAffinity(this.id);
                        const sanLoss = personAff >= 70 ? 1.5 : 0.5;
                        person.sanity = Math.max(0, person.sanity - sanLoss);
                    }
                    if (game.addEvent) {
                        game.addEvent(GST.t('npc_event.bitter_words', { name: this.name }));
                    }
                }
            }
        }

        // ---- 生病机制 ----
        if (!this.isSick && this.health < 30) {
            // 健康低于30时有概率触发生病
            if (Math.random() < 0.0001 * dt) {
                this.isSick = true;
                this.sickTimer = 120; // 生病持续约120游戏秒（≈2游戏小时）
                this.health = Math.max(0, this.health - 10);
                this.stateDesc = '生病了 🤒';
                this.expression = GST.t('npc_attr.feeling_unwell');
                this.expressionTimer = 8;
                if (game.addEvent) {
                    game.addEvent(GST.t('npc_event.got_sick', { name: this.name, health: Math.round(this.health) }));
                }
            }
        }
        // 生病中：持续消耗体力，计时
        if (this.isSick) {
            this.sickTimer -= dt;
            this.stamina = Math.max(0, this.stamina - 0.02 * dt);
            staSrc.push({ label: GST.t('attr_src.sick_sta'), rate: -(0.02 * toPerHour).toFixed(1) });
            // 如果看病（到医疗站治疗，简化为：在医疗站内）
            if (this.currentScene === 'medical') {
                this.health = Math.min(100, this.health + 0.1 * dt); // 加速恢复
                hpSrc.push({ label: GST.t('attr_src.medical_treat'), rate: +(0.1 * toPerHour).toFixed(1) });
            }
            // 生病自然恢复或计时结束
            if (this.sickTimer <= 0 || this.health >= 50) {
                this.isSick = false;
                this.sickTimer = 0;
                this.expression = GST.t('npc_attr.feeling_better');
                this.expressionTimer = 5;
                if (game.addEvent) {
                    game.addEvent(GST.t('npc_event.recovered', { name: this.name }));
                }
            }
        }

        // ---- 【极寒生存】体温系统更新 ----
        this._updateBodyTemp(dt, game);

        // ---- 体力联动效果：影响移动速度 ----
        let speedBase;
        if (this.stamina <= 0) {
            speedBase = (100 + Math.random() * 10) * 0.3; // 【新增】体力归零，移速降至30%
        } else if (this.stamina >= 80) {
            speedBase = (100 + Math.random() * 10) * 1.2; // 精力充沛，速度+20%
        } else if (this.stamina >= 50) {
            speedBase = 100 + Math.random() * 10; // 正常
        } else if (this.stamina >= 20) {
            speedBase = (100 + Math.random() * 10) * 0.7; // 疲惫，速度-30%
        } else {
            speedBase = (100 + Math.random() * 10) * 0.4; // 虚脱，速度-60%
        }
        // 【增强】健康低时额外减速（身体虚弱走不动）
        if (this.health < 25) {
            speedBase *= 0.6;
        } else if (this.health < 40) {
            speedBase *= 0.8;
        }
        // 【增强】San值极低时额外减速（神思恐性、走路踉跄）
        if (this.sanity < 20) {
            speedBase *= 0.7;
        }
        // 【极寒生存】失温减速
        if (this.isHypothermic) {
            speedBase *= 0.5;
        }
        if (this.isSevereHypothermic) {
            speedBase *= 0; // 严重失温：无法移动
        }
        this.speed = speedBase;

        // ---- 属性边界钳制 ----
        this.stamina = Math.max(0, Math.min(100, this.stamina));
        this.health = Math.max(0, Math.min(100, this.health));
        this.bodyTemp = Math.max(25, Math.min(36.5, this.bodyTemp));
        this.sanity = Math.max(0, Math.min(100, this.sanity));

        // 【v4.34】保存属性变化来源供HUD面板展示
        this._attrRateSources = { stamina: staSrc, sanity: sanSrc, health: hpSrc, hunger: hunSrc, bodyTemp: btSrc };

        // ---- 目标系统：追踪器更新 + 进度检测 ----
        // 工作时间追踪（在工作场所时累计）
        if (isWorking) {
            // 【P0修复】dt是gameDt（实际秒×播放倍速），需乘以timeSpeed才是游戏秒，再除3600得游戏小时
            this._goalTrackers.workHours += dt * (game.timeSpeed || 60) / 3600;
        }
        // 学习时间追踪（在工坊或医疗站时累计）
        if (this.currentScene === 'workshop' || this.currentScene === 'medical') {
            this._goalTrackers.studyHours += dt * (game.timeSpeed || 60) / 3600;
        }
        // 演出次数追踪由演出系统外部更新（在startPerformance中++）
        // 每日重置 daily 目标
        if (game.dayCount !== this._lastGoalDay) {
            this._lastGoalDay = game.dayCount;
            this._goalTrackers.chatCount = 0;
            this._goalTrackers.chatPartners = [];
            this._goalTrackers.workHours = 0;
            this._goalTrackers.studyHours = 0;
            this._goalTrackers.performCount = 0;
            // 【任务10】重置末日生存日目标
            this._goalTrackers.mealsToday = 0;
            this._goalTrackers.woodChopped = 0;
            this._goalTrackers.gatherCount = 0;
            this._goalTrackers.frostbiteSaved = 0;
            this._goalTrackers.rareItemsFound = 0;
            this._goalTrackers.patrolCount = 0;
            this._goalTrackers.conflictsResolved = 0;
            this._goalTrackers.medkitsCrafted = 0;
            // 重置daily目标的完成状态
            for (const g of this.goals) {
                if (g.type === 'daily') {
                    g.completed = false;
                    g.rewarded = false;
                    g.progress = 0;
                }
            }
        }
        // ---- 极端状态持续计时器（用于死亡判定）----
        // 【P0修复】dt是gameDt（实际秒×播放倍速），需乘以timeSpeed才是游戏秒
        // 死亡判定阈值（7200/14400/3600等）都是按游戏秒设计的，所以计时器必须用游戏秒累计
        const _deathTimerGameSec = dt * (game.timeSpeed || 60);
        // 体力=0持续计时
        if (this.stamina <= 0) {
            this._zeroStaminaDuration += _deathTimerGameSec;
        } else {
            this._zeroStaminaDuration = 0;
        }
        // 饱腹=0持续计时
        if (this.hunger <= 0) {
            this._zeroHungerDuration += _deathTimerGameSec;
        } else {
            this._zeroHungerDuration = 0;
        }
        // San=0且发疯持续计时
        if (this.sanity <= 0 && this.isCrazy) {
            this._zeroCrazyDuration += _deathTimerGameSec;
        } else {
            this._zeroCrazyDuration = 0;
        }

        // ---- 【第2天户外工作时间限制】----
        const wsDay2 = game.weatherSystem;
        const isOutdoorScene = (this.currentScene === 'village');
        if (wsDay2 && wsDay2.currentDay === 2 && isOutdoorScene) {
            this._outdoorWorkDuration += _deathTimerGameSec;
            // 超过2小时（7200游戏秒）强制回室内
            if (this._outdoorWorkDuration >= 7200 && !this._outdoorForceReturn) {
                this._outdoorForceReturn = true;
                // 强制NPC回到据点
                this._stateOverride = 'force_return';
                this._actionOverride = 'go_to';
                this._actionTarget = 'dorm_a_door';
                this._currentAction = { type: 'go_to', target: 'dorm_a_door', reason: '户外工作超时，必须回室内取暖' };
                if (game.addEvent) {
                    game.addEvent(GST.t('npc_event.outdoor_forced_return', { name: this.name }));
                }
                console.log(`[OutdoorLimit] ${this.name} 第2天户外工作超2小时，强制回室内`);
            }
            // 1.5小时时预警
            if (this._outdoorWorkDuration >= 5400 && this._outdoorWorkDuration < 5400 + _deathTimerGameSec + 1 && !this._outdoorForceReturn) {
                if (game.addEvent) {
                    game.addEvent(GST.t('npc_event.outdoor_warning', { name: this.name }));
                }
            }
        } else {
            // 回到室内后重置计时
            if (this._outdoorWorkDuration > 0 && !isOutdoorScene) {
                this._outdoorWorkDuration = 0;
                this._outdoorForceReturn = false;
            }
        }

        // 定期检测目标进度（每5秒检测一次，避免每帧都算）
        this._goalCheckTimer = (this._goalCheckTimer || 0) + dt;
        if (this._goalCheckTimer >= 5) {
            this._goalCheckTimer = 0;
            this._updateGoals(game);
        }

        // ---- 共同行为关系加成 ----
        // 每隔一段时间检查：在同一场景中一起做某事的NPC，双方关系小幅提升
        this._sharedActivityTimer = (this._sharedActivityTimer || 0) + dt;
        if (this._sharedActivityTimer >= 60) { // 每60真实秒检查一次（降低频率防止好感涨太快）
            this._sharedActivityTimer = 0;
            if (!this.isSleeping && !this.isCrazy) {
                this._checkSharedActivityBonus(game);
            }
        }
    }
    // [已拆分到 npc-body.js / npc-goals.js] _updateBodyTemp
    /** 触发状态覆盖行为 */;

    proto.getAttributeSummary = function() {
        return `💪体力:${Math.round(this.stamina)}(${this.getStaminaLevel()}) ` +
               `🧠San:${Math.round(this.sanity)}(${this.getSanityLevel()}) ` +
               `🫀健康:${Math.round(this.health)}(${this.getHealthLevel()}) ` +
               `🍖饱腹:${Math.round(this.hunger)}(${this.getHungerStatus()}) ` +
               `🌡️体温:${this.bodyTemp.toFixed(1)}°C(${this.getBodyTempStatus()})`;
    }
    // [已拆分到 npc-body.js / npc-goals.js] getBodyTempColor
    /** 事件驱动的属性变化（由对话、冲突等离散事件触发） */;

    proto.getHealthLevel = function() {
        if (this.health >= 80) return '强健';
        if (this.health >= 50) return '正常';
        if (this.health >= 30) return '亚健康';
        if (this.health >= 10) return '生病';
        return '重病';
    };
    // [已拆分到 npc-body.js / npc-goals.js] getHungerEmoji
    /** 获取饥饿状态emoji */;

    proto.getSanityLevel = function() {
        if (this.sanity >= 80) return '神清气爽';
        if (this.sanity >= 60) return '精神不错';
        if (this.sanity >= 40) return '有些疲惫';
        if (this.sanity >= 20) return '精神萎靡';
        return '精神崩溃';
    }

    /** 获取全部属性概览（用于Prompt注入） */;

    // 【v2.2】已删除getSavingsLevel（废弃属性）

    proto.getStaminaLevel = function() {
        if (this.stamina >= 80) return '精力充沛';
        if (this.stamina >= 50) return '正常';
        if (this.stamina >= 20) return '疲惫';
        if (this.stamina >= 1) return '虚脱';
        return '倒下';
    };

    // 【v2.2】已删除getWisdomLevel（废弃属性）

    proto.onChatCompleted = function(partner, quality) {
        // quality: 'good' | 'normal' | 'bad'
        // 社交消耗体力
        this.stamina = Math.max(0, this.stamina - 1);
    };

    proto.onConflict = function() {
        this.stamina = Math.max(0, this.stamina - 5);
        this.health = Math.max(0, this.health - 2);
    };

    proto.onHelpOther = function() {
        // 【v2.2】已移除charisma/empathy，帮助他人只影响好感度（由调用方处理）
    };

    proto.onLearnFromOther = function(teacherWisdom) {
        // 【v2.2】已移除wisdom属性，保留空函数防止调用报错
    }

    // ============ 饥饿系统 ============

    /** 获取饥饿状态描述 */;

    proto.trackChatWith = function(partnerId) {
        if (!this._goalTrackers.chatPartners.includes(partnerId)) {
            this._goalTrackers.chatPartners.push(partnerId);
            this._goalTrackers.chatCount = this._goalTrackers.chatPartners.length;
        }
    }

    /** 记录一次演出（用于目标追踪） */;

    proto.trackPerformance = function() {
        this._goalTrackers.performCount++;
    }

    /** 获取目标摘要（供Prompt使用） */;

})();
