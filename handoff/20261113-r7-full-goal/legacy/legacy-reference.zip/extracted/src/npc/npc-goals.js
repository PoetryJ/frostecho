/**
 * 福音镇 - NPC 目标与饥饿系统 Mixin
 * 职责：目标进度追踪/奖励、饥饿值更新/进食行为、状态覆盖仲裁
 * 从 npc-attributes.js 拆分，遵循SRP原则
 * 挂载到 GST.NPC.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;

    /** 翻译目标desc和rewardDesc（英文模式下） */
    function _translateGoalDesc(goal) {
        if (!GST.i18n || !GST.i18n.isEn || !GST.i18n.isEn()) return { desc: goal.desc, rewardDesc: goal.rewardDesc };
        const descEN = GST.t('goal_desc.' + goal.id);
        const rewardEN = GST.t('goal_reward.' + (goal.rewardDesc || ''));
        return {
            desc: (descEN && !descEN.startsWith('goal_desc.')) ? descEN : goal.desc,
            rewardDesc: (rewardEN && !rewardEN.startsWith('goal_reward.')) ? rewardEN : goal.rewardDesc,
        };
    }

    proto._grantGoalReward = function(goal, game) {
        if (goal.rewarded) return;
        goal.rewarded = true;
        const r = goal.reward;
        if (r.sanity) this.sanity = Math.min(100, this.sanity + r.sanity);
        if (r.health) this.health = Math.min(100, this.health + r.health);
        if (r.stamina) this.stamina = Math.min(100, this.stamina + r.stamina);
        this.mood = GST.t('mood.satisfied');
        const gt = _translateGoalDesc(goal);
        this.expression = goal.type === 'daily' ? GST.t('npc_goal.daily_complete_expr', { desc: gt.desc }) : GST.t('npc_goal.goal_complete_expr', { desc: gt.desc });
        this.expressionTimer = 8;
        this.addMemory(`[${GST.t('npc_goal.achievement')}] ${GST.t('npc_goal.goal_memory', { desc: gt.desc, reward: gt.rewardDesc })}`);
        if (game.addEvent) game.addEvent(GST.t('npc_goal.goal_complete', { name: this.name, desc: gt.desc, reward: gt.rewardDesc }));
        this._logDebug('goal', `完成目标: ${goal.desc} 奖励: ${goal.rewardDesc}`);
    };

    proto._updateGoals = function(game) {
        for (const goal of this.goals) {
            if (goal.completed && goal.rewarded) continue;
            let currentValue = 0;
            switch (goal.targetKey) {
                case 'chatCount': currentValue = this._goalTrackers.chatCount; break;
                case 'workHours': currentValue = this._goalTrackers.workHours; break;
                case 'studyHours': currentValue = this._goalTrackers.studyHours; break;
                case 'performCount': currentValue = this._goalTrackers.performCount; break;
                case 'health': currentValue = this.health; break;
                case 'allAffinity60': case 'allAffinity70': {
                    const threshold = goal.targetKey === 'allAffinity60' ? 60 : 70;
                    currentValue = game.npcs.filter(n => n.id !== this.id).every(n => this.getAffinity(n.id) >= threshold) ? 1 : 0;
                    break;
                }
                case 'mealsToday': currentValue = this._goalTrackers.mealsToday; break;
                case 'woodChopped': currentValue = this._goalTrackers.woodChopped; break;
                case 'gatherCount': currentValue = this._goalTrackers.gatherCount; break;
                case 'frostbiteSaved': currentValue = this._goalTrackers.frostbiteSaved; break;
                case 'rareItemsFound': currentValue = this._goalTrackers.rareItemsFound; break;
                case 'patrolCount': currentValue = this._goalTrackers.patrolCount; break;
                case 'conflictsResolved': currentValue = this._goalTrackers.conflictsResolved; break;
                case 'medkitsCrafted': currentValue = game._medkitCount || 0; break;
                case 'radioRepaired': currentValue = 0; break;
                case 'secondFurnaceBuilt': currentValue = (game.furnaceSystem && game.furnaceSystem.secondFurnaceBuilt) ? 1 : 0; break;
                case 'aliveCount': currentValue = game.npcs.filter(n => !n.isDead).length; break;
                case 'totalWoodCollected': currentValue = (game.resourceSystem && game.resourceSystem.totalCollected) ? game.resourceSystem.totalCollected.woodFuel : 0; break;
                case 'totalFoodCollected': currentValue = (game.resourceSystem && game.resourceSystem.totalCollected) ? game.resourceSystem.totalCollected.food : 0; break;
                case 'sanity': currentValue = this.sanity; break;
                case 'stamina': currentValue = this.stamina; break;
                case 'hunger': currentValue = this.hunger; break;
                case 'daysSurvived': currentValue = game.dayCount || 1; break;
                case 'foodAboveSafe': {
                    const rs_f = game.resourceSystem;
                    if (rs_f) { const fs = rs_f.getResource ? rs_f.getResource('food') : 0; currentValue = fs >= 60 ? 1 : 0; }
                    break;
                }
                case 'protectTarget_alive': {
                    const pid = this.config && this.config.protectTarget;
                    if (pid) { const pn = game.npcs.find(n => n.id === pid); currentValue = (pn && !pn.isDead) ? 1 : 0; }
                    break;
                }
                case 'furnaceUptime': currentValue = (game.furnaceSystem && game.furnaceSystem.isRunning) ? 1 : 0; break;
                case 'generatorUptime': {
                    const rsp = game.resourceSystem;
                    if (rsp) { currentValue = (rsp.getResource ? rsp.getResource('power') : 0) > 0 ? 1 : 0; }
                    break;
                }
                case 'furnace2Designed': currentValue = (game.furnaceSystem && game.furnaceSystem.secondFurnaceBuilt) ? 1 : 0; break;
                case 'noConflictInjury': currentValue = game.npcs.filter(n => !n.isDead).every(n => n.health > 50) ? 1 : 0; break;
                case 'allHealthAbove30': currentValue = game.npcs.filter(n => !n.isDead).every(n => n.health >= 30) ? 1 : 0; break;
                case 'ruinsExploreCount': {
                    const rsr = game.resourceSystem;
                    currentValue = rsr ? (3 - (rsr.getRuinsExploresRemaining ? rsr.getRuinsExploresRemaining() : 3)) : 0;
                    break;
                }
                case 'avgSanityAbove30': {
                    const alive = game.npcs.filter(n => !n.isDead);
                    if (alive.length > 0) currentValue = alive.reduce((s, n) => s + n.sanity, 0) / alive.length >= 30 ? 1 : 0;
                    break;
                }
                default:
                    if (goal.targetKey.startsWith('affinity_')) currentValue = this.getAffinity(goal.targetKey.replace('affinity_', ''));
                    break;
            }
            goal.progress = currentValue;
            if (!goal.completed && currentValue >= goal.targetValue) {
                goal.completed = true;
                goal.completedDay = game.dayCount;
                this._grantGoalReward(goal, game);
            }
        }
    };

    proto.getGoalsSummary = function() {
        if (!this.goals || this.goals.length === 0) return '';
        return this.goals.map(g => {
            const pct = g.targetValue > 0 ? Math.min(100, Math.round((g.progress / g.targetValue) * 100)) : 0;
            const status = g.completed ? `✅${GST.t('npc_goal.completed')}` : `${pct}%`;
            const typeLabel = g.type === 'daily' ? `📅${GST.t('npc_goal.daily')}` : `🏆${GST.t('npc_goal.longterm')}`;
            const gt = _translateGoalDesc(g);
            return `${typeLabel} ${gt.desc} [${status}] ${GST.t('npc_goal.reward')}:${gt.rewardDesc}`;
        }).join('\n');
    };

    proto.getHungerStatus = function() {
        if (this.hunger >= 80) return GST.t('hunger.full');
        if (this.hunger >= 60) return GST.t('hunger.normal');
        if (this.hunger >= 40) return GST.t('hunger.slightly_hungry');
        if (this.hunger >= 20) return GST.t('hunger.very_hungry');
        return GST.t('hunger.starving');
    };

    proto.getHungerEmoji = function() {
        if (this.hunger >= 80) return '😋';
        if (this.hunger >= 60) return '🙂';
        if (this.hunger >= 40) return '😐';
        if (this.hunger >= 20) return '😣';
        return '🤤';
    };

    proto._updateHunger = function(dt, game) {
        const toPerHour = 3600;
        const hunSrc = [];
        const rs = game.resourceSystem;
        const noFoodCrisis = rs && rs.crisisFlags.noFood;
        const hungerMultiplier = noFoodCrisis ? 2.0 : 1.0;
        let coldHungerMult = 1.0;
        const isOutdoor = this.currentScene === 'village';
        if (isOutdoor && game.weatherSystem) {
            const temp = game.weatherSystem.getEffectiveTemp();
            if (temp < -50) coldHungerMult = 3.0;
            else if (temp < -20) coldHungerMult = 2.5;
            else if (temp < 0) coldHungerMult = 1 + Math.abs(temp) / 40;
        }
        const isWorkingForHunger = this.workplaceName && this.currentScene === this.workplaceName;
        const workMult = isWorkingForHunger ? 1.5 : 1.0;
        const _diffHungerMult = game.getDifficultyMult ? game.getDifficultyMult('hungerDecayMult') : 1.0;
        const decayRate = (this.isSleeping ? 0 : 0.0007) * hungerMultiplier * coldHungerMult * workMult * _diffHungerMult;
        const hungerGameSeconds = dt * (game.timeSpeed || 60);
        this.hunger = Math.max(0, this.hunger - decayRate * hungerGameSeconds);
        if (decayRate > 0) {
            let hunLabel = `⏳ ${GST.t('attr_src.natural_decay')}`;
            if (isWorkingForHunger) hunLabel = `⚒️ ${GST.t('attr_src.work_decay')}`;
            if (coldHungerMult > 1) hunLabel += `(${GST.t('attr_src.cold')}×${coldHungerMult.toFixed(1)})`;
            if (noFoodCrisis) hunLabel += `(${GST.t('attr_src.no_food')}×2)`;
            hunSrc.push({ label: hunLabel, rate: -(decayRate * 3600).toFixed(1) });
        } else {
            hunSrc.push({ label: `💤 ${GST.t('attr_src.sleeping')}`, rate: 0, note: GST.t('attr_src.no_decay') });
        }
        if (this.isEating) hunSrc.push({ label: `🍜 ${GST.t('attr_src.eating')}`, rate: 0, note: GST.t('attr_src.recovering_soon') });
        if (this._attrRateSources) this._attrRateSources.hunger = hunSrc;

        if (this.isEating) {
            this.eatingTimer -= dt;
            if (this.eatingTimer <= 0) {
                this.isEating = false;
                const rs2 = game.resourceSystem;
                const foodPerMeal = 1.5;
                if (rs2 && rs2.food >= foodPerMeal) {
                    rs2.consumeResource('food', foodPerMeal, `${this.name}个人进食`);
                    this.hunger = Math.min(100, this.hunger + 60);
                    const sp = this.sanity < 25 ? 0.5 : (this.sanity < 40 ? 0.7 : 1.0);
                    this.stamina = Math.min(100, this.stamina + 15 * sp);
                    this.sanity = Math.min(100, this.sanity + 5);
                    this.health = Math.min(100, this.health + 2);
                    this.mood = GST.t('mood.satisfied'); this.expression = GST.t('npc_goal.ate_full_expr');
                    if (game.addEvent) game.addEvent(GST.t('npc_goal.ate_full', { name: this.name, food: foodPerMeal, hunger: Math.round(this.hunger), remaining: Math.round(rs2.food) }));
                } else if (rs2 && rs2.food > 0) {
                    const avail = rs2.food, ratio = avail / foodPerMeal;
                    rs2.consumeResource('food', avail, `${this.name}个人进食(不足)`);
                    this.hunger = Math.min(100, this.hunger + Math.round(60 * ratio));
                    const sp2 = this.sanity < 25 ? 0.5 : (this.sanity < 40 ? 0.7 : 1.0);
                    this.stamina = Math.min(100, this.stamina + Math.round(15 * ratio * sp2));
                    this.sanity = Math.min(100, this.sanity + Math.round(5 * ratio));
                    this.health = Math.min(100, this.health + Math.round(2 * ratio));
                    this.mood = GST.t('mood.unsatisfied'); this.expression = GST.t('npc_goal.ate_little_expr');
                    if (game.addEvent) game.addEvent(GST.t('npc_goal.food_short', { name: this.name, food: Math.round(avail), gain: Math.round(60 * ratio) }));
                } else {
                    this.hunger = Math.max(0, this.hunger - 10);
                    this.mood = GST.t('mood.depressed'); this.expression = GST.t('npc_goal.no_food_expr');
                    if (game.addEvent) game.addEvent(GST.t('npc_goal.no_food', { name: this.name }));
                }
                this.expressionTimer = 5;
                this._hungerOverride = false; this._hungerTarget = null;
                this._hungerStuckTimer = 0; this._hungerTravelTimer = 0;
                this._hungerTriggerCooldown = 20;
                this._releaseBehaviorLock('eating');
                this.currentScheduleIdx = -1; this.scheduleReached = false;
            }
            return;
        }

        if (this.health <= 0 || this._isDying) return;
        // 【v5.4】P1仲裁暂停期间不触发新的饥饿覆盖
        if (this._arbitrationPaused) return;
        const hour = game.getHour();
        const isLateNight = this._isBedtime(hour);
        const hasHigherPriority = this.stamina < 15 || (this.isSick && this.health < 25) || this._stateOverride;
        const hasFoodAvailable = game.resourceSystem && game.resourceSystem.food > 0;
        const nightSkipHour = game.getHour();
        const isNightSkipWindow = (nightSkipHour >= 20 || nightSkipHour < 6) && !game._nightSkipDone;

        if (this.hunger < 10 && hasFoodAvailable && this.isSleeping && !this._hungerOverride && !this.isEating && !isNightSkipWindow) {
            this._hungerOverride = true;
            console.warn(`[NPC] ${this.name} 饱腹极低(${Math.round(this.hunger)})且在睡觉，打断睡眠去吃饭！`);
            if (game.addEvent) game.addEvent(GST.t('npc_goal.hunger_wake', { name: this.name, hunger: Math.round(this.hunger) }));
            this.isSleeping = false; this.state = 'IDLE'; this._forcedSleep = false;
            this._hungerTriggerCooldown = 5;
            this._triggerHungerBehavior(game);
            return;
        }
        if (this.hunger < 15 && hasFoodAvailable && !this._hungerOverride && !this.isEating && !this.isSleeping
            && !this._stateOverride && !(this._priorityOverride && this.hunger >= 10)) {
            this._hungerOverride = true;
            this._actionOverride = false; this._currentAction = null; this._pendingAction = null;
            if (this.state === 'CHATTING') this.state = 'IDLE';
            this._hungerTriggerCooldown = 5;
            console.warn(`[NPC] ${this.name} 饥饿值极低(${Math.round(this.hunger)})，强制中断任务去进食！`);
            if (game.addEvent) game.addEvent(GST.t('npc_goal.hunger_critical', { name: this.name, hunger: Math.round(this.hunger) }));
            this._triggerHungerBehavior(game);
        } else if (this.hunger < 25 && hasFoodAvailable && !this._hungerOverride && !this.isEating && !this.isSleeping && this._hungerTriggerCooldown <= 0 && !this._stateOverride) {
            this._hungerTriggerCooldown = 8;
            this._triggerHungerBehavior(game);
        } else if (this.hunger < 35 && !this._hungerOverride && !this.isEating && this.state !== 'CHATTING' && !this.isSleeping && !isLateNight && this._hungerTriggerCooldown <= 0 && !hasHigherPriority
            && !(this._taskOverride && this._taskOverride.isActive)) {
            this._hungerTriggerCooldown = 10;
            this._triggerHungerBehavior(game);
        }
    };

    proto._updateStateOverride = function(dt, game) {
        // 【v5.4】P1仲裁暂停期间不触发新的状态覆盖
        if (this._arbitrationPaused) return;
        // 【v5.5修复】弹弹乐恢复期内不触发新的状态覆盖
        if (this._bounceRecoveryTimer > 0) return;
        if (this._stateOverrideCooldown > 0) this._stateOverrideCooldown -= dt;
        if (this._isBeingTreated) {
            this._treatmentTimer -= dt;
            if (this._treatmentTimer <= 0) this._finishTreatment(game);
            return;
        }
        if (this._stateOverride) {
            this._stateOverrideMaxTimer = (this._stateOverrideMaxTimer || 0) + dt;
            if (this._stateOverrideMaxTimer > 60 && !this.isMoving && this.currentPath.length === 0) {
                console.warn(`[NPC-${this.name}] [超时] stateOverride(${this._stateOverride})持续${Math.round(this._stateOverrideMaxTimer)}秒且静止，强制清除`);
                this._clearStateOverride();
                return;
            }
            this._checkStateOverrideArrival(dt, game);
            return;
        }
        if (this._stateOverrideCooldown > 0) return;
        if (this.state === 'CHATTING' || this.isEating) return;
        if (this.isSleeping && this.hunger >= 10) return;
        if (this.isCrazy) return;

        const hour = game.getHour();
        const isLateNight = this._isBedtime(hour);
        const isInIndoorScene = this.currentScene && this.currentScene !== 'village';

        if (this.stamina < 15 && !this.isSleeping && isInIndoorScene && this._isAtHome()) {
            const bedLoc = this._getBedLocation ? this._getBedLocation() : null;
            if (bedLoc) {
                this.x = bedLoc.x * GST.TILE; this.y = bedLoc.y * GST.TILE;
                this.isSleeping = true; this._forcedSleep = true; this._forcedSleepTimer = 0;
                this.stateDesc = GST.t('state_desc.exhausted_sleep');
                this._logDebug('sleep', `在宿舍累坏倒头就睡 体力:${Math.round(this.stamina)} San:${Math.round(this.sanity)}`);
                if (this.game && this.game.aiModeLogger) {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                    this.game.aiModeLogger.log('SLEEP_START', `${this.name} 累坏倒头就睡 | ${snap} | ${this.currentScene || '?'}`);
                    this.game.aiModeLogger.pushNpcEvent(this.id, `😴 累坏倒头就睡 | ${snap}`);
                }
                return;
            }
        }
        // 【v4.43修复】在室内但不在自己宿舍时（如medical/workshop），体力极低也触发exhausted回宿舍
        // 【v5.4重构】不再直接打断饥饿行为，而是让两个P1共存，由仲裁器决定
        if (this.stamina < 15 && !this.isSleeping && isInIndoorScene && !this._isAtHome()) {
            // 如果正在吃饭且快吃完了，不触发（让它吃完）
            if (this.isEating) { this._logDebug('override', `[行为锁] 体力极低但正在吃饭，不打断`); return; }
            // 【v5.4修复】如果无法安全出门（极寒），就地强制入睡而不是尝试出门回宿舍
            // 避免NPC反复触发exhausted→出不了门→超时清除→再触发的循环
            if (this.canSafelyGoOutdoor && !this.canSafelyGoOutdoor(game)) {
                this.isSleeping = true;
                this._forcedSleep = true;
                this._forcedSleepTimer = 0;
                this.stateDesc = GST.t('state_desc.exhausted_rest_here');
                this.expression = GST.t('npc_goal.too_tired_expr');
                this.expressionTimer = 6;
                this.mood = GST.t('mood.exhausted');
                this.currentPath = [];
                this.isMoving = false;
                this._logDebug('sleep', `极寒无法出门，就地强制入睡 体力:${Math.round(this.stamina)} 场景:${this.currentScene}`);
                if (game.addEvent) {
                    game.addEvent(GST.t('npc_goal.exhausted_rest_cold', { name: this.name, stamina: Math.round(this.stamina) }));
                }
                return;
            }
            this._triggerStateOverride('exhausted', game);
            return;
        }
        // 【v4.43修复】户外exhausted阈值从15提高到20
        // 【v5.4重构】不再直接打断饥饿行为
        if (this.stamina < 20 && !this.isSleeping && !isInIndoorScene) {
            if (this.isEating) { this._logDebug('override', `[行为锁] 体力极低但正在吃饭，不打断`); return; }
            this._triggerStateOverride('exhausted', game);
            return;
        }
        if ((this.isSick || this.health < 35) && !isLateNight && this.currentScene !== 'medical') {
            if (this.isEating && this.health >= 10) { this._logDebug('override', `[行为锁] 生病但正在吃饭，不打断`); return; }
            // 【v5.4修复】如果NPC在室内且无法安全出门，不触发sick状态覆盖（去不了医疗站只会卡住60秒超时）
            // 改为就地休息等待天气好转或健康自然恢复
            if (this.currentScene !== 'village' && this.canSafelyGoOutdoor && !this.canSafelyGoOutdoor(game)) {
                // 室内无法出门，跳过sick覆盖，避免反复触发→超时→再触发的循环
                return;
            }
            this._triggerStateOverride('sick', game);
            return;
        }
        if (this._hungerOverride) return;
        if (this.sanity < 35 && !this.isCrazy && !isLateNight && this.id !== 'su_doctor' && this.currentScene !== 'medical') {
            // 【v5.4修复】同sick，室内无法出门时不触发mental覆盖
            if (this.currentScene !== 'village' && this.canSafelyGoOutdoor && !this.canSafelyGoOutdoor(game)) {
                return;
            }
            this._triggerStateOverride('mental', game);
            return;
        }
    };

    proto._updateResourceGatherOverride = function(dt, game) {
        if (this._resourceGatherCooldown > 0) this._resourceGatherCooldown -= dt;
        if (this._resourceGatherOverride) this._clearResourceGatherOverride();
    };

})();