/**
 * 福音镇 - NPC 行动效果模块
 * 通过 mixin 模式挂载到 NPC.prototype
 * 包含：行动效果应用（产出资源、建造进度、制药等）
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.NPC.prototype;

    proto._updateActionEffect = function(dt, game) {
        if (this.isDead || this.isSleeping || this.isEating || this.state === 'CHATTING') return;

        // 【v5.0修复】正在执行紧急回室内休息时，不应匹配任何工作效果
        // 根因：王策属性极低被分配stateDesc="累坏了，赶紧回家休息"，但scheduleDesc="人工发电"
        // 导致匹配到requiredScene='workshop'的条目→场景不匹配→自动纠正→反复循环
        if (this._actionOverride && this._currentAction && this._currentAction.type === 'rest') {
            this._currentActionEffect = null;
            return;
        }

        // ============ 苏岩出诊系统（独立于medical_heal效果，不受requiredScene限制） ============
        this._updateHouseCall(dt, game);

        // 获取当前日程描述
        // 【v5.6修复】schedIdx=-1时不再直接return，否则NPC有有效stateDesc（如"正在砍柴"）
        // 但因为schedIdx=-1（被各种系统重置过）导致workBubble不显示
        const schedIdx = this.currentScheduleIdx;
        const scheduleDesc = (schedIdx >= 0 && this.scheduleTemplate[schedIdx])
            ? (this.scheduleTemplate[schedIdx].desc || '')
            : '';
        const currentDesc = this.stateDesc || scheduleDesc;
        // 如果连stateDesc都没有，且日程也无效，才跳过
        if (!currentDesc && !this._councilStateDesc) {
            this._currentActionEffect = null;
            return;
        }

        // 【投票决策保护】如果NPC有投票分配的stateDesc且未过期，优先使用它
        const councilDesc = this._councilStateDesc || '';

        // 在ACTION_EFFECT_MAP中查找匹配的效果
        // 优先使用 taskOverride 显式 effectKey，避免"建造发电机 / 人工发电"这类关键词互相串台
        // 【P0修复】同时匹配 stateDesc 和日程原始 desc，防止 LLM 行动决策覆盖 stateDesc 后关键词丢失
        // 【投票修复】额外匹配 _councilStateDesc，确保投票决策的行动效果一定能触发
        let matchedEffect = null;
        const explicitEffectKey = this._taskOverride && this._taskOverride.isActive
            ? this._taskOverride.effectKey || null
            : null;
        if (explicitEffectKey) {
            matchedEffect = GST.ACTION_EFFECT_MAP.find(entry => entry.effectKey === explicitEffectKey) || null;
        }
        if (!matchedEffect) {
            // 【v5.0修复】分层匹配：先只匹配 currentDesc（stateDesc），再匹配 councilDesc，最后才用 scheduleDesc
            // 根因：苏岩在medical坐诊，stateDesc="坐诊"应匹配medical条目，
            // 但scheduleDesc="去冰湖采集食物"中的"采集"先匹配到了village条目，导致场景不匹配→弹弹乐
            // 修复：stateDesc优先级最高，只有stateDesc没匹配到时才降级到scheduleDesc
            // 第1层：匹配 currentDesc（stateDesc 或 scheduleDesc 的当前行为描述）
            for (const entry of GST.ACTION_EFFECT_MAP) {
                for (const keyword of entry.keywords) {
                    if (currentDesc.includes(keyword)) {
                        matchedEffect = entry;
                        break;
                    }
                }
                if (matchedEffect) break;
            }
            // 第2层：匹配 councilDesc（投票决策描述）
            if (!matchedEffect && councilDesc) {
                for (const entry of GST.ACTION_EFFECT_MAP) {
                    for (const keyword of entry.keywords) {
                        if (councilDesc.includes(keyword)) {
                            matchedEffect = entry;
                            break;
                        }
                    }
                    if (matchedEffect) break;
                }
            }
            // 第3层：匹配 scheduleDesc（日程原始描述，优先级最低）
            if (!matchedEffect && scheduleDesc && scheduleDesc !== currentDesc) {
                for (const entry of GST.ACTION_EFFECT_MAP) {
                    for (const keyword of entry.keywords) {
                        if (scheduleDesc.includes(keyword)) {
                            matchedEffect = entry;
                            break;
                        }
                    }
                    if (matchedEffect) break;
                }
            }
        }
        if (!matchedEffect) {
            // 空转检测：输出警告日志（含所有匹配源，方便排查关键词缺失）
            this._logDebug?.(`[⚠️ 空转] ${this.name} 的行为 "${currentDesc}" 未匹配到任何效果 (schedule="${scheduleDesc}" council="${councilDesc}")`);
            // 累计空转计时
            this._idleEffectTimer = (this._idleEffectTimer || 0) + dt * (game.timeSpeed || 60);
            // 超过1游戏小时自动回退到角色默认生产行为
            if (this._idleEffectTimer > 3600) {
                this._logDebug?.(`[⚠️ 空转回退] ${this.name} 空转超过1小时，自动切换到默认生产行为`);
                this._idleEffectTimer = 0;
                this._fallbackToRoleDefaultAction(game);
            }
            this._currentActionEffect = null;
            return;
        }

        // 检查场景是否匹配（null表示不限场景）
        if (matchedEffect.requiredScene && this.currentScene !== matchedEffect.requiredScene) {
            this._currentActionEffect = null;
            // 【v5.1修复】弹弹乐恢复期内不触发自动纠正
            // 根因：弹弹乐冻结解除后，action-effects立刻又触发自动纠正→弹弹乐复发
            if (this._bounceRecoveryTimer > 0) {
                const gameSeconds = dt * (game.timeSpeed || 60);
                this._bounceRecoveryTimer -= gameSeconds;
                if (this._bounceRecoveryTimer > 0) {
                    this._wrongSceneTimer = 0; // 恢复期内重置计时器
                    return;
                }
                this._bounceRecoveryTimer = 0;
            }
            // 【v5.1修复】如果NPC正在被冻结（弹弹乐检测触发），不触发自动纠正
            if (this._jitterFreezeTimer > 0) {
                this._wrongSceneTimer = 0;
                return;
            }
            // 【v4.39修复】场景不匹配时自动纠正：缩短容忍时间从30秒到15秒
            // 根因：陆辰在village显示"前往人工发电"但实际在village而非workshop，白白浪费5小时
            // 15秒足够NPC自行移动到正确场景，超时则强制纠正
            const wrongSceneGameSec = dt * (game.timeSpeed || 60);
            this._wrongSceneTimer = (this._wrongSceneTimer || 0) + wrongSceneGameSec;
            if (this._wrongSceneTimer > 15) {
                this._wrongSceneTimer = 0;
                console.warn(`[ActionEffect] ${this.name} 在错误场景(${this.currentScene})执行"${currentDesc}"(需要${matchedEffect.requiredScene})，自动纠正`);
                // 【v4.39增强】记录到AI日志，方便追踪
                if (game && game.aiModeLogger) {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(this);
                    game.aiModeLogger.logDeduped('DECISION_BUG', this.id, 'wrong_scene_auto_correct',
                        `${this.name} 在错误场景(${this.currentScene})执行"${currentDesc}"(需要${matchedEffect.requiredScene})，已自动纠正 | ${snap}`);
                }
                // 清除投票决策的stateDesc，避免反复被拉回错误行为
                if (this._councilStateDesc) this._councilStateDesc = '';
                if (this._taskOverride && this._taskOverride.isActive) {
                    this.deactivateTaskOverride();
                }
                // 【v4.39修复】清除当前stateDesc，防止纠正后仍匹配到错误效果
                this.stateDesc = '';
                // 【P0修复】属性极低时不分配默认工作行为，直接强制回室内休息
                // 根因：王策卡在village，场景纠正反复分配"人工发电"(需workshop)，
                // 但他STA=0/HP<30走不到workshop，在户外暴露致死
                const _isDangerState = this.stamina <= 5 || this.health < 30 || 
                    (this.bodyTemp !== undefined && this.bodyTemp < 35);
                if (this.currentScene === 'village' && _isDangerState) {
                    const homeDoor = (this.id === 'li_shen' || this.id === 'ling_yue' || this.id === 'qing_xuan') 
                        ? 'dorm_b_door' : 'dorm_a_door';
                    this._actionOverride = true;
                    this._currentAction = { type: 'rest', target: homeDoor, reason: '属性极低，紧急回室内' };
                    this._actionTarget = { target: homeDoor, desc: '紧急回室内休息' };
                    this.stateDesc = '累坏了，赶紧回家休息';
                    if (typeof this._navigateToScheduleTarget === 'function') {
                        this._navigateToScheduleTarget(homeDoor, game);
                    }
                } else {
                    this._fallbackToRoleDefaultAction(game);
                }
            }
            return;
        }
        // 场景匹配成功，重置错误场景计时器
        this._wrongSceneTimer = 0;

        // 匹配成功，重置空转计时
        this._idleEffectTimer = 0;

        // 记录当前效果（用于UI显示）
        this._currentActionEffect = matchedEffect;

        // 计算效率系数
        const staminaEfficiency = Math.max(0.1, this.stamina / 100); // 体力效率
        const specialtyMultiplier = this._getSpecialtyMultiplier(matchedEffect); // 专长倍率

        // 根据effectType执行不同效果
        const rs = game.resourceSystem;
        switch (matchedEffect.effectType) {
            case 'produce_resource': {
                // 【v5.8.15修复】户外采集区坐标校验：NPC必须在正确的采集区范围内才能产出
                // 根因：NPC站在工坊门口(village场景)，stateDesc包含"砍柴/采矿"关键词，
                // 匹配到produce_resource效果后在门口原地产出资源，但实际没有移动到采集区
                if (matchedEffect.requiredScene === 'village' && this.currentScene === 'village') {
                    const ts = game.taskSystem;
                    if (ts && ts._detectGatherArea) {
                        const gatherType = ts._detectGatherArea(this);
                        if (!gatherType || gatherType !== matchedEffect.resourceType) {
                            // NPC不在对应的采集区，不产出资源，也不显示工作气泡
                            // 触发位置纠正：导航到正确的采集区
                            if (!this._gatherAreaCorrectionTimer) this._gatherAreaCorrectionTimer = 0;
                            this._gatherAreaCorrectionTimer += dt;
                            if (this._gatherAreaCorrectionTimer > 3) { // 3秒后纠正
                                this._gatherAreaCorrectionTimer = 0;
                                const targetMap = { woodFuel: 'lumber_camp', food: 'frozen_lake', power: 'ore_pile', explore: 'ruins_site' };
                                const correctTarget = targetMap[matchedEffect.resourceType];
                                if (correctTarget && !this.isMoving && this.currentPath.length === 0) {
                                    console.warn(`[ActionEffect] ${this.name} 在错误位置(${(this.x/32).toFixed(0)},${(this.y/32).toFixed(0)})执行"${currentDesc}"，不在${matchedEffect.resourceType}采集区，导航到${correctTarget}`);
                                    this._navigateToScheduleTarget(correctTarget, game);
                                    // 更新状态描述为"前往"
            const resourceNames = { woodFuel: GST.t('location.lumber_camp'), food: GST.t('location.frozen_lake'), power: GST.t('location.ore_pile'), explore: GST.t('location.ruins_site') };
            this.stateDesc = GST.t('state_desc.heading_to', { target: resourceNames[matchedEffect.resourceType] || 'gathering area' });
                                }
                            }
                            this._currentActionEffect = null;
                            this.workBubble = '';
                            this.workBubbleTimer = 0;
                            return; // 提前返回，不产出资源也不显示气泡
                        }
                    }
                    this._gatherAreaCorrectionTimer = 0;
                }
                // 产出资源（每游戏小时 = ratePerHour）
                // 【修复】dt 是 gameDt（真实秒），需乘以 timeSpeed 转为游戏秒，与消耗侧保持一致
                if (rs && matchedEffect.resourceType) {
                    const gameSeconds = dt * (game.timeSpeed || 60);
                    // 【新增】电力效率加成：工坊/医疗站受电力状态影响
                    const powerBonus = rs.getPowerEfficiencyBonus ? rs.getPowerEfficiencyBonus(this.currentScene) : 1.0;
                    // 【v4.37修复】应用难度采集效率倍率（之前此倍率未在产出中生效，导致高难度采集效率降低无效）
                    const _diffGatherMult = game.getDifficultyMult ? game.getDifficultyMult('gatherEfficiencyMult') : 1.0;
                    const rate = matchedEffect.ratePerHour / 3600 * staminaEfficiency * specialtyMultiplier * powerBonus * _diffGatherMult;
                    const produced = rate * gameSeconds;
                    // 【修复】改用addResource方法，让产出被正确统计到dailyCollected
                    // 旧代码直接写rs[type]会绕过统计和电力恢复检测
                    if (rs.addResource) {
                        rs.addResource(matchedEffect.resourceType, produced);
                    } else {
                        rs[matchedEffect.resourceType] = (rs[matchedEffect.resourceType] || 0) + produced;
                    }
                    // 【任务10】更新目标追踪计数器
                    if (this._goalTrackers) {
                        if (matchedEffect.resourceType === 'woodFuel') {
                            this._goalTrackers.woodChopped = (this._goalTrackers.woodChopped || 0) + produced;
                        }
                        this._goalTrackers.gatherCount = (this._goalTrackers.gatherCount || 0) + produced;
                    }

                    // 【任务8】工作产出累计统计与定期日志
                    if (!this._productionStats) this._productionStats = {};
                    const resType = matchedEffect.resourceType;
                    if (!this._productionStats[resType]) {
                        this._productionStats[resType] = { total: 0, sessionTotal: 0, lastLogTime: 0 };
                    }
                    this._productionStats[resType].total += produced;
                    this._productionStats[resType].sessionTotal += produced;
                    // 每游戏小时（3600游戏秒）输出一次产出日志
                    const gameTime = game.gameTimeSeconds || 0;
                    if (gameTime - this._productionStats[resType].lastLogTime >= 3600) {
                        this._productionStats[resType].lastLogTime = gameTime;
                        const hourlyTotal = this._productionStats[resType].sessionTotal;
                        if (hourlyTotal > 0.01) {
                            this._logDebug && this._logDebug('production',
                                `[产出统计] ${this.name} 本小时产出 ${resType}: +${hourlyTotal.toFixed(2)}` +
                                ` (效率: 体力${(staminaEfficiency*100).toFixed(0)}% 专长x${specialtyMultiplier} 电力x${powerBonus.toFixed(1)})` +
                                ` 累计: ${this._productionStats[resType].total.toFixed(2)}`
                            );
                            if (game.addEvent) {
                                game.addEvent(GST.t('action_effect.production', { name: this.name, resType, amount: hourlyTotal.toFixed(1), total: this._productionStats[resType].total.toFixed(1) }));
                            }
                        }
                        this._productionStats[resType].sessionTotal = 0;
                    }
                }
                break;
            }
            case 'build_progress': {
                // 推进暖炉建造进度
                const fs = game.furnaceSystem;
                if (fs) {
                    // 如果满足建造条件且还没开始建造，自动触发
                    if (!fs.isBuildingSecondFurnace && !fs.secondFurnaceBuilt && fs.checkBuildCondition()) {
                        // 只有王策（furnace_build专长）在工坊时才自动启动建造
                        if (this.config.id === 'wang_teacher' || this.config.specialties?.furnace_build) {
                            fs.startBuildSecondFurnace();
                            this._logDebug('action', `[效果] 触发暖炉建造启动！`);
                        }
                    }
                    // 如果正在建造中，作为工人贡献进度
                    if (fs.isBuildingSecondFurnace && !fs.secondFurnaceBuilt) {
                        if (!fs.buildWorkers.includes(this.id)) {
                            fs.buildWorkers.push(this.id);
                        }
                    }
                }
                break;
            }
            case 'build_machine': {
                // 建造自动化机器（发电机/伐木机）
                const ms = game.machineSystem;
                if (ms && matchedEffect.machineType) {
                    const mType = matchedEffect.machineType;
                    const machine = ms[mType];
                    if (machine && !machine.built) {
                        if (!machine.building) {
                            // 尚未开始建造，自动启动
                            ms.startBuild(mType, [this.id]);
                        } else {
                            // 已在建造中，作为工人加入
                            if (!machine.buildWorkers.includes(this.id)) {
                                machine.buildWorkers.push(this.id);
                            }
                        }
                    }
                }
                break;
            }
            case 'repair_machine': {
                // 【v4.22新增】维修故障机器（发电机/伐木机）
                // 实际维修进度由 machine-system.js 的 _tickMachine 通过 stateDesc 关键词检测来推进
                // 这里只需确保 NPC 的 stateDesc 包含正确的维修关键词
                const repairMs = game.machineSystem;
                if (repairMs && matchedEffect.machineType) {
                    const repairType = matchedEffect.machineType;
                    const repairMachine = repairMs[repairType];
                    if (repairMachine && repairMachine.broken) {
                        // 机器确实故障中，维修状态正确
                        if (matchedEffect.bubbleText) {
                            this.workBubble = matchedEffect.bubbleText;
                            this.workBubbleTimer = 8;
                        }
                    } else if (repairMachine && !repairMachine.broken) {
                        // 机器没故障，不需要维修 → 切换到空闲
                        this.stateDesc = repairMachine.built ? '检查机器运行状况' : '等待指令';
                    }
                }
                break;
            }
            case 'craft_medkit': {
                // 制作急救包（由任务5实现具体逻辑，这里标记状态）
                // 【修复】dt 需转为游戏秒
                if (!game._medkitCraftProgress) game._medkitCraftProgress = 0;
                const craftGameSeconds = dt * (game.timeSpeed || 60);
                const craftPowerBonus = rs ? (rs.getPowerEfficiencyBonus ? rs.getPowerEfficiencyBonus(this.currentScene) : 1.0) : 1.0;
                const craftRate = staminaEfficiency * specialtyMultiplier * craftPowerBonus;
                game._medkitCraftProgress += (craftGameSeconds / 7200) * craftRate; // 7200游戏秒(2游戏小时)产出1份
                // 【任务8】制作进度日志（每25%通知一次）
                const medkitPct = Math.floor(game._medkitCraftProgress * 100);
                if (!this._lastMedkitPctLog) this._lastMedkitPctLog = 0;
                if (medkitPct >= this._lastMedkitPctLog + 25 && medkitPct < 100) {
                    this._lastMedkitPctLog = Math.floor(medkitPct / 25) * 25;
                    this._logDebug && this._logDebug('production', `[进度] ${this.name}制作急救包 ${this._lastMedkitPctLog}%`);
                }
                if (game._medkitCraftProgress >= 1) {
                    game._medkitCraftProgress -= 1;
                    game._medkitCount = (game._medkitCount || 0) + 1;
                    // 【任务10】更新目标追踪
                    if (this._goalTrackers) {
                        this._goalTrackers.medkitsCrafted = (this._goalTrackers.medkitsCrafted || 0) + 1;
                    }
                    if (game.addEvent) {
                        game.addEvent(GST.t('action_effect.craft_medkit', { name: this.name, count: game._medkitCount }));
                    }
                    this._logDebug('action', `[效果] 制作急救包完成，总数:${game._medkitCount}`);
                }
                break;
            }
            // repair_radio 已移除（v4.5）
            case 'reduce_waste': {
                // 设置食物浪费减少标记（在用餐系统中使用）
                game._foodWasteReduction = true;
                game._foodWasteReductionTimer = 3600; // 标记持续1游戏小时
                // 【新增】设置木柴浪费减少标记（在资源消耗系统中使用，减少10%木柴消耗）
                game._woodWasteReduction = true;
                game._woodWasteReductionTimer = 3600; // 标记持续1游戏小时
                // 【优化】减少浪费等同于食物产出（+3食物/游戏小时）
                if (rs) {
                    const wasteGameSeconds = dt * (game.timeSpeed || 60);
                    const wasteRate = (3 / 3600) * wasteGameSeconds * specialtyMultiplier;
                    rs.food = (rs.food || 0) + Math.min(wasteRate, 0.05);
                }
                break;
            }
            case 'medical_heal': {
                // 【v2.1重构】医疗效果：同场景NPC健康恢复（降低速率，让急救包有存在价值）
                // 修改：同场景恢复从0.01降为0.005/游戏秒，移除全局光环
                const healGameSeconds = dt * (game.timeSpeed || 60);
                const healPowerBonus = rs ? (rs.getPowerEfficiencyBonus ? rs.getPowerEfficiencyBonus(this.currentScene) : 1.0) : 1.0;
                const npcsInScene = game.npcs.filter(n =>
                    !n.isDead && n.id !== this.id && n.currentScene === this.currentScene
                );
                // 【v4.26d】出诊冷却递减
                if (this._houseCallCooldown > 0) this._houseCallCooldown -= dt;
                // 【v4.34】检查同场景是否有需要治疗的NPC（HP<100）
                const hasPatients = npcsInScene.some(n => n.health < 100 || n.sanity < 100);
                if (hasPatients) {
                    for (const npc of npcsInScene) {
                        if (npc.health < 100) {
                            // 【v2.1】同场景健康恢复从0.01降为0.005（让急救包有用）
                            npc.health = Math.min(100, npc.health + 0.005 * healGameSeconds * specialtyMultiplier * healPowerBonus);
                        }
                        // 同场景NPC San值恢复（心理疏导）
                        if (npc.sanity < 100) {
                            npc.sanity = Math.min(100, npc.sanity + 0.005 * healGameSeconds * specialtyMultiplier);
                        }
                    }
                    this._medicalIdleCrafting = false; // 有患者，清除制药标记
                } else {
                    // 【v4.34】无患者时自动制药（不浪费时间空等）
                    // 直接执行craft_medkit的制药逻辑，不改变stateDesc
                    if (this.currentScene === 'medical') {
                        this._medicalIdleCrafting = true; // 标记正在副业制药
                        if (!game._medkitCraftProgress) game._medkitCraftProgress = 0;
                        const idleCraftGameSeconds = dt * (game.timeSpeed || 60);
                        const idleCraftPowerBonus = rs ? (rs.getPowerEfficiencyBonus ? rs.getPowerEfficiencyBonus(this.currentScene) : 1.0) : 1.0;
                        const idleCraftRate = staminaEfficiency * specialtyMultiplier * idleCraftPowerBonus;
                        game._medkitCraftProgress += (idleCraftGameSeconds / 7200) * idleCraftRate;
                        if (game._medkitCraftProgress >= 1) {
                            game._medkitCraftProgress -= 1;
                            game._medkitCount = (game._medkitCount || 0) + 1;
                            if (this._goalTrackers) {
                                this._goalTrackers.medkitsCrafted = (this._goalTrackers.medkitsCrafted || 0) + 1;
                            }
                            if (game.addEvent) {
                                game.addEvent(GST.t('action_effect.craft_medkit', { name: this.name, count: game._medkitCount }));
                            }
                        }
                    }
                }
                // 【v4.27重构】出诊逻辑已提取到独立的_updateHouseCall方法中
                // 不再在medical_heal内部处理出诊，避免requiredScene:'medical'限制导致出诊无法触发
                // 【v2.1】移除全局健康恢复光环（原+0.005/秒太强，导致急救包永远用不上）
                // 急救包触发阈值从健康<50提高到<60，让急救包更容易触发
                if (game._medkitCount > 0) {
                    const critical = npcsInScene.filter(n => n.health < 60).sort((a, b) => a.health - b.health);
                    if (critical.length > 0 && !this._medkitUseCooldown) {
                        const target = critical[0];
                        game._medkitCount--;
                        // 苏岩（medical_treatment专长）恢复翻倍为+50，其他为+25
                        const isMedicalExpert = !!(this.config.specialties && this.config.specialties.medical_treatment);
                        const healAmount = isMedicalExpert ? 50 : 25;
                        target.health = Math.min(100, target.health + healAmount);
                        this._medkitUseCooldown = 30; // 30秒冷却
                        if (game.addEvent) {
                            game.addEvent(GST.t('action_effect.medkit_heal', { name: this.name, target: target.name, amount: healAmount, health: Math.round(target.health), expert: isMedicalExpert ? GST.t('action_effect.expert_bonus') : '' }));
                        }
                        this._logDebug('action', `[效果] 苏岩增强路径：使用急救包治疗${target.name}，恢复+${healAmount}`);
                    }
                }
                if (this._medkitUseCooldown > 0) this._medkitUseCooldown -= dt * (game.timeSpeed || 60);
                break;
            }
            case 'explore_ruins': {
                // 废墟探索——每1游戏小时触发一次随机探索
                // 【修复】当天已exhausted时不再反复触发fallback，避免废墟↔矿渣堆来回跑
                const curDay = game.dayCount || 1;
                if (this._ruinsExhaustedDay === curDay) {
                    // 当天废墟已搜刮干净，不再执行探索逻辑
                    // 如果还没fallback过，执行一次fallback
                    if (!this._ruinsFallbackDone) {
                        this._ruinsFallbackDone = true;
                        // 【修复】废墟耗尽后取消taskOverride，否则taskOverride持续把NPC拉回ruins_site
                        if (this._taskOverride && this._taskOverride.isActive &&
                            this._taskOverride.targetLocation === 'ruins_site') {
                            this.deactivateTaskOverride();
                        }
                        this._fallbackToRoleDefaultAction(game);
                    }
                    break;
                }
                if (!this._ruinsExploreTimer) this._ruinsExploreTimer = 0;
                const exploreGameSeconds = dt * (game.timeSpeed || 60);
                this._ruinsExploreTimer += exploreGameSeconds;
                if (this._ruinsExploreTimer >= 3600) { // 每游戏小时一次
                    this._ruinsExploreTimer -= 3600;
                    if (rs && rs.performRuinsExploration) {
                        const result = rs.performRuinsExploration(this);
                        if (result && result.type === 'exhausted') {
                            // 标记当天已exhausted，防止重复触发
                            this._ruinsExhaustedDay = curDay;
                            this._ruinsFallbackDone = true;
                            // 【修复】废墟耗尽后取消taskOverride，否则taskOverride持续把NPC拉回ruins_site
                            if (this._taskOverride && this._taskOverride.isActive &&
                                this._taskOverride.targetLocation === 'ruins_site') {
                                this.deactivateTaskOverride();
                            }
                            this._fallbackToRoleDefaultAction(game);
                        }
                    }
                }
                break;
            }
            // furnace_maintain 已移除（v4.13: 暖炉是被动系统，自动燃烧消耗木柴，不需要专人维护）
            case 'patrol_bonus': {
                // 巡逻/警戒——全队San恢复加成+10%
                game._patrolBonus = true;
                game._patrolBonusTimer = 3600;
                // 【优化】巡逻为同场景NPC提供San恢复加成（+0.005/游戏秒）
                // 【修复】排除自身，巡逻效果只给同场景其他NPC加San
                const patrolGameSeconds = dt * (game.timeSpeed || 60);
                const patrolNpcs = game.npcs.filter(n =>
                    !n.isDead && n.id !== this.id && n.currentScene === this.currentScene
                );
                for (const npc of patrolNpcs) {
                    if (npc.sanity < 100) {
                        npc.sanity = Math.min(100, npc.sanity + 0.005 * patrolGameSeconds * specialtyMultiplier);
                    }
                }
                break;
            }
            case 'morale_boost': {
                // 安抚鼓舞——当前场景内NPC San值恢复
                // 【增强】基础速率从0.005提升至0.10，老钱专长×2.0后=0.20/秒，接近歆玥演出水平
                // 【修复】dt 需转为游戏秒
                const moraleGameSeconds = dt * (game.timeSpeed || 60);

                // 【新增】体力下限保护：体力<15时停止安抚效果
                if (this.stamina < 15) {
                    if (!this._moraleBoostTiredNotified) {
                        this._moraleBoostTiredNotified = true;
                        this.workBubble = GST.t('bubble.too_tired_comfort');
                        this.workBubbleTimer = 3;
                    }
                    break;
                }
                this._moraleBoostTiredNotified = false;

                // 【v4.40修复】先检查同场景是否有需要安抚的NPC
                const npcsInScene2 = game.npcs.filter(n =>
                    !n.isDead && n.id !== this.id && n.currentScene === this.currentScene
                );
                const hasTargets = npcsInScene2.some(n => n.sanity < 100);

                if (hasTargets) {
                    // 有安抚目标：正常消耗体力 + 给同场景NPC加San
                    this.stamina = Math.max(0, this.stamina - 0.002 * moraleGameSeconds);
                    for (const npc of npcsInScene2) {
                        if (npc.sanity < 100) {
                            npc.sanity = Math.min(100, npc.sanity + 0.003 * moraleGameSeconds * specialtyMultiplier);
                        }
                    }
                }
                // 无安抚目标时：不消耗体力，气泡层会处理自我休整逻辑
                break;
            }
        }

        // 【新增】动态气泡文本：为所有效果类型添加实时数值信息（含体力效率、专长倍率）
        let dynamicBubble = matchedEffect.bubbleText || '';
        switch (matchedEffect.effectType) {
            case 'produce_resource': {
                // 动态计算实际产出速率（ratePerHour × 体力效率 × 专长倍率 × 电力加成 × 难度采集效率）
                const bubblePowerBonus = rs && rs.getPowerEfficiencyBonus ? rs.getPowerEfficiencyBonus(this.currentScene) : 1.0;
                const _bubbleGatherMult = game.getDifficultyMult ? game.getDifficultyMult('gatherEfficiencyMult') : 1.0;
                const actualRate = (matchedEffect.ratePerHour || 0) * staminaEfficiency * specialtyMultiplier * bubblePowerBonus * _bubbleGatherMult;
                const rateDisplay = actualRate.toFixed(1);
                if (matchedEffect.resourceType === 'woodFuel') {
                    dynamicBubble = `🪓 ${GST.t('bubble.chopping', { rate: rateDisplay })}`;
                } else if (matchedEffect.resourceType === 'food') {
                    dynamicBubble = `🎣 ${GST.t('bubble.fishing', { rate: rateDisplay })}`;
                } else if (matchedEffect.resourceType === 'power') {
                    // 区分人工发电和修理工具
                    const isRepairTool = (this.stateDesc || '').includes('修理工具');
                    const isOutdoorMining = this.currentScene === 'village';
                    if (isOutdoorMining) {
                        dynamicBubble = `⛏️ ${GST.t('bubble.mining', { rate: rateDisplay })}`;
                    } else {
                        dynamicBubble = isRepairTool
                            ? `🔧 ${GST.t('bubble.repair_tool', { rate: rateDisplay })}`
                            : `⚡ ${GST.t('bubble.manual_power', { rate: rateDisplay })}`;
                    }
                }
                break;
            }
            case 'craft_medkit': {
                // 【v4.28】苏岩在medical制药时，如果有伤员来了，触发紧急决策让NPC自己判断
                const isMedExpertCraft = !!(this.config.specialties && this.config.specialties.medical_treatment);
                if (isMedExpertCraft && this.currentScene === 'medical') {
                    const injuredInMedical = game.npcs.filter(n =>
                        !n.isDead && n.id !== this.id && n.currentScene === 'medical' && n.health < 70
                    );
                    if (injuredInMedical.length > 0) {
                        const injNames = injuredInMedical.map(n => `${n.name}(HP:${Math.round(n.health)})`).join('、');
                        this._triggerEmergencyDecision(
                            `你正在制药，但同场景有伤员需要治疗：${injNames}。请决定是继续制药还是转去坐诊治疗伤员。`,
                            game
                        );
                    }
                }
                // 计算制作进度百分比和库存数量
                const medkitProgress = Math.min(100, Math.floor((game._medkitCraftProgress || 0) * 100));
                const medkitStock = game._medkitCount || 0;
                dynamicBubble = GST.t('bubble.crafting_medicine', { pct: medkitProgress, stock: medkitStock });
                break;
            }
            // repair_radio bubble 已移除（v4.5）
            case 'explore_ruins': {
                // 废墟探索气泡
                const rs2 = game.resourceSystem;
                const remaining = rs2 ? rs2.getRuinsExploresRemaining() : 0;
                dynamicBubble = remaining > 0
                    ? `🔍 ${GST.t('bubble.exploring_ruins', { remaining })}`
                    : `🔍 ${GST.t('bubble.ruins_depleted')}`;
                break;
            }
            case 'build_progress': {
                // 读取暖炉建造进度
                const fs = game.furnaceSystem;
                if (fs && fs.isBuildingSecondFurnace && !fs.secondFurnaceBuilt) {
                    const buildPct = Math.min(100, Math.floor((fs.buildProgress || 0) * 100));
                    dynamicBubble = `🔨 ${GST.t('bubble.furnace_building', { pct: buildPct })}`;
                } else if (fs && fs.secondFurnaceBuilt) {
                    dynamicBubble = `🔨 ${GST.t('bubble.furnace_built')}`;
                } else {
                    dynamicBubble = `🔨 ${GST.t('bubble.furnace_designing')}`;
                }
                break;
            }
            case 'build_machine': {
                // 读取机器建造进度
                const ms2 = game.machineSystem;
                if (ms2 && matchedEffect.machineType) {
                    const mach = ms2[matchedEffect.machineType];
                    const mConf = GST.MACHINE_CONFIG ? GST.MACHINE_CONFIG[matchedEffect.machineType] : null;
                    const machName = mConf ? mConf.name : matchedEffect.machineType;
                    if (mach && mach.building && !mach.built) {
                        const machPct = Math.min(100, Math.floor((mach.buildProgress || 0) * 100));
                        dynamicBubble = `🏗️ ${GST.t('bubble.building', { name: machName, pct: machPct, workers: mach.buildWorkers.length })}`;
                    } else if (mach && mach.built) {
                        dynamicBubble = `🏗️ ${GST.t('bubble.built_done', { name: machName })}`;
                    } else {
                        dynamicBubble = `🏗️ ${GST.t('bubble.preparing_build', { name: machName })}`;
                    }
                }
                break;
            }
            case 'repair_machine': {
                // 【v4.22新增】读取机器维修进度
                const repairMs2 = game.machineSystem;
                if (repairMs2 && matchedEffect.machineType) {
                    const repairMach = repairMs2[matchedEffect.machineType];
                    const repairConf = GST.MACHINE_CONFIG ? GST.MACHINE_CONFIG[matchedEffect.machineType] : null;
                    const repairName = repairConf ? repairConf.name : matchedEffect.machineType;
                    if (repairMach && repairMach.broken) {
                        const repairPct = Math.min(100, Math.floor((repairMach._repairProgress || 0) * 100));
                        dynamicBubble = `🔧 ${GST.t('bubble.repairing', { name: repairName, pct: repairPct })}`;
                    } else if (repairMach && repairMach.built) {
                        dynamicBubble = `🔧 ${GST.t('bubble.running_ok', { name: repairName })}`;
                    } else {
                        dynamicBubble = `🔧 ${GST.t('bubble.checking', { name: repairName })}`;
                    }
                }
                break;
            }
            case 'reduce_waste': {
                // 动态计算食物产出（3/h × 专长倍率）
                const wasteFood = (3 * specialtyMultiplier).toFixed(1);
                const wasteFuelPct = Math.round(10 * specialtyMultiplier);
                dynamicBubble = `📦 ${GST.t('bubble.managing_warehouse', { food: wasteFood, fuel: wasteFuelPct })}`;
                break;
            }
            case 'medical_heal': {
                // 【v4.4.3】更新气泡文本：显示具体治疗对象
                const healPerHour = (0.005 * 3600 * specialtyMultiplier).toFixed(0);
                const medkitInfo = (game._medkitCount || 0) > 0 ? `💊×${game._medkitCount}` : '⚠️无急救包';
                // 找出同场景中HP最低的NPC作为显示对象
                const healTargets = game.npcs.filter(n =>
                    !n.isDead && n.id !== this.id && n.currentScene === this.currentScene && n.health < 100
                ).sort((a, b) => a.health - b.health);
                if (healTargets.length > 0) {
                    const mainTarget = healTargets[0];
                    const othersCount = healTargets.length - 1;
                    const targetInfo = othersCount > 0
                        ? GST.t('bubble.n_others', { name: mainTarget.displayName || mainTarget.name, count: healTargets.length })
                        : (mainTarget.displayName || mainTarget.name);
                    dynamicBubble = GST.t('bubble.healing', { rate: healPerHour, medkit: medkitInfo, targets: targetInfo });
                } else {
                    // 【v4.26d重构】医疗站没有伤员时的行为
                    if (this._houseCallTarget) {
                        // 【v4.26d】正在出诊中，显示出诊状态
                        const hcTargetNpc = game.npcs.find(n => n.id === this._houseCallTarget);
                        const hcTargetName = hcTargetNpc ? (hcTargetNpc.displayName || hcTargetNpc.name) : 'patient';
                        const hcTargetHp = hcTargetNpc ? Math.round(hcTargetNpc.health) : '?';
                        dynamicBubble = GST.t('bubble.house_call_heading', { medkit: medkitInfo, target: hcTargetName, hp: hcTargetHp });
                    } else if (this._medicalIdleCrafting && this.currentScene === 'medical') {
                        // 【v4.39修复】无同场景患者且正在副业制药时，优先显示制药气泡
                        // 之前被globalInjuredBubble分支拦截，导致制药气泡永远不显示
                        const idleMedkitProgress = Math.min(100, Math.floor((game._medkitCraftProgress || 0) * 100));
                        const idleMedkitStock = game._medkitCount || 0;
                        // 附带全地图伤员信息，让玩家知道医生在制药但也关注着伤员
                        const globalInjuredForCraft = game.npcs.filter(n =>
                            !n.isDead && n.id !== this.id && n.health < 70
                        );
                        let craftExtra = '';
                        if (globalInjuredForCraft.length > 0) {
                            const injNames = globalInjuredForCraft.map(n => n.displayName || n.name).join(', ');
                            craftExtra = GST.i18n && GST.i18n.isEn && GST.i18n.isEn()
                                ? `\n   📋 ${injNames} injured, can visit after crafting`
                                : `\n   📋 ${injNames}有伤，制完药可出诊`;
                        }
                        dynamicBubble = GST.t('bubble.idle_crafting', { pct: idleMedkitProgress, stock: idleMedkitStock, extra: craftExtra });
                    } else {
                        // 检查全局伤员
                        const globalInjuredBubble = game.npcs.filter(n =>
                            !n.isDead && n.id !== this.id && n.health < 70
                        );
                        // 【v5.0修复】坐诊时如果同时在制药，也显示制药进度
                        const idleCraftInfo = (this._medicalIdleCrafting && this.currentScene === 'medical')
                            ? (GST.i18n && GST.i18n.isEn && GST.i18n.isEn()
                                ? `\n   💊 Crafting (Progress ${Math.min(100, Math.floor((game._medkitCraftProgress || 0) * 100))}%)`
                                : `\n   💊 制药中（进度${Math.min(100, Math.floor((game._medkitCraftProgress || 0) * 100))}%）`)
                            : '';
                        if (globalInjuredBubble.length > 0) {
                            const injuredNames = globalInjuredBubble.map(n => `${n.displayName || n.name}(HP:${Math.round(n.health)})`).join(', ');
                            const isMedExpert = !!(this.config.specialties && this.config.specialties.medical_treatment);
                            if (isMedExpert && !(this._houseCallCooldown > 0)) {
                                dynamicBubble = GST.t('bubble.medical_preparing_hc', { medkit: medkitInfo, names: injuredNames, extra: idleCraftInfo });
                            } else {
                                const cdRemain = this._houseCallCooldown > 0
                                    ? (GST.i18n && GST.i18n.isEn && GST.i18n.isEn()
                                        ? `(can visit in ${Math.round(this._houseCallCooldown)}s)`
                                        : `(${Math.round(this._houseCallCooldown)}s后可出诊)`)
                                    : '';
                                dynamicBubble = GST.t('bubble.medical_standby_cd', { medkit: medkitInfo, cd: cdRemain, names: injuredNames, extra: idleCraftInfo });
                            }
                        } else {
                            // 【v4.29修复】无人需要治疗 → 扫描全地图找受伤NPC，提供具体信息给LLM决策
                            dynamicBubble = GST.t('bubble.medical_standby', { medkit: medkitInfo, extra: idleCraftInfo });
                            if (!this._medicalIdleHintTime || (Date.now() - this._medicalIdleHintTime > 60000)) {
                                this._medicalIdleHintTime = Date.now();
                                // 清除当前工作驻留，允许LLM决策生效
                                this._workResidenceActive = false;
                                this._workResidenceTimer = 0;
                                // 扫描全地图：找出所有受伤的NPC（HP < 80），按HP排序
                                const allInjuredNpcs = game.npcs.filter(n =>
                                    !n.isDead && n.id !== this.id && n.health < 80
                                ).sort((a, b) => a.health - b.health);
                                let healthReport = '';
                                if (allInjuredNpcs.length > 0) {
                                    healthReport = '以下同伴受伤需要治疗：\n' +
                                        allInjuredNpcs.map(n => {
                                            const sceneName = n.getSceneLabel ? n.getSceneLabel() : n.currentScene;
                                            const urgency = n.health < 30 ? '🔴危急' : n.health < 50 ? '🟡较重' : '🟢轻伤';
                                            return `  - ${n.name}（HP:${Math.round(n.health)}, ${urgency}）在${sceneName}`;
                                        }).join('\n') +
                                        '\n你可以考虑出诊去治疗他们，或者留在医疗站帮忙制药备药。';
                                } else {
                                    healthReport = '目前全镇所有人健康状况都还不错（HP≥80），你不需要治疗任何人。你应该休息恢复自己的精力和体力，或者帮忙制药备药。';
                                }
                                this._triggerEmergencyDecision(
                                    `你正在医疗站坐诊，但目前没有伤员来就诊。${healthReport}`,
                                    game
                                );
                            }
                        }
                    }
                }
                break;
            }
            case 'morale_boost': {
                // 【v4.4.3】动态计算San恢复速率 + 显示安抚对象
                const sanPerHour = (0.003 * 3600 * specialtyMultiplier).toFixed(1);
                const moraleTargets = game.npcs.filter(n =>
                    !n.isDead && n.id !== this.id && n.currentScene === this.currentScene && n.sanity < 100
                ).sort((a, b) => a.sanity - b.sanity);
                if (moraleTargets.length > 0) {
                    const mainMTarget = moraleTargets[0];
                    const mOthersCount = moraleTargets.length - 1;
                    const mTargetInfo = mOthersCount > 0
                        ? GST.t('bubble.n_others', { name: mainMTarget.displayName || mainMTarget.name, count: moraleTargets.length })
                        : (mainMTarget.displayName || mainMTarget.name);
                    dynamicBubble = `💬 ${GST.t('bubble.morale_boost', { rate: sanPerHour, targets: mTargetInfo })}`;
                } else {
                    // 【v4.40修复】无人需要安抚 → NPC自我休整恢复San值，不再傻站着
                    // 扫描全地图找精神状态不好的人
                    const allLowSanNpcs = game.npcs.filter(n =>
                        !n.isDead && n.id !== this.id && !n.isSleeping && n.sanity < 80
                    ).sort((a, b) => a.sanity - b.sanity);

                    if (allLowSanNpcs.length > 0) {
                        // 有人需要安抚但不在同场景 → 提示NPC去找他们
                        const sanReport = '以下同伴精神状态不好，需要你去安抚：\n' +
                            allLowSanNpcs.map(n => {
                                const sceneName = n.getSceneLabel ? n.getSceneLabel() : n.currentScene;
                                const urgency = n.sanity < 30 ? '🔴危急' : n.sanity < 50 ? '🟡较差' : '🟢偏低';
                                return `  - ${n.name}（San:${Math.round(n.sanity)}, ${urgency}）在${sceneName}`;
                            }).join('\n') +
                            '\n请优先去精神状态最差的人所在的场景安抚他们。';
                    dynamicBubble = `💬 ${GST.t('bubble.morale_standby')}`;
                        if (!this._moraleIdleHintTime || (Date.now() - this._moraleIdleHintTime > 60000)) {
                            this._moraleIdleHintTime = Date.now();
                            this._workResidenceActive = false;
                            this._workResidenceTimer = 0;
                            this._triggerEmergencyDecision(
                                `你正在安抚鼓舞，但同场景目前没有人需要安抚。${sanReport}`,
                                game
                            );
                        }
                    } else {
                        // 【核心改动】全镇无人需要安抚 → 自我休整，恢复自身San值
                        // 安抚者也需要照顾自己的精神状态
                        const moraleGameSeconds = dt * (game.timeSpeed || 60);
                        const selfSanRecovery = 0.06 * moraleGameSeconds; // 与休息恢复速率相同
                        this.sanity = Math.min(100, this.sanity + selfSanRecovery);
                        // 体力也少量恢复（相当于轻度休息）
                        this.stamina = Math.min(100, this.stamina + 0.02 * moraleGameSeconds);
                        const selfSanPerHour = (0.06 * 3600).toFixed(1);
                        dynamicBubble = GST.t('bubble.self_rest', { rate: selfSanPerHour });
                        // 每3分钟检查一次是否有新的安抚需求
                        if (!this._moraleIdleHintTime || (Date.now() - this._moraleIdleHintTime > 180000)) {
                            this._moraleIdleHintTime = Date.now();
                            this._logDebug && this._logDebug('action', `[自我休整] ${this.name} 全镇无人需要安抚，自我休整恢复San`);
                        }
                    }
                }
                break;
            }
            case 'patrol_bonus': {
                // 动态计算San恢复速率（修正后0.005/游戏秒 × 3600 × 专长倍率）
                const patrolSanPerHour = (0.005 * 3600 * specialtyMultiplier).toFixed(1);
                // 【修复】检查同场景是否有San未满的NPC
                const hasLowSanNpc = game.npcs.some(n =>
                    !n.isDead && n.id !== this.id && n.currentScene === this.currentScene && n.sanity < 100
                );
                dynamicBubble = hasLowSanNpc
                    ? GST.t('bubble.patrol_with_companion', { rate: patrolSanPerHour })
                    : GST.t('bubble.patrol_solo');
                break;
            }
            // furnace_maintain 已移除（v4.13）
        }        // 【v4.35】工作效果气泡使用独立通道workBubble，不与expression竞争
        // 工作气泡每帧更新，始终显示最新的工作状态
        this.workBubble = dynamicBubble;
        this.workBubbleTimer = 3;

        // 【优化】NPC离开辅助效果对应场景时，清除全局标记
        if (matchedEffect.effectType === 'reduce_waste' || matchedEffect.effectType === 'patrol_bonus') {
            // 上面的 requiredScene 检查已确保NPC在正确场景时才执行效果
            // 这里额外处理：检查是否有NPC仍在执行该辅助效果，如果没有则清除标记
            // （由于每帧都会执行，标记会被在场NPC重新设置，所以无需额外检查）
        }

    }

    /**
     * 【新增】独立的全局急救包自动使用检查
     * 不限于苏岩坐诊，任何NPC的update周期都会触发检查
     * 条件：有急救包库存 + 有NPC健康<50 + 无冷却
     */;

    /**
     * 【v4.27重构】苏岩出诊系统 — 独立于medical_heal效果，不受requiredScene限制
     * 解决问题：之前出诊逻辑在medical_heal case内部，受requiredScene:'medical'限制，
     * 苏岩只有在医疗站内才能检测到需要出诊，且出门后日程系统会覆盖出诊导航把她拉回医疗站。
     * 
     * 修复方案：
     * 1. 出诊检查独立为_updateHouseCall，在_updateActionEffect开头调用
     * 2. 出诊时设置_taskOverride保护导航不被日程/LLM覆盖
     * 3. 到达后清除_taskOverride，同场景治疗效果自动生效
     */
    proto._updateHouseCall = function(dt, game) {
        // 只有苏岩（有medical_treatment专长）才会出诊
        const isMedicalExpert = !!(this.config.specialties && this.config.specialties.medical_treatment);
        if (!isMedicalExpert) return;

        // 出诊冷却递减（真实时间）
        if (this._houseCallCooldown > 0) this._houseCallCooldown -= dt;

        // 【出诊现场治疗】苏岩到达伤员场景后，在非medical场景直接执行治疗
        if (this._houseCallHealing) {
            const healTarget = game.npcs.find(n => n.id === this._houseCallHealingTarget);
            if (!healTarget || healTarget.isDead || healTarget.currentScene !== this.currentScene || healTarget.health >= 90) {
                // 治疗完成或目标离开/死亡
                this._houseCallHealing = false;
                this._houseCallHealingTarget = null;
                // 出诊结束，回医疗站
                this._navigateToScheduleTarget('medical_door', game);
                this.stateDesc = '出诊结束，返回医疗站';
                if (game.addEvent && healTarget && !healTarget.isDead) {
                    game.addEvent(GST.t('action_effect.house_call_done', { name: this.name, target: healTarget.name, health: Math.round(healTarget.health) }));
                }
                return;
            }
            // 执行治疗：同场景所有伤员都受益
            const healGameSeconds = dt * (game.timeSpeed || 60);
            const specialtyMult = this._getSpecialtyMultiplier({ effectType: 'medical_heal' });
            const rs = game.resourceSystem;
            const healPowerBonus = rs ? (rs.getPowerEfficiencyBonus ? rs.getPowerEfficiencyBonus(this.currentScene) : 1.0) : 1.0;
            const npcsHere = game.npcs.filter(n => !n.isDead && n.id !== this.id && n.currentScene === this.currentScene);
            for (const npc of npcsHere) {
                if (npc.health < 100) {
                    npc.health = Math.min(100, npc.health + 0.005 * healGameSeconds * specialtyMult * healPowerBonus);
                }
                if (npc.sanity < 100) {
                    npc.sanity = Math.min(100, npc.sanity + 0.005 * healGameSeconds * specialtyMult);
                }
            }
            // 出诊现场也可以使用急救包
            if (game._medkitCount > 0) {
                const critical = npcsHere.filter(n => n.health < 60).sort((a, b) => a.health - b.health);
                if (critical.length > 0 && !this._medkitUseCooldown) {
                    const target = critical[0];
                    game._medkitCount--;
                    const healAmount = 50; // 苏岩专业加成
                    target.health = Math.min(100, target.health + healAmount);
                    this._medkitUseCooldown = 30;
                    if (game.addEvent) {
                        game.addEvent(GST.t('action_effect.house_call_field_medkit', { name: this.name, target: target.name, amount: healAmount, health: Math.round(target.health) }));
                    }
                }
            }
            if (this._medkitUseCooldown > 0) this._medkitUseCooldown -= dt * (game.timeSpeed || 60);
            // 更新气泡
            this.workBubble = `🏥 ${GST.t('bubble.house_call_treating')}\n   → ${healTarget.displayName || healTarget.name}(HP:${Math.round(healTarget.health)})`;
            this.workBubbleTimer = 3;
            this.stateDesc = `出诊治疗${healTarget.name}中`;
            return;
        }

        // 【出诊到达检测】优先检测：如果正在出诊且已到达目标场景，清除出诊状态
        if (this._houseCallTarget) {
            const hcTarget = game.npcs.find(n => n.id === this._houseCallTarget);
            if (hcTarget && hcTarget.currentScene === this.currentScene) {
                // 已到达伤员所在场景，开始现场治疗
                if (game.addEvent) {
                    game.addEvent(GST.t('action_effect.house_call_arrive', { name: this.name, target: hcTarget.name, health: Math.round(hcTarget.health) }));
                }
                // 设置现场治疗标记
                this._houseCallHealing = true;
                this._houseCallHealingTarget = hcTarget.id;
                this._houseCallTarget = null;
                this._houseCallTargetScene = null;
                // 清除出诊taskOverride
                if (this._taskOverride && this._taskOverride.isActive && this._taskOverride.taskId === 'house_call') {
                    this.deactivateTaskOverride();
                }
                this.stateDesc = `出诊治疗${hcTarget.name}中`;
            } else if (!hcTarget || hcTarget.isDead) {
                // 目标已死亡或不存在，清除出诊
                this._houseCallTarget = null;
                this._houseCallTargetScene = null;
                if (this._taskOverride && this._taskOverride.isActive && this._taskOverride.taskId === 'house_call') {
                    this.deactivateTaskOverride();
                }
            } else if (hcTarget.health >= 70) {
                // 目标已恢复到安全线，取消出诊
                this._houseCallTarget = null;
                this._houseCallTargetScene = null;
                if (this._taskOverride && this._taskOverride.isActive && this._taskOverride.taskId === 'house_call') {
                    this.deactivateTaskOverride();
                }
            }
            return; // 正在出诊中，不再触发新的出诊
        }

        // 冷却中不触发新出诊
        if (this._houseCallCooldown > 0) return;

        // P0紧急状态下不出诊（自身健康/体力/失温等危急）
        if (this._priorityOverride && ['health_critical', 'stamina_critical', 'hypothermia', 'medical_urgent', 'day4_lockdown', 'sanity_critical', 'crazy_emergency'].includes(this._priorityOverride)) return;

        // 正在吃饭/睡觉/被治疗中不出诊
        if (this._hungerOverride || this._stateOverride || this._isBeingTreated) return;

        // 检查同场景是否已有HP<70的伤员（有的话就地治疗，不需要出诊）
        const npcsInScene = game.npcs.filter(n =>
            !n.isDead && n.id !== this.id && n.currentScene === this.currentScene
        );
        const injuredInScene = npcsInScene.filter(n => n.health < 70);
        if (injuredInScene.length > 0) return; // 同场景有伤员，就地治疗即可

        // 检查全局是否有需要治疗的NPC
        const globalInjured = game.npcs.filter(n =>
            !n.isDead && n.id !== this.id && n.health < 70
        ).sort((a, b) => a.health - b.health);
        if (globalInjured.length === 0) return; // 全局无伤员

        const houseCallTarget = globalInjured[0];
        const targetScene = houseCallTarget.currentScene;

        // 目标和自己在同一场景不需要出诊
        if (targetScene === this.currentScene) return;

        // 确定出诊目标所在场景的门口
        const sceneToDoor = {
            warehouse: 'warehouse_door', medical: 'medical_door',
            dorm_a: 'dorm_a_door', dorm_b: 'dorm_b_door',
            kitchen: 'kitchen_door', workshop: 'workshop_door',
        };
        const doorKey = sceneToDoor[targetScene];
        // 导航目标：室内场景用门口key，village用目标NPC位置
        const navTarget = doorKey || 'furnace_plaza'; // village场景走到暖炉广场附近

        // 设置出诊状态
        this._houseCallTarget = houseCallTarget.id;
        this._houseCallTargetScene = targetScene;
        this._houseCallCooldown = 60; // 60秒真实时间冷却

        // 【关键】设置taskOverride保护出诊导航不被日程系统/LLM覆盖
        this._taskOverride = {
            isActive: true,
            taskId: 'house_call',
            targetLocation: navTarget,
            desc: `出诊：前往${houseCallTarget.name}身边治疗`,
            priority: 'urgent',
            effectKey: null,
        };
        this._taskOverrideReached = false;
        this.scheduleReached = false;

        // 执行导航
        if (this.currentScene !== 'village') {
            // 苏岩在室内→先出门到village，出门后taskOverride导航会自动接管
            const _self = this;
            this._walkToDoorAndExit(game, function() {
                // 出门回调：到达village后，taskOverride导航系统会自动导航到目标
                // 不需要手动调用_navigateToScheduleTarget，P1层会处理
            });
        } else {
            // 苏岩已在village→直接导航到目标场景门口
            this._navigateToScheduleTarget(navTarget, game);
        }

        this.stateDesc = `出诊中，前往${houseCallTarget.name}身边治疗`;
        if (game.addEvent) {
            game.addEvent(GST.t('action_effect.house_call_start', { name: this.name, target: houseCallTarget.name, scene: targetScene }));
        }
        this._logDebug && this._logDebug('action', `[出诊] ${this.name}→${houseCallTarget.name}(${targetScene}) HP:${Math.round(houseCallTarget.health)}`);
    };

})();
