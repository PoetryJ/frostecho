/**
 * 福音镇 i18n - EN 主入口
 * 此文件已拆分为子模块，由 index.html 按顺序加载：
 *   - en/ui.js
 *   - en/npc.js
 *   - en/game.js
 *   - en/mapping.js
 *   - en/panel.js
 *
 * 注意：此文件现在只是一个空壳，实际翻译在子模块中
 */
(function() {
    'use strict';
    console.log('[i18n] en language pack loaded (modular)');
})();
