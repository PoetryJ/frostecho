/**
 * prompt-data-en.js — 英文版 LLM Prompt 动态数据函数
 * 当语言设置为英文时，prompt-templates-en.js 调用这些函数获取英文数据
 * 替代各系统模块中硬编码中文的 getXxxForPrompt() 函数
 * 
 * 设计原则：
 *   - 直接读取原始数值（woodFuel, food, power 等），用英文拼接
 *   - 不修改任何原始系统模块，纯增量文件
 *   - 所有函数接收 game 对象作为参数，自行提取所需数据
 */
(function () {
    'use strict';
    const _root = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});
    if (!_root.GST) _root.GST = {};
    const GST = _root.GST;

    // NPC 名称映射（中文ID → 英文显示名）
    const NPC_NAME_EN = {
        zhao_chef: 'Zhao Tiezhu', lu_chen: 'Lu Chen', li_shen: 'Aunt Li',
        wang_teacher: 'Wang Ce', old_qian: 'Old Qian', su_doctor: 'Dr. Su',
        ling_yue: 'Ling Yue', qing_xuan: 'Qing Xuan'
    };

    // 任务类型英文映射
    const TASK_SHORT_EN = {
        COLLECT_WOOD: 'Chop Wood', COLLECT_FOOD: 'Gather Food', COLLECT_MATERIAL: 'Explore Ruins',
        MAINTAIN_POWER: 'Maintain Power', COORDINATE: 'Coordinate', PREPARE_MEDICAL: 'Medical',
        SCOUT_RUINS: 'Scout Ruins', BOOST_MORALE: 'Boost Morale', BUILD_FURNACE: 'Build Furnace',
        PREPARE_WARMTH: 'Prepare Warmth', MAINTAIN_ORDER: 'Maintain Order',
        DISTRIBUTE_FOOD: 'Distribute Food', REST_RECOVER: 'Rest'
    };

    // ============ WeatherSystem 英文版 ============

    /**
     * 英文版 getSurvivalSummary
     */
    function getSurvivalSummaryEN(game) {
        const ws = game.weatherSystem;
        if (!ws) return '';
        const temp = ws.getEffectiveTemp();
        const alive = game.npcs.filter(n => !n.isDead).length;
        const rs = game.resourceSystem;
        const fs = game.furnaceSystem;
        return `[Survival Status] Day ${ws.currentDay} | Temp ${temp}°C | ${_weatherEN(ws.currentWeather)} | ` +
            `${alive}/8 alive | ` +
            (rs ? `Wood ${Math.round(rs.woodFuel)} Food ${Math.round(rs.food)} Power ${Math.round(rs.power)} | ` : '') +
            (fs ? `${getHeatingSummaryEN(game)}` : '');
    }

    /** 天气名称中文→英文 */
    function _weatherEN(weather) {
        const map = { '阴天': 'Overcast', '大雪': 'Heavy Snow', '晴冷': 'Clear Cold', '极寒暴风雪': 'Extreme Blizzard' };
        return map[weather] || weather;
    }

    /**
     * 英文版 getBlizzardUrgencyForPrompt
     */
    function getBlizzardUrgencyForPromptEN(game) {
        const ws = game.weatherSystem;
        if (!ws) return '';
        const day = ws.currentDay;
        const hour = game.getHour();
        const rs = game.resourceSystem;
        const fs = game.furnaceSystem;

        let urgency = '';
        let survivalChecklist = '';

        if (day === 1) {
            const hoursUntilStorm = Math.max(0, (4 - 1) * 24 - hour);
            urgency = `🚨 [Blizzard Warning] Today is Preparation Day (Day 1). The extreme blizzard will hit on Day 4 (-60°C!), approximately ${Math.round(hoursUntilStorm)} hours away. Tomorrow (Day 2) drops to -30°C heavy snow, continuous outdoor work over 2 hours causes severe frostbite.`;
            survivalChecklist = _buildSurvivalChecklistEN(rs, fs);
        } else if (day === 2) {
            const hoursUntilStorm = Math.max(0, (4 - 2) * 24 - hour);
            urgency = `🚨🚨 [Blizzard Approaching] Today is Day 2, -30°C heavy snow! Continuous outdoor work over 2 hours causes severe frostbite. Day 4 extreme blizzard (-60°C) is approximately ${Math.round(hoursUntilStorm)} hours away. Tomorrow (Day 3) temperature briefly rises to 0°C.`;
            survivalChecklist = _buildSurvivalChecklistEN(rs, fs);
        } else if (day === 3) {
            const hoursUntilStorm = Math.max(0, 24 - hour);
            urgency = `🚨🚨🚨 [Last Preparation Window! Blizzard hits tonight at midnight!] Today is Day 3 respite day, temperature briefly rises to 0°C. Tonight at midnight (approximately ${Math.round(hoursUntilStorm)} hours) enters Day 4 -60°C extreme blizzard. Everyone must stay indoors surviving on wood, power, and stored supplies.`;
            survivalChecklist = _buildSurvivalChecklistEN(rs, fs);
        } else if (day === 4) {
            urgency = `🚨🚨🚨 [Extreme Cold Has Arrived! -60°C!] Day 4, the extreme blizzard is raging! Going outdoors is extremely dangerous—rapid hypothermia and HP loss. Survive indoors with wood, power, and food. Hold out until sunset (18:00) for rescue.`;
            survivalChecklist = _buildSurvivalChecklistEN(rs, fs);
        }

        return urgency + (survivalChecklist ? '\n' + survivalChecklist : '');
    }

    /** 英文版 _buildSurvivalChecklist */
    function _buildSurvivalChecklistEN(rs, fs) {
        if (!rs) return '';
        const heatingStrength = fs && fs.getHeatingStrength ? fs.getHeatingStrength() : 0;
        const heatingPct = Math.round(heatingStrength * 100);

        const woodNeededDay4 = 72;
        const foodNeededDay4 = 8 * 2 * 2;
        const powerNeededDay4 = 5 * 24;

        let checklist = `📋 [Supply Check]\n`;
        checklist += `  🪵 Wood: ${Math.round(rs.woodFuel)} units (Day 4 needs at least ${woodNeededDay4}) ${rs.woodFuel >= woodNeededDay4 ? '✅Sufficient' : `❌Short ${Math.round(woodNeededDay4 - rs.woodFuel)} units!`}\n`;
        checklist += `  🍞 Food: ${Math.round(rs.food)} units (Day 4 needs at least ${foodNeededDay4}) ${rs.food >= foodNeededDay4 ? '✅Sufficient' : `❌Short ${Math.round(foodNeededDay4 - rs.food)} units!`}\n`;
        checklist += `  ⚡ Power: ${Math.round(rs.power)} units (Day 4 needs at least ${powerNeededDay4}) ${rs.power >= powerNeededDay4 ? '✅Sufficient' : `❌Short ${Math.round(powerNeededDay4 - rs.power)} units!`}\n`;
        checklist += `  🌡️ Heating ${heatingPct}% ${heatingStrength >= 0.75 ? '✅Stable' : '❌Weak, need more wood and power'}`;
        return checklist;
    }

    // ============ ResourceSystem 英文版 ============

    /**
     * 英文版 getResourceStatusForPrompt
     */
    function getResourceStatusForPromptEN(game) {
        const rs = game.resourceSystem;
        if (!rs) return '';
        const woodH = rs.getWoodFuelHoursRemaining();
        const foodM = rs.getFoodMealsRemaining();
        const powerH = rs.getPowerHoursRemaining();
        const RUINS_MAX = GST._resource_system_RUINS_MAX_EXPLORES_PER_DAY || 3;

        let status = `Wood ${Math.round(rs.woodFuel)}(${woodH === Infinity ? '∞' : Math.round(woodH)}h left) `;
        status += `Food ${Math.round(rs.food)}(${foodM === Infinity ? '∞' : foodM} meals left) `;
        status += `Power ${Math.round(rs.power)}(${powerH === Infinity ? '∞' : Math.round(powerH)}h left) `;
        status += `Ruins Exploration(${RUINS_MAX - rs.ruinsExploresToday} left today)`;

        if (game.machineSystem) {
            status += ` | ${getMachineStatusForPromptEN(game)}`;
        }

        if (rs.hasAnyCrisis()) {
            status += ' ⚠️Crisis:';
            if (rs.crisisFlags.noFood) status += ' No Food!';
            if (rs.crisisFlags.noPower) status += ' No Power!';
            if (rs.crisisFlags.noWoodFuel) status += ' No Wood!';
        }

        return status;
    }

    /**
     * 英文版 getResourceSituationBrief
     */
    function getResourceSituationBriefEN(game) {
        const rs = game.resourceSystem;
        if (!rs) return '';
        const tension = rs.getResourceTension();
        const woodH = rs.getWoodFuelHoursRemaining();
        const foodM = rs.getFoodMealsRemaining();
        const powerH = rs.getPowerHoursRemaining();

        const ms = game.machineSystem;
        const generatorOk = ms && ms.generator.built && ms.generator.running && !ms.generator.broken;
        const lumberMillOk = ms && ms.lumberMill.built && ms.lumberMill.running && !ms.lumberMill.broken;
        const hasMachines = generatorOk || lumberMillOk;

        const fs = game.furnaceSystem;
        const heatingOk = fs && fs.heatingStatus === 'stable';

        let brief = '';

        if (tension < 0.05 && hasMachines) {
            brief = `📊[Current Situation] Supplies abundant (wood for ${Math.round(woodH)}h, food for ${foodM} meals, power for ${Math.round(powerH)}h), `;
            if (generatorOk && lumberMillOk) brief += 'generator and lumber mill both running automatically.';
            else if (generatorOk) brief += 'generator running automatically.';
            else if (lumberMillOk) brief += 'lumber mill running automatically.';
            if (heatingOk) brief += ' Heating stable.';
            brief += '\nNo urgent gathering needed. You can freely arrange your time—rest, socialize, explore ruins, or do anything meaningful.';
        } else if (tension < 0.1) {
            brief = `📊[Current Situation] Supplies normal (wood for ${Math.round(woodH)}h, food for ${foodM} meals, power for ${Math.round(powerH)}h).`;
            if (heatingOk) brief += ' Heating stable.';
            brief += '\nReserves are adequate but still need replenishment. Arrange your time based on your condition and judgment.';
        } else if (tension < 0.3) {
            brief = `📊[Current Situation] Supplies tight (wood for ${Math.round(woodH)}h, food for ${foodM} meals, power for ${Math.round(powerH)}h).`;
            brief += '\nSome resource reserves are insufficient, attention needed.';
        } else {
            brief = `📊[Current Situation] Supplies critical! (wood for ${Math.round(woodH)}h, food for ${foodM} meals, power for ${Math.round(powerH)}h).`;
            if (rs.hasAnyCrisis()) {
                if (rs.crisisFlags.noFood) brief += ' ⚠️Food nearly depleted!';
                if (rs.crisisFlags.noPower) brief += ' ⚠️Power nearly depleted!';
                if (rs.crisisFlags.noWoodFuel) brief += ' ⚠️Wood nearly depleted!';
            }
        }

        const aliveCount = game.npcs.filter(n => !n.isDead).length;
        const totalCount = game.npcs.length;
        const lowSanCount = game.npcs.filter(n => !n.isDead && n.sanity < 40).length;
        const sickCount = game.npcs.filter(n => !n.isDead && n.isSick).length;

        if (lowSanCount > 0 || sickCount > 0) {
            brief += `\n👥 Town: ${aliveCount}/${totalCount} alive`;
            if (lowSanCount > 0) brief += `, ${lowSanCount} with poor mental state`;
            if (sickCount > 0) brief += `, ${sickCount} sick`;
            brief += '.';
        }

        return brief;
    }

    /**
     * 英文版 getUrgencyPrompt
     */
    function getUrgencyPromptEN(game) {
        const rs = game.resourceSystem;
        if (!rs) return '';
        const urgency = rs.getResourceUrgency();
        const alerts = [];
        const resourceStatus = [];

        const woodHours = Math.round(rs.getWoodFuelHoursRemaining());
        const powerHours = Math.round(rs.getPowerHoursRemaining());
        const foodMeals = Math.round(rs.getFoodMealsRemaining());

        if (urgency.wood === 'critical') {
            alerts.push(`🔴 Wood critically low! Only ${woodHours} hours of burning left.`);
            resourceStatus.push({ name: 'Wood', hours: woodHours, level: 'critical' });
        } else if (urgency.wood === 'warning') {
            alerts.push(`🟡 Wood reserves low (${Math.round(rs.woodFuel)} units, ${woodHours}h left).`);
            resourceStatus.push({ name: 'Wood', hours: woodHours, level: 'warning' });
        }

        if (urgency.food === 'critical') {
            alerts.push(`🔴 Not enough food for the next meal!`);
            resourceStatus.push({ name: 'Food', hours: foodMeals * 12, level: 'critical' });
        } else if (urgency.food === 'warning') {
            alerts.push(`🟡 Food reserves low (${Math.round(rs.food)} units, ${foodMeals} meals left).`);
            resourceStatus.push({ name: 'Food', hours: foodMeals * 12, level: 'warning' });
        }

        if (urgency.power === 'critical') {
            alerts.push(`🔴 Power nearly depleted! Only ${powerHours} hours left! No power means furnace burns +30% more wood, medical shutdown, double night fear!`);
            resourceStatus.push({ name: 'Power', hours: powerHours, level: 'critical' });
        } else if (urgency.power === 'warning') {
            alerts.push(`🟡 Power reserves low (${Math.round(rs.power)} units, ${powerHours}h left).`);
            resourceStatus.push({ name: 'Power', hours: powerHours, level: 'warning' });
        }

        if (alerts.length === 0) return '';

        resourceStatus.sort((a, b) => a.hours - b.hours);
        const mostUrgent = resourceStatus[0];
        if (mostUrgent) {
            alerts.push(`⚡ Most urgent resource: ${mostUrgent.name} (only ${mostUrgent.hours}h left).`);
        }

        return `\n[Resource Emergency Alert]\n${alerts.join('\n')}`;
    }

    /**
     * 英文版 getResourceForecastForPrompt
     */
    function getResourceForecastForPromptEN(game) {
        try {
            const rs = game.resourceSystem;
            if (!rs) return '';
            const ws = game.weatherSystem;
            const currentDay = ws ? ws.currentDay : 1;
            const currentHour = game.getHour ? game.getHour() : 12;
            const fs = game.furnaceSystem;
            const furnaceCount = fs ? fs.getActiveFurnaceCount() : 1;
            const aliveCount = game.npcs ? game.npcs.filter(n => !n.isDead).length : 8;
            const totalCount = game.npcs ? game.npcs.length : 8;
            const popRatio = Math.max(0.3, aliveCount / totalCount);

            const RC = GST._resource_system_RESOURCE_CONSUMPTION;
            if (!RC) return '';
            const woodPerHour = RC.heatingWoodPerHour * furnaceCount * popRatio;
            const foodPerDay = aliveCount * RC.foodPerMealPerPerson * RC.mealsPerDay;
            const powerPerHour = RC.powerPerHour * popRatio;

            const dayNamesEN = { 1: 'Prep Day', 2: 'Cold Day', 3: 'Respite Day', 4: 'Extreme Cold' };
            const tempLabels = { 1: '0°C', 2: '-30°C', 3: '0°C', 4: '-60°C' };

            const lines = ['[Supply Forecast]'];
            let totalWood = 0, totalFood = 0, totalPower = 0;

            for (let day = currentDay; day <= 4; day++) {
                const dayConfig = ws ? ws.getDayConfig(day) : null;
                const dayTemp = dayConfig ? dayConfig.baseTemp : 0;
                const coldFactor = Math.max(0, -dayTemp);
                const woodMult = Math.max(0.5, 1.0 + coldFactor * 0.04);
                const powerMult = Math.max(0.7, 1.0 + coldFactor * 0.02);

                let hours;
                if (day === currentDay) {
                    hours = Math.max(1, 24 - currentHour);
                } else {
                    hours = 24;
                }

                const dayWood = Math.round(woodPerHour * hours * woodMult);
                const dayFood = day === currentDay ? Math.round(foodPerDay * (hours / 24)) : Math.round(foodPerDay);
                const dayPower = Math.round(powerPerHour * hours * powerMult);

                totalWood += dayWood;
                totalFood += dayFood;
                totalPower += dayPower;

                const label = day === currentDay ? `Today(Day${day}) remaining` : `Day${day}(${dayNamesEN[day]})`;
                const tempNote = tempLabels[day] || '';
                const multNote = woodMult > 1 ? `(${tempNote}, furnace×${woodMult.toFixed(1)}, power×${powerMult.toFixed(1)})` : `(${tempNote})`;
                lines.push(`  ${label}: Wood~${dayWood} Food~${dayFood} Power~${dayPower} ${multNote}`);
            }

            lines.push(`Total needed: Wood~${totalWood} Food~${totalFood} Power~${totalPower}`);
            lines.push(`Current stock: Wood ${Math.round(rs.woodFuel)} Food ${Math.round(rs.food)} Power ${Math.round(rs.power)}`);

            const woodGap = Math.round(rs.woodFuel) - totalWood;
            const foodGap = Math.round(rs.food) - totalFood;
            const powerGap = Math.round(rs.power) - totalPower;

            const statusIcon = (gap, total) => {
                if (gap < 0) return '🔴';
                if (gap < total * 0.2) return '🟡';
                return '✅';
            };

            const gapItems = [];
            gapItems.push(`${statusIcon(woodGap, totalWood)}Wood${woodGap >= 0 ? '+' : ''}${woodGap}`);
            gapItems.push(`${statusIcon(foodGap, totalFood)}Food${foodGap >= 0 ? '+' : ''}${foodGap}`);
            gapItems.push(`${statusIcon(powerGap, totalPower)}Power${powerGap >= 0 ? '+' : ''}${powerGap}`);
            lines.push(`Gap: ${gapItems.join(' ')}`);

            // 缓存缺口数据
            rs._lastForecastGaps = {
                wood: woodGap < 0 ? Math.abs(woodGap) : 0,
                food: foodGap < 0 ? Math.abs(foodGap) : 0,
                power: powerGap < 0 ? Math.abs(powerGap) : 0,
            };

            return '\n' + lines.join('\n');
        } catch (e) {
            console.error('[promptDataEN] getResourceForecastForPromptEN error:', e);
            return '';
        }
    }

    /**
     * 英文版 getSupplyRecommendationPrompt
     */
    function getSupplyRecommendationPromptEN(game) {
        try {
            const rs = game.resourceSystem;
            if (!rs) return '';

            if (!rs._lastForecastGaps) {
                getResourceForecastForPromptEN(game);
            }
            const gaps = rs._lastForecastGaps || { wood: 0, food: 0, power: 0 };

            if (gaps.wood === 0 && gaps.food === 0 && gaps.power === 0) {
                return '\n[Supply Intel] All resource reserves are sufficient, no significant gaps.';
            }

            const NPC_SKILLS = {
                'zhao_chef': { name: 'Zhao Tiezhu', skills: { wood: 1.5, food: 1.3 } },
                'lu_chen': { name: 'Lu Chen', skills: { wood: 1.3, food: 1.3, power: 1.2 } },
                'li_shen': { name: 'Aunt Li', skills: { food: 1.5 } },
                'wang_teacher': { name: 'Wang Ce', skills: { power: 2.0 } },
                'old_qian': { name: 'Old Qian', skills: { morale: 2.0 }, preferMorale: true },
                'su_doctor': { name: 'Dr. Su', skills: {} },
                'ling_yue': { name: 'Ling Yue', skills: { food: 1.2, power: 1.2 } },
                'qing_xuan': { name: 'Qing Xuan', skills: { food: 1.1 } },
            };

            const npcs = game.npcs || [];
            const availableNpcs = [];
            for (const npc of npcs) {
                const skillInfo = NPC_SKILLS[npc.id];
                if (!skillInfo || npc.isDead) continue;
                availableNpcs.push({
                    id: npc.id, name: skillInfo.name, skills: skillInfo.skills,
                    preferMorale: skillInfo.preferMorale || false,
                    stamina: npc.stamina || 0,
                    isExhausted: (npc.stamina < 30 || npc.health < 30),
                });
            }

            const lines = ['[Supply Intel · Specialty Match]'];

            const woodHoursLeft = rs.getWoodFuelHoursRemaining();
            const powerHoursLeft = rs.getPowerHoursRemaining();
            const foodMealsLeft = rs.getFoodMealsRemaining();
            const foodHoursLeft = foodMealsLeft * 12;

            const resourceNeeds = [];
            if (gaps.wood > 0) resourceNeeds.push({ type: 'wood', label: 'Wood', gap: gaps.wood, skillKey: 'wood', hoursLeft: woodHoursLeft, urgencyNote: `${Math.round(woodHoursLeft)}h of burning left` });
            if (gaps.food > 0) resourceNeeds.push({ type: 'food', label: 'Food', gap: gaps.food, skillKey: 'food', hoursLeft: foodHoursLeft, urgencyNote: `${Math.round(foodMealsLeft)} meals left` });
            if (gaps.power > 0) resourceNeeds.push({ type: 'power', label: 'Power', gap: gaps.power, skillKey: 'power', hoursLeft: powerHoursLeft, urgencyNote: `${Math.round(powerHoursLeft)}h left` });

            resourceNeeds.sort((a, b) => a.hoursLeft - b.hoursLeft);

            for (const need of resourceNeeds) {
                const icon = need.gap > 30 ? '🔴' : '🟡';
                const ranked = availableNpcs
                    .filter(n => !n.preferMorale)
                    .map(n => ({ name: n.name, mult: n.skills[need.skillKey] || 1.0, isExhausted: n.isExhausted, stamina: n.stamina }))
                    .sort((a, b) => b.mult !== a.mult ? b.mult - a.mult : b.stamina - a.stamina);

                const recommendations = ranked.map(r => {
                    let tag = r.name;
                    if (r.mult > 1.0) tag += `(eff×${r.mult})`;
                    if (r.isExhausted) tag += '(exhausted)';
                    return tag;
                }).join(', ');

                const urgencyTag = need.hoursLeft <= 6 ? 'Extremely Short' : need.hoursLeft <= 12 ? 'Short' : '';
                lines.push(`${icon} ${need.label} gap ${need.gap} units (${need.urgencyNote}${urgencyTag ? ', ' + urgencyTag : ''}) | Best gatherers: ${recommendations}`);
            }

            return '\n' + lines.join('\n');
        } catch (e) {
            console.error('[promptDataEN] getSupplyRecommendationPromptEN error:', e);
            return '';
        }
    }

    // ============ FurnaceSystem 英文版 ============

    function getHeatingSummaryEN(game) {
        const fs = game.furnaceSystem;
        if (!fs) return '';
        const levelMap = { stable: 'Stable', strained: 'Strained', critical: 'Critical' };
        const label = levelMap[fs.heatingStatus] || 'Failed';
        return `Heating ${Math.round(fs.heatingStrength * 100)}% (${label})`;
    }

    function getFurnaceSummaryEN(game) {
        return getHeatingSummaryEN(game);
    }

    // ============ TaskSystem 英文版 ============

    function getTaskSummaryForPromptEN(game) {
        const ts = game.taskSystem;
        if (!ts) return '';
        const total = ts.dailyTasks.length;
        const completed = ts.dailyTasks.filter(t => t.status === 'completed').length;
        const inProgress = ts.dailyTasks.filter(t => t.status === 'in_progress').length;
        const paused = Object.values(ts.npcTaskState).filter(s => s.paused).length;
        return `Tasks ${completed}/${total} done | ${inProgress} in progress | ${paused} paused`;
    }

    function getNpcTaskDescForPromptEN(game, npcId) {
        const ts = game.taskSystem;
        if (!ts) return '';
        const task = ts.getNpcTask(npcId);
        if (!task) return 'No task assigned';

        const state = ts.npcTaskState[npcId];
        // 翻译任务名称
        const taskNameEN = _translateTaskName(task.name);
        let desc = `Current Task: ${taskNameEN}`;
        if (task.status === 'completed') {
            desc += ' (Completed ✅)';
        } else if (state && state.paused) {
            desc += ` (Paused ⏸️: ${state.pauseReason})`;
        } else {
            const progressPercent = task.target > 0 ? Math.round((task.progress / task.target) * 100) : 0;
            desc += ` (Progress: ${progressPercent}%)`;
            const TASK_DETAILS = ts.constructor._TASK_DETAILS || {};
            const detail = TASK_DETAILS[task.type];
            if (detail && detail.targetLocation) {
                desc += ` (Target: ${detail.targetLocation})`;
            }
        }
        return desc;
    }

    /** 翻译任务名称（带emoji的中文 → 英文） */
    function _translateTaskName(name) {
        const map = {
            '🪵 收集木柴': '🪵 Collect Wood', '🍞 收集食物': '🍞 Collect Food',
            '⚡ 维护电力': '⚡ Maintain Power', '🔍 探索废墟': '🔍 Explore Ruins',
            '🧥 准备御寒物资': '🧥 Prepare Warmth', '💊 医疗救治': '💊 Medical Care',
            '🎵 鼓舞士气': '🎵 Boost Morale', '📢 统筹协调': '📢 Coordinate',
            '🍲 分配食物': '🍲 Distribute Food', '🛡️ 维持秩序': '🛡️ Maintain Order',
            '🛏️ 休息恢复': '🛏️ Rest & Recover', '🔍 废墟侦察': '🔍 Scout Ruins',
            '⚡ 建造自动发电机': '⚡ Build Auto Generator',
            '🪵 建造自动伐木机': '🪵 Build Auto Lumber Mill',
            '🍞 建造自动捕猎机': '🍞 Build Auto Food Collector',
        };
        return map[name] || name;
    }

    // ============ DeathSystem 英文版 ============

    function getDeathSummaryForPromptEN(game) {
        const ds = game.deathSystem;
        if (!ds || ds.deathRecords.length === 0) return '';

        const causeEN = { '冻死': 'froze', '饿死': 'starved', '精神崩溃': 'mental breakdown', '体力耗尽': 'exhaustion', '疾病': 'disease' };

        let summary = `${ds.deathRecords.length} dead: `;
        summary += ds.deathRecords.map(r => {
            const name = NPC_NAME_EN[r.npcId] || r.npcName;
            const cause = causeEN[r.cause] || r.cause;
            return `${name}(${cause})`;
        }).join(', ');

        const deadIds = ds.deathRecords.map(r => r.npcId);
        const suyanDead = deadIds.includes('su_yan') || deadIds.includes('su_doctor');
        const lingyueDead = deadIds.includes('ling_yue');

        if (suyanDead && lingyueDead) {
            summary += '. ⚠️ No one can restore mental state';
        } else if (suyanDead) {
            summary += '. ⚠️ Doctor is dead, only Ling Yue can soothe with guitar';
        } else if (lingyueDead) {
            summary += '. ⚠️ Only musician is dead, only Dr. Su can provide therapy';
        }

        if (summary.length > 150) summary = summary.substring(0, 147) + '...';
        return summary;
    }

    // ============ MachineSystem 英文版 ============

    function getMachineStatusForPromptEN(game) {
        const ms = game.machineSystem;
        if (!ms) return 'No automation';

        const MC = GST.MACHINE_CONFIG || {};
        let status = '';

        if (ms.generator.built) {
            const genStatus = ms.generator.broken ? '⚠️Broken' : ms.generator.running ? 'Running' : 'Stopped';
            const _bkPct = Math.round((game.getDifficultyMult ? game.getDifficultyMult('machineBreakdownChance') : 0.10) * 100);
            const cfg = MC.generator || {};
            status += `Auto Generator: ${genStatus} (output ${cfg.powerOutputPerHour || 24}/h, burns ${cfg.woodConsumptionPerHour || 2}/h wood, ${_bkPct}%/h breakdown, total produced ${Math.round(ms.generator.totalProduced)})`;
        } else if (ms.generator.building) {
            status += `Auto Generator: Building ${Math.round(ms.generator.buildProgress * 100)}%`;
        }

        if (ms.lumberMill.built) {
            const lumStatus = ms.lumberMill.broken ? '⚠️Broken' : ms.lumberMill.running ? 'Running' : 'Stopped';
            const _bkPct2 = Math.round((game.getDifficultyMult ? game.getDifficultyMult('machineBreakdownChance') : 0.10) * 100);
            const cfg = MC.lumberMill || {};
            status += ` | Auto Lumber Mill: ${lumStatus} (output ${cfg.woodOutputPerHour || 30}/h, uses ${cfg.powerConsumptionPerHour || 3}/h power, ${_bkPct2}%/h breakdown, total produced ${Math.round(ms.lumberMill.totalProduced)})`;
        } else if (ms.lumberMill.building) {
            status += ` | Auto Lumber Mill: Building ${Math.round(ms.lumberMill.buildProgress * 100)}%`;
        }

        if (ms.foodCollector.built) {
            const fcStatus = ms.foodCollector.broken ? '⚠️Broken' : ms.foodCollector.running ? 'Running' : 'Stopped';
            const _bkPct3 = Math.round((game.getDifficultyMult ? game.getDifficultyMult('machineBreakdownChance') : 0.10) * 100);
            const cfg = MC.foodCollector || {};
            status += ` | Auto Food Collector: ${fcStatus} (output ${cfg.foodOutputPerHour || 15}/h, uses ${cfg.powerConsumptionPerHour || 2}/h power, ${_bkPct3}%/h breakdown, total produced ${Math.round(ms.foodCollector.totalProduced)})`;
        } else if (ms.foodCollector.building) {
            status += ` | Auto Food Collector: Building ${Math.round(ms.foodCollector.buildProgress * 100)}%`;
        }

        if (!ms.generator.built && !ms.generator.building && ms.canUnlockGenerator()) {
            status += ' | ⚡Generator can be built';
        }
        if (!ms.lumberMill.built && !ms.lumberMill.building && ms.canUnlockLumberMill()) {
            status += ' | 🪵Lumber Mill can be built';
        }
        if (!ms.foodCollector.built && !ms.foodCollector.building && ms.canUnlockFoodCollector()) {
            status += ' | 🍞Food Collector can be built';
        }

        return status || 'No automation';
    }

    // ============ ReincarnationSystem 英文版 ============

    function getPastLifeHintForThinkingEN(game, isReincarnationMode) {
        const rein = game.reincarnationSystem;
        if (!rein || rein.currentLifeNumber <= 1 || rein.pastLives.length === 0) return '';

        const lastLife = rein.pastLives[rein.pastLives.length - 1];
        const bestLife = rein._findBestLife();
        const multiAnalysis = rein.analyzeMultiLifePatterns();
        let hint = '';

        const endingNamesEN = { perfect: 'Perfect Ending', normal: 'Normal Ending', bleak: 'Bleak Ending', extinction: 'Extinction' };

        if (isReincarnationMode) {
            const isFirstReincarnation = (rein.currentLifeNumber === 2);
            if (isFirstReincarnation) {
                hint += `[Life #2 · First Reincarnation] You clearly remember everything from your past life, suddenly finding yourself back at Day 1.`;
            } else {
                hint += `[Life #${rein.currentLifeNumber} · Reincarnated ${rein.pastLives.length} times]`;
            }

            if (lastLife.lifeSummary && lastLife.lifeSummary.forThinking) {
                // LLM 精炼总结可能是中文，通过 i18n 翻译
                let summary = lastLife.lifeSummary.forThinking;
                if (GST.i18n && GST.i18n.translatePromptText) {
                    summary = GST.i18n.translatePromptText(summary);
                }
                hint += summary;
            } else {
                hint += ` Past life result: ${endingNamesEN[lastLife.endingType] || 'Unknown'}, ${lastLife.aliveCount}/8 survived.`;

                if (bestLife && bestLife.aliveCount > lastLife.aliveCount) {
                    hint += ` 🏆 Historical best: Life #${bestLife.lifeNumber} (${bestLife.aliveCount}/8 survived).`;
                }

                if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                    hint += ' Past life deaths:';
                    for (const d of lastLife.deathRecords.slice(0, 5)) {
                        const name = NPC_NAME_EN[d.npcId] || d.name;
                        hint += ` ${name} Day${d.day} ${d.time} at ${d.location} ${d.cause};`;
                    }
                }

                if (lastLife.resourceSnapshot) {
                    const rs = lastLife.resourceSnapshot;
                    hint += ` Final resources: Wood${rs.woodFuel} Food${rs.food} Power${rs.power}.`;
                }

                if (!lastLife.secondFurnaceBuilt) {
                    hint += ' ❗Heating preparation was insufficient in past life.';
                }

                if (lastLife.lessons && lastLife.lessons.length > 0) {
                    // 教训可能是中文，尝试翻译
                    let lessonsText = lastLife.lessons.slice(0, 3).join('; ');
                    if (GST.i18n && GST.i18n.translatePromptText) {
                        lessonsText = GST.i18n.translatePromptText(lessonsText);
                    }
                    hint += ' Past life lessons: ' + lessonsText + '.';
                }

                // _generateStrategyAdvice 可能返回中文
                const advice = rein._generateStrategyAdvice(lastLife);
                if (advice) {
                    if (GST.i18n && GST.i18n.translatePromptText) {
                        hint += GST.i18n.translatePromptText(advice);
                    } else {
                        hint += advice;
                    }
                }
            }

            if (multiAnalysis.failurePatterns.length > 0) {
                let patterns = multiAnalysis.failurePatterns.slice(0, 2).join('; ');
                if (GST.i18n && GST.i18n.translatePromptText) {
                    patterns = GST.i18n.translatePromptText(patterns);
                }
                hint += ' 🔴 Recurring issues across lives: ' + patterns + '.';
            }

            hint += ' Make autonomous decisions based on current resources, stamina, and weather. Past life experience is reference only.';

        } else {
            hint += `[Past Life Experience (Life #${lastLife.lifeNumber})]`;
            hint += ` Past life: ${endingNamesEN[lastLife.endingType] || 'Unknown'}, ${lastLife.aliveCount}/8 survived.`;

            if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                hint += ' Deaths:';
                for (const d of lastLife.deathRecords.slice(0, 4)) {
                    const name = NPC_NAME_EN[d.npcId] || d.name;
                    hint += ` ${name} Day${d.day} ${d.cause}(${d.location});`;
                }
            }

            if (lastLife.resourceSnapshot) {
                const rs = lastLife.resourceSnapshot;
                hint += ` Final resources: Wood${rs.woodFuel} Food${rs.food} Power${rs.power}.`;
            }

            if (!lastLife.secondFurnaceBuilt) {
                hint += ' Heating preparation was insufficient!';
            }

            if (lastLife.lessons && lastLife.lessons.length > 0) {
                let lessonsText = lastLife.lessons.slice(0, 3).join('; ');
                if (GST.i18n && GST.i18n.translatePromptText) {
                    lessonsText = GST.i18n.translatePromptText(lessonsText);
                }
                hint += ' Lessons: ' + lessonsText + '.';
            }

            const advice = rein._generateStrategyAdvice(lastLife);
            if (advice) {
                if (GST.i18n && GST.i18n.translatePromptText) {
                    hint += GST.i18n.translatePromptText(advice);
                } else {
                    hint += advice;
                }
            }
        }

        const maxLen = isReincarnationMode ? 700 : 400;
        if (hint.length > maxLen) hint = hint.substring(0, maxLen - 3) + '…';
        return hint;
    }

    function getWorkPlanSummaryForNpcEN(game, npcId) {
        const rein = game.reincarnationSystem;
        if (!rein) return '';
        const holder = rein.getWorkPlanHolder();
        if (!holder || !holder.workPlan) return '';

        const plan = holder.workPlan;
        const day = game.dayCount || 1;
        const dayPlan = plan.dayPlans[day];
        if (!dayPlan) return '';

        const holderName = NPC_NAME_EN[holder.id] || holder.name;
        let summary = `[${holderName}'s Work Plan · Day ${day}]\n`;
        for (const assignment of dayPlan) {
            const name = NPC_NAME_EN[assignment.npcId] || assignment.npcId;
            const task = TASK_SHORT_EN[assignment.task] || assignment.task;
            const isMe = assignment.npcId === npcId;
            // reason 可能是中文，尝试翻译
            let reason = assignment.reason || '';
            if (reason && GST.i18n && GST.i18n.translatePromptText) {
                reason = GST.i18n.translatePromptText(reason);
            }
            summary += isMe ? `→★${name}: ${task}(${reason})★\n` : `  ${name}: ${task}\n`;
        }
        if (summary.length > 200) summary = summary.substring(0, 197) + '…';
        return summary;
    }

    function getLessonsForNpcEN(game, npcId) {
        const rein = game.reincarnationSystem;
        if (!rein || rein.pastLives.length === 0) return '';
        // 调用原始函数获取中文教训，然后翻译
        const zhText = rein.getLessonsForNpc(npcId);
        if (!zhText) return '';
        if (GST.i18n && GST.i18n.translatePromptText) {
            return GST.i18n.translatePromptText(zhText);
        }
        return zhText;
    }

    /**
     * 英文版 getPastLifeHintForDialogue（用于晨会讨论 prompt）
     */
    function getPastLifeHintForDialogueEN(game, isReincarnationMode) {
        const rein = game.reincarnationSystem;
        if (!rein || rein.currentLifeNumber <= 1 || rein.pastLives.length === 0) return '';

        const lastLife = rein.pastLives[rein.pastLives.length - 1];
        const bestLife = rein._findBestLife();
        let hint = '';

        const endingNamesEN = { perfect: 'Perfect Ending', normal: 'Normal Ending', bleak: 'Bleak Ending', extinction: 'Extinction' };

        if (isReincarnationMode) {
            const isFirstReincarnation = (rein.currentLifeNumber === 2);

            if (isFirstReincarnation) {
                hint += `[Life #2 · First Reincarnation] You clearly remember everything from your past life.`;
                const endingDesc = {
                    perfect: 'Although everyone survived last life, you suddenly find yourself back at Day 1',
                    normal: 'Most people survived last life, but you suddenly find time has reversed, everything starts over',
                    bleak: 'Only a few survived last life, you watched companions fall one by one, then suddenly—you are back at Day 1',
                    extinction: 'Everyone died last life, you remember your consciousness fading, then suddenly—you open your eyes back at Day 1, everyone alive before you',
                };
                hint += ` ${endingDesc[lastLife.endingType] || 'Last life ended badly, then you find yourself back at Day 1'}.`;
                hint += ` This is your first time experiencing this "rebirth", you don't know why.`;
            } else {
                hint += `[Past Life Memory (Clear) · Life #${rein.currentLifeNumber}] You have experienced ${rein.pastLives.length} reincarnations.`;
            }

            if (lastLife.lifeSummary && lastLife.lifeSummary.forDialogue) {
                let summary = lastLife.lifeSummary.forDialogue;
                if (GST.i18n && GST.i18n.translatePromptText) {
                    summary = GST.i18n.translatePromptText(summary);
                }
                hint += summary;
            } else {
                const survivalDesc = { perfect: 'everyone survived', normal: 'most survived', bleak: 'only a few survived', extinction: 'everyone died' };
                hint += ` Last life: ${survivalDesc[lastLife.endingType] || 'unknown outcome'} (${lastLife.aliveCount}/8 survived).`;

                if (bestLife && bestLife !== lastLife && bestLife.aliveCount > lastLife.aliveCount) {
                    hint += ` But Life #${bestLife.lifeNumber} was best (${bestLife.aliveCount}/8 survived).`;
                }

                if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                    const deaths = lastLife.deathRecords.slice(0, 3);
                    hint += ` Last life: ${deaths.map(d => `${NPC_NAME_EN[d.npcId] || d.name} died on Day ${d.day} from ${d.cause}`).join(', ')}.`;
                }

                if (lastLife.lessons && lastLife.lessons.length > 0) {
                    let lessonsText = lastLife.lessons.slice(0, 2).join('; ');
                    if (GST.i18n && GST.i18n.translatePromptText) {
                        lessonsText = GST.i18n.translatePromptText(lessonsText);
                    }
                    hint += ` Lessons: ${lessonsText}.`;
                }
            }

            if (isFirstReincarnation) {
                hint += ' You may naturally express confusion about rebirth, or cite past life lessons to guide actions.';
            } else {
                hint += ' Past life memory is background intel for reference, focus on current reality.';
            }
        } else {
            if (rein.currentLifeNumber === 2) {
                hint += '[Past Life Memory (Vague)] You seem to have had a very long nightmare...';
            } else {
                hint += `[Past Life Memory (Vague)] You have a strong sense of déjà vu, as if you've been through this ${rein.currentLifeNumber - 1} times...`;
            }

            const survivalDesc = { perfect: 'everyone survived', normal: 'most survived', bleak: 'only a few survived', extinction: 'everyone died' };
            hint += ` In the dream, ${survivalDesc[lastLife.endingType] || 'the outcome was unclear'}.`;

            if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                const deaths = lastLife.deathRecords.slice(0, 3);
                const _causeEN = { '冻死': 'freeze', '饿死': 'starve', '精神崩溃': 'have a mental breakdown', '体力耗尽': 'collapse from exhaustion', '疾病': 'fall ill' };
                hint += ` Vaguely remember ${deaths.map(d => `${NPC_NAME_EN[d.npcId] || d.name} seemed to ${_causeEN[d.cause] || 'have an accident'}`).join(', ')}.`;
            }

            if (lastLife.lessons && lastLife.lessons.length > 0) {
                let lesson = lastLife.lessons[0];
                if (GST.i18n && GST.i18n.translatePromptText) {
                    lesson = GST.i18n.translatePromptText(lesson);
                }
                hint += ` Have a feeling that ${lesson}.`;
            }

            hint += ' When speaking, may vaguely reference past life feelings, but keep it ambiguous (use "vaguely remember", "have a feeling", "seems like I dreamed" etc.).';
        }

        const maxLen = (isReincarnationMode && rein.currentLifeNumber === 2) ? 500 : 400;
        if (hint.length > maxLen) hint = hint.substring(0, maxLen - 3) + '…';
        return hint;
    }

    // ============ NPC 属性英文版 ============

    function getAttributeSummaryEN(npc) {
        return `💪Stamina:${Math.round(npc.stamina)}(${_staminaLevelEN(npc.stamina)}) ` +
               `🧠Sanity:${Math.round(npc.sanity)}(${_sanityLevelEN(npc.sanity)}) ` +
               `🫀Health:${Math.round(npc.health)}(${_healthLevelEN(npc.health)}) ` +
               `🍖Hunger:${Math.round(npc.hunger)}(${_hungerStatusEN(npc.hunger)}) ` +
               `🌡️BodyTemp:${npc.bodyTemp.toFixed(1)}°C(${_bodyTempStatusEN(npc.bodyTemp)})`;
    }

    function _staminaLevelEN(stamina) {
        if (stamina >= 80) return 'Energetic';
        if (stamina >= 50) return 'Normal';
        if (stamina >= 20) return 'Tired';
        if (stamina >= 1) return 'Exhausted';
        return 'Collapsed';
    }

    function _sanityLevelEN(sanity) {
        if (sanity >= 80) return 'Clear-headed';
        if (sanity >= 60) return 'Good';
        if (sanity >= 40) return 'Fatigued';
        if (sanity >= 20) return 'Depressed';
        return 'Mental Breakdown';
    }

    function _healthLevelEN(health) {
        if (health >= 80) return 'Strong';
        if (health >= 50) return 'Normal';
        if (health >= 30) return 'Unwell';
        if (health >= 10) return 'Sick';
        return 'Critical';
    }

    function _hungerStatusEN(hunger) {
        if (hunger >= 80) return 'Full';
        if (hunger >= 60) return 'Normal';
        if (hunger >= 40) return 'Slightly Hungry';
        if (hunger >= 20) return 'Very Hungry';
        return 'Starving';
    }

    function _bodyTempStatusEN(bodyTemp) {
        if (bodyTemp >= 36) return 'Normal';
        if (bodyTemp >= 35) return 'Low';
        if (bodyTemp >= 32) return 'Hypothermia';
        if (bodyTemp >= 30) return 'Severe Hypothermia';
        return 'Near Death';
    }

    // ============ NPC 实例数据英文适配 ============
    // 这些函数将 npc-ai.js / npc-renderer.js 中构建的中文动态数据翻译为英文
    // 解决"英文 prompt 框架 + 中文动态数据"导致 LLM 输出中文的问题

    /** 场景标签中英映射 */
    const SCENE_LABEL_EN = {
        '炊事房': 'Kitchen', '厨房': 'Kitchen', '医疗站': 'Medical Station',
        '工坊': 'Workshop', '宿舍A': 'Dorm A', '宿舍B': 'Dorm B',
        '指挥部': 'Command Center', '仓库': 'Warehouse', '伐木场': 'Lumber Yard',
        '冰湖': 'Frozen Lake', '废墟': 'Ruins', '矿场': 'Ore Pile',
        '暖炉广场': 'Furnace Plaza', '村庄': 'Village', '营地': 'Camp',
        '发电房': 'Generator Room', '室内': 'Indoors', '户外': 'Outdoors',
        '暖炉大厅': 'Furnace Hall', '村庄中心': 'Village Center',
    };

    /** 通用中文→英文文本翻译（用于 prompt 中的动态数据） */
    function _translateText(text) {
        if (!text || typeof text !== 'string') return text || '';
        let result = text;
        // NPC 名字
        for (const [id, en] of Object.entries(NPC_NAME_EN)) {
            const zhNames = { old_qian: '老钱', qing_xuan: '清璇', wang_teacher: '王策',
                zhao_chef: '赵铁柱', li_shen: '李婶', su_doctor: '苏医生',
                lu_chen: '陆辰', ling_yue: '凌月' };
            if (zhNames[id]) result = result.replace(new RegExp(zhNames[id], 'g'), en);
        }
        // 场景标签
        for (const [zh, en] of Object.entries(SCENE_LABEL_EN)) {
            result = result.replace(new RegExp(zh, 'g'), en);
        }
        // 常见关键词
        const KW = {
            '挚友': 'best friend', '好友': 'close friend', '正在发疯': 'going insane',
            '状态非常差': 'in very bad condition', '紧急情报': 'URGENT INTEL',
            '你的好朋友': 'Your close friend', '砍柴': 'chopping wood',
            '采集食物': 'gathering food', '采矿': 'mining', '探索废墟': 'exploring ruins',
            '做饭': 'cooking', '坐诊': 'treating patients', '休息': 'resting',
            '睡觉': 'sleeping', '吃饭': 'eating', '发电': 'generating power',
            '建造': 'building', '维修': 'repairing', '巡逻': 'patrolling',
            '准备早餐': 'preparing breakfast', '准备午餐': 'preparing lunch',
            '准备晚餐': 'preparing dinner', '出诊': 'house call',
            '安抚': 'comforting', '陪伴': 'accompanying', '聊天': 'chatting',
            '前往': 'heading to', '正在': 'currently', '等待指令': 'awaiting orders',
            '随便走走': 'wandering', '待在原地': 'staying put',
            '累坏了': 'exhausted', '赶紧回家休息': 'rushing home to rest',
            '检查机器运行状况': 'checking machine status',
            '出诊结束': 'house call complete', '返回医疗站': 'returning to medical station',
            '肚子饿了': 'hungry', '去吃饭': 'going to eat',
            '补足资源缺口': 'filling resource gap', '去砍柴': 'going to chop wood',
            '采集物资': 'gathering supplies', '伐木场砍柴': 'chopping wood at lumber yard',
            '去宿舍': 'going to dorm', '安抚大家': 'comforting everyone',
            '去医疗站坐诊': 'going to medical station for treatment',
            '去炊事房做饭': 'going to kitchen to cook',
            '去工坊': 'going to workshop', '发疯中': 'going insane',
            '严重失温': 'severe hypothermia', '倒地不起': 'collapsed',
            '濒死': 'near death', '昏厥': 'fainted', '生病': 'sick',
            '饥饿': 'hungry', '疲惫': 'fatigued', '焦虑': 'anxious',
            '恐惧': 'fearful', '绝望': 'desperate', '满足': 'content',
            '平静': 'calm', '开心': 'happy', '愤怒': 'angry',
            '悲伤': 'sad', '紧张': 'nervous', '兴奋': 'excited',
            '无聊': 'bored', '困倦': 'drowsy', '精力充沛': 'energetic',
            '附近': 'nearby', '格': 'tiles away', '同一区域较远处还有': 'Also in the area (farther away):',
            '注意：你附近有': 'Note: There are', '个人': 'people near you',
            '你不是一个人': 'you are not alone',
            '不要说"没人"或"空无一人"之类的话': 'do not say "no one" or "empty"',
            '紧急！你的好朋友需要你': 'URGENT! Your close friend needs you',
            '你必须主动关心他们': 'You must actively care for them',
            '走过去安慰他们': 'Go comfort them', '陪他们去看医生': 'accompany them to the doctor',
            '带他们去吃饭': 'take them to eat', '朋友有难你不能袖手旁观': 'You cannot stand by when friends are in trouble',
            '在wantChat中填写最需要帮助的朋友的名字': 'Fill in wantChat with the name of the friend who needs help most',
            '作为有情感的人': 'As a compassionate person',
            '你可以主动关心他们': 'you can proactively care for them',
            '提议陪他们去看医生': 'suggest accompanying them to the doctor',
            '暂无': 'None', '仅供参考': 'reference only',
            '你完全可以自主决定做什么': 'you can freely decide what to do',
            '现在是深夜了': 'It is late night', '你的体力消耗会加快': 'your stamina drains faster',
            '白天时间': 'Daytime', '你可以自主决定做什么': 'you can freely decide what to do',
            '采集资源': 'gather resources', '找人聊天': 'chat with friends',
            '探索废墟': 'explore ruins', '一切由你决定': 'all up to you',
            '精神状态不佳时': 'When sanity is low', '休息或社交能恢复精神': 'resting or socializing can restore sanity',
            '当前状态提示': 'Status', '我正在去吃饭': 'I am on my way to eat',
            '正在吃饭中': 'currently eating', '当前外部任务': 'Current External Task',
            '系统任务情报': 'System Task Intel', '投票决策分工': 'Council Vote Assignment',
            '紧急状态提醒': 'Emergency Alert', '自身生存危机情报': 'Survival Crisis',
            '全镇NPC状态': 'All NPC Status', '你的状态': 'Your Status',
            '你的目标': 'Your Goals', '当前日程': 'Current Schedule',
            '最近想法': 'Recent Thoughts', '最近记忆': 'Recent Memories',
            '当前行动': 'Current Action', '待执行行动': 'Pending Action',
            '同伴模式': 'Companion Mode', '正在跟随': 'Following',
            '一起行动': 'acting together', '最近行动决策': 'Recent Action Decision',
            '你当前的身心状态': 'Your current physical and mental state',
            '你现在体力极低': 'Your stamina is critically low',
            '非常疲惫': 'very fatigued', '再硬撑下去身体会出问题': 'pushing further will cause health issues',
            '你有点累了': 'You are a bit tired',
            '你的健康状况非常糟糕': 'Your health is very poor',
            '你能感觉到身体在告急': 'You can feel your body failing',
            '再拖下去会更严重': 'delaying will make it worse',
            '医疗站可以治疗': 'Medical station can treat you',
            '你身体状况很差': 'Your health is poor',
            '感觉浑身乏力': 'feeling weak all over', '头晕目眩': 'dizzy',
            '体力恢复变慢了': 'stamina recovery slowed', '干什么都提不起劲': 'no energy for anything',
            '你感觉身体不太舒服': 'You feel unwell', '有点亚健康': 'somewhat unhealthy',
            '最好注意休息和饮食': 'better rest and eat well',
            '你正在生病': 'You are sick', '非常不舒服': 'very uncomfortable',
            '拖着不治只会越来越严重': 'delaying treatment will only worsen',
            '你正在发疯': 'You are going insane', '精神完全崩溃': 'mental breakdown',
            '无法正常思考': 'cannot think normally',
            '你需要想办法恢复精神状态': 'you need to find a way to restore sanity',
            '你快疯了': 'You are about to go insane',
            '脑子里全是噪音': 'your mind is full of noise',
            '你控制不住自己的情绪': 'you cannot control your emotions',
            '随时可能崩溃': 'could break down any moment',
            '你精神状态非常差': 'Your mental state is very poor',
            '你感到极度焦虑': 'You feel extreme anxiety',
            '恐惧': 'fear', '绝望': 'despair',
            '脑子像被什么东西紧紧箍住': 'mind feels tightly constricted',
            '工作效率大幅下降': 'work efficiency greatly reduced',
            '和人说话也容易失态': 'easily lose composure when talking',
            '你精神状态很差': 'Your mental state is poor',
            '经常感到莫名的焦虑和烦躁': 'often feel inexplicable anxiety and irritability',
            '做事难以集中注意力': 'hard to concentrate',
            '你觉得自己快要撑不住了': 'you feel like you cannot hold on',
            '你精神状态一般': 'Your mental state is average',
            '有些疲惫和低落': 'somewhat tired and down',
            '你精神状态很好': 'Your mental state is good',
            '头脑清晰': 'clear-headed', '充满干劲': 'full of energy',
            '警告': 'WARNING', '项指标处于危险状态': 'indicators in danger zone',
            '你的身心正在全面崩溃': 'Your body and mind are collapsing',
            '可用的恢复途径': 'Available recovery options',
            '健康': 'health', '饱食': 'hunger', '宿舍': 'dorm',
            '体力': 'stamina', '精神': 'sanity', '找人聊天': 'chat with someone',
            '优先级': 'priority', '理由': 'reason',
        };
        for (const [zh, en] of Object.entries(KW)) {
            result = result.replace(new RegExp(zh.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), en);
        }
        return result;
    }

    /** 构建英文版 friendCrisisHint */
    function buildFriendCrisisHintEN(npc, game) {
        const friendsInCrisis = game.npcs.filter(n =>
            n.id !== npc.id && !n.isDead && !n.isSleeping && npc.getAffinity(n.id) >= 70
            && (n.sanity < 25 || n.isCrazy)
        );
        if (friendsInCrisis.length === 0 || npc.sanity < 40) return '';
        return `\n\n🚨🚨 URGENT INTEL: Your close friend ${friendsInCrisis.map(f => {
            const aff = npc.getAffinity(f.id);
            const rel = aff >= 90 ? 'best friend' : 'close friend';
            const dn = NPC_NAME_EN[f.id] || f.displayName || f.name;
            return `${dn} (${rel}, Sanity:${Math.round(f.sanity)}${f.isCrazy ? ', going insane!' : ''}, at ${SCENE_LABEL_EN[f.getSceneLabel()] || f.getSceneLabel()})`;
        }).join(', ')} is in very bad condition!`;
    }

    /** 构建英文版 nearbyStr */
    function buildNearbyStrEN(nearby) {
        if (!nearby || nearby.length === 0) return 'No one nearby';
        return nearby.map(n => {
            const dn = NPC_NAME_EN[n.id] || n.displayName || n.name;
            const dist = n.dist || n.distance;
            return `${dn}(${dist || '?'} tiles)`;
        }).join(', ');
    }

    /** 构建英文版 envDesc */
    function buildEnvDescEN(npc) {
        const scene = npc.currentScene || '';
        const label = npc.getSceneLabel ? npc.getSceneLabel() : scene;
        return SCENE_LABEL_EN[label] || _translateText(label) || scene;
    }

    /** 构建英文版 sceneOverview */
    function buildSceneOverviewEN(npc, game, nearby) {
        const sameSceneNPCs = game.npcs.filter(n =>
            n.id !== npc.id && !n.isDead && n.currentScene === npc.currentScene && !n.isSleeping
        );
        const nearbyIds = new Set((nearby || []).map(n => n.id));
        const farNPCs = sameSceneNPCs.filter(n => !nearbyIds.has(n.id));
        if (farNPCs.length === 0) return '';
        return `\nAlso in the area (farther away): ${farNPCs.map(n => {
            const dn = NPC_NAME_EN[n.id] || n.displayName || n.name;
            const sd = _translateText(n.stateDesc || '');
            return `${dn}(${sd}${n.isCrazy ? ', going insane' : ''})`;
        }).join(', ')}`;
    }

    /** 构建英文版 nearbyEmphasis */
    function buildNearbyEmphasisEN(nearby) {
        if (!nearby || nearby.length === 0) return '';
        const names = nearby.map(n => NPC_NAME_EN[n.id] || n.displayName || n.name).join(', ');
        return `\n⚠️ Note: There are ${nearby.length} people near you (${names}), you are not alone! Do not say "no one" or "empty".`;
    }

    /** 构建英文版 helpHint */
    function buildHelpHintEN(npc, game, nearby) {
        const needHelp = game.npcs.filter(n =>
            n.id !== npc.id && !n.isDead && (n.sanity < 30 || n.health < 30 || n.stamina < 15 || n.isCrazy)
        );
        if (needHelp.length === 0) return '';
        const helpDetails = needHelp.map(n => {
            const dn = NPC_NAME_EN[n.id] || n.displayName || n.name;
            const issues = [];
            if (n.isCrazy) issues.push('going insane');
            if (n.sanity < 30) issues.push(`Sanity:${Math.round(n.sanity)}`);
            if (n.health < 30) issues.push(`Health:${Math.round(n.health)}`);
            if (n.stamina < 15) issues.push(`Stamina:${Math.round(n.stamina)}`);
            return `${dn}(${issues.join(', ')})`;
        }).join(', ');
        const friendsInTrouble = needHelp.filter(n => {
            return npc.getAffinity && npc.getAffinity(n.id) >= 70;
        });
        if (friendsInTrouble.length > 0) {
            return `\n🆘🆘 URGENT! Your close friend needs you! ${helpDetails}. You must actively care for them! Go comfort them, accompany them to the doctor, take them to eat. You cannot stand by when friends are in trouble! Fill in wantChat with the name of the friend who needs help most.`;
        }
        return `\n🆘 Note: ${helpDetails}. As a compassionate person, you can proactively care for them, suggest accompanying them to the doctor/eat/rest.`;
    }

    /** 构建英文版 attrHintStr */
    function buildAttrHintStrEN(npc) {
        const hints = [];
        if (npc.stamina < 20) hints.push(`⚠️ Your stamina is critically low (${Math.round(npc.stamina)}/100), very fatigued, pushing further will cause health issues.`);
        else if (npc.stamina < 50) hints.push('You are a bit tired');
        if (npc.health < 20) hints.push(`🚨 Your health is very poor (${Math.round(npc.health)}/100)! You can feel your body failing, delaying will make it worse. Medical station can treat you.`);
        else if (npc.health < 35) hints.push(`⚠️ Your health is poor (${Math.round(npc.health)}/100), feeling weak all over, dizzy. Stamina recovery slowed, no energy for anything.`);
        else if (npc.health < 50) hints.push('You feel unwell, somewhat unhealthy, better rest and eat well');
        if (npc.isSick) hints.push('⚠️ You are sick, very uncomfortable. Delaying treatment will only worsen. Medical station can treat you.');
        if (npc.isCrazy) hints.push('🤯 You are going insane! Mental breakdown, cannot think normally, you need to find a way to restore sanity');
        else if (npc.sanity < 15) hints.push(`🚨🚨 You are about to go insane!! Your mind is full of noise, you cannot control your emotions, could break down any moment! Sanity only ${Math.round(npc.sanity)}.`);
        else if (npc.sanity < 25) hints.push(`🚨 Your mental state is very poor (Sanity:${Math.round(npc.sanity)})! You feel extreme anxiety, fear, despair, mind feels tightly constricted. Work efficiency greatly reduced, easily lose composure when talking.`);
        else if (npc.sanity < 35) hints.push('⚠️ Your mental state is poor, often feel inexplicable anxiety and irritability, hard to concentrate. You feel like you cannot hold on.');
        else if (npc.sanity < 50) hints.push('Your mental state is average, somewhat tired and down');
        else if (npc.sanity >= 80) hints.push('Your mental state is good, clear-headed, full of energy');
        const criticalCount = [npc.sanity < 30, npc.health < 35, npc.stamina < 20, npc.hunger < 25].filter(Boolean).length;
        if (criticalCount >= 2) {
            hints.push(`🆘 WARNING: ${criticalCount} indicators in danger zone! Your body and mind are collapsing. Available recovery: Medical Station (health), Kitchen (hunger), Dorm (stamina/sanity), Chat with someone (sanity).`);
        }
        return hints.length > 0 ? '\nYour current physical and mental state:\n' + hints.map(h => '- ' + h).join('\n') : '';
    }

    /** 构建英文版 allNPCStatus */
    function buildAllNPCStatusEN(game) {
        return game.npcs.filter(n => !n.isDead).map(n => {
            const dn = NPC_NAME_EN[n.id] || n.displayName || n.name;
            const loc = SCENE_LABEL_EN[n.getSceneLabel()] || n.getSceneLabel();
            const sd = _translateText(n.stateDesc || '');
            return `${dn}: ${loc}, ${sd}, STA:${Math.round(n.stamina)} HP:${Math.round(n.health)} SAN:${Math.round(n.sanity)} HUN:${Math.round(n.hunger)}${n.isSick ? ' 🤒' : ''}${n.isCrazy ? ' 🤯' : ''}`;
        }).join('\n');
    }

    /** 构建英文版 targetList */
    function buildTargetListEN(game) {
        const targets = {
            lumber_yard: 'Lumber Yard (outdoor, chop wood)',
            frozen_lake: 'Frozen Lake (outdoor, fish for food)',
            ore_pile: 'Ore Pile (outdoor, mine ore)',
            ruins_site: 'Ruins (outdoor, explore for rare supplies)',
            furnace_plaza: 'Furnace Plaza (outdoor, gathering)',
            kitchen_door: 'Kitchen (indoor, cook/eat)',
            medical_door: 'Medical Station (indoor, treatment/counseling)',
            workshop_door: 'Workshop (indoor, build/repair)',
            dorm_a_door: 'Dorm A (indoor, rest)',
            dorm_b_door: 'Dorm B (indoor, rest)',
            warehouse_door: 'Warehouse (indoor, manage supplies)',
            command_door: 'Command Center (indoor, coordinate)',
            generator_room: 'Generator Room (indoor, generate power)',
        };
        return Object.entries(targets).map(([k, v]) => `  "${k}": ${v}`).join('\n');
    }

    /** 通用翻译函数（用于翻译 prompt 中残留的中文） */
    function translatePromptText(text) {
        return _translateText(text);
    }

    // ============ 挂载到 GST ============

    GST.promptDataEN = {
        // WeatherSystem
        getSurvivalSummaryEN,
        getBlizzardUrgencyForPromptEN,
        // ResourceSystem
        getResourceStatusForPromptEN,
        getResourceSituationBriefEN,
        getUrgencyPromptEN,
        getResourceForecastForPromptEN,
        getSupplyRecommendationPromptEN,
        // FurnaceSystem
        getHeatingSummaryEN,
        getFurnaceSummaryEN,
        // TaskSystem
        getTaskSummaryForPromptEN,
        getNpcTaskDescForPromptEN,
        // DeathSystem
        getDeathSummaryForPromptEN,
        // MachineSystem
        getMachineStatusForPromptEN,
        // ReincarnationSystem
        getPastLifeHintForThinkingEN,
        getPastLifeHintForDialogueEN,
        getWorkPlanSummaryForNpcEN,
        getLessonsForNpcEN,
        // NPC Attributes
        getAttributeSummaryEN,
        // 辅助函数（供外部使用）
        staminaLevelEN: _staminaLevelEN,
        sanityLevelEN: _sanityLevelEN,
        healthLevelEN: _healthLevelEN,
        hungerStatusEN: _hungerStatusEN,
        bodyTempStatusEN: _bodyTempStatusEN,
        translateTaskName: _translateTaskName,
        weatherEN: _weatherEN,
        // NPC 实例数据英文适配
        buildFriendCrisisHintEN,
        buildNearbyStrEN,
        buildEnvDescEN,
        buildSceneOverviewEN,
        buildNearbyEmphasisEN,
        buildHelpHintEN,
        buildAttrHintStrEN,
        buildAllNPCStatusEN,
        buildTargetListEN,
        translatePromptText,
    };

    console.log('[i18n] prompt-data-en.js loaded');
})();
