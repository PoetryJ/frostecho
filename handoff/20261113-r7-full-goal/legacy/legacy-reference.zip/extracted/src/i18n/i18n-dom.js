/**
 * 福音镇 - i18n DOM 更新模块
 * 负责根据当前语言刷新所有带 data-i18n 属性的 DOM 元素
 * 以及语言切换按钮的交互逻辑
 * 挂载到 GST.i18n.updateDOM
 */
(function() {
    'use strict';
    const GST = window.GST;
    const t = GST.t;

    /**
     * 扫描并更新所有带 data-i18n 属性的 DOM 元素
     * @param {Element} [root=document] - 扫描的根元素
     */
    function updateDOM(root) {
        const elements = (root || document).querySelectorAll('[data-i18n]');
        elements.forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (!key) return;
            const text = t(key);
            if (text !== key) {
                // 如果元素有子元素（如按钮内的 span），只更新文本内容
                // 对于纯文本元素，直接设置 textContent
                if (el.children.length === 0) {
                    el.textContent = text;
                } else {
                    // 有子元素的情况，只更新直接文本节点
                    // 这种情况通常不需要处理，因为我们给子元素加了 data-i18n
                }
            }
        });
    }

    /**
     * 更新加载页轮播内容（HTML内容需要特殊处理）
     */
    function updateCarouselContent() {
        const track = document.getElementById('carousel-track');
        if (!track) return;

        const pages = track.querySelectorAll('.carousel-page');
        const pageKeys = [
            { titleKey: 'carousel.page1_title', bodyKey: 'carousel.page1_body' },
            { titleKey: 'carousel.page2_title', bodyKey: 'carousel.page2_body', highlightKey: 'carousel.page2_highlight' },
            { titleKey: 'carousel.page3_title', bodyKey: null }, // 角色页特殊处理
            { titleKey: 'carousel.page4_title', bodyKey: 'carousel.page4_body' },
            { titleKey: 'carousel.page5_title', bodyKey: 'carousel.page5_body' },
            { titleKey: 'carousel.page6_title', bodyKey: 'carousel.page6_body' },
            { titleKey: 'carousel.page7_title', bodyKey: 'carousel.page7_body' },
        ];

        pages.forEach((page, idx) => {
            if (idx >= pageKeys.length) return;
            const cfg = pageKeys[idx];

            // 更新标题
            const titleEl = page.querySelector('.carousel-page-title');
            if (titleEl && cfg.titleKey) {
                let titleHtml = t(cfg.titleKey);
                if (cfg.highlightKey) {
                    titleHtml += ` <span class="carousel-highlight">${t(cfg.highlightKey)}</span>`;
                }
                titleEl.innerHTML = titleHtml;
            }

            // 更新正文（HTML内容）
            if (cfg.bodyKey) {
                const bodyEl = page.querySelector('.carousel-page-body');
                if (bodyEl) {
                    bodyEl.innerHTML = t(cfg.bodyKey);
                }
            }

            // 第3页：角色介绍特殊处理
            if (idx === 2) {
                const charRows = page.querySelectorAll('.char-row');
                const npcIds = ['old_qian', 'li_shen', 'zhao_chef', 'wang_teacher', 'su_doctor', 'lu_chen', 'ling_yue', 'qing_xuan'];
                charRows.forEach((row, i) => {
                    if (i >= npcIds.length) return;
                    const id = npcIds[i];
                    const nameEl = row.querySelector('.char-name');
                    const roleEl = row.querySelector('.char-role');
                    if (nameEl) nameEl.textContent = t(`npc.${id}`);
                    if (roleEl) roleEl.textContent = t(`npc_role.${id}`);
                });
            }
        });
    }

    /**
     * 初始化语言切换按钮
     */
    function initLangSwitch() {
        const btn = document.getElementById('btn-lang-switch');
        if (!btn) return;

        // 更新按钮文本
        function updateBtnText() {
            const lang = GST.i18n.getLang();
            btn.textContent = lang === 'zh' ? '🌐 English' : '🌐 中文';
        }

        updateBtnText();

        btn.addEventListener('click', () => {
            const current = GST.i18n.getLang();
            const next = current === 'zh' ? 'en' : 'zh';
            GST.i18n.setLang(next);
        });

        // 监听语言变更事件
        window.addEventListener('langchange', () => {
            updateBtnText();
            updateDOM();
            updateCarouselContent();
            updateDynamicButtons();
            // 更新 HTML lang 属性
            document.documentElement.lang = GST.i18n.getLang() === 'en' ? 'en' : 'zh-CN';
            // 更新 title
            document.title = GST.i18n.getLang() === 'en' 
                ? '🥶 Gospel Snow Town - Doomsday Survival v5.0'
                : '🥶 福音雪镇 - 末日生存 v5.0';
        });
    }

    /**
     * 更新由 JS 动态控制文本的按钮（不走 data-i18n 机制）
     * 这些按钮的文本在运行时由 JS 设置，语言切换时需要手动刷新
     */
    function updateDynamicButtons() {
        // 跟随按钮
        const btnFollow = document.getElementById('btn-follow');
        if (btnFollow) {
            const isFollowing = btnFollow.classList.contains('active');
            btnFollow.textContent = isFollowing ? t('hud.follow_lock') : t('hud.follow_free');
        }
        // BGM 按钮 — 根据当前状态决定文本
        const btnBgm = document.getElementById('btn-bgm-mute');
        if (btnBgm) {
            const currentText = btnBgm.textContent;
            // 判断当前是否静音状态（通过检查按钮文本中是否包含 Off/关）
            if (currentText.includes('…')) {
                btnBgm.textContent = t('hud.bgm_pending');
            } else if (currentText.includes('Off') || currentText.includes('关')) {
                btnBgm.textContent = t('hud.bgm_off');
                btnBgm.title = t('hud.bgm_tip_muted');
            } else {
                btnBgm.textContent = t('hud.bgm_on');
                btnBgm.title = t('hud.bgm_tip_playing');
            }
        }
        // 会议面板 BGM 按钮
        const councilMute = document.getElementById('council-mute');
        if (councilMute) {
            const ct = councilMute.textContent;
            if (ct.includes('…')) {
                councilMute.textContent = t('hud.bgm_council_pending');
            } else if (ct.includes('Off') || ct.includes('关')) {
                councilMute.textContent = t('hud.bgm_council_off');
            } else {
                councilMute.textContent = t('hud.bgm_council_on');
            }
        }
        // 【v5.8.17】节能模式按钮
        const btnPowerSave = document.getElementById('btn-power-save');
        if (btnPowerSave) {
            const isActive = btnPowerSave.classList.contains('active');
            btnPowerSave.textContent = isActive ? t('hud.power_save_on') : t('hud.power_save_off');
            btnPowerSave.title = isActive ? t('hud.power_save_tip_on') : t('hud.power_save_tip_off');
        }
    }

    // 挂载
    GST.i18n.updateDOM = updateDOM;
    GST.i18n.updateCarouselContent = updateCarouselContent;
    GST.i18n.initLangSwitch = initLangSwitch;

    /**
     * 天气名称翻译映射（中文内部名 → i18n key）
     * 天气系统内部使用中文名作为标识符，UI 显示时通过此函数翻译
     */
    const WEATHER_KEY_MAP = {
        '阴天': 'weather_name.cloudy',
        '小雪': 'weather_name.light_snow',
        '大雪': 'weather_name.heavy_snow',
        '极寒暴风雪': 'weather_name.blizzard',
        '多云': 'weather_name.cloudy',
        '晴天': 'weather_name.clear',
        '大雾': 'weather_name.fog',
        '小雨': 'weather_name.light_rain',
        '大雨': 'weather_name.heavy_rain',
    };

    /**
     * 翻译天气名称（供 HUD 等 UI 使用）
     * @param {string} weatherZh - 中文天气名（内部标识符）
     * @returns {string} 翻译后的天气名
     */
    GST.i18n.translateWeather = function(weatherZh) {
        const key = WEATHER_KEY_MAP[weatherZh];
        return key ? t(key) : weatherZh;
    };

    // 页面加载完成后初始化
    window.addEventListener('load', () => {
        initLangSwitch();
        // 无论什么语言，都刷新一次动态按钮（确保初始文本正确）
        updateDynamicButtons();
        // 如果已经是英文，立刻刷新DOM
        if (GST.i18n.getLang() === 'en') {
            updateDOM();
            updateCarouselContent();
            document.documentElement.lang = 'en';
            document.title = '🥶 Gospel Snow Town - Doomsday Survival v5.0';
        }
    });

    console.log('[i18n] i18n-dom.js 已加载');
})();
