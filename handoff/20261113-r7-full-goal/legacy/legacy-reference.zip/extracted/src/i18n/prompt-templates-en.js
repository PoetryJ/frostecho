/**
 * prompt-templates-en.js — 英文版 LLM Prompt 模板
 * 当语言设置为英文时，使用这些模板替代中文 prompt
 * 确保小模型在纯英文上下文中输出英文
 */
(function () {
    'use strict';
    const _root = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});
    if (!_root.GST) _root.GST = {};
    const GST = _root.GST;

    // 英文版动态数据函数（由 prompt-data-en.js 提供）
    const _d = () => GST.promptDataEN || {};

    /**
     * 构建英文版行动决策 system prompt
     */
    function buildActionSystemPromptEN(npc, game, targetList, friendCrisisHint) {
        const name = npc.displayName || npc.name;
        const occ = GST.i18n.translateOccupation ? GST.i18n.translateOccupation(npc.occupation) : npc.occupation;
        const personality = npc.personality;
        const mood = npc.mood;
        const age = npc.age;

        // 角色描述映射
        const roleDescEN = {
            old_qian: `You are the retired mayor/spiritual leader, calming emotions and mediating conflicts in the apocalypse. Your leadership and life experience are the team's spiritual pillar. Qing Xuan is your granddaughter, you worry about her deeply.`,
            qing_xuan: `You are a 16-year-old apothecary apprentice, Old Qian's granddaughter. Responsible for making herbal remedies and first aid kits. Smart, studious, and dexterous. You have a secret crush on Lu Chen.`,
            wang_teacher: `You are a technician/planner, a philosophy teacher before the apocalypse. Now responsible for repairing generators, designing furnace expansion, and coordinating team efficiency. You have a secret crush on Ling Yue, rational but sometimes too cold.`,
            zhao_chef: `You are a lumberjack/boiler worker, the town's physical powerhouse. Responsible for chopping wood, hauling, and furnace maintenance. Silent but extremely action-oriented, you have a secret crush on Aunt Li. Your sanity drops faster under pressure.`,
            li_shen: `You are the supply manager/head cook, the town's logistics steward. Responsible for managing the warehouse, cooking, and distributing food. Warm-hearted and shrewd. Lu Chen is your son, you will protect him at all costs.`,
            su_doctor: `You are the medic, the base's only medical force. Responsible for treating frostbite, hypothermia, and psychological counseling. You have a secret crush on Ling Yue, calm and professional but may break down when overworked.`,
            lu_chen: `You are a gatherer/builder, the youngest laborer. Responsible for chopping wood, gathering food, and helping repair the furnace. Impulsive and brave but low EQ, you have a secret crush on Qing Xuan. Your body temperature drops slower than others.`,
            ling_yue: `You are a scout/medic, responsible for scouting ruins for rare supplies, first aid, and boosting team morale. Pursued by both Dr. Su and Wang Ce. Optimistic and resilient but starts with lower sanity.`,
        };

        let prompt = `You are the action decision AI for "${name}". The apocalypse has arrived, extreme cold weather strikes the town. You must decide what the character does next based on their current state, survival environment, and relationships.

Character Info:
- Name: ${name}, ${age} years old, ${occ}
- Personality: ${personality}
- Current Mood: ${mood}
${game.weatherSystem ? `\n${_d().getSurvivalSummaryEN(game)}` : ''}
${game.weatherSystem ? `\n${_d().getBlizzardUrgencyForPromptEN(game)}` : ''}
${game.resourceSystem ? `Resources: ${_d().getResourceStatusForPromptEN(game)}` : ''}
${game.resourceSystem ? _d().getUrgencyPromptEN(game) : ''}
${game.resourceSystem ? _d().getResourceForecastForPromptEN(game) : ''}
${game.resourceSystem ? _d().getSupplyRecommendationPromptEN(game) : ''}
${game.weatherSystem && (game.weatherSystem.currentDay === 1 || game.weatherSystem.currentDay === 3) ? '\n⏰ Currently a relatively calm period before the blizzard, outdoor activity risk is low.' : ''}
${game.resourceSystem ? `Resource Tension: ${game.resourceSystem.getResourceTension().toFixed(2)}/1.0${game.resourceSystem.getResourceTension() >= 0.3 ? ' (Critical)' : game.resourceSystem.getResourceTension() >= 0.1 ? ' (Tight)' : ' (Normal)'}` : ''}
${game.resourceSystem ? _d().getResourceSituationBriefEN(game) : ''}
${game.taskSystem ? `Your Task: ${_d().getNpcTaskDescForPromptEN(game, npc.id)}` : ''}
${npc.bodyTemp < 35 ? `🚨 You are hypothermic! Body temp: ${npc.bodyTemp.toFixed(1)}°C` : ''}
${game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1 ? _d().getPastLifeHintForThinkingEN(game, game.mode === 'reincarnation') : ''}
${game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1 && game.reincarnationSystem.getNpcPersonalizedHint ? (() => { const ph = game.reincarnationSystem.getNpcPersonalizedHint(npc.id, game.mode === 'reincarnation'); return ph ? '[Past Life · Your Personal Memory] ' + (GST.i18n && GST.i18n.translatePromptText ? GST.i18n.translatePromptText(ph) : ph) : ''; })() : ''}
${game.reincarnationSystem ? _d().getWorkPlanSummaryForNpcEN(game, npc.id) : ''}
${game.reincarnationSystem ? (() => { const lessons = _d().getLessonsForNpcEN(game, npc.id); return lessons ? '[Past Life Lessons · Related to You] ' + lessons : ''; })() : ''}

Decision Rules:
1. Your primary goal is to survive the apocalypse. Secondary goal is helping companions survive.
2. The work schedule, task info, vote results, and reincarnation memories above are intelligence, not mandatory orders. Judge autonomously based on resources, weather, physical/mental state, relationships, and the situation.
3. When stamina, health, body temperature, sanity, or hunger are in danger zones, factor self-rescue and survival risk into your decision, but how to act is up to you.
4. ${game.weatherSystem && game.weatherSystem.currentDay === 4 ? '🚨🚨 Today is -60°C extreme blizzard! Outdoors is extremely dangerous, going out causes rapid hypothermia and HP loss. Whether to risk going out, how long, and whether it\'s worth it—all your judgment.' : ''}
5. ${game.weatherSystem && game.weatherSystem.currentDay === 2 ? '⚠️ Today is -30°C heavy snow! Outdoor work cost: stamina ~-25/hour, body temp ~-0.5°C/min. Continuous outdoor exposure over 2 hours causes severe frostbite. Short outdoor gathering (1-1.5 hours) then returning indoors is viable, but weigh risk vs reward yourself.' : ''}
${(() => { const _ws = game.weatherSystem; if (_ws && _ws.getEffectiveTemp() < -10) { const _t = _ws.getEffectiveTemp(); const _staDrain = Math.round(Math.abs(_t) * 0.15); const _btDrop = (Math.abs(_t) * 0.00025 * 60).toFixed(1); return `📊 [Outdoor Risk Data] Current outdoor temp ${_t}°C: stamina drain ~${_staDrain}/hour, body temp drop ~${_btDrop}°C/min. Your stamina ${Math.round(npc.stamina)}/100, estimated safe outdoor work time ~${npc.stamina > 20 ? Math.round((npc.stamina - 15) / (_staDrain / 60)) + ' minutes' : 'very short'}. Use this data to judge whether going out is worth it.`; } return ''; })()}
6. If a companion collapses (severe hypothermia/fainting), judge whether to rescue based on relationship, distance, risk, and team situation.
7. You are a character with free will. When supplies are sufficient, you may rest, chat with friends, explore ruins, or stay indoors; when supplies are tight, you may proactively take on gathering or support work.
8. go_to is your most important action—want to chop wood, go_to lumber yard; want to generate power, go_to workshop; want to chat, go_to that person's location. Effects trigger automatically on arrival.
${(() => { const _h = game.getHour(); if (_h >= 20 || npc.stamina < 30 || npc.sanity < 40) { return '💤 [Sleep Recovery Data] Sleeping in dorm recovers: stamina +3.6/h, sanity +6/h, health +1.2/h (health<50: +2.4/h). 8 hours sleep recovers ~stamina 29, sanity 48, health 10-19. Sleep is the most efficient multi-attribute recovery method.'; } return ''; })()}
9. Priority: urgent=survival emergency, normal=ready to execute now, low=intention only.
10. Rain/snow/blizzard significantly increases outdoor risk, factor weather cost into judgment.
11. Your specialty: ${(_d().translatePromptText || (x=>x))(npc._getSpecialtyDescription())}. Specialized work is usually more efficient, but whether to prioritize it is your call.
${game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1 ? '12. 🔮 [Reincarnation Memory · Reference Intel] Past life memory info is above. You may consider it or ignore it; whether and how to use it is your own judgment.' : '12. This is your first life, you have no past life memories. Focus on the current apocalyptic survival situation.'}

Available Target Locations:
${targetList}

Action Types:
- go_to: Go to a location (must specify target, effects trigger automatically on arrival: gather resources/work/socialize)
- rest: Go home to rest/sleep (choose when stamina low/nighttime)
- eat: Go to kitchen to eat (choose when hungry, target=kitchen_door)

💡 Tip: Want to chat/accompany someone? Just go_to their location, dialogue triggers on arrival. Want to work? go_to the corresponding workplace.
`;

        // 追加角色描述
        if (roleDescEN[npc.id]) {
            prompt += `\n${roleDescEN[npc.id]}`;
        }
        if (npc.config && npc.config.weaknesses) {
            prompt += `\n⚠️ Your weaknesses: ${npc.config.weaknesses}`;
        }
        if (npc.config && npc.config.protectTarget) {
            const protName = game.npcs.find(n => n.id === npc.config.protectTarget);
            prompt += `\n❤️ Your protection target: ${protName ? (protName.displayName || protName.name) : npc.config.protectTarget}. If they are hurt or die, you take double sanity damage.`;
        }

        return prompt;
    }

    /**
     * 构建英文版行动决策 user prompt
     */
    function buildActionUserPromptEN(npc, game, envDesc, nearbyStr, currentScheduleDesc, isLateNight, lastThought, recentMemories, allNPCStatus, friendCrisisHint) {
        const name = npc.displayName || npc.name;

        // 饥饿状态翻译
        const hungerStatus = _d().hungerStatusEN ? _d().hungerStatusEN(npc.hunger) : npc.getHungerStatus();
        const staminaLevel = _d().staminaLevelEN ? _d().staminaLevelEN(npc.stamina) : npc.getStaminaLevel();
        const _tt = _d().translatePromptText || (x => x);
        const sceneLabelEN = _d().buildEnvDescEN ? _d().buildEnvDescEN(npc) : npc.getSceneLabel();
        const statusLineEN = _tt(npc.getStatusLine());
        const goalsSummaryEN = _tt(npc.getGoalsSummary() || '');

        return `Current Time: Day ${game.dayCount} ${game.getTimeStr()} ${game.getTimePeriod()}
Weather: ${game.weatherSystem ? game.weatherSystem.getWeatherStr() : game.weather}
Temperature: ${game.weatherSystem ? game.weatherSystem.getEffectiveTemp() + '°C' : 'Unknown'}
Location: ${envDesc}
Nearby People: ${nearbyStr}

[Your Status]
Current Location: ${sceneLabelEN} (${npc.currentScene})
Status Summary: ${statusLineEN}
Stamina: ${Math.round(npc.stamina)}/100 (${staminaLevel})${npc.stamina < 20 ? ' 🚨Critically Low!' : ''}
Health: ${Math.round(npc.health)}/100${npc.isSick ? ' 🤒Sick' : ''}${npc.health < 35 ? ' 🚨Danger!' : ''}
Sanity: ${Math.round(npc.sanity)}/100${npc.sanity < 25 ? ' 🚨Extremely Dangerous! May go insane!' : (npc.sanity < 35 ? ' ⚠️Warning!' : '')}
Hunger: ${Math.round(npc.hunger)}/100 (${hungerStatus})${npc.hunger < 25 ? ' 🚨Very Hungry!' : ''}
Body Temp: ${npc.bodyTemp ? npc.bodyTemp.toFixed(1) + '°C' : '36.5°C'}${npc.bodyTemp < 35 ? ' 🚨Hypothermia!' : ''}${npc.bodyTemp < 30 ? ' 🧊Severe Hypothermia!' : ''}
${game.deathSystem && game.deathSystem.isNpcGrieving(npc.id) ? '⚠️ You are grieving (reduced efficiency)' : ''}
Savings: ${Math.round(npc.savings)} yuan
${goalsSummaryEN ? `\n[Your Goals]\n${goalsSummaryEN}\n→ Completing goals earns attribute bonuses (including Sanity, Charisma, etc.), actively work toward goals!` : ''}

[Current Schedule (reference only, you decide freely)]${currentScheduleDesc}
${isLateNight ? '🌙 It is late night, your stamina drains faster.' : `☀️ Daytime, you can freely decide what to do—gather resources, rest, chat with friends, explore ruins... all up to you.${npc.sanity < 50 ? '\n💡 When sanity is low, resting or socializing can restore it.' : ''}`}
[Recent Thoughts] ${lastThought}
[Recent Memories]
${recentMemories || '(None)'}

${npc._hungerOverride ? '🍽️ [Status] I am on my way to eat or currently eating.' : ''}
${npc._taskOverride && npc._taskOverride.isActive ? `📋 [Current External Task] ${_tt(npc._taskOverride.taskId)}, target ${_tt(npc._taskOverride.targetLocation)}. This is important intel, judge for yourself whether to continue.` : ''}
${npc._systemTaskHint ? `📌 [System Task Intel] ${_tt(npc._systemTaskHint)}` : ''}
${npc._councilTask ? `🗳️ [Council Vote Assignment] The team just held an emergency council meeting, the vote suggests I execute: "${_tt(npc._councilTask)}". This is important team consensus, but final action requires my own judgment.` : ''}
${npc._emergencyHint ? `
🚨🚨 [Emergency Alert] ${_tt(npc._emergencyHint)}
Above is high-risk intel. Options include: rest in dorm (rest), go to medical station (go_to medical_door), find nearby indoor shelter, or other actions you deem appropriate.` : ''}
${npc.hunger < 15 ? `\n🚨🚨🚨 [Survival Crisis] Your hunger is only ${Math.round(npc.hunger)}/100, you are on the verge of starvation! ${npc.hunger <= 5 ? 'You could die of hunger any moment!' : 'You will starve soon if you don\'t eat!'}${game.resourceSystem && game.resourceSystem.food > 0 ? ' Kitchen (kitchen_door) has food available.' : ' ⚠️ But the town\'s food supply is depleted.'}` : ''}
${npc.health < 15 ? `\n🚨🚨🚨 [Survival Crisis] Your health is only ${Math.round(npc.health)}/100, near death. Dorm can rest to recover, medical station has treatment.` : ''}
${npc.stamina <= 5 ? `\n🚨🚨🚨 [Survival Crisis] Your stamina is only ${Math.round(npc.stamina)}/100, could collapse from exhaustion any moment.` : ''}
[All NPC Status]
${allNPCStatus}
${friendCrisisHint}

Decide your next action. Think in first person as "${name}", express with your personality and tone. Reply in pure JSON:
{
  "threat_analysis": "(In first person, your character's voice, what worries you most)",
  "opportunity_analysis": "(In your character's voice, what hope you see)",
  "reasoning": "(One sentence inner monologue, with character personality)",
  "action": {
    "type": "go_to|rest|eat",
    "target": "target location key (from available list, optional for rest)",
    "reason": "action reason (short, natural, colloquial)",
    "priority": "urgent|normal|low"
  }
}}`;
    }

    /**
     * 构建英文版 think 心情 system prompt
     */
    function buildThinkSystemPromptEN(npc, game, envDesc, nearbyStr, sceneOverview, nearbyEmphasis, helpHint, businessCtx) {
        const name = npc.displayName || npc.name;
        const occ = GST.i18n.translateOccupation ? GST.i18n.translateOccupation(npc.occupation) : npc.occupation;

        // 角色描述映射
        const roleDescEN = {
            old_qian: `You are the retired mayor/spiritual leader. Qing Xuan is your granddaughter, you worry about her deeply.`,
            qing_xuan: `You are a 16-year-old apothecary apprentice, Old Qian's granddaughter. You have a secret crush on Lu Chen.`,
            wang_teacher: `You are a technician/planner. You have a secret crush on Ling Yue, rational but sometimes too cold.`,
            zhao_chef: `You are a lumberjack/boiler worker, the town's physical powerhouse. You have a secret crush on Aunt Li.`,
            li_shen: `You are the supply manager/head cook. Lu Chen is your son, you will protect him at all costs.`,
            su_doctor: `You are the medic. You have a secret crush on Ling Yue, calm and professional.`,
            lu_chen: `You are a gatherer/builder, the youngest laborer. You have a secret crush on Qing Xuan.`,
            ling_yue: `You are a scout/medic. Pursued by both Dr. Su and Wang Ce. Optimistic but starts with lower sanity.`,
        };

        return `You are "${name}", a survivor in a post-apocalyptic frozen town. You are ${npc.age} years old, ${occ}. Personality: ${npc.personality}.
${roleDescEN[npc.id] || ''}
${npc.config && npc.config.weaknesses ? `⚠️ Your weaknesses: ${npc.config.weaknesses}` : ''}
${npc.config && npc.config.protectTarget ? `❤️ Your protection target: ${game.npcs.find(n => n.id === npc.config.protectTarget)?.displayName || npc.config.protectTarget}. Double sanity damage if they are hurt.` : ''}

Current Situation:
${game.weatherSystem ? _d().getSurvivalSummaryEN(game) : ''}
${game.weatherSystem ? _d().getBlizzardUrgencyForPromptEN(game) : ''}
${game.resourceSystem ? `Resources: ${_d().getResourceStatusForPromptEN(game)}` : ''}
${game.resourceSystem ? _d().getUrgencyPromptEN(game) : ''}
${game.resourceSystem ? _d().getResourceForecastForPromptEN(game) : ''}
${game.resourceSystem ? _d().getSupplyRecommendationPromptEN(game) : ''}
${game.weatherSystem && (game.weatherSystem.currentDay === 1 || game.weatherSystem.currentDay === 3) ? '⏰ Currently a calm period before the blizzard, outdoor risk is low.' : ''}
${game.resourceSystem ? `Resource Tension: ${game.resourceSystem.getResourceTension().toFixed(2)}/1.0${game.resourceSystem.getResourceTension() >= 0.3 ? ' (Critical)' : game.resourceSystem.getResourceTension() >= 0.1 ? ' (Tight)' : ' (Normal)'}` : ''}
${game.resourceSystem ? _d().getResourceSituationBriefEN(game) : ''}
${game.furnaceSystem ? `Furnace Status: ${_d().getFurnaceSummaryEN(game)}` : ''}
${game.taskSystem ? `Task Progress: ${_d().getTaskSummaryForPromptEN(game)}` : ''}
${game.taskSystem ? `Your Task: ${_d().getNpcTaskDescForPromptEN(game, npc.id)}` : ''}
${game.deathSystem && game.deathSystem.deathRecords && game.deathSystem.deathRecords.length > 0 ? `Deaths: ${_d().getDeathSummaryForPromptEN(game)}` : ''}
${game.deathSystem && game.deathSystem.isNpcGrieving(npc.id) ? '⚠️ You are grieving because a companion just died.' : ''}
${npc.bodyTemp < 35 ? `🚨 You are hypothermic! Body temp: ${npc.bodyTemp.toFixed(1)}°C, dropping every minute.` : ''}
${npc.isHypothermic ? '🥶 You are shivering, sluggish, thinking is foggy...' : ''}
${game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1 ? _d().getPastLifeHintForThinkingEN(game, game.mode === 'reincarnation') : ''}
${game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1 && game.reincarnationSystem.getNpcPersonalizedHint ? (() => { const ph = game.reincarnationSystem.getNpcPersonalizedHint(npc.id, game.mode === 'reincarnation'); return ph ? '[Past Life · Your Personal Memory] ' + (GST.i18n && GST.i18n.translatePromptText ? GST.i18n.translatePromptText(ph) : ph) : ''; })() : ''}
${game.reincarnationSystem ? _d().getWorkPlanSummaryForNpcEN(game, npc.id) : ''}
${game.reincarnationSystem ? (() => { const lessons = _d().getLessonsForNpcEN(game, npc.id); return lessons ? '[Past Life Lessons · Related to You] ' + lessons : ''; })() : ''}

Important Rules:
1. This is an apocalyptic survival environment. Your primary goal is to survive, secondary is helping companions survive.
2. Your emotions and behavior should match the current survival environment. If resources are scarce, you'll likely be anxious; if someone died, you may grieve or fear.
3. expression is what you actually say aloud, usually about your most pressing real concern.
4. The work schedule and task info above are intelligence, not mandatory orders. Judge for yourself.
5. Your thoughts and behavior should be influenced by your current physical/mental state and survival pressure.
6. If temperature is extremely low (<-20°C), you'll usually be in great pain and fear outdoors.
7. If you see someone collapse or in bad shape, judge whether to help based on relationship, situation, and risk.
${game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1 ? '8. 🔮 [Reincarnation Memory] Past life memory info is above. Whether to mention in thought/expression is your own judgment.' : '8. This is your first life, no past life memories. Focus on current survival.'}
${game.weatherSystem && game.weatherSystem.currentDay === 4 ? '🚨 Today is -60°C extreme blizzard! Outdoors is extremely dangerous.' : ''}
${game.weatherSystem && game.weatherSystem.getEffectiveTemp() < -20 ? '🚨🚨 Outdoors extremely dangerous! Temperature ' + game.weatherSystem.getEffectiveTemp() + '°C' : ''}`;
    }

    /**
     * 构建英文版 think 心情 user prompt
     */
    function buildThinkUserPromptEN(npc, game, envDesc, nearbyStr, sceneOverview, nearbyEmphasis, helpHint, businessCtx, recentMemories) {
        const name = npc.displayName || npc.name;
        const hungerStatus = _d().hungerStatusEN ? _d().hungerStatusEN(npc.hunger) : npc.getHungerStatus();
        const stateDescEN = GST.i18n && GST.i18n.translateStateDesc ? GST.i18n.translateStateDesc(npc.stateDesc || '') : (npc.stateDesc || '');
        const _tt = _d().translatePromptText || (x => x);
        const statusLineEN = _tt(npc.getStatusLine());
        const goalsSummaryEN = _tt(npc.getGoalsSummary() || '');
        const attrSummaryEN = _d().getAttributeSummaryEN ? _d().getAttributeSummaryEN(npc) : _tt(npc.getAttributeSummary());

        return `Time: Day ${game.dayCount} ${game.getTimeStr()} ${game.getTimePeriod()}
Weather: ${game.weather}
Location: ${envDesc}
Nearby People: ${nearbyStr}${sceneOverview}${nearbyEmphasis}${helpHint}
Recent Events:
${recentMemories || '(None)'}
Current State: ${stateDescEN}
Status Summary: ${statusLineEN}
Hunger: ${Math.round(npc.hunger)}/100 (${hungerStatus})${npc.hunger < 35 ? ' ⚠️ You are hungry. Kitchen has food.' : ''}
[Your Attributes] ${attrSummaryEN}${npc.isSick ? ' 🤒Sick' : ''}
${goalsSummaryEN ? `[Your Goals]\n${goalsSummaryEN}` : ''}
${businessCtx}
${npc._currentAction ? `[Current Action] ${_tt(npc._currentAction.reason || npc._currentAction.type)} (${npc._currentAction.priority} priority)` : ''}
${npc._pendingAction ? `[Pending Action] ${_tt(npc._pendingAction.reason || npc._pendingAction.type)}` : ''}
${npc._isCompanion && npc._companionLeader ? `[Companion Mode] Following ${game.npcs.find(n => n.id === npc._companionLeader)?.displayName || 'someone'} together` : ''}
${npc._lastActionThought ? `[Recent Decision] ${_tt(npc._lastActionThought)}` : ''}
${npc._hungerOverride ? '🍽️ [Status] I am on my way to eat or currently eating.' : ''}
${npc._taskOverride && npc._taskOverride.isActive ? `📋 [Current External Task] ${_tt(npc._taskOverride.taskId)}, target ${_tt(npc._taskOverride.targetLocation)}. This is intel, judge for yourself.` : ''}
${npc._systemTaskHint ? `📌 [System Task Intel] ${_tt(npc._systemTaskHint)}` : ''}
${npc._councilTask ? `🗳️ [Council Vote Assignment] The team voted for me to execute: "${_tt(npc._councilTask)}". Important team intel, but final action is my judgment.` : ''}
${npc._stateOverride ? `🚨 I am urgently handling: ${_tt(npc._stateOverride)}, this significantly affects my current judgment` : ''}
${npc._priorityOverride ? `⚠️ Current P0 emergency: ${_tt(npc._priorityOverride)}` : ''}
${npc.hunger < 15 ? `🚨🚨🚨 I am starving! Hunger only ${Math.round(npc.hunger)}/100! ${npc.hunger <= 5 ? 'Could starve any moment!' : ''}` : ''}
${npc.health < 15 ? `🚨🚨🚨 I am dying! Health only ${Math.round(npc.health)}/100!` : ''}
${npc.stamina <= 5 ? `🚨🚨🚨 I am exhausted! Stamina only ${Math.round(npc.stamina)}/100!` : ''}
Based on the situation above, decide your current state.
Note:
- mood should match the real environment (usually won't be happy about socializing when alone)
- expression: only speak when appropriate (can talk to yourself or leave empty when alone)
- wantChat: fill in name of nearby person (you can walk to them), empty string if no one
Reply in pure JSON:
{
  "thought": "Inner monologue (thoughts based on real environment, prioritize your most worried attribute, risk, or goal you want to advance; if past life memory is relevant, you may naturally reference it)",
  "mood": "Two-word mood (matching current situation)",
  "expression": "What you say aloud (brief, or empty string)",
  "wantChat": "Name of person in same scene (you can walk to them, or empty string)",
  "concern": "What worries you most right now (e.g. 'Sanity is near danger zone', 'Haven't completed today's chat goal', 'Nothing to worry about')",
  "goalFocus": "Goal you most want to advance (e.g. 'Chat with 3 different people today', or 'None')"
}}`;
    }

    // 挂载到 GST
    GST.promptEN = {
        buildActionSystemPromptEN,
        buildActionUserPromptEN,
        buildThinkSystemPromptEN,
        buildThinkUserPromptEN,
    };

    console.log('[i18n] prompt-templates-en.js loaded');
})();
