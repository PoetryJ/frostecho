/**
 * 福音镇 - 国际化核心模块
 * 提供 t(key) 翻译函数、语言切换、模板变量替换
 * 挂载到 GST.i18n / GST.t
 * 
 * 用法：
 *   GST.t('ui.title')                    → "🥶 福音雪镇 — 末日生存"
 *   GST.t('ui.day_n', { n: 3 })          → "第3天"
 *   GST.i18n.setLang('en')               → 切换到英文
 *   GST.i18n.getLang()                    → 'zh' | 'en'
 */
(function() {
    'use strict';
    const GST = window.GST || (window.GST = {});

    // 当前语言（默认中文）
    let _currentLang = 'zh';

    // 语言包注册表 { zh: { ... }, en: { ... } }
    const _packs = {};

    /**
     * 注册语言包（可多次调用，合并到已有包中）
     * @param {string} lang - 语言代码 'zh' | 'en'
     * @param {Object} pack - 扁平化或嵌套的翻译键值对
     */
    function registerPack(lang, pack) {
        if (!_packs[lang]) _packs[lang] = {};
        _mergePack(_packs[lang], pack);
    }

    /** 深度合并语言包 */
    function _mergePack(target, source, prefix) {
        for (const key in source) {
            const fullKey = prefix ? `${prefix}.${key}` : key;
            if (typeof source[key] === 'object' && source[key] !== null && !Array.isArray(source[key])) {
                _mergePack(target, source[key], fullKey);
            } else {
                target[fullKey] = source[key];
            }
        }
    }

    /**
     * 翻译函数
     * @param {string} key - 翻译键，如 'ui.title'
     * @param {Object} [params] - 模板变量，如 { n: 3, name: '老钱' }
     * @returns {string} 翻译后的文本，找不到则返回 key 本身
     */
    function t(key, params) {
        const pack = _packs[_currentLang] || _packs['zh'] || {};
        let text = pack[key];

        // 回退到中文
        if (text === undefined && _currentLang !== 'zh') {
            text = (_packs['zh'] || {})[key];
        }

        // 找不到翻译，返回 key
        if (text === undefined) {
            console.warn(`[i18n] 缺少翻译: ${key} (${_currentLang})`);
            return key;
        }

        // 模板变量替换 {name} → params.name
        if (params) {
            text = text.replace(/\{(\w+)\}/g, (match, varName) => {
                return params[varName] !== undefined ? params[varName] : match;
            });
        }

        return text;
    }

    /**
     * 设置当前语言
     * @param {string} lang - 'zh' | 'en'
     */
    function setLang(lang) {
        if (!_packs[lang]) {
            console.warn(`[i18n] 语言包 '${lang}' 未注册，保持当前语言 '${_currentLang}'`);
            return;
        }
        _currentLang = lang;
        try {
            localStorage.setItem('gospel_lang', lang);
        } catch (e) { /* ignore */ }
        console.log(`[i18n] 语言已切换为: ${lang}`);

        // 触发语言变更事件，供各模块监听并刷新UI
        window.dispatchEvent(new CustomEvent('langchange', { detail: { lang } }));
    }

    /**
     * 获取当前语言
     * @returns {string} 'zh' | 'en'
     */
    function getLang() {
        return _currentLang;
    }

    /**
     * 判断当前是否英文
     * @returns {boolean}
     */
    function isEn() {
        return _currentLang === 'en';
    }

    /**
     * 从 localStorage 恢复语言设置
     */
    function restoreLang() {
        try {
            const saved = localStorage.getItem('gospel_lang');
            if (saved && _packs[saved]) {
                _currentLang = saved;
                console.log(`[i18n] 从存储恢复语言: ${saved}`);
            }
        } catch (e) { /* ignore */ }
    }

    // ============ 翻译辅助函数 ============

    /** NPC 中文名 → nameKey 映射 */
    const _npcNameKeyMap = {
        '李婶': 'npc.li_shen',
        '赵铁柱': 'npc.zhao_chef',
        '王策': 'npc.wang_teacher',
        '老钱': 'npc.old_qian',
        '苏岩': 'npc.su_doctor',
        '陆辰': 'npc.lu_chen',
        '歆玥': 'npc.ling_yue',
        '清璇': 'npc.qing_xuan',
    };

    /** NPC id → nameKey 映射 */
    const _npcIdKeyMap = {
        'li_shen': 'npc.li_shen',
        'zhao_chef': 'npc.zhao_chef',
        'wang_teacher': 'npc.wang_teacher',
        'old_qian': 'npc.old_qian',
        'su_doctor': 'npc.su_doctor',
        'lu_chen': 'npc.lu_chen',
        'ling_yue': 'npc.ling_yue',
        'qing_xuan': 'npc.qing_xuan',
    };

    /**
     * 翻译 NPC 名字（支持中文名或 id）
     * @param {string} nameOrId - NPC 中文名或 id
     * @returns {string} 翻译后的名字
     */
    function translateNpcName(nameOrId) {
        if (!nameOrId) return nameOrId;
        const key = _npcNameKeyMap[nameOrId] || _npcIdKeyMap[nameOrId];
        if (key) return t(key);
        return nameOrId;
    }

    /** 天气中文 → key 映射 */
    const _weatherKeyMap = {
        '阴天': 'weather_name.cloudy',
        '小雪': 'weather_name.light_snow',
        '大雪': 'weather_name.heavy_snow',
        '暴风雪': 'weather_name.blizzard',
        '极寒暴风雪': 'weather_name.blizzard',
        '晴天': 'weather_name.clear',
        '大雾': 'weather_name.fog',
        '小雨': 'weather_name.light_rain',
        '大雨': 'weather_name.heavy_rain',
    };

    /**
     * 翻译天气名称
     * @param {string} weatherCN - 中文天气名
     * @returns {string} 翻译后的天气名
     */
    function translateWeather(weatherCN) {
        if (!weatherCN) return weatherCN;
        const key = _weatherKeyMap[weatherCN];
        if (key) return t(key);
        return weatherCN;
    }

    /** 任务类型 → key 映射 */
    const _taskKeyMap = {
        'COLLECT_WOOD': 'task_label.collect_wood',
        'COLLECT_FOOD': 'task_label.collect_food',
        'MAINTAIN_POWER': 'task_label.maintain_power',
        'MINE_POWER': 'task_label.mine_power',
        'COLLECT_MATERIAL': 'task_label.collect_material',
        'BUILD_GENERATOR': 'task_label.build_generator',
        'BUILD_LUMBER_MILL': 'task_label.build_lumber_mill',
        'BUILD_FOOD_COLLECTOR': 'task_label.build_food_collector',
        'REPAIR_GENERATOR': 'task_label.repair_generator',
        'REPAIR_LUMBER_MILL': 'task_label.repair_lumber_mill',
        'REPAIR_FOOD_COLLECTOR': 'task_label.repair_food_collector',
        'DISTRIBUTE_FOOD': 'task_label.distribute_food',
        'PREPARE_MEDICAL': 'task_label.prepare_medical',
        'PSYCHOLOGY': 'task_label.psychology',
        'WAREHOUSE': 'task_label.warehouse',
        'BOOST_MORALE': 'task_label.boost_morale',
        'MAINTAIN_ORDER': 'task_label.maintain_order',
        'REST': 'task_label.rest',
        'TREATMENT': 'task_label.treatment',
        'COORDINATE': 'task_label.coordinate',
        'SCOUT_RUINS': 'task_label.scout_ruins',
        'PREPARE_WARMTH': 'task_label.prepare_warmth',
        'REST_RECOVER': 'task_label.rest_recover',
    };

    /**
     * 翻译任务类型标签
     * @param {string} taskType - 任务类型 key（如 'COLLECT_WOOD'）
     * @returns {string} 翻译后的标签
     */
    function translateTaskLabel(taskType) {
        if (!taskType) return taskType;
        const key = _taskKeyMap[String(taskType).trim().toUpperCase()];
        if (key) return t(key);
        return taskType;
    }

    /**
     * 翻译 NPC 职业
     * @param {string} npcId - NPC id
     * @returns {string} 翻译后的职业
     */
    function translateOccupation(npcId) {
        if (!npcId) return '';
        const key = `occupation.${npcId}`;
        const result = t(key);
        return result !== key ? result : '';
    }

    /** 供暖等级中文 → key 映射 */
    const _furnaceLevelKeyMap = {
        '稳定': 'furnace_level.stable',
        '吃紧': 'furnace_level.strained',
        '危险': 'furnace_level.critical',
        '失效': 'furnace_level.failed',
    };

    /**
     * 翻译供暖等级
     * @param {string} levelCN - 中文供暖等级
     * @returns {string} 翻译后的等级
     */
    function translateFurnaceLevel(levelCN) {
        if (!levelCN) return levelCN;
        const key = _furnaceLevelKeyMap[levelCN];
        if (key) return t(key);
        return levelCN;
    }

    /** 死亡原因中文 → key 映射 */
    const _deathCauseKeyMap = {
        '因严重失温而死亡': 'death_cause.frozen',
        '因长期饥饿而死亡': 'death_cause.starved',
        '因长期体力枯竭而死亡': 'death_cause.stamina_exhaustion',
        '精神崩溃导致的悲剧': 'death_cause.mental_breakdown',
        '在冲突中被攻击致死': 'death_cause.violence',
    };

    /**
     * 翻译死亡原因
     * @param {string} causeCN - 中文死亡原因
     * @returns {string} 翻译后的原因
     */
    function translateDeathCause(causeCN) {
        if (!causeCN) return causeCN;
        const key = _deathCauseKeyMap[causeCN];
        if (key) return t(key);
        return causeCN;
    }

    /**
     * 翻译时间段
     * @param {string} periodCN - 中文时间段
     * @returns {string} 翻译后的时间段
     */
    const _timePeriodKeyMap = {
        '清晨': 'time_period.dawn',
        '上午': 'time_period.morning',
        '中午': 'time_period.noon',
        '下午': 'time_period.afternoon',
        '傍晚': 'time_period.evening',
        '晚上': 'time_period.night',
        '深夜': 'time_period.midnight',
    };

    function translateTimePeriod(periodCN) {
        if (!periodCN) return periodCN;
        const key = _timePeriodKeyMap[periodCN];
        if (key) return t(key);
        return periodCN;
    }

    // ============ NPC 状态描述翻译（stateDesc / dynamicBubble） ============

    /** 中文状态描述 → i18n key 映射（精确匹配） */
    const _stateDescKeyMap = {
        // 采集/工作状态
        '正在砍柴': 'state_desc.chopping_wood',
        '正在捕鱼': 'state_desc.fishing',
        '正在探索废墟': 'state_desc.exploring_ruins',
        '正在维护电力': 'state_desc.maintaining_power',
        '正在采集': 'state_desc.gathering',
        '人工发电': 'state_desc.manual_power',
        '正在人工发电中': 'state_desc.manual_power',
        '砍柴': 'state_desc.chopping_wood',
        '搬运木柴': 'state_desc.carrying_wood',
        '探索废墟': 'state_desc.exploring_ruins',
        // 任务名称（task-system.js中的name字段，带emoji）
        '🪵 收集木柴': 'task_label.collect_wood',
        '🍞 收集食物': 'task_label.collect_food',
        '⚡ 维护电力': 'task_label.maintain_power',
        '🔍 探索废墟': 'task_label.collect_material',
        '🧥 准备御寒物资': 'task_label.prepare_warmth',
        '💊 医疗救治': 'task_label.prepare_medical',
        '🎵 鼓舞士气': 'task_label.boost_morale',
        '📢 统筹协调': 'task_label.coordinate',
        '🍲 分配食物': 'task_label.distribute_food',
        '🛡️ 维持秩序': 'task_label.maintain_order',
        '🛏️ 休息恢复': 'task_label.rest_recover',
        '🔍 废墟侦察': 'task_label.scout_ruins',
        '⚡ 建造自动发电机': 'task_label.build_generator',
        '🪵 建造自动伐木机': 'task_label.build_lumber_mill',
        '🍞 建造自动捕猎机': 'task_label.build_food_collector',
        // 不带emoji的任务名
        '收集木柴': 'task_label.collect_wood',
        '收集食物': 'task_label.collect_food',
        '维护电力': 'task_label.maintain_power',
        '探索废墟': 'task_label.collect_material',
        '医疗救治': 'task_label.prepare_medical',
        '鼓舞士气': 'task_label.boost_morale',
        '统筹协调': 'task_label.coordinate',
        '分配食物': 'task_label.distribute_food',
        '维持秩序': 'task_label.maintain_order',
        '侦察废墟': 'task_label.scout_ruins',
        // 休息/睡觉
        '回宿舍休息': 'state_desc.going_dorm_rest',
        '在原地休息整理': 'state_desc.resting_in_place',
        '在室内整理物资': 'state_desc.organizing_indoor',
        '累坏了，赶紧回家休息': 'state_desc.exhausted_go_home',
        '累坏了，倒头就睡': 'state_desc.exhausted_sleep',
        '累坏了，就地休息': 'state_desc.exhausted_rest_here',
        '累坏了，就地休息 💤': 'state_desc.exhausted_rest_here_zzz',
        '准备执行任务': 'state_desc.preparing_task',
        '回家睡觉了': 'state_desc.going_home_sleep',
        '在家休息中': 'state_desc.resting_at_home',
        '休息完毕': 'state_desc.rest_done',
        '对话结束': 'state_desc.chat_ended',
        // 医疗
        '出诊结束，返回医疗站': 'state_desc.house_call_done_returning',
        '咨询结束，精神好多了': 'state_desc.counseling_done',
        '看完病了，感觉好多了': 'state_desc.treatment_done',
        // 紧急状态
        '大极寒！紧急返回室内': 'state_desc.extreme_cold_emergency',
        '严重失温！紧急返回室内': 'state_desc.hypothermia_emergency',
        '严重失温，倒地不起 🧊': 'state_desc.hypothermia_collapse',
        '严重失温，倒地不起 🧶': 'state_desc.hypothermia_collapse',
        '体温过低，瑟瑟发抖 🥶': 'state_desc.hypothermia_shivering',
        '精神崩溃了 🤯': 'state_desc.mental_breakdown',
        '生病了 🤒': 'state_desc.sick',
        '⚠️ 濒死': 'state_desc.dying',
        // 日程
        '起床去吃早餐': 'state_desc.wake_up_breakfast',
        '准备晚餐、分配食物': 'state_desc.prepare_dinner',
        '准备早餐': 'state_desc.prepare_breakfast',
        '太累了…安抚不动了': 'state_desc.too_tired_to_comfort',
        '店里太冷清了，出门转转招揽客人': 'state_desc.go_out_recruit',
        // 工作状态补充
        '检查机器运行状况': 'state_desc.checking_machine',
        '等待指令': 'state_desc.awaiting_orders',
        '坐诊': 'state_desc.on_duty_medical',
        '坐诊空闲': 'state_desc.on_duty_idle',
        '制药中': 'state_desc.making_medicine',
        // === 补全缺失的 stateDesc 映射 ===
        '采矿': 'state_desc.mining',
        '采集食物': 'state_desc.gathering_food',
        '做饭': 'state_desc.cooking',
        '安抚': 'state_desc.comforting',
        '巡逻': 'state_desc.patrolling',
        '盘点物资': 'state_desc.inventory',
        '医疗救治': 'state_desc.medical_treatment',
        '心理疏导': 'state_desc.counseling',
        '建造发电机': 'state_desc.building_generator',
        '建造伐木机': 'state_desc.building_lumber_mill',
        '建造捕猎机': 'state_desc.building_food_collector',
        '维修发电机': 'state_desc.repairing_generator',
        '维修伐木机': 'state_desc.repairing_lumber_mill',
        '维修捕猎机': 'state_desc.repairing_food_collector',
        '休息': 'state_desc.resting',
        '治疗': 'state_desc.treating',
        '制作草药': 'state_desc.making_herbs',
        '休息恢复': 'state_desc.rest_recover',
        // desc 字段中的完整短语
        '回宿舍休息恢复体力': 'state_desc.going_dorm_rest',
        '去伐木场砍柴补充木柴': 'state_desc.going_lumber_chop',
        '去冰湖采集食物': 'state_desc.going_lake_gather',
        '去工坊人工发电，紧急补电': 'state_desc.going_workshop_power',
        '去废墟探索物资': 'state_desc.going_ruins_explore',
        '去矿渣堆采矿发电': 'state_desc.going_mine_power',
        '去炊事房做饭，减少食物浪费': 'state_desc.going_kitchen_cook',
        '去炊事房吃饭': 'state_desc.going_kitchen_eat',
        '去医疗站治疗伤员或处理医疗事务': 'state_desc.going_medical_treat',
        '去医疗站做心理疏导': 'state_desc.going_medical_counsel',
        '去安抚和鼓舞大家，恢复士气': 'state_desc.going_boost_morale',
        '去宿舍巡逻警戒': 'state_desc.going_dorm_patrol',
        '去宿舍巡视': 'state_desc.going_dorm_inspect',
        '去宿舍待命': 'state_desc.going_dorm_standby',
        '去仓库盘点物资，减少浪费': 'state_desc.going_warehouse_inventory',
        '去工坊建造自动发电机，建成后可自动产电': 'state_desc.going_build_generator',
        '去工坊建造自动伐木机，建成后可自动产柴': 'state_desc.going_build_lumber_mill',
        '去工坊建造自动捕猎机，建成后可自动产食物': 'state_desc.going_build_food_collector',
        '去工坊维修故障的自动发电机': 'state_desc.going_repair_generator',
        '去工坊维修故障的自动伐木机': 'state_desc.going_repair_lumber_mill',
        '去工坊维修故障的自动捕猎机': 'state_desc.going_repair_food_collector',
        '去工坊工作': 'state_desc.going_workshop_work',
        // reason 字段
        '去宿舍安抚大家': 'state_desc.going_dorm_comfort',
        '去医疗站坐诊': 'state_desc.going_medical_duty',
        '伐木场砍柴': 'state_desc.lumber_chopping',
        // npc-state-override.js 中的 desc/expression/stateDesc
        '去医疗站看病': 'state_desc.going_medical_sick',
        '去医疗站看心理': 'state_desc.going_medical_mental',
        '在医疗站接受治疗中…': 'state_desc.receiving_treatment',
        '咨询结束，精神好多了': 'state_desc.counseling_done',
        '看完医生，身体舒服多了！': 'state_desc.treatment_done_expr',
        '看完病了，感觉好多了': 'state_desc.treatment_done',
        '苏岩不在医疗站…回头再来吧': 'state_desc.doctor_not_here',
        '在室内原地休息': 'state_desc.resting_in_place',
        '紧急回室内休息': 'state_desc.emergency_indoor_rest',
        // npc-state-override.js 中的 desc（addEvent用）
        '身体不舒服，去医疗站看看': 'state_desc.feeling_sick_going_medical',
        '精神状态不好，去找医官聊聊': 'state_desc.mental_bad_going_counseling',
        // npc-ai.js 中的 desc
        '去炊事房做饭': 'state_desc.going_kitchen_cook_short',
        '去伐木场砍柴': 'state_desc.going_lumber_chop_short',
        '去工坊人工发电': 'state_desc.going_workshop_power_short',
        '去伐木场搬运': 'state_desc.going_lumber_carry',
        '去医疗站制作草药': 'state_desc.going_medical_herbs',
        '去矿渣堆采矿': 'state_desc.going_mine',
        '去宿舍A安抚大家': 'state_desc.going_dorm_comfort',
        // council-discussion.js 中的 desc
        '去室内安抚士气': 'state_desc.going_boost_morale',
        '去室内巡逻': 'state_desc.going_indoor_patrol',
        '回去休息': 'state_desc.going_back_rest',
        '去医疗站接受治疗': 'state_desc.going_medical_treatment',
        '去医疗站心理疏导': 'state_desc.going_medical_counsel',
        '去仓库盘点物资': 'state_desc.going_warehouse_inventory_short',
        '去医疗站治疗': 'state_desc.going_medical_treat_short',
        '去工坊建造发电机': 'state_desc.going_build_generator_short',
        '去工坊建造伐木机': 'state_desc.going_build_lumber_mill_short',
        '去工坊建造捕猎机': 'state_desc.going_build_food_collector_short',
        '去工坊维修发电机': 'state_desc.going_repair_generator_short',
        '去工坊维修伐木机': 'state_desc.going_repair_lumber_mill_short',
        '去工坊维修捕猎机': 'state_desc.going_repair_food_collector_short',
        '去废墟探索物资': 'state_desc.going_ruins_explore',
        '去冰湖采集食物': 'state_desc.going_lake_gather',
        // 睡眠/休息状态
        '休息好了': 'state_desc.rested_well',
        '刚起床': 'state_desc.just_woke_up',
        '小憩醒来': 'state_desc.nap_woke_up',
        '正在睡觉 💤': 'state_desc.sleeping',
        '醒了过来': 'state_desc.woke_up',
        '回去休息': 'state_desc.going_back_rest',
        // 治疗状态
        '正在接受心理咨询': 'state_desc.receiving_counseling',
        '正在看病治疗': 'state_desc.receiving_treatment_medical',
        '执行任务': 'state_desc.executing_task',
        // 地图名称（用于小地图标题等）
        '末日据点': 'location.village',
        // npc-ai.js 中的额外 stateDesc
        '去吃饭': 'state_desc.going_to_eat',
        '待在原地': 'state_desc.staying_put',
        '随便走走': 'state_desc.wandering',
        '属性极低，紧急回室内休息': 'state_desc.critical_emergency_rest',
        '无法安全出门，在室内原地休息': 'state_desc.unsafe_outdoor_rest',
        // npc-eating.js 中的额外 desc
        '在炊事房吃饭': 'state_desc.eating_in_kitchen',
        '去仓库拿干粮': 'state_desc.getting_rations',
        '在宿舍吃点东西': 'state_desc.eating_in_dorm',
        '回宿舍做饭': 'state_desc.cooking_in_dorm',
        '去炊事房吃饭': 'state_desc.going_kitchen_eat',
    };

    /** 中文模式匹配翻译规则（用于动态拼接的文本） */
    const _stateDescPatterns = [
        // "紧急前往XXX" → "Urgently heading to XXX"
        { regex: /^紧急前往(.+)$/, replace: (m) => t('state_desc.urgent_heading_to', { target: _translateLocation(m[1]) }) },
        // "前往XXX" → "Heading to XXX"
        { regex: /^前往(.+)$/, replace: (m) => t('state_desc.heading_to', { target: _translateLocation(m[1]) }) },
        // "正在和XXX附近闲逛" → "Wandering near XXX"
        { regex: /^正在和(.+)附近闲逛$/, replace: (m) => t('state_desc.wandering_with', { names: translateNpcNamesInText(m[1]) }) },
        // "和XXX一起YYY" → "With XXX doing YYY"
        { regex: /^和(.+)一起(.+)$/, replace: (m) => t('state_desc.doing_together', { name: translateNpcNamesInText(m[1]), action: translateStateDesc(m[2]) }) },
        // "跟着XXX一起走" → "Following XXX"
        { regex: /^跟着(.+)一起走$/, replace: (m) => t('state_desc.following', { name: translateNpcNamesInText(m[1]) }) },
        // "出诊治疗XXX中" → "House call treating XXX"
        { regex: /^出诊治疗(.+)中$/, replace: (m) => t('state_desc.house_call_treating', { name: translateNpcNamesInText(m[1]) }) },
        // "出诊中，前往XXX身边治疗" → "House call, heading to XXX"
        { regex: /^出诊中，前往(.+)身边治疗$/, replace: (m) => t('state_desc.house_call_heading', { name: translateNpcNamesInText(m[1]) }) },
        // "因XXX的死亡陷入悲痛" → "Grieving for XXX"
        { regex: /^因(.+)的死亡陷入悲痛$/, replace: (m) => t('state_desc.grieving', { name: translateNpcNamesInText(m[1]) }) },
        // "已故 — XXX" → "Deceased — XXX"
        { regex: /^已故 — (.+)$/, replace: (m) => t('state_desc.deceased', { cause: translateDeathCause(m[1]) }) },
        // "肚子饿了，去XXX" → "Hungry, going to XXX"
        { regex: /^肚子饿了，去(.+)$/, replace: (m) => t('state_desc.hungry_going', { place: _translateLocation(m[1]) }) },
        // "正在走向XXX" → "Walking towards XXX"
        { regex: /^正在走向(.+)$/, replace: (m) => t('state_desc.walking_towards', { name: translateNpcNamesInText(m[1]) }) },
        // "正在XXX" (吃饭相关) → "Eating at XXX"
        { regex: /^正在(.+吃饭.*)$/, replace: (m) => t('state_desc.eating_at', { place: _translateLocation(m[1]) }) },
        // "正在XXX" (通用) → "Doing XXX"
        { regex: /^正在(.+)$/, replace: (m) => t('state_desc.doing', { action: translateStateDesc(m[1]) }) },
        // "去砍柴，YYY" → "Chopping Wood"（去+动作+逗号+原因）
        { regex: /^去砍柴[，,](.+)$/, replace: () => t('state_desc.chopping_wood') },
        { regex: /^去捕鱼[，,](.+)$/, replace: () => t('state_desc.fishing') },
        { regex: /^去探索[，,](.+)$/, replace: () => t('state_desc.exploring_ruins') },
        { regex: /^去发电[，,](.+)$/, replace: () => t('state_desc.manual_power') },
        // "去砍柴" → "Chopping Wood"（去+动作，无逗号）
        { regex: /^去砍柴$/, replace: () => t('state_desc.chopping_wood') },
        { regex: /^去捕鱼$/, replace: () => t('state_desc.fishing') },
        { regex: /^去探索废墟$/, replace: () => t('state_desc.exploring_ruins') },
        { regex: /^去发电$/, replace: () => t('state_desc.manual_power') },
        // "去XXX，YYY" → "Heading to XXX"（去+地点+逗号+原因）
        { regex: /^去(.+?)[，,](.+)$/, replace: (m) => t('state_desc.heading_to', { target: _translateLocation(m[1]) }) },
        // "去XXX" → "Heading to XXX"
        { regex: /^去(.+)$/, replace: (m) => t('state_desc.heading_to', { target: _translateLocation(m[1]) }) },
        // "正在XXX中" → 通用工作状态
        { regex: /^正在(.+)中\.{0,3}$/, replace: (m) => translateStateDesc(m[1]) + '...' },
        // "XXX中..." → 通用进行中状态
        { regex: /^(.+)中\.{3}$/, replace: (m) => translateStateDesc(m[1]) + '...' },
    ];

    /** 气泡文本中文 → 英文模式匹配 */
    const _bubblePatterns = [
        { regex: /^🪓 砍柴中（木柴\+([\d.]+)\/h）$/, replace: (m) => `🪓 ${t('bubble.chopping', { rate: m[1] })}` },
        { regex: /^🎣 采集食物中（食物\+([\d.]+)\/h）$/, replace: (m) => `🎣 ${t('bubble.fishing', { rate: m[1] })}` },
        { regex: /^⛏️ 采矿中（⚡\+([\d.]+)\/h）$/, replace: (m) => `⛏️ ${t('bubble.mining', { rate: m[1] })}` },
        { regex: /^⚡ 人工发电中（⚡\+([\d.]+)\/h）$/, replace: (m) => `⚡ ${t('bubble.manual_power', { rate: m[1] })}` },
        { regex: /^🔧 修理工具（⚡\+([\d.]+)\/h）$/, replace: (m) => `🔧 ${t('bubble.repair_tool', { rate: m[1] })}` },
        { regex: /^📦 管理仓库中（食物\+([\d.]+)\/h，柴耗-([\d.]+)%）$/, replace: (m) => `📦 ${t('bubble.managing_warehouse', { food: m[1], fuel: m[2] })}` },
        { regex: /^🏥 医疗救治中（HP\+([\d.]+)\/h (.+?)）\n\s+→ 治疗对象: (.+)$/, replace: (m) => t('bubble.healing', { rate: m[1], medkit: m[2], targets: translateNpcNamesInText(m[3]) }) },
        { regex: /^💊 制药中（进度(\d+)% 库存×(\d+)）$/, replace: (m) => t('bubble.crafting_medicine', { pct: m[1], stock: m[2] }) },
        { regex: /^💊 坐诊空闲·制药中/, replace: () => null },  // 已在源头通过GST.t()生成
        { regex: /^🏗️ (.+)建造中（进度(\d+)%，(\d+)人）$/, replace: (m) => `🏗️ ${t('bubble.building', { name: m[1], pct: m[2], workers: m[3] })}` },
        { regex: /^🏗️ (.+)已建成！$/, replace: (m) => `🏗️ ${t('bubble.built_done', { name: m[1] })}` },
        { regex: /^🏗️ 准备建造(.+)…$/, replace: (m) => `🏗️ ${t('bubble.preparing_build', { name: m[1] })}` },
        { regex: /^🔧 (.+)维修中（进度(\d+)%）$/, replace: (m) => `🔧 ${t('bubble.repairing', { name: m[1], pct: m[2] })}` },
        { regex: /^🔧 (.+)运行正常！$/, replace: (m) => `🔧 ${t('bubble.running_ok', { name: m[1] })}` },
        { regex: /^🔧 检查(.+)状态…$/, replace: (m) => `🔧 ${t('bubble.checking', { name: m[1] })}` },
        { regex: /^🔨 暖炉扩建中（进度(\d+)%）$/, replace: (m) => `🔨 ${t('bubble.furnace_building', { pct: m[1] })}` },
        { regex: /^🔨 暖炉已建成！$/, replace: () => `🔨 ${t('bubble.furnace_built')}` },
        { regex: /^🔨 暖炉扩建设计中$/, replace: () => `🔨 ${t('bubble.furnace_designing')}` },
        { regex: /^💬 安抚鼓舞中（San\+(.+?)\/h）\n\s+→ 安抚对象: (.+)$/, replace: (m) => `💬 ${t('bubble.morale_boost', { rate: m[1], targets: translateNpcNamesInText(m[2]) })}` },
        { regex: /^💬 安抚鼓舞待命中/, replace: () => `💬 ${t('bubble.morale_standby')}` },
        { regex: /^🛋️ 自我休整中/, replace: () => `🛋️ ${t('bubble.self_rest')}` },
        { regex: /^🏥 出诊中/, replace: () => `🏥 ${t('bubble.house_call_heading')}` },
        { regex: /^🏥 准备出诊/, replace: () => `🏥 ${t('bubble.house_call_preparing')}` },
        { regex: /^🏥 医疗待命中/, replace: () => `🏥 ${t('bubble.medical_standby')}` },
        { regex: /^🏥 出诊治疗中/, replace: () => `🏥 ${t('bubble.house_call_treating')}` },
        { regex: /^🔍 探索废墟中…（今日剩(\d+)次）$/, replace: (m) => `🔍 ${t('bubble.exploring_ruins', { remaining: m[1] })}` },
        { regex: /^🔍 废墟已搜刮干净$/, replace: () => `🔍 ${t('bubble.ruins_depleted')}` },
        { regex: /^🛡️ 巡逻警戒中（全队San恢复\+10%, 同伴San\+([\d.]+)\/h）$/, replace: (m) => t('bubble.patrol_with_companion', { rate: m[1] }) },
        { regex: /^🛡️ 巡逻警戒中（全队San恢复\+10%）$/, replace: () => t('bubble.patrol_solo') },
    ];

    /** 辅助：翻译地点名称（从中文地点名到i18n） */
    function _translateLocation(locCN) {
        if (!locCN) return locCN;
        const locMap = {
            '仓库': 'location.warehouse', '医疗站': 'location.medical',
            '宿舍A': 'location.dorm_a', '宿舍B': 'location.dorm_b',
            '炊事房': 'location.kitchen', '工坊': 'location.workshop',
            '据点': 'location.village', '采集区': 'location.village',
            '末日据点': 'location.village', '营地': 'location.village',
            '仓库门口': 'location.warehouse_door', '医疗站门口': 'location.medical_door',
            '炊事房门口': 'location.kitchen_door', '工坊门口': 'location.workshop_door',
            '宿舍A门口': 'location.dorm_a_door', '宿舍B门口': 'location.dorm_b_door',
            '暖炉广场': 'location.furnace_plaza', '冰湖': 'location.frozen_lake',
            '伐木场': 'location.lumber_camp', '废墟': 'location.ruins_site',
            '废墟探索点': 'location.ruins_site', '废墟采集场': 'location.ruins_site',
            '矿渣堆': 'location.ore_pile', '指挥所': 'location.command',
        };
        const key = locMap[locCN];
        if (key) {
            const result = t(key);
            return result !== key ? result : locCN;
        }
        // 回退1：尝试在 stateDesc 映射表中查找（如 "安抚" → "Comforting"）
        const descKey = _stateDescKeyMap[locCN];
        if (descKey) {
            const result = t(descKey);
            return result !== descKey ? result : locCN;
        }
        // 回退2：尝试翻译NPC名字（"前往XXX身边"中的名字）
        return translateNpcNamesInText(locCN);
    }

    /**
     * 翻译 NPC 状态描述（stateDesc）
     * 在显示层统一调用，不修改数据源
     * @param {string} text - 中文状态描述
     * @returns {string} 翻译后的文本
     */
    function translateStateDesc(text) {
        if (!text || _currentLang === 'zh') return text;
        // 1. 精确匹配
        const exactKey = _stateDescKeyMap[text];
        if (exactKey) return t(exactKey);
        // 2. 去掉emoji前缀后再精确匹配
        const stripped = text.replace(/^[\s🪓🎣🔍🔧📦🏥💊💬🛋️🔨🏗️⚠️⛏️🚶]+\s*/, '').trim();
        const strippedKey = _stateDescKeyMap[stripped];
        if (strippedKey) return t(strippedKey);
        // 3. 模式匹配
        for (const pattern of _stateDescPatterns) {
            const m = text.match(pattern.regex);
            if (m) return pattern.replace(m);
        }
        // 4. 翻译NPC名字
        return translateNpcNamesInText(text);
    }

    /**
     * 翻译气泡文本（dynamicBubble / workBubble）
     * @param {string} text - 中文气泡文本
     * @returns {string} 翻译后的文本
     */
    function translateBubble(text) {
        if (!text || _currentLang === 'zh') return text;
        for (const pattern of _bubblePatterns) {
            const m = text.match(pattern.regex);
            if (m) {
                const result = pattern.replace(m);
                if (result !== null) return result;
                // null 表示保持原样但仍需翻译NPC名字
                return translateNpcNamesInText(text);
            }
        }
        // 回退：尝试翻译NPC名字
        return translateNpcNamesInText(text);
    }

    /**
     * 批量替换文本中的 NPC 中文名为翻译后的名字
     * 用于事件日志等包含 NPC 名字的文本
     * @param {string} text - 原始文本
     * @returns {string} 替换后的文本
     */
    function translateNpcNamesInText(text) {
        if (!text || _currentLang === 'zh') return text;
        let result = text;
        for (const [cn, key] of Object.entries(_npcNameKeyMap)) {
            if (result.includes(cn)) {
                result = result.split(cn).join(t(key));
            }
        }
        return result;
    }

    /**
     * 【v5.9】将整个 LLM prompt 从中文翻译为英文
     * 用于英文模式下，让小模型在全英文上下文中工作
     * 采用批量关键词替换策略，覆盖 prompt 中所有中文标签和固定短语
     */
    const _promptTranslationMap = [
        // === prompt 结构标签 ===
        ['【生存状况】', '[Survival Status]'],
        ['【户外风险数据】', '[Outdoor Risk Data]'],
        ['【当前行动】', '[Current Action]'],
        ['【待执行行动】', '[Pending Action]'],
        ['【同伴模式】', '[Companion Mode]'],
        ['【最近行动决策】', '[Recent Decision]'],
        ['【状态】', '[Status]'],
        ['【当前外部任务】', '[Current External Task]'],
        ['【系统任务情报】', '[System Task Intel]'],
        ['【投票决策分工】', '[Council Vote Assignment]'],
        ['【紧急状态提醒】', '[Emergency Alert]'],
        ['【自身生存危机情报】', '[Personal Survival Crisis]'],
        ['【你的状态】', '[Your Status]'],
        ['【你的目标】', '[Your Goals]'],
        ['【你的属性】', '[Your Attributes]'],
        ['【当前日程（仅供参考，你完全可以自主决定做什么）】', '[Current Schedule (reference only, you decide freely)]'],
        ['【最近想法】', '[Recent Thoughts]'],
        ['【最近记忆】', '[Recent Memories]'],
        ['【全镇NPC状态】', '[All NPC Status]'],
        ['【前世·你的个人记忆】', '[Past Life · Your Personal Memory]'],
        ['【前世教训·与你相关】', '[Past Life Lessons · Related to You]'],
        ['【睡眠恢复数据】', '[Sleep Recovery Data]'],
        ['【当前状态提示】', '[Current Status Hint]'],
        ['前世记忆', 'past life memory'],
        ['已轮回', 'reincarnated'],
        ['首次轮回重生', 'first reincarnation rebirth'],
        // === 角色信息 ===
        ['角色信息：', 'Character Info:'],
        ['姓名：', 'Name: '],
        ['性格：', 'Personality: '],
        ['当前心情：', 'Current Mood: '],
        ['你当前的身心状态：', 'Your current physical/mental state:'],
        // === 决策规则 ===
        ['决策规则：', 'Decision Rules:'],
        ['可选目标位置：', 'Available Target Locations:'],
        ['行动类型说明：', 'Action Types:'],
        ['重要规则：', 'Important Rules:'],
        // === 状态描述 ===
        ['体力：', 'Stamina: '],
        ['健康：', 'Health: '],
        ['精神：', 'Sanity: '],
        ['饱食：', 'Hunger: '],
        ['饱食度：', 'Hunger: '],
        ['体温：', 'Body Temp: '],
        ['存款：', 'Savings: '],
        ['当前位置：', 'Location: '],
        ['状态摘要：', 'Status Summary: '],
        ['当前状态：', 'Current State: '],
        ['当前状态摘要：', 'Current Status Summary: '],
        // === 资源 ===
        ['资源:', 'Resources:'],
        ['资源: ', 'Resources: '],
        ['资源状况:', 'Resource Status:'],
        ['资源状况: ', 'Resource Status: '],
        ['资源紧张度:', 'Resource Tension:'],
        ['资源紧张度: ', 'Resource Tension: '],
        ['（高度紧张）', '(Critical)'],
        ['（偏紧）', '(Tight)'],
        ['（正常）', '(Normal)'],
        ['你的任务:', 'Your Tasks:'],
        ['你的任务: ', 'Your Tasks: '],
        ['任务进度:', 'Task Progress:'],
        ['任务进度: ', 'Task Progress: '],
        ['暖炉状况:', 'Furnace Status:'],
        ['暖炉状况: ', 'Furnace Status: '],
        ['死亡情况:', 'Death Report:'],
        ['死亡情况: ', 'Death Report: '],
        // === 天气/时间 ===
        ['当前时间：', 'Current Time: '],
        ['时间：', 'Time: '],
        ['天气：', 'Weather: '],
        ['温度：', 'Temperature: '],
        ['位置：', 'Location: '],
        ['附近的人：', 'Nearby People: '],
        ['最近发生的事：', 'Recent Events:'],
        // === 紧急提示 ===
        ['🚨 你正在失温！体温:', '🚨 You are hypothermic! Body Temp:'],
        ['🥶 你浑身发抖，行动迟缓，思维模糊...', '🥶 You are shivering, sluggish, mind foggy...'],
        ['🚨极低！', '🚨Critical!'],
        ['🚨危险！', '🚨Danger!'],
        ['🚨极度危险！可能随时发疯！', '🚨Extreme danger! May go insane any moment!'],
        ['⚠️警告！', '⚠️Warning!'],
        ['🚨很饿！', '🚨Very hungry!'],
        ['🚨失温！', '🚨Hypothermic!'],
        ['🧊严重失温！', '🧊Severe hypothermia!'],
        ['🤒生病中', '🤒Sick'],
        ['⚠️ 你正处于悲痛状态（效率降低）', '⚠️ You are grieving (reduced efficiency)'],
        ['⚠️ 你正处于悲痛状态，因为有同伴刚刚死去。', '⚠️ You are grieving because a companion just died.'],
        // === 行动相关 ===
        ['go_to: 前往某地（必须指定target，到达后根据地点自动触发对应效果：采集资源/工作/社交等）', 'go_to: Go to a location (must specify target, triggers corresponding effect on arrival: gather/work/socialize)'],
        ['rest: 回家休息/睡觉（体力低/天黑时选择）', 'rest: Go home to rest/sleep (when stamina low or nighttime)'],
        ['eat: 去炊事房吃饭（饥饿时选择，target选kitchen_door）', 'eat: Go to kitchen to eat (when hungry, target=kitchen_door)'],
        // === 优先级 ===
        ['urgent=你判断为生存紧急', 'urgent=survival emergency'],
        ['normal=准备立即执行', 'normal=ready to execute now'],
        ['low=仅记录意向', 'low=just noting intention'],
        ['优先级', 'priority'],
        // === 时间段 ===
        ['白天时间', 'Daytime'],
        ['现在是深夜了，你的体力消耗会加快。', 'It is late night, your stamina drains faster.'],
        ['精神状态不佳时，休息或社交能恢复精神。', 'When sanity is low, resting or socializing can help recover.'],
        // === 暴风雪 ===
        ['当前为暴风雪前的相对平静期，户外活动风险较低。', 'Currently in a calm period before the blizzard, outdoor risk is low.'],
        ['今天-60°C极寒暴风雪！户外极度危险，出门会快速失温掉血。', 'Today -60°C extreme blizzard! Outdoors is extremely dangerous, rapid hypothermia and HP loss.'],
        ['是否冒险外出、外出多久、值不值得冒险，都由你根据目标和代价自行判断。', 'Whether to risk going out, how long, and if it is worth it, is entirely your judgment.'],
        ['是否冒险外出，由你结合当前局势自行权衡。', 'Whether to risk going out is your own judgment based on the situation.'],
        ['今天-30°C大雪天！', 'Today -30°C heavy snow!'],
        ['户外工作代价：', 'Outdoor work cost: '],
        ['户外极度危险！温度', 'Outdoors extremely dangerous! Temperature '],
        ['请把这个风险纳入你的自主判断。', 'Factor this risk into your judgment.'],
        // === 通用动词/短语 ===
        ['你是', 'You are '],
        ['的行动决策AI。世界末日来临，极端寒冷天气侵袭小镇。你需要根据角色的当前状态、生存环境和人际关系，决定角色下一步做什么。', "'s action decision AI. The apocalypse has come, extreme cold weather strikes the town. Decide the character's next action based on current status, survival environment, and relationships."],
        ['的居民。世界末日来临，极端寒冷天气侵袭小镇，你们必须团结协作、收集物资、维持暖炉运转才能存活。', "'s resident. The apocalypse has come, extreme cold strikes the town. You must cooperate, gather supplies, and keep the furnace running to survive."],
        ['请决定你的下一步行动。以', 'Decide your next action. Think from '],
        ['的第一人称视角思考，用你的性格和口吻来表达。用纯JSON回复：', "'s first-person perspective, express in your personality and tone. Reply in pure JSON:"],
        ['请根据上面的实际情境，决定你现在的状态。', 'Based on the above situation, decide your current state.'],
        ['用纯 JSON 回复：', 'Reply in pure JSON:'],
        ['用纯JSON回复：', 'Reply in pure JSON:'],
        ['（暂无）', '(none)'],
        ['（用第一人称、角色口吻说出最担心的事）', '(express your biggest worry in first person, in character)'],
        ['（用角色口吻说出看到的希望）', '(express the hope you see, in character)'],
        ['（一句话内心独白，要有角色性格特色）', '(one-line inner monologue, show character personality)'],
        ['目标位置key（从可选列表选，type为rest时可省略）', 'target location key (from available list, optional for rest)'],
        ['行动原因（简短自然的口语化表达）', 'action reason (brief, natural, colloquial)'],
        ['内心独白（基于真实环境的想法', 'inner monologue (thoughts based on real environment'],
        ['优先体现你当前最担忧的属性、风险或最想推进的目标', 'prioritize your most worried attribute, risk, or goal'],
        ['如前世记忆相关，可自然引用，但不强制）', 'may reference past life memory naturally, not forced)'],
        ['两字心情（符合当前处境）', 'two-word mood (matching current situation)'],
        ['说出的话（简短，或空字符串）', 'spoken words (brief, or empty string)'],
        ['同场景的人名（可以走过去找他，或空字符串）', 'name of person in same scene (can walk to them, or empty string)'],
        ['当前最担忧的事', 'current biggest worry'],
        ['当前最想推进的目标名称', 'current goal to focus on'],
        ['没有就写', 'if none write '],
        // === JSON字段中文注释 ===
        ['"threat_analysis": "', '"threat_analysis": "'],
        ['"opportunity_analysis": "', '"opportunity_analysis": "'],
        ['"reasoning": "', '"reasoning": "'],
        // === 决策规则内容 ===
        ['你的首要目标是在末日中存活。其次是帮助同伴存活。', 'Your primary goal is to survive the apocalypse. Secondary is helping companions survive.'],
        ['这是一个末日生存环境。你的首要目标是活下去，其次是帮助同伴活下去。', 'This is an apocalyptic survival environment. Your primary goal is to survive, secondary is helping companions.'],
        ['上方的工作安排表、任务信息、投票结果和轮回记忆都属于情报，不是强制命令。你要结合当前资源、天气、身心状态、人际关系和现场局势自主判断。', 'The work schedule, task info, vote results, and reincarnation memories above are intelligence, not mandatory orders. Make your own judgment based on resources, weather, physical/mental state, relationships, and situation.'],
        ['当体力、健康、体温、精神或饱食处于危险区间时，请把自救与生存风险放进你的权衡，但具体怎么做由你决定。', 'When stamina, health, body temp, sanity, or hunger are in danger zones, factor self-rescue and survival risk into your decisions, but how to act is up to you.'],
        ['如果有同伴倒下（严重失温/昏厥），你可以结合关系、距离、风险和团队局势判断是否救援。', 'If a companion collapses (severe hypothermia/faint), you may judge whether to rescue based on relationship, distance, risk, and team situation.'],
        ['你是一个有自主意志的角色。', 'You are a character with free will.'],
        ['物资充足时，你可以选择休息恢复精神、和朋友聊天、探索废墟，或者待在室内；物资紧张时，你也可以主动承担采集或支援工作。', 'When supplies are sufficient, you can rest, chat with friends, explore ruins, or stay indoors; when supplies are tight, you can proactively take on gathering or support work.'],
        ['go_to是你最重要的行动——想砍柴就go_to伐木场，想发电就go_to工坊，想找人聊天就go_to那个人的位置。到达目的地后会自动触发对应效果（采集/工作/社交等）。', 'go_to is your most important action—want to chop wood, go_to lumber yard; want to generate power, go_to workshop; want to chat, go_to that person\'s location. Effects trigger automatically on arrival.'],
        ['回宿舍睡觉可以同时恢复：', 'Sleeping in dorm recovers: '],
        ['睡觉是最高效的多属性同时恢复方式。', 'Sleep is the most efficient way to recover multiple attributes simultaneously.'],
        ['下雨/大雪/暴风雪会显著提高户外风险，请把天气代价纳入判断。', 'Rain/snow/blizzard significantly increases outdoor risk, factor weather cost into judgment.'],
        ['你的角色专长：', 'Your specialty: '],
        ['擅长的工作通常效率更高，但是否优先做，仍由你根据局势决定。', 'Specialized work is usually more efficient, but whether to prioritize it is your call based on the situation.'],
        ['这是第一世，你没有任何前世记忆，专注于当前的末日生存处境。', 'This is your first life, you have no past life memories. Focus on the current apocalyptic survival situation.'],
        ['提示：想找人聊天/陪伴某人？直接go_to到那个人所在的位置，到达后自然会触发对话。想工作？go_to到对应的工作地点即可。', 'Tip: Want to chat/accompany someone? Just go_to their location, dialogue triggers on arrival. Want to work? go_to the corresponding workplace.'],
        ['完成目标可以获得属性奖励（包括San值、魅力等），请主动朝目标努力！', 'Completing goals earns attribute bonuses (including Sanity, Charisma, etc.), actively work toward goals!'],
        // === think prompt 特有 ===
        ['你的情绪和言行应与当前生存环境一致。', 'Your emotions and behavior should match the current survival environment.'],
        ['如果资源紧缺，你大概率会焦虑；如果有人死了，你可能会悲痛或恐惧。', 'If resources are scarce, you\'ll likely be anxious; if someone died, you may grieve or fear.'],
        ['expression是你真正说出口的话，通常会围绕你此刻最在意的现实问题。', 'expression is what you actually say aloud, usually about your most pressing real concern.'],
        ['上方有工作安排表和任务信息，它们都是情报，不是强制命令。你可以结合资源、天气、身心状态和人际关系，自主判断是否执行、调整或暂缓。', 'The work schedule and task info above are intelligence, not mandatory orders. Judge for yourself whether to execute, adjust, or delay based on resources, weather, and condition.'],
        ['你的思考和行为应受到你当前身心状态和生存压力的影响。', 'Your thoughts and behavior should be influenced by your current physical/mental state and survival pressure.'],
        ['如果温度极低（<-20°C），你在户外通常会非常痛苦和恐惧。', 'If temperature is extremely low (<-20°C), you\'ll usually be in great pain and fear outdoors.'],
        ['如果你看到有人倒下或状态很差，你可以根据关系、处境和风险判断是否帮助他们。', 'If you see someone collapse or in bad shape, judge whether to help based on relationship, situation, and risk.'],
        ['mood（心情）应与当前真实环境匹配（周围没人时一般不会因社交而高兴）', 'mood should match the real environment (usually won\'t be happy about socializing when alone)'],
        ['expression只有在合适的时候才说话（周围没人时可以自言自语或留空）', 'expression: only speak when appropriate (can talk to yourself or leave empty when alone)'],
        ['wantChat可以填写附近或同一区域的人名（你可以走过去找他们），没人时留空字符串', 'wantChat: fill in name of nearby person (you can walk to them), empty string if no one'],
        // === 饥饿/健康/体力危机 ===
        ['我正在去吃饭的路上或正在吃饭。', 'I am on my way to eat or currently eating.'],
        ['我正在去吃饭/正在吃饭中。', 'I am on my way to eat or currently eating.'],
        ['这是当前局势中的一条重要情报，请结合实际状况自行判断是否继续。', 'This is important intel about the current situation, judge for yourself whether to continue.'],
        ['这是当前局势中的一条情报，请结合实际状况自行判断。', 'This is intel about the current situation, judge for yourself.'],
        ['全体成员刚开过紧急决策会议，投票建议我执行：', 'The team just held an emergency council meeting, the vote suggests I execute: '],
        ['这是重要团队共识，但最终行动仍需我结合现实状况权衡。', 'This is important team consensus, but final action still requires my own judgment.'],
        ['这是一条重要团队情报，但最终如何行动仍由我结合现实状况判断。', 'This is important team intel, but how to act is still my judgment.'],
        ['我正在紧急处理：', 'I am urgently handling: '],
        ['这会显著影响我此刻的判断', 'this significantly affects my current judgment'],
        ['当前P0紧急状态：', 'Current P0 emergency: '],
        ['我快饿死了！饱食度只有', 'I am starving! Hunger only '],
        ['随时可能饿死！', 'Could starve any moment!'],
        ['再不进食你很快就会饿死！', 'You will starve soon if you don\'t eat!'],
        ['你自己正处于饿死的边缘！', 'You are on the verge of starvation!'],
        ['炊事房(kitchen_door)有食物可以吃。', 'Kitchen (kitchen_door) has food available.'],
        ['但全镇食物已经耗尽，没有食物可吃。', 'But the town\'s food supply is depleted, no food available.'],
        ['我快死了！健康值只有', 'I am dying! Health only '],
        ['已接近死亡边缘。宿舍可以休息恢复，医疗站有治疗条件。', 'Near death. Dorm can rest to recover, medical station has treatment.'],
        ['我体力耗尽了！体力只有', 'I am exhausted! Stamina only '],
        ['随时可能因体力耗尽而倒下。', 'Could collapse from exhaustion any moment.'],
        ['你的饱食度只有', 'Your hunger is only '],
        ['你随时可能因饥饿而死亡！', 'You could die of hunger any moment!'],
        ['再不进食你很快就会饿死！', 'You will starve soon if you don\'t eat!'],
        ['你的健康值只有', 'Your health is only '],
        ['你的体力只有', 'Your stamina is only '],
        ['随时可能因体力耗尽而倒下。', 'Could collapse from exhaustion any moment.'],
        // === 以上是高风险情报 ===
        ['以上是高风险情报。可选应对方式包括但不限于：回宿舍休息(rest)、去医疗站就医(go_to medical_door)、就近找室内建筑避难，或其他你认为合适的行动。', 'Above is high-risk intel. Options include but not limited to: rest in dorm (rest), go to medical station (go_to medical_door), find nearby indoor shelter, or other actions you deem appropriate.'],
        // === 正在跟随 ===
        ['正在跟随', 'Following '],
        ['一起行动', ' together'],
        // === NPC角色描述 ===
        ['你是退休镇长/精神领袖，在末日中承担起安抚情绪、调解冲突的重任。你的领导力和人生阅历是团队的精神支柱。清璇是你的孙女，你格外牵挂她。', 'You are the retired mayor/spiritual leader, taking on the role of calming emotions and mediating conflicts in the apocalypse. Your leadership and life experience are the team\'s spiritual pillar. Qing Xuan is your granddaughter, you worry about her deeply.'],
        ['你是16岁的药剂师学徒，老钱的孙女。负责制作草药制剂和急救包、协助医疗救治。你聪明好学、心灵手巧，在危机中逐渐展现超越年龄的能力。你暗恋陆辰。', 'You are a 16-year-old apothecary apprentice, Old Qian\'s granddaughter. Responsible for making herbal remedies and first aid kits, assisting medical treatment. Smart, studious, and dexterous, you gradually show abilities beyond your age in crisis. You have a secret crush on Lu Chen.'],
        ['你是技师/规划师，末日前是哲学教师，现在负责维修发电机、设计暖炉扩建方案、统筹全队效率。你暗恋歆玥，理性冷静但有时过于冷酷。', 'You are a technician/planner, a philosophy teacher before the apocalypse, now responsible for repairing generators, designing furnace expansion plans, and coordinating team efficiency. You have a secret crush on Ling Yue, rational and calm but sometimes too cold.'],
        ['你是伐木工/锅炉工，全镇体力担当。负责砍柴、搬运、暖炉维护。你沉默寡言但行动力极强，暗恋李婶。压力大时San值下降更快。', 'You are a lumberjack/boiler worker, the town\'s physical powerhouse. Responsible for chopping wood, hauling, and furnace maintenance. Silent but extremely action-oriented, you have a secret crush on Aunt Li. Your sanity drops faster under pressure.'],
        ['你是物资总管/炊事长，全镇后勤管家。负责管理仓库、烹饪分配食物。你热心精明，照顾所有人。陆辰是你儿子，你会不惜一切保护他。', 'You are the supply manager/head cook, the town\'s logistics steward. Responsible for managing the warehouse, cooking, and distributing food. Warm-hearted and shrewd, you take care of everyone. Lu Chen is your son, you will protect him at all costs.'],
        ['你是医官，据点唯一的医疗力量。负责治疗冻伤失温、心理疏导。你暗恋歆玥，冷静专业但过度操劳时自己也会崩溃。', 'You are the medic, the base\'s only medical force. Responsible for treating frostbite, hypothermia, and psychological counseling. You have a secret crush on Ling Yue, calm and professional but may break down when overworked.'],
        ['你是采集工/建筑工，最年轻的劳动力。负责砍柴和采集食物、协助修复暖炉。你冲动勇敢但情商低，暗恋清璇。体温下降速度比常人慢。', 'You are a gatherer/builder, the youngest laborer. Responsible for chopping wood, gathering food, and helping repair the furnace. Impulsive and brave but low EQ, you have a secret crush on Qing Xuan. Your body temperature drops slower than others.'],
        ['你是侦察员/急救兵，负责废墟侦察搜索稀有物资、急救护理、鼓舞全队士气。被苏岩和王策同时追求。你乐观坚韧但初始San值较低。', 'You are a scout/medic, responsible for scouting ruins for rare supplies, first aid, and boosting team morale. Pursued by both Dr. Su and Wang Ce. Optimistic and resilient but starts with lower sanity.'],
        ['你的弱点：', 'Your weaknesses: '],
        ['你的保护对象：', 'Your protection target: '],
        ['如果ta受伤或死亡，你会受到双倍San打击。', 'If they are hurt or die, you take double sanity damage.'],
        // === 轮回相关 ===
        ['轮回记忆·参考情报', 'Reincarnation Memory · Reference Intel'],
        ['上方有前世记忆信息。你可以综合考虑，也可以在当前情境下完全不提；是否使用、如何使用，取决于你当下的自主判断。', 'Past life memory info is above. You may consider it or ignore it entirely; whether and how to use it is your own judgment.'],
        ['上方有前世记忆信息作为背景参考。是否在thought或expression中提及、以及如何使用这些记忆，都由你根据当前情境自行判断。', 'Past life memory info is above as background reference. Whether to mention in thought/expression and how to use these memories is your own judgment.'],
        // === 饥饿状态 ===
        ['极度饥饿', 'Extremely Hungry'],
        ['很饿', 'Very Hungry'],
        ['饥饿', 'Hungry'],
        ['微饿', 'Slightly Hungry'],
        ['正常', 'Normal'],
        ['饱足', 'Full'],
        // === 体力状态 ===
        ['精力充沛', 'Energetic'],
        ['体力充足', 'Good Stamina'],
        ['有些疲惫', 'Somewhat Tired'],
        ['疲惫', 'Tired'],
        ['非常疲惫', 'Very Tired'],
        ['精疲力竭', 'Exhausted'],
        // === 通用 ===
        ['岁', ' years old'],
        ['元', ' yuan'],
        ['天', 'Day '],
        ['你现在很饿。食堂有食物可以吃。', 'You are very hungry. The kitchen has food.'],
        ['正在发疯！', 'Going insane!'],
        ['状态非常差！', 'in very bad condition!'],
        ['某人', 'someone'],
        // === 体力消耗/小时 ===
        ['体力消耗约', 'stamina drain ~'],
        ['体温下降约', 'body temp drop ~'],
        ['你的体力', 'Your stamina '],
        ['预计可在户外安全工作约', 'estimated safe outdoor work time ~'],
        ['分钟', ' minutes'],
        ['这些数据供你自主判断是否值得出门。', 'Use this data to judge whether going out is worth it.'],
        ['连续户外超过2小时会严重冻伤。', 'Continuous outdoor exposure over 2 hours causes severe frostbite.'],
        ['短时间出门采集（1-1.5小时）后回室内恢复是可行的策略，但需要你自己权衡风险和收益。', 'Short outdoor gathering (1-1.5 hours) then returning indoors to recover is a viable strategy, but you need to weigh risk vs reward.'],
        ['小时', '/hour'],
        ['极短时间', 'very short time'],
        // === 紧急情报 ===
        ['紧急情报：你的好朋友', 'Urgent intel: your good friend '],
        ['挚友', 'best friend'],
        ['好友', 'good friend'],

        // ============================================================
        // === 子系统方法返回的动态中文（getSurvivalSummary 等） ===
        // ============================================================

        // --- getSurvivalSummary() ---
        ['【生存状态】', '[Survival Status] '],
        ['存活', 'Alive '],
        ['人', ' people'],

        // --- getResourceStatusForPrompt() ---
        ['木柴', 'Wood'],
        ['食物', 'Food'],
        ['电力', 'Power'],
        ['够烧', 'lasts '],
        ['够吃', 'lasts '],
        ['剩', 'left '],
        ['废墟探索(今日剩', 'Ruins exploration(today remaining '],
        ['废墟探索', 'Ruins exploration'],
        ['次)', ' times)'],
        ['⚠️危机:', '⚠️Crisis:'],
        ['无食物!', 'No food!'],
        ['无电力!', 'No power!'],
        ['无木柴!', 'No wood!'],
        ['餐)', ' meals)'],
        ['餐', ' meals'],

        // --- getHeatingSummary() ---
        ['供暖', 'Heating '],
        ['稳定', 'Stable'],
        ['偏弱', 'Weak'],
        ['紧张', 'Strained'],
        ['停摆', 'Failed'],

        // --- getBlizzardUrgencyForPrompt() ---
        ['【暴风雪预警】', '[Blizzard Warning] '],
        ['【暴风雪迫近】', '[Blizzard Approaching] '],
        ['【最后准备窗口！今晚24点暴风雪来袭！】', '[Last Preparation Window! Blizzard hits tonight at midnight!] '],
        ['【大极寒已降临！-60°C！】', '[Extreme Cold Has Arrived! -60°C!] '],
        ['今天是准备日（第1天），大极寒暴风雪将在第4天降临（-60°C！），距离暴风雪大约还有', 'Today is preparation day (Day 1), extreme blizzard arrives Day 4 (-60°C!), approximately '],
        ['小时。明天（第2天）降温到-30°C大雪，户外连续工作超过2小时会严重冻伤。', ' hours until blizzard. Tomorrow (Day 2) drops to -30°C heavy snow, continuous outdoor work over 2 hours causes severe frostbite.'],
        ['今天是第2天，-30°C大雪天！户外连续工作超过2小时会严重冻伤。距离第4天大极寒暴风雪（-60°C）还有约', 'Today is Day 2, -30°C heavy snow! Continuous outdoor work over 2 hours causes severe frostbite. Approximately '],
        ['小时。明天（第3天）气温会短暂回升到0°C。', ' hours until Day 4 extreme blizzard (-60°C). Tomorrow (Day 3) temperature briefly rises to 0°C.'],
        ['今天是第3天喘息日，气温短暂回升到0°C。今晚24点（约', 'Today is Day 3 respite day, temperature briefly rises to 0°C. Tonight at midnight (approximately '],
        ['小时后）进入第4天-60°C极寒暴风雪，届时户外极度危险，所有人只能待在室内靠木材、电力和储备物资活命。', ' hours) enters Day 4 -60°C extreme blizzard, outdoors will be extremely dangerous, everyone must stay indoors surviving on wood, power, and stored supplies.'],
        ['现在是第4天，极寒暴风雪正在肆虐！户外极度危险，出门会快速失温掉血。室内靠木材、电力和食物维持生存。坚持到今天日落（18:00）即可迎来救援。', 'Now is Day 4, extreme blizzard is raging! Outdoors is extremely dangerous, going out causes rapid hypothermia and HP loss. Survive indoors with wood, power, and food. Hold on until sunset today (18:00) for rescue.'],

        // --- _buildSurvivalChecklist() ---
        ['【物资检查】', '[Supply Check] '],
        ['单位（第4天至少需要', ' units (Day 4 needs at least '],
        ['单位）', ' units)'],
        ['✅够了', '✅Sufficient'],
        ['❌还差', '❌Short by '],
        ['单位！', ' units!'],
        ['✅稳定', '✅Stable'],
        ['❌偏弱，需继续补木材和电力', '❌Weak, need more wood and power'],

        // --- getUrgencyPrompt() ---
        ['🔴 木柴严重不足！仅够烧', '🔴 Wood critically low! Only lasts '],
        ['🟡 木柴储备偏低（', '🟡 Wood reserves low ('],
        ['单位，够烧', ' units, lasts '],
        ['🔴 食物不够下一顿饭！', '🔴 Not enough food for next meal!'],
        ['🟡 食物储备偏低（', '🟡 Food reserves low ('],
        ['单位，够吃', ' units, lasts '],
        ['🔴 电力即将耗尽！仅剩', '🔴 Power nearly depleted! Only '],
        ['小时！无电会导致暖炉耗柴+30%、医疗停摆、夜间恐惧加倍！', ' hours left! No power causes furnace wood consumption +30%, medical shutdown, nighttime fear doubled!'],
        ['🟡 电力储备偏低（', '🟡 Power reserves low ('],
        ['单位，剩余', ' units, remaining '],
        ['最紧急的资源是', 'Most urgent resource is '],
        ['，仅剩约', ', only about '],
        ['小时可用', ' hours remaining'],

        // --- getResourceForecastForPrompt() ---
        ['【物资需求总览】', '[Supply Demand Overview]'],
        ['准备日', 'Preparation Day'],
        ['寒冷天', 'Cold Day'],
        ['喘息日', 'Respite Day'],
        ['大极寒', 'Extreme Cold'],
        ['今天(Day', 'Today(Day'],
        [')剩余', ') remaining'],
        ['总计还需:', 'Total needed:'],
        ['总计还需: ', 'Total needed: '],
        ['当前库存:', 'Current stock:'],
        ['当前库存: ', 'Current stock: '],
        ['缺口:', 'Gap:'],
        ['缺口: ', 'Gap: '],
        ['暖炉消耗×', 'furnace consumption ×'],
        ['电力×', 'power ×'],

        // --- getSupplyRecommendationPrompt() ---
        ['【补给情报】当前各项物资储备充足，无明显缺口。', '[Supply Intel] All resource reserves are sufficient, no significant gaps.'],
        ['【补给情报·专长匹配】', '[Supply Intel · Skill Matching]'],
        ['【补给情报】', '[Supply Intel] '],
        ['缺口', 'Gap '],
        ['单位（', ' units ('],
        ['当前够烧', 'currently lasts '],
        ['当前够吃', 'currently lasts '],
        ['当前仅剩', 'currently only '],
        ['极度短缺', 'Extremely Scarce'],
        ['短缺', 'Scarce'],
        ['高效采集者：', 'Efficient gatherers: '],
        ['效率×', 'efficiency ×'],
        ['体力不支', 'exhausted'],

        // --- getResourceSituationBrief() ---
        ['【当前态势】', '[Current Situation] '],
        ['物资充足', 'Supplies sufficient'],
        ['物资正常', 'Supplies normal'],
        ['物资偏紧', 'Supplies tight'],
        ['物资紧张！', 'Supplies critical!'],
        ['发电机和伐木机都在自动运转。', 'Generator and lumber mill are both running automatically.'],
        ['发电机在自动运转。', 'Generator is running automatically.'],
        ['伐木机在自动运转。', 'Lumber mill is running automatically.'],
        ['供暖稳定。', 'Heating is stable.'],
        ['当前不需要紧急采集。你可以自由安排时间——休息恢复精力、找人聊天社交、探索废墟、或者做任何你觉得有意义的事。', 'No urgent gathering needed. You can freely arrange your time—rest to recover, chat with friends, explore ruins, or do anything you find meaningful.'],
        ['资源储备尚可，但仍需适当补充。你可以根据自己的状态和判断来安排时间。', 'Resource reserves are okay but still need replenishment. You can arrange your time based on your condition and judgment.'],
        ['部分资源储备不太够，需要关注。', 'Some resource reserves are insufficient, need attention.'],
        ['⚠️食物即将耗尽！', '⚠️Food nearly depleted!'],
        ['⚠️电力即将耗尽！', '⚠️Power nearly depleted!'],
        ['⚠️木柴即将耗尽！', '⚠️Wood nearly depleted!'],
        ['精神状态不佳的人较多', 'Many people have low sanity'],
        ['有人生病', 'Someone is sick'],

        // --- getHungerStatus() 补充 ---
        ['有点饿', 'Slightly Hungry'],
        ['饥肠辘辘', 'Starving'],

        // --- 通用资源/状态词汇 ---
        ['关系:', 'Relationship:'],
        ['关系：', 'Relationship: '],
        ['一般', 'Normal'],
        ['在', 'at '],
        ['第', 'Day '],
    ];

    function translatePromptToEn(text) {
        if (!text || _currentLang === 'zh') return text;
        let result = text;
        // 先翻译NPC名字
        result = translateNpcNamesInText(result);
        // 再翻译所有中文标签和短语
        for (const [cn, en] of _promptTranslationMap) {
            if (result.includes(cn)) {
                result = result.split(cn).join(en);
            }
        }
        return result;
    }

    // 挂载到 GST
    GST.i18n = {
        registerPack,
        t,
        setLang,
        getLang,
        isEn,
        restoreLang,
        translateNpcName,
        translateWeather,
        translateTaskLabel,
        translateOccupation,
        translateFurnaceLevel,
        translateDeathCause,
        translateTimePeriod,
        translateNpcNamesInText,
        translatePromptToEn,
        translateStateDesc,
        translateBubble,
    };

    // 快捷方式
    GST.t = t;

    console.log('[i18n] i18n-core.js 已加载');
})();
