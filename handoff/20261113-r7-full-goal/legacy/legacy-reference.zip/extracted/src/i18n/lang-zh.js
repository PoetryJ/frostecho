/**
 * 福音镇 i18n - ZH 主入口
 * 此文件已拆分为子模块，由 index.html 按顺序加载：
 *   - zh/ui.js
 *   - zh/npc.js
 *   - zh/game.js
 *   - zh/mapping.js
 *   - zh/panel.js
 *
 * 注意：此文件现在只是一个空壳，实际翻译在子模块中
 */
(function() {
    'use strict';
    console.log('[i18n] zh language pack loaded (modular)');
})();
