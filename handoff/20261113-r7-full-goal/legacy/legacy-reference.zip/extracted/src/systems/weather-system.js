/**
 * 福音镇 - WeatherSystem
 * 挂载到 GST.WeatherSystem
 */
(function() {
    'use strict';
    const GST = window.GST;

/**
 * 天气系统 - 世界末日极寒生存
 * 管理4天温度周期、天气状态、户外寒冷伤害
 * 依赖: game.js
 */

// ============ 四天温度与天气配置 ============
const DAY_CONFIG = [
    // Day 1: 准备日
    {
        day: 1,
        baseTemp: 0,
        weather: '阴天',
        weatherEmoji: '☁️',
        desc: '准备日 — 收集物资、修整设备',
        outdoorTimeLimit: Infinity, // 无限制
        canGoOutside: true,
        nightTempDrop: -5,
        announcement: 'weather.announce_day1',
    },
    // Day 2: 寒冷天
    {
        day: 2,
        baseTemp: -30,
        weather: '大雪',
        weatherEmoji: '🌨️',
        desc: '寒冷天 — 户外活动严格限制2小时',
        outdoorTimeLimit: 2 * 3600, // 2小时（游戏秒）
        canGoOutside: true,
        nightTempDrop: -5,
        announcement: 'weather.announce_day2',
    },
    // Day 3: 喘息日
    {
        day: 3,
        baseTemp: 0,
        weather: '多云',
        weatherEmoji: '⛅',
        desc: '喘息日 — 补充物资、加固集中供暖保障',
        outdoorTimeLimit: Infinity,
        canGoOutside: true,
        nightTempDrop: -5,
        announcement: 'weather.announce_day3',
    },
    // Day 4: 大极寒
    {
        day: 4,
        baseTemp: -60,
        weather: '极寒暴风雪',
        weatherEmoji: '🥶',
        desc: '大极寒 — 户外极度危险！尽量待在室内',
        outdoorTimeLimit: 600, // 10分钟（游戏秒）极限，超过会快速冻伤
        canGoOutside: true, // 【v4.19】允许外出但极度危险，NPC自主判断
        nightTempDrop: -10,
        announcement: 'weather.announce_day4',
    },
];

class WeatherSystem {
    constructor(game) {
        this.game = game;
        this.currentDay = 1;
        this.currentTemp = 0;
        this.currentWeather = '阴天';
        this.weatherEmoji = '☁️';
        this.dayConfig = DAY_CONFIG[0];

        // 冬季白天时间: 6:00 ~ 16:00
        this.dawnHour = 6;
        this.duskHour = 16;

        // 户外NPC的累计户外时间追踪 { npcId: seconds }
        this.outdoorTime = {};

        // 雪花粒子系统
        this.snowParticles = [];
        this.maxSnowParticles = 0;
        this.windOffset = 0;

        // 暴风雪视觉效果
        this.blizzardAlpha = 0; // 白色遮罩透明度
        this.visibilityFactor = 1.0; // 能见度因子 0~1

        // 寒冷伤害tick间隔（每游戏秒执行一次）
        this._coldDamageTick = 0;
    }

    /** 获取当天配置 */
    getDayConfig(day) {
        const idx = Math.max(0, Math.min(day - 1, DAY_CONFIG.length - 1));
        return DAY_CONFIG[idx];
    }

    /** 当天数切换时调用 */
    onDayChange(newDay) {
        this.currentDay = newDay;
        this.dayConfig = this.getDayConfig(newDay);
        this.currentTemp = this.dayConfig.baseTemp;
        this.currentWeather = this.dayConfig.weather;
        this.weatherEmoji = this.dayConfig.weatherEmoji;

        // 【难度系统】应用温度偏移
        if (this.game && this.game.difficulty && this.game.difficulty.tempOffset) {
            this.currentTemp -= this.game.difficulty.tempOffset;
            console.log(`[WeatherSystem-难度] 温度偏移-${this.game.difficulty.tempOffset}°C, 实际基础温度: ${this.currentTemp}°C`);
        }

        // 【难度系统】户外时间限制缩减
        if (this.game && this.game.difficulty && this.game.difficulty.outdoorTimePenalty > 0) {
            const penalty = this.game.difficulty.outdoorTimePenalty;
            if (this.dayConfig.outdoorTimeLimit !== Infinity && this.dayConfig.outdoorTimeLimit > 0) {
                this.dayConfig = { ...this.dayConfig, outdoorTimeLimit: Math.max(600, this.dayConfig.outdoorTimeLimit - penalty) };
                console.log(`[WeatherSystem-难度] 户外时间限制缩减${penalty}秒, 实际限制: ${this.dayConfig.outdoorTimeLimit}秒`);
            }
        }

        // 【修复】同步到game.weather，确保全局一致
        if (this.game) {
            this.game.weather = this.currentWeather;
        }

        // 重置户外时间追踪
        this.outdoorTime = {};

        // 更新雪花粒子数量
        this._updateSnowConfig();

        // 弹出公告
        if (this.game.addEvent) {
            this.game.addEvent(GST.t(this.dayConfig.announcement));

            // 【物资消耗预警】在天气播报后追加物资预估
            if (this.game.resourceSystem && this.game.resourceSystem.getResourceForecastForPrompt) {
                const forecast = this.game.resourceSystem.getResourceForecastForPrompt();
                if (forecast) {
                    this.game.addEvent(GST.t('weather.forecast', { forecast: forecast.trim() }));
                }
            }

            // 补给窗口/极寒提示
            if (newDay === 1 || newDay === 3) {
                this.game.addEvent(GST.t('weather.supply_window'));
            } else if (newDay === 2 || newDay === 4) {
                this.game.addEvent(GST.t('weather.extreme_cold'));
            }
        }

        console.log(`[WeatherSystem] 第${newDay}天开始: ${this.currentTemp}°C, ${this.currentWeather}`);

        // 【v2.0】通知资源系统天气变化，刷新消耗乘数
        if (this.game.resourceSystem && this.game.resourceSystem.onWeatherChange) {
            this.game.resourceSystem.onWeatherChange(newDay);
        }

        // 【第3天喘息日恢复加成】
        if (newDay === 3) {
            this.game._day3RecoveryBoost = true;
            // 所有存活NPC的San值+15（士气回升）
            for (const npc of this.game.npcs) {
                if (npc.isDead) continue;
                npc.sanity = Math.min(100, npc.sanity + 15);
            }
            if (this.game.addEvent) {
                this.game.addEvent(GST.t('weather.day3_respite'));
            }
            // 健康<30的NPC自动安排休息任务
            if (this.game.taskSystem) {
                for (const npc of this.game.npcs) {
                    if (npc.isDead) continue;
                    if (npc.health < 30) {
                        if (this.game.addEvent) {
                        this.game.addEvent(GST.t('weather.day3_weak_npc', { name: npc.name, health: Math.round(npc.health) }));
                        }
                    }
                }
            }
            console.log(`[WeatherSystem] 第3天喘息日恢复加成已激活`);
        } else {
            this.game._day3RecoveryBoost = false;
        }
    }

    /** 根据当前小时计算实际温度（夜间额外降温 + 难度温度偏移） */
    getEffectiveTemp() {
        const hour = this.game.getHour();
        const isNight = hour < this.dawnHour || hour >= this.duskHour;
        // 【修复】currentTemp 在 onDayChange 中已经应用了 tempOffset，这里不再重复扣减
        // 旧代码会导致 tempOffset 被双重扣减，高难度下温度异常低，资源消耗严重偏高
        let temp = this.currentTemp + (isNight ? this.dayConfig.nightTempDrop : 0);
        return temp;
    }

    /** 是否为白天 */
    isDaytime() {
        const hour = this.game.getHour();
        return hour >= this.dawnHour && hour < this.duskHour;
    }

    /** 是否允许外出 */
    canGoOutside() {
        return this.dayConfig.canGoOutside;
    }

    /** NPC是否超时在户外 */
    isOutdoorTimeExceeded(npcId) {
        if (this.dayConfig.outdoorTimeLimit === Infinity) return false;
        if (this.dayConfig.outdoorTimeLimit === 0) return true;
        const time = this.outdoorTime[npcId] || 0;
        return time >= this.dayConfig.outdoorTimeLimit;
    }

    /** 获取NPC户外剩余时间（秒） */
    getOutdoorTimeRemaining(npcId) {
        if (this.dayConfig.outdoorTimeLimit === Infinity) return Infinity;
        const time = this.outdoorTime[npcId] || 0;
        return Math.max(0, this.dayConfig.outdoorTimeLimit - time);
    }

    /** 主更新循环 - 在game.update()中调用 */
    update(gameDt) {
        const temp = this.getEffectiveTemp();
        this.currentTemp = this.dayConfig.baseTemp; // 保持基础温度记录

        // 更新户外NPC的累计时间和施加寒冷伤害
        this._coldDamageTick += gameDt;
        if (this._coldDamageTick >= 1.0) { // 每游戏秒检查一次
            this._coldDamageTick -= 1.0;
            this._applyOutdoorEffects(temp, 1.0);
        }

        // 更新雪花粒子
        this._updateSnowParticles(gameDt);
    }

    /** 户外寒冷效果 */
    _applyOutdoorEffects(temp, dt) {
        // 【v2.1】风寒效应加成：大雪/暴风雪时属性衰减×1.3
        const windChillMult = (this.currentWeather === '大雪' || this.currentWeather === '极寒暴风雪') ? 1.3 : 1.0;
        // 【P0修复】dt=1.0是gameDt单位，需乘以timeSpeed转为游戏秒
        // outdoorTimeLimit阈值（7200/600等）是游戏秒，所以outdoorTime也必须用游戏秒累计
        const _outdoorGameSec = dt * (this.game.timeSpeed || 60);

        for (const npc of this.game.npcs) {
            if (npc.isDead) continue;

            const isOutdoor = npc.currentScene === 'village';

            if (isOutdoor) {
                // 累计户外时间（游戏秒）
                this.outdoorTime[npc.id] = (this.outdoorTime[npc.id] || 0) + _outdoorGameSec;

                // 【v5.8.14修复】体温下降已由 npc-body.js._updateBodyTemp() 统一管理
                // 此处移除重复的体温计算，避免双重降温导致角色过快失温

                // 【v2.1】梯度衰减层：温度<0°C时，越冷衰减越大
                // 【P0修复】梯度衰减是基础层，与Tier1/Tier2改为互斥（else if），避免三重叠加导致户外秒死
                if (temp < 0) {
                    const baseFactor = Math.abs(temp) / 30; // -30°C=1.0, -60°C=2.0
                    let gradStamina = 0.15 * baseFactor * dt;
                    let gradHealth = 0.10 * baseFactor * dt;
                    let gradSan = 0.08 * baseFactor * dt;
                    // 应用风寒加成
                    gradStamina *= windChillMult;
                    gradHealth *= windChillMult;
                    gradSan *= windChillMult;
                    npc.stamina = Math.max(0, npc.stamina - gradStamina);
                    npc.health = Math.max(0, npc.health - gradHealth);
                    npc.sanity = Math.max(0, npc.sanity - gradSan);
                }

                // 【v2.1】-20°C~0°C 轻度衰减（之前此区间无惩罚）
                if (temp < 0 && temp >= -20) {
                    let lightStamina = 0.05 * (Math.abs(temp) / 20) * dt;
                    lightStamina *= windChillMult;
                    npc.stamina = Math.max(0, npc.stamina - lightStamina);
                }

                // 【P0修复】Tier1和Tier2改为互斥（else if），避免叠加
                // 寒冷伤害 Tier 2: 温度 < -50°C (致命)
                if (temp < -50) {
                    let staminaDrain = 1.5 * dt;
                    let healthDrain = 1.2 * dt;
                    let sanDrain = 0.4 * dt;
                    staminaDrain *= windChillMult;
                    healthDrain *= windChillMult;
                    sanDrain *= windChillMult;
                    npc.stamina = Math.max(0, npc.stamina - staminaDrain);
                    npc.health = Math.max(0, npc.health - healthDrain);
                    npc.sanity = Math.max(0, npc.sanity - sanDrain);
                }
                // 寒冷伤害 Tier 1: -50°C ~ -20°C
                else if (temp < -20) {
                    let staminaDrain = 0.5 * dt;
                    let healthDrain = 0.35 * dt;
                    let sanDrain = 0.25 * dt;
                    staminaDrain *= windChillMult;
                    healthDrain *= windChillMult;
                    sanDrain *= windChillMult;
                    npc.stamina = Math.max(0, npc.stamina - staminaDrain);
                    npc.health = Math.max(0, npc.health - healthDrain);
                    npc.sanity = Math.max(0, npc.sanity - sanDrain);
                }

                // 第2天: 户外超过2小时严重冻伤
                if (this.currentDay === 2 && this.isOutdoorTimeExceeded(npc.id)) {
                    npc.stamina = Math.max(0, npc.stamina - 0.5 * dt);
                    npc.health = Math.max(0, npc.health - 0.3 * dt);
                }
            } else {
                // 室内时重置户外累计时间（休息恢复）
                if (this.outdoorTime[npc.id] > 0) {
                    this.outdoorTime[npc.id] = Math.max(0, (this.outdoorTime[npc.id] || 0) - _outdoorGameSec * 2);
                }

                // 室内寒冷惩罚：集中供暖越弱，室内越接近失温
                if (temp < -20) {
                    const hs = this.game.furnaceSystem;
                    const heatingStrength = hs && hs.getHeatingStrength ? hs.getHeatingStrength() : 0;
                    const indoorExposure = Math.max(0, 1 - heatingStrength);
                    if (indoorExposure > 0) {
                        npc.stamina = Math.max(0, npc.stamina - 0.03 * indoorExposure * dt);
                        npc.health = Math.max(0, npc.health - 0.02 * indoorExposure * dt);
                        npc.sanity = Math.max(0, npc.sanity - 0.01 * indoorExposure * dt);
                        // 【v4.34】室内寒冷来源追踪
                        if (npc._attrRateSources) {
                            const toPerHour = 3600;
                            const coldLabel = '🏠 室内偏冷(供暖' + Math.round(heatingStrength * 100) + '%)';
                            if (npc._attrRateSources.stamina) npc._attrRateSources.stamina.push({ label: coldLabel, rate: -(0.03 * indoorExposure * toPerHour).toFixed(1) });
                            if (npc._attrRateSources.health) npc._attrRateSources.health.push({ label: coldLabel, rate: -(0.02 * indoorExposure * toPerHour).toFixed(1) });
                            if (npc._attrRateSources.sanity) npc._attrRateSources.sanity.push({ label: coldLabel, rate: -(0.01 * indoorExposure * toPerHour).toFixed(1) });
                        }
                    }
                }
            }
        }
    }

    /** 更新雪花配置 */
    _updateSnowConfig() {
        const temp = this.dayConfig.baseTemp;
        if (this.currentWeather === '极寒暴风雪') {
            this.maxSnowParticles = 500;
            this.windOffset = 3;
            this.blizzardAlpha = 0.6;
            this.visibilityFactor = 0.15;
        } else if (this.currentWeather === '大雪') {
            this.maxSnowParticles = 300;
            this.windOffset = 1.5;
            this.blizzardAlpha = 0.2;
            this.visibilityFactor = 0.5;
        } else if (temp < -20) {
            this.maxSnowParticles = 200;
            this.windOffset = 1;
            this.blizzardAlpha = 0.15;
            this.visibilityFactor = 0.6;
        } else if (temp <= 0) {
            this.maxSnowParticles = 80;
            this.windOffset = 0.3;
            this.blizzardAlpha = 0;
            this.visibilityFactor = 1.0;
        } else {
            this.maxSnowParticles = 0;
            this.windOffset = 0;
            this.blizzardAlpha = 0;
            this.visibilityFactor = 1.0;
        }
    }

    /** 更新雪花粒子 */
    _updateSnowParticles(dt) {
        // 动态调整粒子数量
        while (this.snowParticles.length < this.maxSnowParticles) {
            this.snowParticles.push(this._createSnowParticle());
        }
        while (this.snowParticles.length > this.maxSnowParticles) {
            this.snowParticles.pop();
        }

        // 更新每个粒子
        const viewW = this.game.viewW;
        const viewH = this.game.viewH;
        for (const p of this.snowParticles) {
            p.y += p.speed * dt;
            p.x += (this.windOffset * 30 + p.wobble * Math.sin(p.phase)) * dt;
            p.phase += dt * 2;

            if (p.y > viewH + 10) {
                p.y = -10;
                p.x = Math.random() * viewW;
            }
            if (p.x > viewW + 10) p.x = -10;
            if (p.x < -10) p.x = viewW + 10;
        }
    }

    /** 创建单个雪花粒子 */
    _createSnowParticle() {
        const viewW = this.game.viewW || 640;
        const viewH = this.game.viewH || 480;
        return {
            x: Math.random() * viewW,
            y: Math.random() * viewH,
            size: 1 + Math.random() * 3,
            speed: 20 + Math.random() * 40,
            wobble: Math.random() * 10,
            phase: Math.random() * Math.PI * 2,
            opacity: 0.4 + Math.random() * 0.6,
        };
    }

    /** 渲染雪花和暴风雪效果（在draw()中调用） */
    drawSnow(ctx) {
        if (this.snowParticles.length === 0) return;

        // 绘制雪花粒子
        for (const p of this.snowParticles) {
            ctx.fillStyle = `rgba(255,255,255,${p.opacity})`;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        }

        // 暴风雪白色遮罩
        if (this.blizzardAlpha > 0) {
            ctx.fillStyle = `rgba(220,225,235,${this.blizzardAlpha})`;
            ctx.fillRect(0, 0, this.game.viewW, this.game.viewH);
        }
    }

    /** 昼夜遮罩覆盖 - 替代原有的昼夜系统 */
    drawDayNightOverlay(ctx) {
        const hour = this.game.getHour();
        let alpha = 0;
        let r = 10, g = 15, b = 40;

        // 冬季缩短白天 6:00 ~ 16:00
        if (hour >= 0 && hour < 5) {
            alpha = 0.6; r = 5; g = 10; b = 35;
        } else if (hour >= 5 && hour < 6) {
            const t = hour - 5;
            alpha = 0.6 * (1 - t) + 0.1 * t;
            r = 5; g = 10; b = 35;
        } else if (hour >= 6 && hour < 16) {
            // 冬季白天 - 比正常白天略暗
            alpha = 0.05;
            r = 180; g = 200; b = 220;
        } else if (hour >= 16 && hour < 18) {
            const t = (hour - 16) / 2;
            alpha = 0.05 + 0.4 * t;
            r = Math.floor(180 * (1 - t) + 5 * t);
            g = Math.floor(200 * (1 - t) + 10 * t);
            b = Math.floor(220 * (1 - t) + 35 * t);
        } else {
            alpha = 0.55; r = 5; g = 10; b = 35;
        }

        if (alpha > 0.01) {
            ctx.fillStyle = `rgba(${r},${g},${b},${alpha})`;
            ctx.fillRect(0, 0, this.game.viewW, this.game.viewH);
        }

        // 寒冷天气额外变暗/变蓝
        const temp = this.getEffectiveTemp();
        if (temp < -20) {
            const coldAlpha = Math.min(0.3, Math.abs(temp + 20) / 100);
            ctx.fillStyle = `rgba(100,120,180,${coldAlpha})`;
            ctx.fillRect(0, 0, this.game.viewW, this.game.viewH);
        }
    }

    /** 获取天气描述字符串 */
    getWeatherStr() {
        const temp = this.getEffectiveTemp();
        return `${this.weatherEmoji} ${this.currentWeather} ${temp}°C`;
    }

    /** 获取生存状态摘要（给AI prompt用） */
    getSurvivalSummary() {
        const temp = this.getEffectiveTemp();
        const alive = this.game.npcs.filter(n => !n.isDead).length;
        const rs = this.game.resourceSystem;
        const hs = this.game.furnaceSystem;
        return `【生存状态】第${this.currentDay}天 | 温度${temp}°C | ${this.currentWeather} | ` +
            `存活${alive}/8人 | ` +
            (rs ? `木柴${Math.round(rs.woodFuel)} 食物${Math.round(rs.food)} 电力${Math.round(rs.power)} | ` : '') +
            (hs ? `${hs.getHeatingSummary()}` : '');
    }

    /** 获取暴风雪紧迫感描述（给对话prompt注入，让NPC知道暴风雪即将到来） */
    getBlizzardUrgencyForPrompt() {
        const day = this.currentDay;
        const hour = this.game.getHour();
        const rs = this.game.resourceSystem;
        const fs = this.game.furnaceSystem;

        let urgency = '';
        let survivalChecklist = '';

        if (day === 1) {
            // 第1天：准备日，距暴风雪还有约2天
            const hoursUntilStorm = Math.max(0, (4 - 1) * 24 - hour);
            urgency = `🚨 【暴风雪预警】今天是准备日（第1天），大极寒暴风雪将在第4天降临（-60°C！），距离暴风雪大约还有${Math.round(hoursUntilStorm)}小时。明天（第2天）降温到-30°C大雪，户外连续工作超过2小时会严重冻伤。`;
            survivalChecklist = this._buildSurvivalChecklist(rs, fs);
        } else if (day === 2) {
            // 第2天：寒冷天，-30°C
            const hoursUntilStorm = Math.max(0, (4 - 2) * 24 - hour);
            urgency = `🚨🚨 【暴风雪迫近】今天是第2天，-30°C大雪天！户外连续工作超过2小时会严重冻伤。距离第4天大极寒暴风雪（-60°C）还有约${Math.round(hoursUntilStorm)}小时。明天（第3天）气温会短暂回升到0°C。`;
            survivalChecklist = this._buildSurvivalChecklist(rs, fs);
        } else if (day === 3) {
            // 第3天：喘息日，最后准备机会
            const hoursUntilStorm = Math.max(0, 24 - hour);
            urgency = `🚨🚨🚨 【最后准备窗口！今晚24点暴风雪来袭！】今天是第3天喘息日，气温短暂回升到0°C。今晚24点（约${Math.round(hoursUntilStorm)}小时后）进入第4天-60°C极寒暴风雪，届时户外极度危险，所有人只能待在室内靠木材、电力和储备物资活命。`;
            survivalChecklist = this._buildSurvivalChecklist(rs, fs);
        } else if (day === 4) {
            // 第4天：大极寒
            urgency = `🚨🚨🚨 【大极寒已降临！-60°C！】现在是第4天，极寒暴风雪正在肆虐！户外极度危险，出门会快速失温掉血。室内靠木材、电力和食物维持生存。坚持到今天日落（18:00）即可迎来救援。`;
            survivalChecklist = this._buildSurvivalChecklist(rs, fs);
        }

        return urgency + (survivalChecklist ? '\n' + survivalChecklist : '');
    }

    /** 构建生存物资清单检查（给AI看当前准备够不够） */
    _buildSurvivalChecklist(rs, fs) {
        if (!rs) return '';
        const heatingStrength = fs && fs.getHeatingStrength ? fs.getHeatingStrength() : 0;
        const heatingSummary = fs && fs.getHeatingSummary ? fs.getHeatingSummary() : `供暖${Math.round(heatingStrength * 100)}%`;

        // 计算第4天需要的最低物资
        const woodNeededDay4 = 72;
        const foodNeededDay4 = 8 * 2 * 2;
        const powerNeededDay4 = 5 * 24;

        let checklist = `📋 【物资检查】\n`;
        checklist += `  🪵 木柴: ${Math.round(rs.woodFuel)}单位（第4天至少需要${woodNeededDay4}单位）${rs.woodFuel >= woodNeededDay4 ? '✅够了' : `❌还差${Math.round(woodNeededDay4 - rs.woodFuel)}单位！`}\n`;
        checklist += `  🍞 食物: ${Math.round(rs.food)}单位（第4天至少需要${foodNeededDay4}单位）${rs.food >= foodNeededDay4 ? '✅够了' : `❌还差${Math.round(foodNeededDay4 - rs.food)}单位！`}\n`;
        checklist += `  ⚡ 电力: ${Math.round(rs.power)}单位（第4天至少需要${powerNeededDay4}单位）${rs.power >= powerNeededDay4 ? '✅够了' : `❌还差${Math.round(powerNeededDay4 - rs.power)}单位！`}\n`;
        checklist += `  🌡️ ${heatingSummary}${heatingStrength >= 0.75 ? '✅稳定' : '❌偏弱，需继续补木材和电力'}`;
        return checklist;
    }
}

    GST.WeatherSystem = WeatherSystem;
})();
