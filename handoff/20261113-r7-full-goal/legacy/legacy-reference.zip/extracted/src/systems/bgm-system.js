/**
 * 福音镇 - BGM 系统
 * 根据游戏状态自动切换背景音乐：日常/暴风雪/告急/会议
 * 挂载到 GST.BgmSystem
 */
(function() {
    'use strict';
    const GST = window.GST;

    // ============ BGM 配置 ============
    const BGM_TRACKS = {
        // 第1天日常（随机选一首）
        day1: [
            'music/第一天Frozen_Gridline_Echo.mp3',
            'music/第一天peaceFrozen_Gridline_Echo.mp3',
        ],
        // 第2天暴风雪（紧张）
        day2_blizzard: [
            'music/告急Frozen_Ledger.mp3',
        ],
        // 第3天日常（随机选一首）
        day3: [
            'music/第三天-日常Frozen_Outpost_Vigil.mp3',
            'music/第三天-萨克斯贼牛逼Frozen_Skyward_Plains.mp3',
        ],
        // 第4天极寒暴风雪（紧张）
        day4_blizzard: [
            'music/告急Frozen_Ledger.mp3',
        ],
        // 和平日常（通用备选）
        peace: [
            'music/peace1-Frozen_Embers,_Fading_Maps.mp3',
            'music/peace2-Frozen_Embers,_Fading_Maps.mp3',
        ],
        // 资源告急
        crisis: [
            'music/告急Frozen_Ledger.mp3',
        ],
        // 告急会议专用
        council: [
            'music/告急会议Frozen_Circuit_Vigil.mp3',
        ],
    };

    // 淡入淡出时长（毫秒）
    const FADE_DURATION = 800;
    // 淡出时长（切换曲目时稍长一点）
    const FADEOUT_DURATION = 1500;
    // 默认音量
    const DEFAULT_VOLUME = 0.35;
    // 淡入起始音量（不从0开始，让用户立刻能听到）
    const FADE_IN_START = 0.08;

    class BgmSystem {
        constructor(game) {
            this.game = game;

            // 当前播放的Audio对象
            this._currentAudio = null;
            // 当前播放的曲目路径
            this._currentTrack = null;
            // 当前BGM类别（day1/day2_blizzard/crisis/council等）
            this._currentCategory = null;
            // 会议前的BGM类别（会议结束后恢复）
            this._preCouncilCategory = null;
            this._preCouncilTrack = null;

            // 是否正在会议中
            this._inCouncil = false;
            // 是否处于告急状态
            this._inCrisis = false;

            // 淡入淡出相关
            this._fadeTimer = null;
            this._targetVolume = DEFAULT_VOLUME;
            this._muted = false;

            // 【v5.4.1修复BGM重合】追踪所有正在淡出的Audio对象
            // 当快速连续切换时，需要强制停止之前正在淡出的Audio，防止多首BGM同时播放
            this._fadingOutAudios = new Set();

            // 用户交互标记（浏览器要求用户交互后才能播放音频）
            this._userInteracted = false;
            this._pendingPlay = null;

            // 检查启动流程中是否已经有过用户交互（点击"开始游戏"按钮）
            // 如果有，直接标记为已交互，避免用户需要再次点击才能播放BGM
            if (window.__userHasInteracted) {
                this._userInteracted = true;
                console.log('[BgmSystem] 检测到启动时用户已交互，音频播放已解锁');
            }

            // 监听用户首次交互（如果还没交互过，则等待）
            this._setupUserInteraction();
            // 监听标签页可见性变化，切回前台时恢复被浏览器暂停的音频
            this._setupVisibilityHandler();

            console.log('[BgmSystem] 初始化完成');
        }

        // ============ 用户交互检测 ============
        // 浏览器策略：必须有用户交互（点击/键盘）后才能播放音频
        _setupUserInteraction() {
            // 如果启动流程中已经标记了用户交互（点击了"开始游戏"按钮），跳过等待
            if (this._userInteracted) {
                console.log('[BgmSystem] 用户已在启动流程中交互，跳过交互等待');
                return;
            }

            // 初始状态：按钮显示等待交互提示
            this._syncMuteButtons('pending');

            const handler = () => {
                this._userInteracted = true;
                document.removeEventListener('click', handler);
                document.removeEventListener('keydown', handler);
                document.removeEventListener('touchstart', handler);
                document.removeEventListener('pointerdown', handler);
                console.log('[BgmSystem] 用户已交互，音频播放已解锁');
                // 如果有待播放的BGM，立即播放
                if (this._pendingPlay) {
                    const { category, track } = this._pendingPlay;
                    this._pendingPlay = null;
                    this._playTrack(track, category);
                }
                // 交互后恢复按钮为正常状态
                this._syncMuteButtons('normal');
            };
            document.addEventListener('click', handler);
            document.addEventListener('keydown', handler);
            document.addEventListener('touchstart', handler);
            document.addEventListener('pointerdown', handler);
        }

        // ============ 标签页可见性恢复 ============
        // macOS 浏览器在标签页/窗口切到后台时可能暂停 Audio 播放
        // 切回前台时需要检测并恢复
        _setupVisibilityHandler() {
            document.addEventListener('visibilitychange', () => {
                if (!document.hidden) {
                    this._resumeIfSuspended();
                }
            });
            // macOS 多桌面/多屏幕切换时，focus 事件比 visibilitychange 更可靠
            window.addEventListener('focus', () => {
                this._resumeIfSuspended();
            });
        }

        // 检测并恢复被浏览器暂停的音频
        _resumeIfSuspended() {
            if (!this._currentAudio || this._muted) return;
            if (this._currentAudio.paused && this._currentTrack) {
                console.log('[BgmSystem] 检测到音频被浏览器暂停，正在恢复播放...');
                const playPromise = this._currentAudio.play();
                if (playPromise) {
                    playPromise.then(() => {
                        // 恢复到目标音量
                        this._currentAudio.volume = this._targetVolume;
                        console.log('[BgmSystem] 音频恢复播放成功');
                    }).catch(err => {
                        console.warn('[BgmSystem] 音频恢复失败:', err.message);
                    });
                }
            }
        }

        // ============ 主更新（由game.update调用） ============
        update() {
            // 会议期间不自动切换（由会议系统控制）
            if (this._inCouncil) return;

            // 检测当前应该播放什么类别的BGM
            const targetCategory = this._determineCategory();

            // 如果类别没变，不切换
            if (targetCategory === this._currentCategory) return;

            // 切换BGM
            this._switchToCategory(targetCategory);
        }

        // ============ 判断当前应该播放的BGM类别 ============
        _determineCategory() {
            const game = this.game;
            const day = game.dayCount || 1;

            // 1. 检测资源告急
            if (this._checkResourceCrisis()) {
                return 'crisis';
            }

            // 2. 按天数和天气决定
            const weather = game.weather || '';
            if (day === 1) {
                return 'day1';
            } else if (day === 2) {
                // 第2天大雪 → 紧张BGM
                return 'day2_blizzard';
            } else if (day === 3) {
                return 'day3';
            } else if (day === 4) {
                // 第4天极寒暴风雪 → 紧张BGM
                return 'day4_blizzard';
            }

            // 默认和平
            return 'peace';
        }

        // ============ 检测资源是否告急 ============
        _checkResourceCrisis() {
            const rs = this.game.resourceSystem;
            if (!rs) return false;

            // 使用资源系统的紧急度判断
            if (rs.getResourceUrgency) {
                const urgency = rs.getResourceUrgency();
                // 任何一项资源处于critical就算告急
                if (urgency.wood === 'critical' || urgency.food === 'critical' || urgency.power === 'critical') {
                    return true;
                }
            }

            // 或者直接检测危机标志
            if (rs.crisisFlags) {
                if (rs.crisisFlags.noFood || rs.crisisFlags.noWoodFuel || rs.crisisFlags.noPower) {
                    return true;
                }
            }

            return false;
        }

        // ============ 切换到指定类别的BGM ============
        _switchToCategory(category) {
            const tracks = BGM_TRACKS[category];
            if (!tracks || tracks.length === 0) {
                console.warn(`[BgmSystem] 未找到类别 ${category} 的BGM配置`);
                return;
            }

            // 随机选一首
            const track = tracks[Math.floor(Math.random() * tracks.length)];

            console.log(`[BgmSystem] 切换BGM: ${this._currentCategory || '无'} → ${category} (${track})`);
            this._currentCategory = category;

            // 淡出当前 → 淡入新曲
            this._crossfadeTo(track, category);
        }

        // ============ 会议开始：根据严重程度决定是否切换BGM ============
        /**
         * @param {string} severity - 会议严重程度
         *   'death'  : 有人死亡后的紧急会议 → 播放告急会议BGM
         *   'crisis' : 资源危机/NPC濒死 → 不切换BGM，保持当前背景
         *   'normal' : 晨会等日常会议 → 不切换BGM，保持当前背景
         */
        onCouncilOpen(severity) {
            if (this._inCouncil) return;
            this._inCouncil = true;
            severity = severity || 'normal';

            // 保存当前状态
            this._preCouncilCategory = this._currentCategory;
            this._preCouncilTrack = this._currentTrack;
            this._councilSeverity = severity;

            // 只有死亡级别的会议才切换到告急会议BGM
            if (severity === 'death') {
                console.log('[BgmSystem] 死亡紧急会议，切换到告急会议BGM');
                this._currentCategory = 'council';
                const tracks = BGM_TRACKS.council;
                const track = tracks[Math.floor(Math.random() * tracks.length)];
                this._crossfadeTo(track, 'council');
            } else {
                console.log(`[BgmSystem] 会议开始(${severity})，保持当前BGM`);
                // 不切换BGM，保持当前背景音乐
            }
        }

        // ============ 会议结束：恢复之前的BGM ============
        onCouncilClose() {
            if (!this._inCouncil) return;
            this._inCouncil = false;

            const wasDeath = this._councilSeverity === 'death';
            this._councilSeverity = null;

            // 只有死亡级别会议切换过BGM，才需要恢复
            if (wasDeath && this._preCouncilCategory) {
                console.log('[BgmSystem] 死亡会议结束，恢复之前的BGM');
                this._currentCategory = this._preCouncilCategory;
                const track = this._preCouncilTrack;
                this._preCouncilCategory = null;
                this._preCouncilTrack = null;

                if (track) {
                    this._crossfadeTo(track, this._currentCategory);
                } else {
                    this._currentCategory = null;
                    this.update();
                }
            } else {
                console.log('[BgmSystem] 会议结束，继续当前BGM');
                this._preCouncilCategory = null;
                this._preCouncilTrack = null;
                // 不切换，但重新允许update检测
            }
        }

        // ============ 天数切换时重新判断BGM ============
        onDayChange(newDay) {
            console.log(`[BgmSystem] 天数切换到第${newDay}天，重新选择BGM`);
            // 强制重新判断（清除当前类别让update重新选择）
            const oldCategory = this._currentCategory;
            this._currentCategory = null;
            this._inCrisis = false;
            this.update();
        }

        // ============ 交叉淡入淡出 ============
        _crossfadeTo(newTrack, category) {
            // 如果和当前播放的是同一首（且非静音状态下正在播放），不切换
            if (newTrack === this._currentTrack && !this._muted && this._currentAudio && !this._currentAudio.paused) {
                this._currentCategory = category;
                return;
            }

            // 【v5.4.1修复BGM重合】先强制停止所有之前正在淡出的Audio
            // 防止快速连续切换时多首BGM叠加播放
            for (const fadingAudio of this._fadingOutAudios) {
                try {
                    fadingAudio.pause();
                    fadingAudio.src = '';
                } catch (e) { /* ignore */ }
            }
            this._fadingOutAudios.clear();

            const oldAudio = this._currentAudio;

            // 淡出旧曲（用较长的淡出时长，过渡更自然）
            if (oldAudio && !oldAudio.paused) {
                this._fadingOutAudios.add(oldAudio);
                this._fadeOut(oldAudio, FADEOUT_DURATION, () => {
                    oldAudio.pause();
                    oldAudio.src = '';
                    this._fadingOutAudios.delete(oldAudio);
                });
            }

            // 淡入新曲（_playTrack内部会检查_muted状态）
            this._playTrack(newTrack, category);
        }

        // ============ 播放指定曲目 ============
        _playTrack(track, category) {
            // 如果用户还没交互，先记录待播放
            if (!this._userInteracted) {
                this._pendingPlay = { category, track };
                this._currentCategory = category;
                this._currentTrack = track;
                console.log(`[BgmSystem] 等待用户交互后播放: ${track}`);
                return;
            }

            // 如果处于静音状态，只更新内部状态，不实际播放音频
            // 等用户取消静音时再恢复播放
            if (this._muted) {
                this._currentCategory = category;
                this._currentTrack = track;
                console.log(`[BgmSystem] 静音中，记录待播放曲目: ${track}`);
                return;
            }

            // 优先使用启动时预加载好的Audio对象（避免重复加载等待）
            let audio;
            if (window.__preloadedBgm && window.__preloadedBgm.track === track && window.__preloadedBgm.audio) {
                audio = window.__preloadedBgm.audio;
                audio.loop = true;
                audio.volume = FADE_IN_START;
                // 用完即清，防止重复使用
                window.__preloadedBgm = null;
                console.log(`[BgmSystem] 使用预加载的BGM: ${track}`);
            } else {
                audio = new Audio(track);
                audio.loop = true;
                audio.volume = FADE_IN_START;
                audio.preload = 'auto';
            }

            this._currentAudio = audio;
            this._currentTrack = track;
            this._currentCategory = category;

            // 先等元数据加载完成 → 跳转到随机位置 → 再播放并淡入
            // 这样避免从安静的开头开始播放
            const startPlayback = () => {
                const playPromise = audio.play();
                if (playPromise) {
                    playPromise.then(() => {
                        // 播放成功，快速淡入
                        this._fadeIn(audio, FADE_DURATION);
                        console.log(`[BgmSystem] 开始播放: ${track}`);
                    }).catch(err => {
                        console.warn(`[BgmSystem] 播放失败（可能需要用户交互）: ${err.message}`);
                        this._pendingPlay = { category, track };
                    });
                }
            };

            // 如果元数据已经加载好了（预加载的情况），直接跳转并播放
            if (audio.readyState >= 1 && audio.duration && isFinite(audio.duration)) {
                this._seekToRandomPosition(audio);
                startPlayback();
                return;
            }

            // 音频元数据加载后，跳转到随机位置再开始播放
            // 【v5.4.1修复BGM重合】加检查：如果在等待期间audio已经不是当前audio了，不播放
            audio.addEventListener('loadedmetadata', () => {
                if (audio !== this._currentAudio) {
                    // 在等待元数据期间，已经切换到了新的BGM，放弃播放这个旧的
                    console.log(`[BgmSystem] 元数据加载完成但audio已过期，放弃播放: ${track}`);
                    audio.src = '';
                    return;
                }
                this._seekToRandomPosition(audio);
                startPlayback();
            }, { once: true });

            // 安全兜底：如果3秒内loadedmetadata没触发，直接播放（不等了）
            setTimeout(() => {
                if (audio === this._currentAudio && audio.paused) {
                    console.log('[BgmSystem] 元数据加载超时，直接开始播放');
                    startPlayback();
                }
            }, 3000);
        }

        // ============ 跳转到随机位置（跳过安静前奏） ============
        _seekToRandomPosition(audio) {
            if (audio.duration && isFinite(audio.duration) && audio.duration > 30) {
                // 跳过前15秒（通常是安静前奏），随机跳转到 15秒~80% 的位置
                const minPos = 15;
                const maxPos = audio.duration * 0.8;
                const randomPos = minPos + Math.random() * (maxPos - minPos);
                audio.currentTime = randomPos;
                const mins = Math.floor(randomPos / 60);
                const secs = Math.floor(randomPos % 60);
                console.log(`[BgmSystem] 随机起始位置: ${mins}:${secs < 10 ? '0' : ''}${secs} / ${Math.floor(audio.duration / 60)}:${Math.floor(audio.duration % 60).toString().padStart(2, '0')}`);
            } else if (audio.duration && isFinite(audio.duration) && audio.duration > 10) {
                // 短曲目跳过前5秒
                const randomPos = 5 + Math.random() * (audio.duration * 0.7 - 5);
                audio.currentTime = Math.max(0, randomPos);
            }
        }

        // ============ 淡入 ============
        _fadeIn(audio, duration) {
            if (!audio) return;
            const targetVol = this._muted ? 0 : this._targetVolume;
            // 从当前音量开始淡入（不重置为0，保持FADE_IN_START的起始音量）
            const startVol = Math.min(audio.volume || FADE_IN_START, targetVol);
            const startTime = Date.now();

            // 使用 easeOut 曲线，前半段快速提升音量
            const easeOut = (t) => 1 - Math.pow(1 - t, 2);

            const tick = () => {
                if (audio.paused || audio !== this._currentAudio) return;
                const elapsed = Date.now() - startTime;
                const progress = Math.min(1, elapsed / duration);
                audio.volume = startVol + (targetVol - startVol) * easeOut(progress);
                if (progress < 1) {
                    requestAnimationFrame(tick);
                }
            };
            requestAnimationFrame(tick);
        }

        // ============ 淡出 ============
        _fadeOut(audio, duration, onComplete) {
            if (!audio) { if (onComplete) onComplete(); return; }
            const startVol = audio.volume;
            const startTime = Date.now();

            const tick = () => {
                if (audio.paused) { if (onComplete) onComplete(); return; }
                const elapsed = Date.now() - startTime;
                const progress = Math.min(1, elapsed / duration);
                audio.volume = Math.max(0, startVol * (1 - progress));
                if (progress < 1) {
                    requestAnimationFrame(tick);
                } else {
                    if (onComplete) onComplete();
                }
            };
            requestAnimationFrame(tick);
        }

        // ============ 静音/取消静音 ============
        toggleMute() {
            this._muted = !this._muted;
            if (this._muted) {
                // 静音：淡出当前音频
                if (this._currentAudio) {
                    this._fadeOut(this._currentAudio, 500, () => {
                        if (this._currentAudio) this._currentAudio.volume = 0;
                    });
                }
            } else {
                // 取消静音：检查是否有待播放的曲目（静音期间切换了BGM类别）
                if (this._currentTrack && (!this._currentAudio || this._currentAudio.paused || !this._currentAudio.src)) {
                    // 静音期间记录了新曲目但没有实际播放，现在开始播放
                    console.log(`[BgmSystem] 取消静音，恢复播放: ${this._currentTrack}`);
                    this._playTrack(this._currentTrack, this._currentCategory);
                } else if (this._currentAudio) {
                    // 有正在播放的音频，直接淡入恢复音量
                    this._fadeIn(this._currentAudio, 500);
                }
            }
            console.log(`[BgmSystem] ${this._muted ? '静音' : '取消静音'}`);
            return this._muted;
        }

        // ============ 设置音量 ============
        setVolume(vol) {
            this._targetVolume = Math.max(0, Math.min(1, vol));
            if (this._currentAudio && !this._muted) {
                this._currentAudio.volume = this._targetVolume;
            }
        }

        // ============ 同步所有静音按钮的显示状态 ============
        _syncMuteButtons(mode) {
            const mainBtn = document.getElementById('btn-bgm-mute');
            const councilBtn = document.getElementById('council-mute');
            const btns = [mainBtn, councilBtn].filter(Boolean);
            const t = GST.t;

            if (mode === 'pending') {
                // 等待用户交互状态
                btns.forEach(btn => {
                    if (btn.id === 'btn-bgm-mute') {
btn.textContent = t('hud.bgm_pending');
                    } else {
btn.textContent = t('hud.bgm_council_pending');
                    }
btn.title = t('hud.bgm_tip_pending');
                    btn.style.animation = 'bgm-pending-pulse 1.5s ease-in-out infinite';
                });
                // 注入动画样式（只注入一次）
                if (!document.getElementById('bgm-pending-style')) {
                    const style = document.createElement('style');
                    style.id = 'bgm-pending-style';
                    style.textContent = `
                        @keyframes bgm-pending-pulse {
                            0%, 100% { opacity: 0.5; }
                            50% { opacity: 1; }
                        }
                    `;
                    document.head.appendChild(style);
                }
            } else {
                // 正常状态
                const tip = this._muted ? t('hud.bgm_tip_muted') : t('hud.bgm_tip_playing');
                btns.forEach(btn => {
// 主界面按钮用♬ BGM:开/关，会议面板按钮用♬开/关
                    if (btn.id === 'btn-bgm-mute') {
btn.textContent = this._muted ? t('hud.bgm_off') : t('hud.bgm_on');
                    } else {
btn.textContent = this._muted ? t('hud.bgm_council_off') : t('hud.bgm_council_on');
                    }
                    btn.title = tip;
                    btn.style.animation = '';
                });
            }
        }

        // ============ 获取当前状态（供HUD显示） ============
        getStatus() {
            return {
                category: this._currentCategory,
                track: this._currentTrack,
                muted: this._muted,
                volume: this._targetVolume,
                playing: this._currentAudio && !this._currentAudio.paused,
                inCouncil: this._inCouncil,
                pendingInteraction: !this._userInteracted && !!this._pendingPlay,
            };
        }

        // ============ 停止播放 ============
        stop() {
            // 【v5.4.1】先清理所有正在淡出的Audio
            for (const fadingAudio of this._fadingOutAudios) {
                try {
                    fadingAudio.pause();
                    fadingAudio.src = '';
                } catch (e) { /* ignore */ }
            }
            this._fadingOutAudios.clear();

            if (this._currentAudio) {
                this._fadeOut(this._currentAudio, 1000, () => {
                    if (this._currentAudio) {
                        this._currentAudio.pause();
                        this._currentAudio.src = '';
                        this._currentAudio = null;
                    }
                });
            }
            this._currentTrack = null;
            this._currentCategory = null;
        }
    }

    GST.BgmSystem = BgmSystem;
})();
