/**
 * 福音镇 - ReincarnationSystem
 * 挂载到 GST.ReincarnationSystem
 */
(function() {
    'use strict';
    const GST = window.GST;

/**
 * 轮回系统 — ReincarnationSystem
 * 管理轮回记忆的存储、摘要生成、教训推断、Prompt注入
 * 依赖: game.js, death-system.js, resource-system.js, task-system.js
 */

const REINCARNATION_STORAGE_KEY = 'gospel_reincarnation';
const REINCARNATION_LIFE_NUM_KEY = 'gospel_reincarnation_life_num'; // 独立存储世数，不受pastLives上限影响
const MAX_PAST_LIVES = 20; // 最多保留最近20世记忆

class ReincarnationSystem {
    constructor(game) {
        this.game = game;

        // 非轮回模式（agent/debug）不加载历史轮回数据，强制第1世
        if (game.mode !== 'reincarnation') {
            this.pastLives = [];
            this.currentLifeNumber = 1;
            console.log(`[ReincarnationSystem] 非轮回模式(${game.mode})，强制第1世，不加载历史记忆`);
            return;
        }

        // 轮回模式：从 localStorage 加载历史轮回记忆
        this.pastLives = this.loadPastLives();

        // 从独立存储读取世数（不再从pastLives.length推导，因为pastLives有上限裁剪）
        this.currentLifeNumber = this._loadLifeNumber();

        console.log(`[ReincarnationSystem] 轮回模式初始化完成，当前第${this.currentLifeNumber}世，历史${this.pastLives.length}条记忆`);
    }

    // ============ localStorage 读写 ============

    /** 从 localStorage 加载历史轮回记忆 */
    loadPastLives() {
        try {
            const raw = localStorage.getItem(REINCARNATION_STORAGE_KEY);
            if (!raw) return [];
            const data = JSON.parse(raw);
            if (!Array.isArray(data)) return [];
            return data;
        } catch (e) {
            console.warn('[ReincarnationSystem] 加载轮回记忆失败:', e);
            return [];
        }
    }

    /** 保存当前世的轮回记忆摘要到 localStorage */
    async savePastLife() {
        const summary = await this.generateReincarnationSummary();
        if (!summary) {
            console.warn('[ReincarnationSystem] 无法生成轮回摘要');
            return;
        }

        this.pastLives.push(summary);

        // 上限管理：最多保留最近5世
        while (this.pastLives.length > MAX_PAST_LIVES) {
            this.pastLives.shift(); // 丢弃最早的记录
        }

        try {
            localStorage.setItem(REINCARNATION_STORAGE_KEY, JSON.stringify(this.pastLives));
            // 同时保存当前世数到独立key
            this._saveLifeNumber(this.currentLifeNumber);
            console.log(`[ReincarnationSystem] 第${this.currentLifeNumber}世记忆已保存`);
        } catch (e) {
            console.error('[ReincarnationSystem] 保存轮回记忆失败:', e);
        }
    }

    /** 清除所有轮回记忆（彻底重来） */
    clearAllMemories() {
        this.pastLives = [];
        this.currentLifeNumber = 1;
        try {
            localStorage.removeItem(REINCARNATION_STORAGE_KEY);
            localStorage.removeItem(REINCARNATION_LIFE_NUM_KEY);
            console.log('[ReincarnationSystem] 所有轮回记忆已清除');
        } catch (e) {
            console.error('[ReincarnationSystem] 清除轮回记忆失败:', e);
        }
    }

    // ============ 世数管理 ============

    /** 获取当前世数 */
    getLifeNumber() {
        return this.currentLifeNumber;
    }

    /** 轮回后更新世数（在 game.reincarnate() 中调用） */
    advanceLife() {
        this.pastLives = this.loadPastLives(); // 重新从 localStorage 加载
        // 直接递增世数，不从pastLives.length推导（因为pastLives有MAX_PAST_LIVES上限裁剪）
        this.currentLifeNumber++;
        this._saveLifeNumber(this.currentLifeNumber);
        console.log(`[ReincarnationSystem] 进入第${this.currentLifeNumber}世`);
    }

    /** 从 localStorage 读取独立存储的世数 */
    _loadLifeNumber() {
        try {
            const raw = localStorage.getItem(REINCARNATION_LIFE_NUM_KEY);
            if (raw) {
                const num = parseInt(raw, 10);
                if (!isNaN(num) && num >= 1) return num;
            }
        } catch (e) {
            console.warn('[ReincarnationSystem] 读取世数失败:', e);
        }
        // 兼容旧版：如果没有独立存储的世数，从pastLives.length推导
        return this.pastLives.length + 1;
    }

    /** 保存世数到 localStorage */
    _saveLifeNumber(num) {
        try {
            localStorage.setItem(REINCARNATION_LIFE_NUM_KEY, String(num));
        } catch (e) {
            console.warn('[ReincarnationSystem] 保存世数失败:', e);
        }
    }

    // ============ 轮回记忆摘要生成 ============

    /** 在结局触发时，从各子系统收集数据，生成结构化摘要 */
    async generateReincarnationSummary() {
        const game = this.game;
        const ds = game.deathSystem;
        const rs = game.resourceSystem;
        const ts = game.taskSystem;
        const ws = game.weatherSystem;
        const fs = game.furnaceSystem;

        // 存活/死亡统计
        const aliveCount = game.npcs.filter(n => !n.isDead).length;
        const deadCount = game.npcs.filter(n => n.isDead).length;

        // 结局类型
        let endingType = 'unknown';
        if (ds && ds.currentEnding) {
            endingType = ds.currentEnding.id;
        } else if (aliveCount >= 8) {
            endingType = 'perfect';
        } else if (aliveCount >= 5) {
            endingType = 'normal';
        } else if (aliveCount >= 2) {
            endingType = 'bleak';
        } else {
            endingType = 'extinction';
        }

        // 死亡记录
        const deathRecords = ds ? ds.getDeathRecords().map(r => ({
            name: r.npcName,
            cause: r.cause,
            day: r.dayNum,
            time: r.time,
            location: r.location,
        })) : [];

        // 资源快照（当前剩余）
        const resourceSnapshot = rs ? {
            woodFuel: Math.round(rs.woodFuel),
            food: Math.round(rs.food),
            power: Math.round(rs.power),
            totalConsumed: { ...rs.totalConsumed },
            totalCollected: { ...rs.totalCollected },
        } : null;

        // 供暖准备状态（兼容旧字段名，语义已改为集中供暖是否准备充分）
        const secondFurnaceBuilt = fs ? (fs.getHeatingStrength ? fs.getHeatingStrength() >= 0.75 : true) : true;

        // 未完成任务
        const unfinishedTasks = ts ? ts.unfinishedTaskLog.map(log => ({
            day: log.day,
            tasks: log.tasks.map(t => ({
                name: t.name,
                progress: t.progress,
                target: t.target,
            })),
        })) : [];

        // 关键事件（冲突和危机）
        const keyEvents = ds ? ds.timeline
            .filter(e => e.type === 'conflict' || e.type === 'crisis' || e.type === 'death')
            .map(e => ({
                day: e.dayNum,
                time: e.time,
                text: e.text,
                type: e.type,
            })) : [];

        // NPC最终状态
        const npcFinalStates = game.npcs.map(npc => ({
            id: npc.id,
            name: npc.name,
            isDead: npc.isDead,
            sanity: Math.round(npc.sanity || 0),
            stamina: Math.round(npc.stamina || 0),
            health: Math.round(npc.health || 0),
            bodyTemp: npc.bodyTemp ? parseFloat(npc.bodyTemp.toFixed(1)) : 36.5,
        }));

        // 教训总结 — 调用LLM生成，硬编码作为fallback
        let lessons = await this._generateLessonsViaLLM(deathRecords, resourceSnapshot, secondFurnaceBuilt, aliveCount, npcFinalStates, keyEvents);
        if (!lessons || lessons.length === 0) {
            console.warn('[ReincarnationSystem] LLM教训生成失败，使用硬编码fallback');
            lessons = this._generateLessonsFallback(deathRecords, resourceSnapshot, secondFurnaceBuilt, aliveCount);
        }

        // 【修复A】保存当世的分工方案，供后续世复用成功方案
        let savedWorkPlan = null;
        const holder = this.game.reincarnationSystem ? this.game.reincarnationSystem.getWorkPlanHolder() : null;
        if (holder && holder.workPlan) {
            savedWorkPlan = JSON.parse(JSON.stringify(holder.workPlan)); // 深拷贝
        }

        // 通过LLM预生成深度教训、策略建议和精炼总结（并行调用以节省时间）
        let deepLessons = null;
        let strategyAdvice = null;
        let lifeSummary = null;
        try {
            // 构造临时lastLife对象用于LLM调用
            const tempLife = { endingType, aliveCount, deadCount, deathRecords, resourceSnapshot, secondFurnaceBuilt, npcFinalStates, unfinishedTasks, keyEvents: keyEvents.slice(-10), lessons };
            const [dlResult, saResult, lsResult] = await Promise.all([
                this._generateDeepLessonsViaLLM(tempLife).catch(e => { console.warn('[ReincarnationSystem] LLM深度教训异常:', e); return null; }),
                this._generateStrategyAdviceViaLLM(tempLife).catch(e => { console.warn('[ReincarnationSystem] LLM策略建议异常:', e); return null; }),
                this._generateLifeSummaryViaLLM(tempLife).catch(e => { console.warn('[ReincarnationSystem] LLM精炼总结异常:', e); return null; }),
            ]);
            deepLessons = dlResult;
            strategyAdvice = saResult;
            lifeSummary = lsResult;
        } catch (e) {
            console.warn('[ReincarnationSystem] LLM预生成异常:', e);
        }

        // deepLessons fallback
        if (!deepLessons) {
            const tempLife = { endingType, aliveCount, deadCount, deathRecords, resourceSnapshot, secondFurnaceBuilt, npcFinalStates, unfinishedTasks };
            deepLessons = this._generateDeepLessonsFallback(tempLife);
        }

        const summary = {
            lifeNumber: this.currentLifeNumber,
            endingType: endingType,
            aliveCount: aliveCount,
            deadCount: deadCount,
            deathRecords: deathRecords,
            resourceSnapshot: resourceSnapshot,
            secondFurnaceBuilt: secondFurnaceBuilt,
            unfinishedTasks: unfinishedTasks,
            keyEvents: keyEvents.slice(-10), // 最多保留10条关键事件
            npcFinalStates: npcFinalStates,
            lessons: lessons,
            deepLessons: deepLessons,          // LLM预生成的深度教训
            strategyAdvice: strategyAdvice,    // LLM预生成的策略建议
            lifeSummary: lifeSummary,          // LLM预生成的精炼总结（供下一世NPC prompt使用）
            workPlan: savedWorkPlan, // 【修复A】保存成功方案
            timestamp: Date.now(),
        };

        return summary;
    }

    // ============ 教训推断 ============

    /**
     * 通过LLM生成教训总结（异步）
     * 将本世的全部数据发给LLM，让它自行分析并总结教训
     */
    async _generateLessonsViaLLM(deathRecords, resourceSnapshot, secondFurnaceBuilt, aliveCount, npcFinalStates, keyEvents) {
        try {
            const systemPrompt = `你是一个末日生存游戏的复盘分析师。玩家在一个极寒小镇中指挥8位居民生存4天。
请根据本世的数据，总结出3-6条关键教训和经验。

要求：
- 每条教训要具体、可执行，结合真实的数据（人名、天数、资源数值）
- 语气简洁有力，像一位经验丰富的指挥官在做复盘
- 如果全员存活，总结成功经验；如果有人死亡，分析原因和改进方向
- 不要泛泛而谈，要针对本世的具体情况
- 返回JSON数组格式：["教训1", "教训2", ...]
- 只返回JSON数组，不要其他内容`;

            let userPrompt = `本世数据：\n`;
            userPrompt += `存活: ${aliveCount}/8人\n`;
            userPrompt += `供暖准备: ${secondFurnaceBuilt ? '充分' : '不足'}\n`;

            if (resourceSnapshot) {
                userPrompt += `最终资源: 木柴${resourceSnapshot.woodFuel} 食物${resourceSnapshot.food} 电力${resourceSnapshot.power}\n`;
                if (resourceSnapshot.totalCollected) {
                    const tc = resourceSnapshot.totalCollected;
                    userPrompt += `总采集量: 木柴${tc.woodFuel || 0} 食物${tc.food || 0} 电力${tc.power || 0}\n`;
                }
                if (resourceSnapshot.totalConsumed) {
                    const tc = resourceSnapshot.totalConsumed;
                    userPrompt += `总消耗量: 木柴${tc.woodFuel || 0} 食物${tc.food || 0} 电力${tc.power || 0}\n`;
                }
            }

            if (deathRecords && deathRecords.length > 0) {
                userPrompt += `死亡记录:\n`;
                for (const d of deathRecords) {
                    userPrompt += `  - ${d.name} 第${d.day}天${d.time || ''} ${d.cause}（${d.location || '未知地点'}）\n`;
                }
            } else {
                userPrompt += `无人死亡（全员存活）\n`;
            }

            if (npcFinalStates && npcFinalStates.length > 0) {
                userPrompt += `NPC最终状态:\n`;
                for (const s of npcFinalStates) {
                    userPrompt += `  - ${s.name}: ${s.isDead ? '已故' : '存活'} 精神${s.sanity} 体力${s.stamina} 健康${s.health} 体温${s.bodyTemp}°C\n`;
                }
            }

            if (keyEvents && keyEvents.length > 0) {
                userPrompt += `关键事件:\n`;
                for (const e of keyEvents.slice(-6)) {
                    userPrompt += `  - 第${e.day}天${e.time || ''}: ${e.text}\n`;
                }
            }

            userPrompt += `\n请根据以上数据总结3-6条教训（JSON数组格式）：`;

            console.log('[ReincarnationSystem] 调用LLM生成教训总结...');
            const raw = await GST.callLLMDirect(systemPrompt, userPrompt, 600);
            if (!raw) return null;

            // 尝试解析JSON数组
            let lessons = null;
            try {
                let cleaned = raw.replace(/```json|```/g, '').trim();
                // 提取JSON数组
                const match = cleaned.match(/\[[\s\S]*\]/);
                if (match) cleaned = match[0];
                lessons = JSON.parse(cleaned);
                if (!Array.isArray(lessons)) lessons = null;
            } catch (e) {
                console.warn('[ReincarnationSystem] LLM教训JSON解析失败:', e.message);
                // 尝试按行分割
                const lines = raw.split('\n').map(l => l.replace(/^[\d\-\*\.]+\s*/, '').trim()).filter(l => l.length > 5);
                if (lines.length >= 2) lessons = lines.slice(0, 6);
            }

            if (lessons && lessons.length > 0) {
                console.log(`[ReincarnationSystem] LLM生成了${lessons.length}条教训`);
                return lessons.slice(0, 6); // 最多6条
            }
            return null;
        } catch (err) {
            console.error('[ReincarnationSystem] LLM教训生成异常:', err);
            return null;
        }
    }
    // [已拆分到 reincarnation-memory.js] _generateLessonsFallback
    // [已拆分到 reincarnation-memory.js] getPastLifeHintForDialogue
    // [已拆分到 reincarnation-memory.js] getPastLifeHintForThinking
    // [已拆分到 reincarnation-memory.js] _generateStrategyAdvice
    // [已拆分到 reincarnation-memory.js] _generateStrategyAdviceFallback
    /**
     * 通过LLM生成策略建议（异步，在savePastLife时调用并存入summary）
     */
    async _generateStrategyAdviceViaLLM(lastLife) {
        try {
            const systemPrompt = `你是一个末日生存游戏的战略顾问。请根据上一世的数据，给出2-4条简洁的下一世策略建议。

要求：
- 每条建议一句话，简洁有力，可直接执行
- 结合具体数据（资源数值、人名、天数）
- 侧重于"下一世应该怎么做"而非"上一世做错了什么"
- 用分号(;)分隔各条建议，不要编号
- 只返回建议文本，不要其他内容`;

            let userPrompt = `上一世数据：\n`;
            userPrompt += `结局: ${lastLife.endingType}，存活${lastLife.aliveCount}/8人\n`;
            userPrompt += `供暖准备: ${lastLife.secondFurnaceBuilt ? '充分' : '不足'}\n`;

            if (lastLife.resourceSnapshot) {
                const rs = lastLife.resourceSnapshot;
                userPrompt += `最终资源: 木柴${rs.woodFuel} 食物${rs.food} 电力${rs.power}\n`;
                if (rs.totalConsumed) {
                    userPrompt += `总消耗: 木柴${rs.totalConsumed.woodFuel || 0} 食物${rs.totalConsumed.food || 0} 电力${rs.totalConsumed.power || 0}\n`;
                }
            }

            if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                userPrompt += `死亡: `;
                for (const d of lastLife.deathRecords) {
                    userPrompt += `${d.name}第${d.day}天${d.cause}(${d.location || ''}); `;
                }
                userPrompt += '\n';
            }

            userPrompt += `\n请给出策略建议：`;

            console.log('[ReincarnationSystem] 调用LLM生成策略建议...');
            const raw = await GST.callLLMDirect(systemPrompt, userPrompt, 300);
            if (!raw) return null;

            // 清理返回内容
            let advice = raw.replace(/```/g, '').replace(/^\d+[\.\)]\s*/gm, '').trim();
            if (advice.length > 300) advice = advice.substring(0, 297) + '…';

            console.log(`[ReincarnationSystem] LLM策略建议: ${advice.substring(0, 80)}...`);
            return advice;
        } catch (err) {
            console.error('[ReincarnationSystem] LLM策略建议生成异常:', err);
            return null;
        }
    }
    /**
     * 通过LLM生成精炼的上一世总结（异步，在savePastLife时调用并存入summary）
     * 目标：用最精简的语句传递最多的信息量，供下一世每个NPC的prompt使用
     * 返回 { forDialogue: string, forThinking: string, perNpc: { [npcId]: string } }
     */
    async _generateLifeSummaryViaLLM(lastLife) {
        try {
            const systemPrompt = `你是一个末日生存游戏的轮回记忆压缩器。玩家在极寒小镇指挥8位居民生存4天。

你的任务是将上一世的完整数据压缩成3段精炼总结，供下一世的NPC作为"前世记忆"使用：

1. forDialogue（≤200字）：用于NPC对话时的前世记忆提示。要求：
   - 用第二人称"你"，像在对NPC描述前世经历
   - 包含：结局、关键死亡（谁在第几天因什么死的）、最致命的资源缺口
   - 语气简洁有力，信息密度高

2. forThinking（≤350字）：用于NPC做决策时的前世经验参考。要求：
   - 包含：结局数据、死亡因果链、资源收支分析、具体可执行的改进建议
   - 用数据说话（具体数值、天数、人名）
   - 最后给出2-3条最关键的行动指令

3. perNpc（每人≤80字）：为每个NPC生成个性化的前世记忆片段。要求：
   - 只包含与该NPC直接相关的信息（自己是否死亡、自己的任务表现、与自己相关的教训）
   - 如果该NPC上世死了，重点描述死因和如何避免
   - 如果该NPC上世活着，提及其贡献或需要改进的地方

角色名单和ID：
- zhao_chef(赵铁柱): 厨师，体力强，砍柴效率高
- lu_chen(陆辰): 年轻多面手
- li_shen(李婶): 采集能手，食物采集效率高
- wang_teacher(王策): 教师，协调能力强
- old_qian(老钱): 统筹指挥
- su_doctor(苏岩): 医生
- ling_yue(歆玥): 侦察探索
- qing_xuan(清璇): 心理安抚/制药

返回JSON格式：
{
  "forDialogue": "...",
  "forThinking": "...",
  "perNpc": {
    "zhao_chef": "...",
    "lu_chen": "...",
    "li_shen": "...",
    "wang_teacher": "...",
    "old_qian": "...",
    "su_doctor": "...",
    "ling_yue": "...",
    "qing_xuan": "..."
  }
}
只返回JSON，不要其他内容。`;

            let userPrompt = `第${this.currentLifeNumber}世完整数据：\n`;
            userPrompt += `结局: ${lastLife.endingType}，存活${lastLife.aliveCount}/8人，死亡${lastLife.deadCount}人\n`;
            userPrompt += `供暖准备: ${lastLife.secondFurnaceBuilt ? '充分' : '不足'}\n`;

            if (lastLife.resourceSnapshot) {
                const rs = lastLife.resourceSnapshot;
                userPrompt += `最终资源: 木柴${rs.woodFuel} 食物${rs.food} 电力${rs.power}\n`;
                if (rs.totalCollected) {
                    const tc = rs.totalCollected;
                    userPrompt += `总采集: 木柴${tc.woodFuel || 0} 食物${tc.food || 0} 电力${tc.power || 0}\n`;
                }
                if (rs.totalConsumed) {
                    const tc = rs.totalConsumed;
                    userPrompt += `总消耗: 木柴${tc.woodFuel || 0} 食物${tc.food || 0} 电力${tc.power || 0}\n`;
                }
            }

            if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                userPrompt += `死亡记录:\n`;
                for (const d of lastLife.deathRecords) {
                    userPrompt += `  - ${d.name} 第${d.day}天${d.time || ''} ${d.cause}（${d.location || ''}）\n`;
                }
            } else {
                userPrompt += `无人死亡（全员存活）\n`;
            }

            if (lastLife.npcFinalStates && lastLife.npcFinalStates.length > 0) {
                userPrompt += `NPC最终状态:\n`;
                for (const s of lastLife.npcFinalStates) {
                    userPrompt += `  - ${s.name}(${s.id}): ${s.isDead ? '已故' : '存活'} 精神${s.sanity} 体力${s.stamina} 健康${s.health} 体温${s.bodyTemp}°C\n`;
                }
            }

            if (lastLife.keyEvents && lastLife.keyEvents.length > 0) {
                userPrompt += `关键事件:\n`;
                for (const e of lastLife.keyEvents.slice(-8)) {
                    userPrompt += `  - 第${e.day}天${e.time || ''}: ${e.text}\n`;
                }
            }

            if (lastLife.lessons && lastLife.lessons.length > 0) {
                userPrompt += `已总结的教训: ${lastLife.lessons.join('；')}\n`;
            }

            if (lastLife.unfinishedTasks && lastLife.unfinishedTasks.length > 0) {
                userPrompt += `未完成任务:\n`;
                for (const log of lastLife.unfinishedTasks.slice(-3)) {
                    userPrompt += `  第${log.day}天: ${log.tasks.map(t => `${t.name}(${t.progress}/${t.target})`).join(', ')}\n`;
                }
            }

            userPrompt += `\n请生成精炼总结（JSON格式）：`;

            console.log('[ReincarnationSystem] 调用LLM生成精炼总结...');
            const raw = await GST.callLLMDirect(systemPrompt, userPrompt, 1200);
            if (!raw) return null;

            const parsed = GST.parseLLMJSON(raw);
            if (parsed && parsed.forDialogue && parsed.forThinking) {
                // 确保perNpc存在且是对象
                if (!parsed.perNpc || typeof parsed.perNpc !== 'object') {
                    parsed.perNpc = {};
                }
                // 截断保护
                if (parsed.forDialogue.length > 250) parsed.forDialogue = parsed.forDialogue.substring(0, 247) + '…';
                if (parsed.forThinking.length > 400) parsed.forThinking = parsed.forThinking.substring(0, 397) + '…';
                for (const [npcId, text] of Object.entries(parsed.perNpc)) {
                    if (typeof text === 'string' && text.length > 100) {
                        parsed.perNpc[npcId] = text.substring(0, 97) + '…';
                    }
                }
                console.log(`[ReincarnationSystem] LLM精炼总结生成成功: 对话${parsed.forDialogue.length}字 思考${parsed.forThinking.length}字 个性化${Object.keys(parsed.perNpc).length}人`);
                return parsed;
            }

            console.warn('[ReincarnationSystem] LLM精炼总结格式不正确:', raw.substring(0, 200));
            return null;
        } catch (err) {
            console.error('[ReincarnationSystem] LLM精炼总结生成异常:', err);
            return null;
        }
    }

    // [已拆分到 reincarnation-workplan.js] generateWorkPlan
    // [已拆分到 reincarnation-workplan.js] _getDefaultWorkPlan
    // [已拆分到 reincarnation-workplan.js] _generateOptimizedPlan
    // [已拆分到 reincarnation-workplan.js] _analyzeResourceBottlenecks
    // [已拆分到 reincarnation-workplan.js] _generateWorkPlanSummary
    // [已拆分到 reincarnation-workplan.js] _generateDeepLessons
    // [已拆分到 reincarnation-workplan.js] _generateDeepLessonsFallback
    /**
     * 通过LLM生成深度教训分析（异步，在savePastLife时调用并存入summary）
     * 返回 { strategic: [...], tactical: [...], execution: [...] }
     */
    async _generateDeepLessonsViaLLM(lastLife) {
        try {
            const systemPrompt = `你是一个末日生存游戏的深度复盘分析师。请对本世的表现进行分层分析。

分析要分为三层：
1. strategic（战略层）：整体资源分配、人力调度的宏观问题
2. tactical（战术层）：与特定角色相关的具体问题（必须提到角色名字）
3. execution（执行层）：因果链推导，格式为"A → B → C"

角色名单：赵铁柱(厨师/体力强)、陆辰(年轻/多面手)、李婶(采集能手)、王策(教师/协调)、老钱(统筹指挥)、苏岩(医生)、歆玥(侦察/探索)、清璇(心理安抚)

要求：
- 每层1-3条，结合具体数据（人名、数值、天数）
- tactical层必须提到具体角色名字
- execution层用因果链格式
- 返回JSON格式：{"strategic":["..."],"tactical":["..."],"execution":["..."]}
- 只返回JSON，不要其他内容`;

            let userPrompt = `本世数据：\n`;
            userPrompt += `结局: ${lastLife.endingType}，存活${lastLife.aliveCount}/8人\n`;
            userPrompt += `供暖准备: ${lastLife.secondFurnaceBuilt ? '充分' : '不足'}\n`;

            if (lastLife.resourceSnapshot) {
                const rs = lastLife.resourceSnapshot;
                userPrompt += `最终资源: 木柴${rs.woodFuel} 食物${rs.food} 电力${rs.power}\n`;
                if (rs.totalCollected) {
                    const tc = rs.totalCollected;
                    userPrompt += `总采集: 木柴${tc.woodFuel || 0} 食物${tc.food || 0} 电力${tc.power || 0}\n`;
                }
            }

            if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                userPrompt += `死亡记录:\n`;
                for (const d of lastLife.deathRecords) {
                    userPrompt += `  - ${d.name} 第${d.day}天${d.time || ''} ${d.cause}（${d.location || ''}）\n`;
                }
            }

            if (lastLife.npcFinalStates && lastLife.npcFinalStates.length > 0) {
                userPrompt += `NPC最终状态:\n`;
                for (const s of lastLife.npcFinalStates) {
                    userPrompt += `  - ${s.name}: ${s.isDead ? '已故' : '存活'} 精神${s.sanity} 体力${s.stamina} 健康${s.health}\n`;
                }
            }

            userPrompt += `\n请分层分析（JSON格式）：`;

            console.log('[ReincarnationSystem] 调用LLM生成深度教训...');
            const raw = await GST.callLLMDirect(systemPrompt, userPrompt, 800);
            if (!raw) return null;

            const parsed = GST.parseLLMJSON(raw);
            if (parsed && parsed.strategic && parsed.tactical && parsed.execution) {
                // 确保每层都是数组
                const result = {
                    strategic: Array.isArray(parsed.strategic) ? parsed.strategic.slice(0, 3) : [],
                    tactical: Array.isArray(parsed.tactical) ? parsed.tactical.slice(0, 3) : [],
                    execution: Array.isArray(parsed.execution) ? parsed.execution.slice(0, 3) : [],
                };
                console.log(`[ReincarnationSystem] LLM深度教训: 战略${result.strategic.length}条 战术${result.tactical.length}条 执行${result.execution.length}条`);
                return result;
            }

            console.warn('[ReincarnationSystem] LLM深度教训格式不正确:', raw.substring(0, 200));
            return null;
        } catch (err) {
            console.error('[ReincarnationSystem] LLM深度教训生成异常:', err);
            return null;
        }
    }
    // [已拆分到 reincarnation-workplan.js] analyzeMultiLifePatterns
    // ============ 【需求2】老钱指挥中心辅助方法 ============

    /** 获取当前工作安排持有者（老钱→王策→李婶→歆玥） */
    getWorkPlanHolder() {
        const game = this.game;
        const succession = ['old_qian', 'wang_teacher', 'li_shen', 'ling_yue'];
        for (const id of succession) {
            const npc = game.npcs.find(n => n.id === id && !n.isDead);
            if (npc) return npc;
        }
        // 所有继任者都死了，返回任意存活NPC
        return game.npcs.find(n => !n.isDead) || null;
    }

    /** 获取给特定NPC看的工作安排摘要 */
    getWorkPlanSummaryForNpc(npcId) {
        const holder = this.getWorkPlanHolder();
        if (!holder || !holder.workPlan) return '';

        const plan = holder.workPlan;
        const day = this.game.dayCount || 1;
        const dayPlan = plan.dayPlans[day];
        if (!dayPlan) return '';

        const nameMap = { zhao_chef: '赵铁柱', lu_chen: '陆辰', li_shen: '李婶', wang_teacher: '王策', old_qian: '老钱', su_doctor: '苏岩', ling_yue: '歆玥', qing_xuan: '清璇' };
        const taskShort = { COLLECT_WOOD: '砍柴', COLLECT_FOOD: '采食物', COLLECT_MATERIAL: '探索废墟', MAINTAIN_POWER: '维护电力', COORDINATE: '统筹协调', PREPARE_MEDICAL: '医疗', SCOUT_RUINS: '侦察', BOOST_MORALE: '鼓舞士气', BUILD_FURNACE: '建暖炉', PREPARE_WARMTH: '御寒', MAINTAIN_ORDER: '维持秩序', DISTRIBUTE_FOOD: '分配食物', REST_RECOVER: '休息' };

        let summary = `【${nameMap[holder.id] || holder.name}的工作安排·第${day}天】\n`;
        for (const assignment of dayPlan) {
            const name = nameMap[assignment.npcId] || assignment.npcId;
            const task = taskShort[assignment.task] || assignment.task;
            const isMe = assignment.npcId === npcId;
            summary += isMe ? `→★${name}:${task}(${assignment.reason})★\n` : `  ${name}:${task}\n`;
        }
        // 截断到200字符
        if (summary.length > 200) summary = summary.substring(0, 197) + '…';
        return summary;
    }

    /** 获取与特定NPC相关的教训 */
    getLessonsForNpc(npcId) {
        if (this.pastLives.length === 0) return '';
        const lastLife = this.pastLives[this.pastLives.length - 1];
        const deepLessons = this._generateDeepLessons(lastLife);

        const npc = this.game.npcs.find(n => n.id === npcId);
        if (!npc) return '';

        // 筛选与该NPC相关的战术和执行层教训
        const relevantLessons = [];
        const npcName = npc.name;
        for (const lesson of [...deepLessons.tactical, ...deepLessons.execution]) {
            if (lesson.includes(npcName) || lesson.includes(npc.id)) {
                relevantLessons.push(lesson);
            }
        }
        // 也加入战略层前2条
        relevantLessons.push(...deepLessons.strategic.slice(0, 2));

        if (relevantLessons.length === 0) return '';
        let text = relevantLessons.slice(0, 3).join('；');
        if (text.length > 300) text = text.substring(0, 297) + '…';
        return text;
    }

    // ============ 【修复A】查找历史最好的一世 ============

    /** 从所有历史记忆中找到存活人数最多的那一世 */
    _findBestLife() {
        if (this.pastLives.length === 0) return null;
        let best = this.pastLives[0];
        for (const life of this.pastLives) {
            if (life.aliveCount > best.aliveCount) {
                best = life;
            } else if (life.aliveCount === best.aliveCount && life.endingType === 'perfect') {
                best = life; // 同分时优先完美结局
            }
        }
        return best;
    }

    // ============ 【修复A】基于历史最好方案微调 ============

    /** 以历史最好世代的分工方案为基础，结合最近一世的失败教训微调 */
    _generateOptimizedPlanFromBase(bestLife, lastLife, multiLifeAnalysis) {
        // 从最好世代的方案深拷贝
        const plan = JSON.parse(JSON.stringify(bestLife.workPlan));
        plan.strategy = 'optimize_from_best';

        const deaths = lastLife.deathRecords || [];
        const rs = lastLife.resourceSnapshot;

        // 针对最近一世的失败做针对性微调
        // 如果最近一世有人冻死且是木柴不足导致的
        const frozenDeaths = deaths.filter(d => d.cause === '冻死');
        if (frozenDeaths.length > 0 && rs && rs.woodFuel < 30) {
            // Day1加派一人砍柴
            if (plan.dayPlans && plan.dayPlans[1]) {
                for (let i = 0; i < plan.dayPlans[1].length; i++) {
                    const a = plan.dayPlans[1][i];
                    if (a.task === 'SCOUT_RUINS' || a.task === 'PREPARE_MEDICAL') {
                        plan.dayPlans[1][i] = { ...a, task: 'COLLECT_WOOD', targetLocation: 'lumber_camp', reason: `基于最好方案微调:上世木柴仅剩${rs.woodFuel}导致冻死` };
                        break;
                    }
                }
            }
        }

        // 如果最近一世有人饿死
        const starvedDeaths = deaths.filter(d => d.cause === '饿死');
        if (starvedDeaths.length > 0 && rs && rs.food < 15) {
            if (plan.dayPlans && plan.dayPlans[1]) {
                for (let i = 0; i < plan.dayPlans[1].length; i++) {
                    const a = plan.dayPlans[1][i];
                    if (a.task === 'SCOUT_RUINS' || a.task === 'PREPARE_MEDICAL') {
                        plan.dayPlans[1][i] = { ...a, task: 'COLLECT_FOOD', targetLocation: 'frozen_lake', reason: `基于最好方案微调:上世食物仅剩${rs.food}导致饿死` };
                        break;
                    }
                }
            }
        }

        // 如果最近一世暖炉未建
        if (!lastLife.secondFurnaceBuilt && plan.dayPlans && plan.dayPlans[3]) {
            for (let i = 0; i < plan.dayPlans[3].length; i++) {
                const a = plan.dayPlans[3][i];
                if (a.task !== 'BUILD_FURNACE' && a.npcId === 'zhao_chef') {
                    plan.dayPlans[3][i] = { ...a, task: 'BUILD_FURNACE', targetLocation: 'dorm_b_door', reason: '基于最好方案微调:上世暖炉未建！全力建造' };
                    break;
                }
            }
        }

        plan.summary = `第${this.currentLifeNumber}世(基于第${bestLife.lifeNumber}世最优方案微调):结合上世失败教训调整`;
        plan.workPlanSummary = this._generateWorkPlanSummary(plan);

        console.log(`[WorkPlan] 第${this.currentLifeNumber}世:以第${bestLife.lifeNumber}世(${bestLife.aliveCount}存活)方案为基础微调`);
        return plan;
    }

    // ============ 序列化 ============

    serialize() {
        return {
            pastLives: this.pastLives,
            currentLifeNumber: this.currentLifeNumber,
        };
    }

    deserialize(data) {
        if (!data) return;
        this.pastLives = data.pastLives || [];
        this.currentLifeNumber = data.currentLifeNumber || (this.pastLives.length + 1);
    }
}

    GST.ReincarnationSystem = ReincarnationSystem;
})();
