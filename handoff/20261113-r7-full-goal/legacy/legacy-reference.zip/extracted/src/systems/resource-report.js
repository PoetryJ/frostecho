/**
 * 福音镇 - 资源报告与状态查询
 * 从 resource-system.js 拆分，遵循SRP原则
 * 挂载到 GST.ResourceSystem.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.ResourceSystem.prototype;

    // 从原文件导入常量
    const RESOURCE_CONSUMPTION = GST._resource_system_RESOURCE_CONSUMPTION;
    const RESOURCE_DEFAULTS = GST._resource_system_RESOURCE_DEFAULTS;
    const RUINS_MAX_EXPLORES_PER_DAY = GST._resource_system_RUINS_MAX_EXPLORES_PER_DAY;
    const _safeNum = GST._resource_system_safeNum;

    // [已拆分到 resource-consumption.js] _tickConsumption
    // [已拆分到 resource-consumption.js] _getWeatherConsumptionMult
    // [已拆分到 resource-consumption.js] onWeatherChange
    // [已拆分到 resource-consumption.js] _checkMealTime
    // [已拆分到 resource-consumption.js] _updateCrisisFlags
    // ============ 日结算 ============

    /** 生成日结算报告（在天数切换时调用） */
    proto.generateDayReport = function(dayNum) {
        const ws = this.game.weatherSystem;
        const nextDay = dayNum + 1;
        const nextConfig = ws ? ws.getDayConfig(nextDay) : null;

        // 预估明日消耗（【v2.0】应用天气消耗乘数）
        const furnaceCount = this.game.furnaceSystem ? this.game.furnaceSystem.furnaces.length : 1;
        const aliveCount = this.game.npcs.filter(n => !n.isDead).length;

        // 获取明日天气乘数（含食物乘数）
        // 【v2.1】基于新的连续温度公式计算预估明日消耗
        let nextWoodMult = 1.0, nextPowerMult = 1.0, nextFoodMult = 1.0;
        if (nextConfig) {
            const nextTemp = nextConfig.baseTemp || 0;
            const coldFactor = Math.max(0, -nextTemp);
            nextWoodMult = Math.max(0.5, 1.0 + coldFactor * 0.04);
            nextPowerMult = Math.max(0.7, 1.0 + coldFactor * 0.02);
            nextFoodMult = 1.0; // 食物消耗不受温度影响
        }

        const popRatio = this.getPopulationRatio();
        const estimatedWood = _safeNum(RESOURCE_CONSUMPTION.heatingWoodPerHour * furnaceCount * 24 * nextWoodMult * popRatio, 20, 'estimatedWood');
        const estimatedFood = _safeNum(aliveCount * RESOURCE_CONSUMPTION.foodPerMealPerPerson * RESOURCE_CONSUMPTION.mealsPerDay * nextFoodMult, 24, 'estimatedFood');
        const estimatedPower = _safeNum(RESOURCE_CONSUMPTION.powerPerHour * 24 * nextPowerMult * popRatio, 48, 'estimatedPower');

        const report = {
            day: dayNum,
            consumed: { ...this.dailyConsumed },
            collected: { ...this.dailyCollected },
            remaining: {
                woodFuel: Math.round(this.woodFuel),
                food: Math.round(this.food),
                power: Math.round(this.power),
            },
            aliveCount: aliveCount,
            nextDay: nextConfig ? {
                temp: nextConfig.baseTemp,
                weather: nextConfig.weather,
                desc: nextConfig.desc,
            } : null,
            estimated: {
                woodNeeded: Math.round(estimatedWood),
                foodNeeded: Math.round(estimatedFood),
                powerNeeded: Math.round(estimatedPower),
            },
            warnings: [],
        };

        // 【v2.0】今日收支平衡检查
        const resourceTypes = ['woodFuel', 'food', 'power'];
        const resourceNames = { woodFuel: '木柴', food: '食物', power: '电力' };
        const resourceIcons = { woodFuel: '🪵', food: '🍞', power: '⚡' };
        for (const rt of resourceTypes) {
            const collected = this.dailyCollected[rt] || 0;
            const consumed = this.dailyConsumed[rt] || 0;
            if (consumed > collected && consumed > 0) {
                const deficit = Math.round(consumed - collected);
                report.warnings.push(`📉 今日${resourceNames[rt]}收支不平衡：收集${Math.round(collected)} < 消耗${Math.round(consumed)}，缺口${deficit}单位`);
            }
        }

        // 生成预警
        if (nextConfig) {
            if (this.woodFuel < estimatedWood) {
                report.warnings.push(`⚠️ 木柴不足！明天需要${Math.round(estimatedWood)}单位，当前仅${Math.round(this.woodFuel)}单位`);
            }
            if (this.food < estimatedFood) {
                report.warnings.push(`⚠️ 食物不足！明天需要${Math.round(estimatedFood)}单位，当前仅${Math.round(this.food)}单位`);
            }
            if (this.power < estimatedPower) {
                report.warnings.push(`⚠️ 电力不足！明天需要${Math.round(estimatedPower)}单位，当前仅${Math.round(this.power)}单位`);
            }
            if (nextConfig.day === 4 && furnaceCount < 2) {
                report.warnings.push(`🚨 警告：第二座暖炉尚未修复！明天-60°C仅1座暖炉，8人拥挤将导致巨大压力！`);
            }

            // 【v2.0-需求10】第3天结束时显示第4天准备评估清单
            if (dayNum === 3) {
                const woodOk = this.woodFuel >= estimatedWood;
                const foodOk = this.food >= estimatedFood;
                const powerOk = this.power >= estimatedPower;
                const furnaceOk = furnaceCount >= 2;
                report.day4ReadinessCheck = {
                    wood: { ok: woodOk, current: Math.round(this.woodFuel), needed: Math.round(estimatedWood) },
                    food: { ok: foodOk, current: Math.round(this.food), needed: Math.round(estimatedFood) },
                    power: { ok: powerOk, current: Math.round(this.power), needed: Math.round(estimatedPower) },
                    furnace: { ok: furnaceOk, count: furnaceCount },
                };
                const checkIcon = (ok) => ok ? '✅' : '❌';
                report.warnings.push(`\n📋 第4天准备评估：`);
                report.warnings.push(`  🪵 木柴 ${checkIcon(woodOk)} （${Math.round(this.woodFuel)}/${Math.round(estimatedWood)}）`);
                report.warnings.push(`  🍞 食物 ${checkIcon(foodOk)} （${Math.round(this.food)}/${Math.round(estimatedFood)}）`);
                report.warnings.push(`  ⚡ 电力 ${checkIcon(powerOk)} （${Math.round(this.power)}/${Math.round(estimatedPower)}）`);
                report.warnings.push(`  🔥 暖炉 ${checkIcon(furnaceOk)} （${furnaceCount}座）`);
                if (!woodOk || !foodOk || !powerOk) {
                    report.warnings.push(`⚠️⚠️ 物资不足以度过明天的极寒暴风雪！缺口详见上方数据。`);
                }
            }
        }

        this.lastDayReport = report;

        // 重置每日统计 + 废墟探索次数重置
        this.dailyConsumed = { woodFuel: 0, food: 0, power: 0 };
        this.dailyCollected = { woodFuel: 0, food: 0, power: 0 };
        this.ruinsExploresToday = 0;

        return report;
    };


    /** 格式化日结算报告为可展示的文本 */
    proto.formatDayReport = function(report) {
        if (!report) return '无报告数据';

        let text = `\n📋 ===== 第${report.day}天结算报告 =====\n`;
        text += `\n📦 资源剩余:\n`;
        text += `  🪵 木柴: ${report.remaining.woodFuel} 单位\n`;
        text += `  🍞 食物: ${report.remaining.food} 单位\n`;
        text += `  ⚡ 电力: ${report.remaining.power} 单位\n`;
        text += `\n📊 今日消耗/收集:\n`;
        text += `  🪵 木柴: -${Math.round(report.consumed.woodFuel)} / +${Math.round(report.collected.woodFuel)}\n`;
        text += `  🍞 食物: -${Math.round(report.consumed.food)} / +${Math.round(report.collected.food)}\n`;
        text += `  ⚡ 电力: -${Math.round(report.consumed.power)} / +${Math.round(report.collected.power)}\n`;
        text += `\n👥 存活人数: ${report.aliveCount}/8\n`;

        if (report.nextDay) {
            text += `\n🌡️ 明日预报: ${report.nextDay.temp}°C ${report.nextDay.weather}\n`;
            text += `  ${report.nextDay.desc}\n`;
            text += `\n📐 明日预估消耗:\n`;
            text += `  🪵 木柴: ~${report.estimated.woodNeeded} 单位\n`;
            text += `  🍞 食物: ~${report.estimated.foodNeeded} 单位\n`;
            text += `  ⚡ 电力: ~${report.estimated.powerNeeded} 单位\n`;
        }

        if (report.warnings.length > 0) {
            text += `\n🚨 预警:\n`;
            for (const w of report.warnings) {
                text += `  ${w}\n`;
            }
        }

        text += `\n===========================\n`;
        return text;
    };


    // ============ 查询接口 ============

    /** 获取资源摘要字符串 */
    proto.getResourceSummary = function() {
        return `🪵${Math.round(this.woodFuel)} 🍞${Math.round(this.food)} ⚡${Math.round(this.power)}`;
    };


    /** 获取资源状态详情（给AI prompt用） */
    proto.getResourceStatusForPrompt = function() {
        const woodH = this.getWoodFuelHoursRemaining();
        const foodM = this.getFoodMealsRemaining();
        const powerH = this.getPowerHoursRemaining();

        let status = `木柴${Math.round(this.woodFuel)}(够烧${woodH === Infinity ? '∞' : Math.round(woodH)}h) `;
        status += `食物${Math.round(this.food)}(够吃${foodM === Infinity ? '∞' : foodM}餐) `;
        status += `电力${Math.round(this.power)}(剩${powerH === Infinity ? '∞' : Math.round(powerH)}h) `;
        status += `废墟探索(今日剩${RUINS_MAX_EXPLORES_PER_DAY - this.ruinsExploresToday}次)`;

        // 自动化机器状态
        if (this.game.machineSystem) {
            const ms = this.game.machineSystem;
            status += ` | ${ms.getMachineStatusForPrompt()}`;
        }

        if (this.hasAnyCrisis()) {
            status += ' ⚠️危机:';
            if (this.crisisFlags.noFood) status += '无食物!';
            if (this.crisisFlags.noPower) status += '无电力!';
            if (this.crisisFlags.noWoodFuel) status += '无木柴!';
        }

        return status;
    };


    /**
    * 【v4.16新增】物资综合态势评估 — 用自然语言告诉NPC当前生存条件如何
    * 核心原则：只提供信息，不做决策辅助
    * 返回格式：一段简短的态势描述 + 事实信息
    */
    proto.getResourceSituationBrief = function() {
        const tension = this.getResourceTension();
        const woodH = this.getWoodFuelHoursRemaining();
        const foodM = this.getFoodMealsRemaining();
        const powerH = this.getPowerHoursRemaining();
        
        // 机器状态
        const ms = this.game.machineSystem;
        const generatorOk = ms && ms.generator.built && ms.generator.running && !ms.generator.broken;
        const lumberMillOk = ms && ms.lumberMill.built && ms.lumberMill.running && !ms.lumberMill.broken;
        const hasMachines = generatorOk || lumberMillOk;
        
        // 供暖状态
        const fs = this.game.furnaceSystem;
        const heatingOk = fs && fs.heatingStatus === 'stable';
        
        // 综合评估
        let brief = '';
        
        if (tension < 0.05 && hasMachines) {
            brief = `📊【当前态势】物资充足（木柴够${Math.round(woodH)}小时，食物够${foodM}餐，电力够${Math.round(powerH)}小时），`;
            if (generatorOk && lumberMillOk) {
                brief += '发电机和伐木机都在自动运转。';
            } else if (generatorOk) {
                brief += '发电机在自动运转。';
            } else if (lumberMillOk) {
                brief += '伐木机在自动运转。';
            }
            if (heatingOk) brief += '供暖稳定。';
            brief += '\n当前不需要紧急采集。你可以自由安排时间——休息恢复精力、找人聊天社交、探索废墟、或者做任何你觉得有意义的事。';
        } else if (tension < 0.1) {
            brief = `📊【当前态势】物资正常（木柴够${Math.round(woodH)}小时，食物够${foodM}餐，电力够${Math.round(powerH)}小时）。`;
            if (heatingOk) brief += '供暖稳定。';
            brief += '\n资源储备尚可，但仍需适当补充。你可以根据自己的状态和判断来安排时间。';
        } else if (tension < 0.3) {
            brief = `📊【当前态势】物资偏紧（木柴够${Math.round(woodH)}小时，食物够${foodM}餐，电力够${Math.round(powerH)}小时）。`;
            brief += '\n部分资源储备不太够，需要关注。';
        } else {
            brief = `📊【当前态势】物资紧张！（木柴够${Math.round(woodH)}小时，食物够${foodM}餐，电力够${Math.round(powerH)}小时）。`;
            if (this.hasAnyCrisis()) {
                if (this.crisisFlags.noFood) brief += '⚠️食物即将耗尽！';
                if (this.crisisFlags.noPower) brief += '⚠️电力即将耗尽！';
                if (this.crisisFlags.noWoodFuel) brief += '⚠️木柴即将耗尽！';
            }
        }
        
        // 附加全镇人员状态概要
        const aliveCount = this.game.npcs.filter(n => !n.isDead).length;
        const totalCount = this.game.npcs.length;
        const lowSanCount = this.game.npcs.filter(n => !n.isDead && n.sanity < 40).length;
        const sickCount = this.game.npcs.filter(n => !n.isDead && n.isSick).length;
        
        if (lowSanCount > 0 || sickCount > 0) {
            brief += `\n👥 全镇${aliveCount}/${totalCount}人存活`;
            if (lowSanCount > 0) brief += `，${lowSanCount}人精神状态不佳`;
            if (sickCount > 0) brief += `，${sickCount}人生病`;
            brief += '。';
        }
        
        return brief;
    };


    /** 资源紧张程度（0~1，用于AI prompt紧迫感）【v4.24】添加NaN哨兵 */
    proto.getResourceTension = function() {
        let tension = 0;
        // 食物紧张度
        if (this.food <= 0) tension += 0.4;
        else if (this.getFoodMealsRemaining() <= 1) tension += 0.3;
        else if (this.getFoodMealsRemaining() <= 3) tension += 0.1;
        // 木柴紧张度
        if (this.woodFuel <= 0) tension += 0.3;
        else if (this.getWoodFuelHoursRemaining() <= 4) tension += 0.2;
        else if (this.getWoodFuelHoursRemaining() <= 12) tension += 0.1;
        // 电力紧张度
        if (this.power <= 0) tension += 0.2;
        else if (this.getPowerHoursRemaining() <= 4) tension += 0.15;
        else if (this.getPowerHoursRemaining() <= 12) tension += 0.05;
        return Math.min(1, tension);
    };


    /** 【新增】获取各资源的紧张等级 */
    proto.getResourceUrgency = function() {
        const aliveCount = this.game.npcs.filter(n => !n.isDead).length;
        const furnaceCount = this.game.furnaceSystem ? this.game.furnaceSystem.getActiveFurnaceCount() : 1;

        // 每天消耗量估算（【v4.1】应用人口缩减系数）
        const popRatio = this.getPopulationRatio();
        const dailyWood = RESOURCE_CONSUMPTION.heatingWoodPerHour * furnaceCount * 24 * popRatio;
        const dailyFood = aliveCount * RESOURCE_CONSUMPTION.foodPerMealPerPerson * RESOURCE_CONSUMPTION.mealsPerDay;
        const dailyPower = RESOURCE_CONSUMPTION.powerPerHour * 24 * popRatio;

        const woodHours = this.getWoodFuelHoursRemaining();
        const foodMeals = this.getFoodMealsRemaining();

        return {
            wood: woodHours <= 6 ? 'critical' : (this.woodFuel < dailyWood * 0.5 ? 'warning' : 'normal'),
            food: foodMeals <= 1 ? 'critical' : (this.food < dailyFood * 0.5 ? 'warning' : 'normal'),
            power: this.getPowerHoursRemaining() <= 6 ? 'critical' : (this.power < dailyPower * 0.5 ? 'warning' : 'normal'),

        };
    };


    /** 【新增】获取资源紧张提示（注入到NPC prompt中） */
    proto.getUrgencyPrompt = function() {
        const urgency = this.getResourceUrgency();
        const alerts = [];

        // 收集各资源剩余时间，用于排序
        const resourceStatus = [];

        const woodHours = Math.round(this.getWoodFuelHoursRemaining());
        const powerHours = Math.round(this.getPowerHoursRemaining());
        const foodMeals = Math.round(this.getFoodMealsRemaining());

        if (urgency.wood === 'critical') {
            alerts.push(`🔴 木柴严重不足！仅够烧${woodHours}小时。`);
            resourceStatus.push({ name: '木柴', hours: woodHours, level: 'critical' });
        } else if (urgency.wood === 'warning') {
            alerts.push(`🟡 木柴储备偏低（${Math.round(this.woodFuel)}单位，够烧${woodHours}h）。`);
            resourceStatus.push({ name: '木柴', hours: woodHours, level: 'warning' });
        }

        if (urgency.food === 'critical') {
            alerts.push(`🔴 食物不够下一顿饭！`);
            resourceStatus.push({ name: '食物', hours: foodMeals * 12, level: 'critical' });
        } else if (urgency.food === 'warning') {
            alerts.push(`🟡 食物储备偏低（${Math.round(this.food)}单位，够吃${foodMeals}餐）。`);
            resourceStatus.push({ name: '食物', hours: foodMeals * 12, level: 'warning' });
        }

        if (urgency.power === 'critical') {
            alerts.push(`🔴 电力即将耗尽！仅剩${powerHours}小时！无电会导致暖炉耗柴+30%、医疗停摆、夜间恐惧加倍！`);
            resourceStatus.push({ name: '电力', hours: powerHours, level: 'critical' });
        } else if (urgency.power === 'warning') {
            alerts.push(`🟡 电力储备偏低（${Math.round(this.power)}单位，剩余${powerHours}h）。`);
            resourceStatus.push({ name: '电力', hours: powerHours, level: 'warning' });
        }

        if (alerts.length === 0) return '';

        // 按剩余时间排序，标注最紧急的资源
        resourceStatus.sort((a, b) => a.hours - b.hours);
        const mostUrgent = resourceStatus[0];
        if (mostUrgent) {
            alerts.push(`⚡ 当前最紧缺资源：${mostUrgent.name}（仅剩${mostUrgent.hours}小时）。`);
        }

        return `\n【资源紧急警报】\n${alerts.join('\n')}`;
    };

    // [已拆分到 resource-consumption.js] _getWoodConsumptionMultiplier
    // [已拆分到 resource-consumption.js] _getPowerConsumptionMultiplier
    /**
    * 【物资需求总览】生成从当前天到Day4的物资预估prompt
    * 分天列出木柴/食物/电力的消耗预估，汇总缺口，用emoji标注紧急程度
    * @returns {string} 物资需求总览文本，供注入LLM prompt
    */
    proto.getResourceForecastForPrompt = function() {
        try {
            const currentDay = this.game.weatherSystem ? this.game.weatherSystem.currentDay : 1;
            const currentHour = this.game.getHour ? this.game.getHour() : 12;
            const furnaceCount = this.game.furnaceSystem ? this.game.furnaceSystem.getActiveFurnaceCount() : 1;
            const aliveCount = this.game.npcs ? this.game.npcs.filter(n => !n.isDead).length : 8;
            const totalCount = this.game.npcs ? this.game.npcs.length : 8;
            const popRatio = Math.max(0.3, aliveCount / totalCount); // 【v4.1】人口缩减系数

            const woodPerHour = RESOURCE_CONSUMPTION.heatingWoodPerHour * furnaceCount * popRatio;
            const foodPerDay = aliveCount * RESOURCE_CONSUMPTION.foodPerMealPerPerson * RESOURCE_CONSUMPTION.mealsPerDay;
            const powerPerHour = RESOURCE_CONSUMPTION.powerPerHour * popRatio;

            // 温度标签映射
            const tempLabels = { 1: '0°C', 2: '-30°C', 3: '0°C', 4: '-60°C' };
            const dayNames = { 1: '准备日', 2: '寒冷天', 3: '喘息日', 4: '大极寒' };

            const lines = ['【物资需求总览】'];
            let totalWood = 0, totalFood = 0, totalPower = 0;

            for (let day = currentDay; day <= 4; day++) {
                // 【v2.1】使用连续温度公式计算乘数
                const ws = this.game.weatherSystem;
                const dayConfig = ws ? ws.getDayConfig(day) : null;
                const dayTemp = dayConfig ? dayConfig.baseTemp : 0;
                const coldFactor = Math.max(0, -dayTemp);
                const woodMult = Math.max(0.5, 1.0 + coldFactor * 0.04);
                const powerMult = Math.max(0.7, 1.0 + coldFactor * 0.02);
                const foodMult = 1.0; // 食物消耗不受温度影响

                let hours;
                if (day === currentDay) {
                    // 当天剩余小时数（从当前小时到24点）
                    hours = Math.max(1, 24 - currentHour);
                } else {
                    hours = 24;
                }

                const dayWood = Math.round(woodPerHour * hours * woodMult);
                const dayFood = day === currentDay ? Math.round(foodPerDay * (hours / 24)) : Math.round(foodPerDay);
                const dayPower = Math.round(powerPerHour * hours * powerMult);

                totalWood += dayWood;
                totalFood += dayFood;
                totalPower += dayPower;

                const label = day === currentDay ? `今天(Day${day})剩余` : `Day${day}(${dayNames[day]})`;
                const tempNote = tempLabels[day] || '';
                const multNote = woodMult > 1 ? `(${tempNote},暖炉消耗×${woodMult.toFixed(1)},电力×${powerMult.toFixed(1)})` : `(${tempNote})`;
                lines.push(`  ${label}: 木柴~${dayWood} 食物~${dayFood} 电力~${dayPower} ${multNote}`);
            }

            // 汇总
            lines.push(`总计还需: 木柴~${totalWood} 食物~${totalFood} 电力~${totalPower}`);
            lines.push(`当前库存: 木柴${Math.round(this.woodFuel)} 食物${Math.round(this.food)} 电力${Math.round(this.power)}`);

            // 缺口计算与紧急标注
            const woodGap = Math.round(this.woodFuel) - totalWood;
            const foodGap = Math.round(this.food) - totalFood;
            const powerGap = Math.round(this.power) - totalPower;

            const gapItems = [];
            const statusIcon = (gap, total) => {
                if (gap < 0) return '🔴';
                if (gap < total * 0.2) return '🟡';
                return '✅';
            };

            gapItems.push(`${statusIcon(woodGap, totalWood)}木柴${woodGap >= 0 ? '+' : ''}${woodGap}`);
            gapItems.push(`${statusIcon(foodGap, totalFood)}食物${foodGap >= 0 ? '+' : ''}${foodGap}`);
            gapItems.push(`${statusIcon(powerGap, totalPower)}电力${powerGap >= 0 ? '+' : ''}${powerGap}`);
            lines.push(`缺口: ${gapItems.join(' ')}`);

            // 缓存缺口数据供getSupplyRecommendationPrompt使用
            this._lastForecastGaps = {
                wood: woodGap < 0 ? Math.abs(woodGap) : 0,
                food: foodGap < 0 ? Math.abs(foodGap) : 0,
                power: powerGap < 0 ? Math.abs(powerGap) : 0,
            };

            return '\n' + lines.join('\n');
        } catch (e) {
            console.error('[ResourceSystem] getResourceForecastForPrompt error:', e);
            return '';
        }
    };


    /**
    * 【补给情报】根据物资缺口生成角色-资源匹配情报prompt
    * 基于缺口数据和NPC专长，提供客观的采集效率数据
    * @returns {string} 补给情报文本，供注入LLM prompt
    */
    proto.getSupplyRecommendationPrompt = function() {
        try {
            // 确保先调用getResourceForecastForPrompt()生成缺口数据
            if (!this._lastForecastGaps) {
                this.getResourceForecastForPrompt();
            }
            const gaps = this._lastForecastGaps || { wood: 0, food: 0, power: 0 };

            // 所有资源充足
            if (gaps.wood === 0 && gaps.food === 0 && gaps.power === 0) {
                return '\n【补给情报】当前各项物资储备充足，无明显缺口。';
            }

            // NPC专长映射（内联，避免跨文件依赖）
            const NPC_RESOURCE_SKILLS = {
                'zhao_chef': { name: '赵铁柱', skills: { wood: 1.5, food: 1.3 } },
                'lu_chen': { name: '陆辰', skills: { wood: 1.3, food: 1.3, power: 1.2 } },
                'li_shen': { name: '李婶', skills: { food: 1.5 } },
                'wang_teacher': { name: '王策', skills: { power: 2.0 } },
                'old_qian': { name: '老钱', skills: { morale: 2.0 }, preferMorale: true },
                'su_doctor': { name: '苏岩', skills: {} },
                'ling_yue': { name: '歆玥', skills: { food: 1.2, power: 1.2 } },
                'qing_xuan': { name: '清璇', skills: { food: 1.1 } },
            };

            // 获取存活NPC列表及其状态
            const npcs = this.game.npcs || [];
            const availableNpcs = [];
            for (const npc of npcs) {
                const skillInfo = NPC_RESOURCE_SKILLS[npc.id];
                if (!skillInfo) continue;
                if (npc.isDead) continue;

                const isExhausted = (npc.stamina < 30 || npc.health < 30);
                availableNpcs.push({
                    id: npc.id,
                    name: skillInfo.name,
                    skills: skillInfo.skills,
                    preferMorale: skillInfo.preferMorale || false,
                    stamina: npc.stamina || 0,
                    isExhausted,
                });
            }

            const lines = ['【补给情报·专长匹配】'];

            // 计算各资源剩余可用时间（小时），用于紧急度排序
            const woodHoursLeft = this.getWoodFuelHoursRemaining();
            const powerHoursLeft = this.getPowerHoursRemaining();
            const foodMealsLeft = this.getFoodMealsRemaining();
            // 食物转换为等效小时数（每天2餐，每12小时1餐）
            const foodHoursLeft = foodMealsLeft * 12;

            // 资源缺口排序推荐
            const resourceNeeds = [];
            if (gaps.wood > 0) resourceNeeds.push({ type: 'wood', label: '木柴', gap: gaps.wood, skillKey: 'wood', hoursLeft: woodHoursLeft, urgencyNote: `当前够烧${Math.round(woodHoursLeft)}小时` });
            if (gaps.food > 0) resourceNeeds.push({ type: 'food', label: '食物', gap: gaps.food, skillKey: 'food', hoursLeft: foodHoursLeft, urgencyNote: `当前够吃${Math.round(foodMealsLeft)}餐` });
            if (gaps.power > 0) resourceNeeds.push({ type: 'power', label: '电力', gap: gaps.power, skillKey: 'power', hoursLeft: powerHoursLeft, urgencyNote: `当前仅剩${Math.round(powerHoursLeft)}小时` });

            // 【修复】按剩余可用小时数排序（越少越紧急），而非按缺口绝对值
            resourceNeeds.sort((a, b) => a.hoursLeft - b.hoursLeft);

            for (const need of resourceNeeds) {
                const icon = need.gap > 30 ? '🔴' : '🟡';

                // 按专长倍率排序推荐NPC
                const ranked = availableNpcs
                    .filter(n => !n.preferMorale) // 老钱优先安抚，不推荐去采集
                    .map(n => ({
                        name: n.name,
                        mult: n.skills[need.skillKey] || 1.0,
                        isExhausted: n.isExhausted,
                        stamina: n.stamina,
                    }))
                    .sort((a, b) => {
                        if (a.mult !== b.mult) return b.mult - a.mult;
                        return b.stamina - a.stamina;
                    });

                const recommendations = ranked.map(r => {
                    let tag = r.name;
                    if (r.mult > 1.0) tag += `(效率×${r.mult})`;
                    if (r.isExhausted) tag += '(体力不支)';
                    return tag;
                }).join('、');

                const urgencyTag = need.hoursLeft <= 6 ? '极度短缺' : need.hoursLeft <= 12 ? '短缺' : '';
                lines.push(`${icon} ${need.label}缺口${need.gap}单位（${need.urgencyNote}${urgencyTag ? ',' + urgencyTag : ''}） | 高效采集者：${recommendations}`);
            }

            return '\n' + lines.join('\n');
        } catch (e) {
            console.error('[ResourceSystem] getSupplyRecommendationPrompt error:', e);
            return '';
        }
    };


    /** 【v4.1】获取存活人口缩减系数（人少了消耗降低，最低30%） */
    proto.getPopulationRatio = function() {
        const total = this.game.npcs ? this.game.npcs.length : 8;
        const alive = this.game.npcs ? this.game.npcs.filter(n => !n.isDead).length : 8;
        return Math.max(0.3, alive / total);
    };

})();
