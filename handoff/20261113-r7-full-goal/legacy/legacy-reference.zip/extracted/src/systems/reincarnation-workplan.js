/**
 * 福音镇 - 轮回工作计划生成
 * 从 reincarnation-system.js 拆分，遵循SRP原则
 * 挂载到 GST.ReincarnationSystem.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.ReincarnationSystem.prototype;

    // [已拆分到 reincarnation-memory.js] getCompositePastLifeHint
    // [已拆分到 reincarnation-memory.js] getLastLifeData
    // [已拆分到 reincarnation-memory.js] getLastLifeDeathRecords
    // [已拆分到 reincarnation-memory.js] getLastLifeResourceSnapshot
    // [已拆分到 reincarnation-memory.js] getLastLifeLessons
    // [已拆分到 reincarnation-memory.js] getLastLifeConflictEvents
    // [已拆分到 reincarnation-memory.js] getLastLifeAliveCount
    // [已拆分到 reincarnation-memory.js] getLastLifeEndingType
    // [已拆分到 reincarnation-memory.js] wasNpcDeadLastLife
    // [已拆分到 reincarnation-memory.js] getNpcDeathCauseLastLife
    // ============ 【需求1】轮回经验自动生成分工方案 ============

    /**
    * 基于前世数据生成本世分工方案
    * 在每世开始时由game.js调用，结果存储到老钱的workPlan属性
    * @returns {{ dayPlans: Object, summary: string, workPlanSummary: string }} 分工方案
    */
    proto.generateWorkPlan = function() {
        const pastLives = this.pastLives;
        const lifeNum = this.currentLifeNumber;

        // 第1世无前世记忆：返回默认方案
        if (lifeNum <= 1 || pastLives.length === 0) {
            return this._getDefaultWorkPlan();
        }

        const lastLife = pastLives[pastLives.length - 1];
        const multiLifeAnalysis = this.analyzeMultiLifePatterns();

        // 【修复A】查找历史上最好的一世，优先复用其成功方案
        const bestLife = this._findBestLife();

        // 如果历史上有完美结局的世代且保存了分工方案 → 直接复用成功方案
        if (bestLife && bestLife.aliveCount >= 8 && bestLife.workPlan) {
            console.log(`[WorkPlan] 第${lifeNum}世：复用第${bestLife.lifeNumber}世的完美方案`);
            const reusedPlan = JSON.parse(JSON.stringify(bestLife.workPlan));
            reusedPlan.strategy = 'reuse_perfect';
            reusedPlan.summary = `第${lifeNum}世(复用第${bestLife.lifeNumber}世完美方案):直接沿用成功策略`;
            reusedPlan.workPlanSummary = this._generateWorkPlanSummary(reusedPlan);
            return reusedPlan;
        }

        // 如果历史上有较好的世代（存活>=7）且保存了方案，以它为基础微调
        if (bestLife && bestLife.aliveCount >= 7 && bestLife.workPlan && bestLife.aliveCount > lastLife.aliveCount) {
            console.log(`[WorkPlan] 第${lifeNum}世：以第${bestLife.lifeNumber}世(${bestLife.aliveCount}存活)的方案为基础微调`);
            return this._generateOptimizedPlanFromBase(bestLife, lastLife, multiLifeAnalysis);
        }

        // 前世全员存活：基本保持不变，微调过剩资源
        if (lastLife.aliveCount >= 8) {
            return this._generateOptimizedPlan(lastLife, multiLifeAnalysis, 'maintain');
        }

        // 存活人数下降：激进调整
        return this._generateOptimizedPlan(lastLife, multiLifeAnalysis, 'aggressive');
    };


    /** 第1世默认分工方案（等价于task-system的硬编码） */
    proto._getDefaultWorkPlan = function() {
        const plan = {
            dayPlans: {
                1: [
                    { npcId: 'zhao_chef', task: 'COLLECT_WOOD', targetLocation: 'lumber_camp', reason: '默认：砍柴' },
                    { npcId: 'lu_chen', task: 'COLLECT_WOOD', targetLocation: 'lumber_camp', reason: '默认：砍柴' },
                    { npcId: 'li_shen', task: 'COLLECT_FOOD', targetLocation: 'frozen_lake', reason: '默认：采食物' },
                    { npcId: 'wang_teacher', task: 'MAINTAIN_POWER', targetLocation: 'workshop_door', reason: '默认：维护电力' },
                    { npcId: 'old_qian', task: 'COORDINATE', targetLocation: 'dorm_a_door', reason: '默认：统筹协调' },
                    { npcId: 'su_doctor', task: 'PREPARE_MEDICAL', targetLocation: 'medical_door', reason: '默认：医疗准备' },
                    { npcId: 'ling_yue', task: 'SCOUT_RUINS', targetLocation: 'ruins_site', reason: '默认：废墟侦察' },
{ npcId: 'qing_xuan', task: 'PREPARE_MEDICAL', targetLocation: 'medical_door', reason: '默认：医疗救治' },
                ],
                2: [
                    { npcId: 'zhao_chef', task: 'COLLECT_WOOD', targetLocation: 'lumber_camp', reason: '冒险砍柴(限2h)' },
                    { npcId: 'lu_chen', task: 'COLLECT_FOOD', targetLocation: 'frozen_lake', reason: '冒险采食(限2h)' },
                    { npcId: 'li_shen', task: 'DISTRIBUTE_FOOD', targetLocation: 'kitchen_door', reason: '分配食物' },
                    { npcId: 'wang_teacher', task: 'MAINTAIN_POWER', targetLocation: 'workshop_door', reason: '维护电力' },
                    { npcId: 'old_qian', task: 'MAINTAIN_ORDER', targetLocation: 'dorm_a_door', reason: '安抚情绪' },
                    { npcId: 'su_doctor', task: 'PREPARE_MEDICAL', targetLocation: 'medical_door', reason: '医疗待命' },
                    { npcId: 'ling_yue', task: 'BOOST_MORALE', targetLocation: 'dorm_a_door', reason: '鼓舞士气' },
{ npcId: 'qing_xuan', task: 'PREPARE_MEDICAL', targetLocation: 'medical_door', reason: '医疗救治' },
                ],
                3: [
                    { npcId: 'zhao_chef', task: 'COLLECT_WOOD', targetLocation: 'lumber_camp', reason: '补充木柴为第4天' },
                    { npcId: 'lu_chen', task: 'MAINTAIN_POWER', targetLocation: 'workshop_door', reason: '补充供暖电力储备' },
                    { npcId: 'li_shen', task: 'COLLECT_FOOD', targetLocation: 'frozen_lake', reason: '补充食物' },
                    { npcId: 'wang_teacher', task: 'MAINTAIN_POWER', targetLocation: 'workshop_door', reason: '加固供暖系统' },
                    { npcId: 'old_qian', task: 'COORDINATE', targetLocation: 'dorm_a_door', reason: '统筹第4天准备' },
                    { npcId: 'su_doctor', task: 'PREPARE_MEDICAL', targetLocation: 'medical_door', reason: '医疗准备' },
                    { npcId: 'ling_yue', task: 'SCOUT_RUINS', targetLocation: 'ruins_site', reason: '最后侦察' },
                    { npcId: 'qing_xuan', task: 'PREPARE_MEDICAL', targetLocation: 'medical_door', reason: '医疗准备' },
                ],
                4: [
                    { npcId: 'zhao_chef', task: 'PREPARE_WARMTH', targetLocation: 'warehouse_door', reason: '准备御寒物资(室内)' },
                    { npcId: 'lu_chen', task: 'PREPARE_WARMTH', targetLocation: 'warehouse_door', reason: '准备御寒物资(室内)' },
                    { npcId: 'li_shen', task: 'DISTRIBUTE_FOOD', targetLocation: 'kitchen_door', reason: '分配食物(室内)' },
                    { npcId: 'wang_teacher', task: 'MAINTAIN_POWER', targetLocation: 'workshop_door', reason: '维护电力(室内)' },
                    { npcId: 'old_qian', task: 'MAINTAIN_ORDER', targetLocation: 'dorm_a_door', reason: '维持秩序(室内)' },
                    { npcId: 'su_doctor', task: 'PREPARE_MEDICAL', targetLocation: 'medical_door', reason: '医疗待命(室内)' },
                    { npcId: 'ling_yue', task: 'BOOST_MORALE', targetLocation: 'dorm_a_door', reason: '鼓舞士气(室内)' },
{ npcId: 'qing_xuan', task: 'PREPARE_MEDICAL', targetLocation: 'medical_door', reason: '医疗救治(室内)' },
                ],
            },
            strategy: 'default',
            summary: '第1世：默认分工方案',
            workPlanSummary: '第1世默认:赵砍柴,陆砍柴,李食物,王电力,钱统筹,苏医疗,玥侦察,璇制药',
        };
        return plan;
    };


    /** 基于前世数据优化分工方案 */
    proto._generateOptimizedPlan = function(lastLife, multiLifeAnalysis, mode) {
        // 从默认方案开始，然后根据前世数据调整
        const plan = this._getDefaultWorkPlan();
        plan.strategy = mode;

        const rs = lastLife.resourceSnapshot;
        const deaths = lastLife.deathRecords || [];
        const lessons = this._generateDeepLessons(lastLife);

        // ===== 资源瓶颈分析 =====
        const bottlenecks = this._analyzeResourceBottlenecks(rs);

        // ===== Day 1 调整 =====
        if (bottlenecks.woodFuel === 'critical') {
            // 木柴严重不足：增派陆辰也去砍柴
            plan.dayPlans[1] = plan.dayPlans[1].map(a => {
                if (a.npcId === 'lu_chen') return { ...a, task: 'COLLECT_WOOD', targetLocation: 'lumber_camp', reason: `前世木柴仅剩${rs.woodFuel}，增派砍柴` };
                return a;
            });
        }
        if (bottlenecks.food === 'critical') {
            // 食物严重不足：歆玥改为采集食物
            plan.dayPlans[1] = plan.dayPlans[1].map(a => {
                if (a.npcId === 'ling_yue') return { ...a, task: 'COLLECT_FOOD', targetLocation: 'frozen_lake', reason: `前世食物仅剩${rs.food}，增派采食物` };
                return a;
            });
        }
        if (bottlenecks.power === 'critical') {
            // 电力不足：第1天就让歆玥去矿渣堆采矿
            plan.dayPlans[1] = plan.dayPlans[1].map(a => {
                if (a.npcId === 'ling_yue') return { ...a, task: 'COLLECT_POWER', targetLocation: 'ore_pile', reason: `前世电力仅剩${rs.power}，增派采矿` };
                return a;
            });
        }

        // ===== Day 2 调整（户外限2h）=====
        const day2FrozenDeaths = deaths.filter(d => d.cause === '冻死' && d.day <= 2);
        if (day2FrozenDeaths.length > 0 && mode === 'aggressive') {
            // 前世第2天有人冻死：减少户外工作，全部转室内
            plan.dayPlans[2] = plan.dayPlans[2].map(a => {
                if (a.task === 'COLLECT_WOOD' || a.task === 'COLLECT_FOOD' || a.task === 'SCOUT_RUINS') {
                    return { ...a, task: 'PREPARE_WARMTH', targetLocation: 'warehouse_door', reason: `前世${day2FrozenDeaths.map(d => d.name).join('、')}第2天冻死，改为室内准备御寒` };
                }
                return a;
            });
        }

        // ===== Day 3 调整 =====
        if (!lastLife.secondFurnaceBuilt) {
            // 前世暖炉未建：增派赵铁柱也去建暖炉
            plan.dayPlans[3] = plan.dayPlans[3].map(a => {
                if (a.npcId === 'zhao_chef') return { ...a, task: 'BUILD_FURNACE', targetLocation: 'dorm_b_door', reason: '前世暖炉未建！全力建造' };
                return a;
            });
        }
        if (bottlenecks.power === 'critical') {
            // 电力不足：第3天清璇也去维护电力
            plan.dayPlans[3] = plan.dayPlans[3].map(a => {
                if (a.npcId === 'qing_xuan') return { ...a, task: 'MAINTAIN_POWER', targetLocation: 'workshop_door', reason: `前世电力仅剩${rs.power}，增派维护` };
                return a;
            });
        }

        // ===== 应用多世模式分析 =====
        if (multiLifeAnalysis && multiLifeAnalysis.failurePatterns.length > 0) {
            for (const pattern of multiLifeAnalysis.failurePatterns) {
                if (pattern.includes('木柴') && pattern.includes('连续')) {
                    // 连续多世木柴不足：第1天派3人砍柴
                    plan.dayPlans[1] = plan.dayPlans[1].map(a => {
                        if (a.npcId === 'ling_yue') return { ...a, task: 'COLLECT_WOOD', targetLocation: 'lumber_camp', reason: '🔴连续多世木柴不足！全力砍柴' };
                        return a;
                    });
                }
                if (pattern.includes('食物') && pattern.includes('连续')) {
                    plan.dayPlans[1] = plan.dayPlans[1].map(a => {
                        if (a.npcId === 'ling_yue') return { ...a, task: 'COLLECT_FOOD', targetLocation: 'frozen_lake', reason: '🔴连续多世食物不足！全力采集' };
                        return a;
                    });
                }
            }
        }

        // ===== 前世全员存活时的微调 =====
        if (mode === 'maintain' && rs) {
            // 找过剩资源，将对应人力转到最缺的资源
            const surplus = [];
            const deficit = [];
            if (rs.woodFuel > 80) surplus.push('woodFuel');
            else if (rs.woodFuel < 30) deficit.push('woodFuel');
            if (rs.food > 40) surplus.push('food');
            else if (rs.food < 15) deficit.push('food');
            if (rs.power > 50) surplus.push('power');
            else if (rs.power < 15) deficit.push('power');

            // 如果有过剩且有缺口，调整Day1
            if (surplus.length > 0 && deficit.length > 0) {
                const surplusTask = surplus[0] === 'woodFuel' ? 'COLLECT_WOOD' : surplus[0] === 'food' ? 'COLLECT_FOOD' : 'MAINTAIN_POWER';
                const deficitTask = deficit[0] === 'woodFuel' ? 'COLLECT_WOOD' : deficit[0] === 'food' ? 'COLLECT_FOOD' : 'MAINTAIN_POWER';
                const deficitLoc = deficit[0] === 'woodFuel' ? 'lumber_camp' : deficit[0] === 'food' ? 'frozen_lake' : 'workshop_door';
                // 找第一个做过剩资源的NPC改为做缺口资源
                for (let i = 0; i < plan.dayPlans[1].length; i++) {
                    if (plan.dayPlans[1][i].task === surplusTask) {
                        plan.dayPlans[1][i] = { ...plan.dayPlans[1][i], task: deficitTask, targetLocation: deficitLoc, reason: `前世${surplus[0]}过剩(${rs[surplus[0]]}),调去补${deficit[0]}` };
                        break;
                    }
                }
            }
        }

        // 生成摘要（≤200字符）
        plan.summary = `第${this.currentLifeNumber}世(${mode}):基于前世${lastLife.aliveCount}/8存活调整`;
        plan.workPlanSummary = this._generateWorkPlanSummary(plan);

        console.log(`[WorkPlan] 第${this.currentLifeNumber}世分工方案生成:`, plan.summary);
        return plan;
    };


    /** 分析资源瓶颈 */
    proto._analyzeResourceBottlenecks = function(rs) {
        if (!rs) return {};
        const result = {};
        // 木柴
        if (rs.woodFuel < 15) result.woodFuel = 'critical';
        else if (rs.woodFuel < 40) result.woodFuel = 'warning';
        else result.woodFuel = 'ok';
        // 食物
        if (rs.food < 8) result.food = 'critical';
        else if (rs.food < 20) result.food = 'warning';
        else result.food = 'ok';
        // 电力
        if (rs.power < 10) result.power = 'critical';
        else if (rs.power < 25) result.power = 'warning';
        else result.power = 'ok';
        return result;
    };


    /** 生成工作安排摘要（≤200字符） */
    proto._generateWorkPlanSummary = function(plan) {
        const nameMap = { zhao_chef: '赵', lu_chen: '陆', li_shen: '李', wang_teacher: '王', old_qian: '钱', su_doctor: '苏', ling_yue: '玥', qing_xuan: '璇' };
        const taskShort = { COLLECT_WOOD: '砍柴', COLLECT_FOOD: '采食', COLLECT_MATERIAL: '探索', MAINTAIN_POWER: '电力', COORDINATE: '统筹', PREPARE_MEDICAL: '医疗', SCOUT_RUINS: '侦察', BOOST_MORALE: '鼓舞', PREPARE_WARMTH: '御寒', MAINTAIN_ORDER: '秩序', DISTRIBUTE_FOOD: '分食', REST_RECOVER: '休息' };
        // 只输出Day1的安排
        const day1 = (plan.dayPlans[1] || []).map(a => `${nameMap[a.npcId] || '?'}${taskShort[a.task] || a.task}`).join(',');
        let summary = `D1:${day1}`;
        if (summary.length > 200) summary = summary.substring(0, 197) + '…';
        return summary;
    };


    // ============ 【需求3】前世教训深度分析 ============

    /** 深度教训生成（分层：战略/战术/执行）— 优先读取LLM预生成，fallback到硬编码 */
    proto._generateDeepLessons = function(lastLife) {
        // 优先使用LLM预生成的深度教训（在savePastLife时已生成并存入summary）
        if (lastLife.deepLessons) {
            return lastLife.deepLessons;
        }
        // fallback: 硬编码分析
        return this._generateDeepLessonsFallback(lastLife);
    };


    /** 硬编码深度教训fallback */
    proto._generateDeepLessonsFallback = function(lastLife) {
        const strategic = [];  // 战略层
        const tactical = [];   // 战术层（与特定NPC相关）
        const execution = [];  // 执行层（具体行动建议）

        const rs = lastLife.resourceSnapshot;
        const deaths = lastLife.deathRecords || [];
        const npcStates = lastLife.npcFinalStates || [];
        const unfinished = lastLife.unfinishedTasks || [];

        // ===== 资源比例分析 =====
        if (rs && rs.totalCollected) {
            const tc = rs.totalCollected;
        const total = (tc.woodFuel || 0) + (tc.food || 0) + (tc.power || 0);
            if (total > 0) {
                const woodRatio = (tc.woodFuel || 0) / total;
                const foodRatio = (tc.food || 0) / total;
                const powerRatio = (tc.power || 0) / total;
                // 检测偏科
                if (woodRatio > 0.5) strategic.push(`资源分配偏科：木柴占采集总量${Math.round(woodRatio * 100)}%，其他资源被忽视`);
                if (foodRatio < 0.15 && rs.food < 20) strategic.push(`食物采集严重不足，仅占总采集量${Math.round(foodRatio * 100)}%`);
                if (powerRatio < 0.1 && rs.power < 15) strategic.push(`电力维护不足，仅占总采集量${Math.round(powerRatio * 100)}%`);
            }
        }

        // ===== 人力分配分析 =====
        for (const state of npcStates) {
            if (state.isDead) continue;
            // 体力还很高的NPC → 可能没充分利用
            if (state.stamina > 70) {
                tactical.push(`${state.name}体力剩余${state.stamina}%，劳动力未充分利用，可增加工作量`);
            }
            // San值极低但未死 → 缺乏精神维护
            if (state.sanity < 20) {
                tactical.push(`${state.name}精神濒危(San:${state.sanity})，需要更多安抚和休息`);
            }
        }

        // ===== 时序分析 =====
        const deathsByDay = {};
        for (const d of deaths) {
            if (!deathsByDay[d.day]) deathsByDay[d.day] = [];
            deathsByDay[d.day].push(d);
        }
        for (const [day, dayDeaths] of Object.entries(deathsByDay)) {
            if (dayDeaths.length >= 2) {
                strategic.push(`第${day}天有${dayDeaths.length}人死亡(${dayDeaths.map(d => d.name + d.cause).join('、')})，该天安排严重失误`);
            }
        }

        // ===== 因果链推导 =====
        const frozenDeaths = deaths.filter(d => d.cause === '冻死');
        if (frozenDeaths.length > 0) {
            if (rs && rs.woodFuel < 20) {
                execution.push(`因果链：木柴不足(剩${rs.woodFuel}) → ${frozenDeaths.map(d => d.name).join('、')}冻死 → 赵铁柱+陆辰的砍柴专长倍率最高`);
            }
            const outdoorFrozen = frozenDeaths.filter(d => d.location === 'village');
            if (outdoorFrozen.length > 0) {
                execution.push(`因果链：${outdoorFrozen.map(d => d.name).join('、')}在户外冻死 → 第${outdoorFrozen[0].day}天户外连续工作超过2小时会严重冻伤`);
            }
        }

        const starvedDeaths = deaths.filter(d => d.cause === '饿死');
        if (starvedDeaths.length > 0) {
            execution.push(`因果链：食物不足(剩${rs ? rs.food : '?'}) → ${starvedDeaths.map(d => d.name).join('、')}饿死 → 李婶+陆辰的食物采集专长倍率最高`);
        }

        // 供暖准备不足因果链
        if (!lastLife.secondFurnaceBuilt) {
            const day4Deaths = deaths.filter(d => d.day >= 4);
            if (day4Deaths.length > 0) {
                execution.push(`因果链：木材/电力准备不足 → 第4天供暖强度不够 → ${day4Deaths.map(d => d.name).join('、')}死亡 → 第3天木材和电力储备未达标`);
            } else {
                execution.push(`上世供暖准备不足，第3天木材和电力储备未达到第4天集中供暖所需的最低量`);
            }
        }

    // ===== 【修复D】扫描所有历史记录，识别长期反复出现的问题 =====
        if (this.pastLives.length >= 2) {
            // 统计所有历史中各问题出现的次数
            let woodShortCount = 0;
            let foodShortCount = 0;
            let furnaceFailCount = 0;
            const dayDeathCounts = { 1: 0, 2: 0, 3: 0, 4: 0 }; // 每天大量死亡的世数
            let consecutiveWoodShort = 0;
            let consecutiveFoodShort = 0;
            let consecutiveFurnaceFail = 0;

            for (let i = this.pastLives.length - 1; i >= 0; i--) {
                const life = this.pastLives[i];
                const rs = life.resourceSnapshot;
                // 木柴不足
                if (rs && rs.woodFuel < 30) {
                    woodShortCount++;
                    if (i === this.pastLives.length - 1 - (this.pastLives.length - 1 - i)) consecutiveWoodShort++;
                }
                // 食物不足
                if (rs && rs.food < 15) {
                    foodShortCount++;
                    if (i === this.pastLives.length - 1 - (this.pastLives.length - 1 - i)) consecutiveFoodShort++;
                }
                // 供暖准备不足
                if (!life.secondFurnaceBuilt) {
                    furnaceFailCount++;
                    if (i === this.pastLives.length - 1 - (this.pastLives.length - 1 - i)) consecutiveFurnaceFail++;
                }
                // 某天大量死亡
                for (let day = 1; day <= 4; day++) {
                    const dayD = (life.deathRecords || []).filter(d => d.day === day).length;
                    if (dayD >= 2) dayDeathCounts[day]++;
                }
            }

            // 计算真正的连续次数（从最近一世往回数）
            consecutiveWoodShort = 0;
            consecutiveFoodShort = 0;
            consecutiveFurnaceFail = 0;
            for (let i = this.pastLives.length - 1; i >= 0; i--) {
                const life = this.pastLives[i];
                const rs = life.resourceSnapshot;
                if (rs && rs.woodFuel < 30) consecutiveWoodShort++; else break;
            }
            for (let i = this.pastLives.length - 1; i >= 0; i--) {
                const life = this.pastLives[i];
                const rs = life.resourceSnapshot;
                if (rs && rs.food < 15) consecutiveFoodShort++; else break;
            }
            for (let i = this.pastLives.length - 1; i >= 0; i--) {
                if (!this.pastLives[i].secondFurnaceBuilt) consecutiveFurnaceFail++; else break;
            }

            // 生成严重警告
            if (consecutiveWoodShort >= 3) {
                strategic.unshift(`🔴🔴 连续${consecutiveWoodShort}世木柴严重不足！历史共${woodShortCount}/${this.pastLives.length}世木柴不够。赵铁柱砍柴效率×1.5，陆辰×1.3。`);
            } else if (consecutiveWoodShort >= 2) {
                strategic.unshift(`🔴 连续${consecutiveWoodShort}世木柴不足！增加砍柴人手`);
            }

            if (consecutiveFoodShort >= 3) {
                strategic.unshift(`🔴🔴 连续${consecutiveFoodShort}世食物严重不足！历史共${foodShortCount}/${this.pastLives.length}世食物不够。李婶采集食物效率×1.5，陆辰×1.3。`);
            } else if (consecutiveFoodShort >= 2) {
                strategic.unshift(`🔴 连续${consecutiveFoodShort}世食物不足！增加食物采集`);
            }

            if (consecutiveFurnaceFail >= 3) {
                strategic.unshift(`🔴🔴 连续${consecutiveFurnaceFail}世供暖准备不足！历史共${furnaceFailCount}/${this.pastLives.length}世失败。Day3木材和电力储备未达到第4天集中供暖所需的最低量。`);
            } else if (consecutiveFurnaceFail >= 2) {
                strategic.unshift(`🔴 连续${consecutiveFurnaceFail}世供暖准备不足！Day3木材和电力储备未达标`);
            }

            for (let day = 1; day <= 4; day++) {
                if (dayDeathCounts[day] >= 3) {
                    strategic.unshift(`🔴🔴 历史上有${dayDeathCounts[day]}世在第${day}天大量死亡！该天策略完全失败，需彻底改变`);
                } else if (dayDeathCounts[day] >= 2) {
                    strategic.unshift(`🔴 有${dayDeathCounts[day]}世在第${day}天大量死亡，需重点防范`);
                }
            }
        }

        return { strategic, tactical, execution };
    };


    // ============ 【需求6】多世学习演进 ============

    /** 综合多世数据识别成功/失败模式
    *  【修复B】扩大分析视野：从最近3世→全部历史
    */
    proto.analyzeMultiLifePatterns = function() {
        if (this.pastLives.length < 2) {
            return { successPatterns: [], failurePatterns: [], trends: {} };
        }

        const lives = this.pastLives; // 【修复B】分析全部历史，不再限制3世
        const successPatterns = [];
        const failurePatterns = [];
        const trends = { aliveCount: [], woodFuel: [], food: [], power: [] };

        // 收集趋势数据
        for (const life of lives) {
            trends.aliveCount.push(life.aliveCount);
            if (life.resourceSnapshot) {
                trends.woodFuel.push(life.resourceSnapshot.woodFuel);
                trends.food.push(life.resourceSnapshot.food);
                trends.power.push(life.resourceSnapshot.power);
            }
        }

        // 分析存活趋势
        if (trends.aliveCount.length >= 2) {
            const last = trends.aliveCount[trends.aliveCount.length - 1];
            const prev = trends.aliveCount[trends.aliveCount.length - 2];
            if (last > prev) {
                successPatterns.push(`存活人数从${prev}提升到${last}，策略在改善`);
            } else if (last < prev) {
                failurePatterns.push(`存活人数从${prev}下降到${last}，策略在退步`);
            }
        }

        // 资源趋势
        for (const [resName, values] of Object.entries(trends)) {
            if (resName === 'aliveCount' || values.length < 2) continue;
            const last = values[values.length - 1];
            const prev = values[values.length - 2];
            if (last < prev * 0.5) {
                failurePatterns.push(`${resName}连续下降(${Math.round(prev)}→${Math.round(last)})，需增加采集`);
            } else if (last > prev * 1.5) {
                successPatterns.push(`${resName}大幅提升(${Math.round(prev)}→${Math.round(last)})，采集策略有效`);
            }
        }

        // 检测反复死亡模式
        const deathCauseCounts = {};
        const deathDayCounts = {};
        for (const life of lives) {
            for (const d of (life.deathRecords || [])) {
                deathCauseCounts[d.cause] = (deathCauseCounts[d.cause] || 0) + 1;
                const key = `day${d.day}_${d.cause}`;
                deathDayCounts[key] = (deathDayCounts[key] || 0) + 1;
            }
        }
        for (const [cause, count] of Object.entries(deathCauseCounts)) {
            if (count >= lives.length) {
                failurePatterns.push(`连续${count}世有人${cause}，该问题从未解决`);
            }
        }
        for (const [key, count] of Object.entries(deathDayCounts)) {
            if (count >= 2) {
                failurePatterns.push(`连续多世在${key.replace('_', '天')}，需重点防范`);
            }
        }

        // 检测成功世代的分配特征
        for (const life of lives) {
            if (life.aliveCount >= 7 && life.resourceSnapshot) {
                const rs = life.resourceSnapshot;
                if (rs.woodFuel > 50) successPatterns.push(`第${life.lifeNumber}世木柴充足(${Math.round(rs.woodFuel)})，砍柴策略可复用`);
                if (life.secondFurnaceBuilt) successPatterns.push(`第${life.lifeNumber}世供暖准备充分，资源分配时机可复用`);
            }
        }

        return { successPatterns, failurePatterns, trends };
    };

})();
