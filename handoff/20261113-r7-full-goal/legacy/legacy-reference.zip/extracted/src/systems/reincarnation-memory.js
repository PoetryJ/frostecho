/**
 * 福音镇 - 轮回记忆与提示
 * 从 reincarnation-system.js 拆分，遵循SRP原则
 * 挂载到 GST.ReincarnationSystem.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.ReincarnationSystem.prototype;


    // ============ Prompt 生成方法 ============

    /**
    * 生成对话用的前世记忆提示（≤300字符）
    * @param {boolean} isReincarnationMode - 是否轮回模式，轮回模式下记忆更清晰直接
    /**
    * 生成对话用的前世记忆提示（≤400字符）
    * 【修复C】综合多世记忆，不再只看上一世
    * @param {boolean} isReincarnationMode - 是否轮回模式，轮回模式下记忆更清晰直接
    */
    proto.getPastLifeHintForDialogue = function(isReincarnationMode = false) {
        if (this.currentLifeNumber <= 1 || this.pastLives.length === 0) {
            return ''; // 第1世不注入
        }

        const lastLife = this.pastLives[this.pastLives.length - 1];
        const bestLife = this._findBestLife();
        let hint = '';

        if (isReincarnationMode) {
            const isFirstReincarnation = (this.currentLifeNumber === 2);

            if (isFirstReincarnation) {
                hint += `【第2世·首次轮回重生】你清楚地记得上一世发生的一切。`;
                const endingDesc = {
                    perfect: '虽然上一世全员存活，但你突然发现自己又回到了第1天的起点',
                    normal: '上一世大部分人活了下来，但你突然发现时间倒流，一切重新开始了',
                    bleak: '上一世只有少数人活下来，你眼睁睁看着同伴一个个倒下，然后突然——你又回到了第1天',
                    extinction: '上一世所有人都死了，你记得自己最后的意识在消散，然后突然——你睁开眼，发现自己又回到了第1天的起点，所有人都活着站在你面前',
                };
                hint += `${endingDesc[lastLife.endingType] || '上一世结局惨烈，然后你突然发现自己回到了第1天'}。`;
                hint += `这是你第一次经历这种"死而复生"，你不知道为什么会这样。`;
            } else {
                hint += `【前世记忆(清晰)·第${this.currentLifeNumber}世】你已经经历了${this.pastLives.length}次轮回。`;
            }

            // 【优化】优先使用LLM精炼总结（信息密度更高，语言更自然）
            if (lastLife.lifeSummary && lastLife.lifeSummary.forDialogue) {
                hint += lastLife.lifeSummary.forDialogue;
            } else {
                // fallback: 硬编码拼接
                const endingNames = { perfect: '全员存活', normal: '大部分人存活', bleak: '只有少数人活下来', extinction: '全员死亡' };
                hint += `上一世${endingNames[lastLife.endingType] || '结局不明'}（${lastLife.aliveCount}/8人存活）。`;

                if (bestLife && bestLife !== lastLife && bestLife.aliveCount > lastLife.aliveCount) {
                    hint += `但第${bestLife.lifeNumber}世最好(${bestLife.aliveCount}/8存活)。`;
                }

                if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                    const deaths = lastLife.deathRecords.slice(0, 3);
                    hint += `上世${deaths.map(d => `${d.name}在第${d.day}天${d.cause}`).join('，')}。`;
                }

                if (lastLife.lessons && lastLife.lessons.length > 0) {
                    hint += `教训：${lastLife.lessons.slice(0, 2).join('；')}。`;
                }
            }

            // 对话规则
            if (isFirstReincarnation) {
                hint += '你可以根据当前情境自然地表达对重生的困惑，也可以引用前世教训来指导行动。';
            } else {
                hint += '前世记忆作为背景情报参考，重点关注当前实际状况。';
            }
        } else {
            // 非轮回模式：模糊语言
            if (this.currentLifeNumber === 2) {
                hint += '【前世记忆(模糊)】你好像做了一个很长的噩梦…';
            } else {
                hint += `【前世记忆(模糊)】你有一种强烈的既视感，好像经历过${this.currentLifeNumber - 1}次了…`;
            }

            const endingNames = { perfect: '全员存活', normal: '大部分人存活', bleak: '只有少数人活下来', extinction: '全员死亡' };
            hint += `梦里${endingNames[lastLife.endingType] || '结局模糊'}。`;

            if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                const deaths = lastLife.deathRecords.slice(0, 3);
                hint += `隐约记得${deaths.map(d => `${d.name}好像${d.cause === '冻死' ? '被冻僵了' : d.cause === '饿死' ? '饿倒了' : '出了事'}`).join('，')}。`;
            }

            if (lastLife.lessons && lastLife.lessons.length > 0) {
                hint += `总觉得${lastLife.lessons[0]}。`;
            }

            hint += '说话时可隐晦提及前世感觉，但保持模糊（用"隐约记得"、"总觉得"、"好像梦到过"等词）。';
        }

        // 截断
        const maxLen = (isReincarnationMode && this.currentLifeNumber === 2) ? 500 : 400;
        if (hint.length > maxLen) {
            hint = hint.substring(0, maxLen - 3) + '…';
        }

        return hint;
    }

    /**

    * 生成思考/行动决策用的前世经验参考
    * 【修复C】综合多世记忆，引用历史最好成绩和成功方案
    * @param {boolean} isReincarnationMode - 是否轮回模式，轮回模式下给出更具体的行动指令
    */
    proto.getPastLifeHintForThinking = function(isReincarnationMode = false) {
        if (this.currentLifeNumber <= 1 || this.pastLives.length === 0) {
            return ''; // 第1世不注入
        }

        const lastLife = this.pastLives[this.pastLives.length - 1];
        // 【修复C】找到历史最好的一世 + 综合多世分析
        const bestLife = this._findBestLife();
        const multiAnalysis = this.analyzeMultiLifePatterns();
        let hint = '';

        if (isReincarnationMode) {
            // 轮回模式：记忆完全清晰
            const isFirstReincarnation = (this.currentLifeNumber === 2);

            if (isFirstReincarnation) {
                hint += `【第2世·首次轮回重生】你清楚地记得上一世的一切，突然发现自己回到了第1天的起点。`;
            } else {
                hint += `【第${this.currentLifeNumber}世·已轮回${this.pastLives.length}次】`;
            }

            // 【优化】优先使用LLM精炼总结（信息密度更高，包含因果分析和行动指令）
            if (lastLife.lifeSummary && lastLife.lifeSummary.forThinking) {
                hint += lastLife.lifeSummary.forThinking;
            } else {
                // fallback: 硬编码拼接
                const endingNames = { perfect: '完美结局', normal: '普通结局', bleak: '惨淡结局', extinction: '全灭结局' };
                hint += `上世结果：${endingNames[lastLife.endingType] || '未知'}，${lastLife.aliveCount}/8人存活。`;

                if (bestLife && bestLife.aliveCount > lastLife.aliveCount) {
                    hint += `🏆历史最好：第${bestLife.lifeNumber}世(${bestLife.aliveCount}/8存活)。`;
                }

                if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                    hint += '上世死亡:';
                    for (const d of lastLife.deathRecords.slice(0, 5)) {
                        hint += `${d.name}第${d.day}天${d.time}在${d.location}${d.cause};`;
                    }
                }

                if (lastLife.resourceSnapshot) {
                    const rs = lastLife.resourceSnapshot;
                    hint += `上世最终资源:木柴${rs.woodFuel}食物${rs.food}电力${rs.power}。`;
                }

                if (!lastLife.secondFurnaceBuilt) {
                    hint += '❗上世未完成集中供暖准备。';
                }

                if (lastLife.lessons && lastLife.lessons.length > 0) {
                    hint += '前世教训:' + lastLife.lessons.slice(0, 3).join('；') + '。';
                }

                hint += this._generateStrategyAdvice(lastLife);
            }

            // 【修复D】多世综合失败模式（无论是否有LLM总结都追加，因为这是跨世代分析）
            if (multiAnalysis.failurePatterns.length > 0) {
                hint += '🔴多世反复问题:' + multiAnalysis.failurePatterns.slice(0, 2).join('；') + '。';
            }

            hint += '请综合当前实际资源、体力、天气自主决策，前世经验仅作参考。';

        } else {
            // 非轮回模式：原有的半模糊经验
            hint += `【前世经验(第${lastLife.lifeNumber}世)】`;

            const endingNames = { perfect: '完美结局', normal: '普通结局', bleak: '惨淡结局', extinction: '全灭结局' };
            hint += `上世${endingNames[lastLife.endingType] || '未知'}，存活${lastLife.aliveCount}/8人。`;

            if (lastLife.deathRecords && lastLife.deathRecords.length > 0) {
                hint += '死亡:';
                for (const d of lastLife.deathRecords.slice(0, 4)) {
                    hint += `${d.name}第${d.day}天${d.cause}(${d.location});`;
                }
            }

            if (lastLife.resourceSnapshot) {
                const rs = lastLife.resourceSnapshot;
                hint += `最终资源:木柴${rs.woodFuel}食物${rs.food}电力${rs.power}。`;
            }

            if (!lastLife.secondFurnaceBuilt) {
                hint += '供暖准备不足！';
            }

            if (lastLife.lessons && lastLife.lessons.length > 0) {
                hint += '教训:' + lastLife.lessons.slice(0, 3).join('；') + '。';
            }

            hint += this._generateStrategyAdvice(lastLife);
        }

        // 截断到700字符（轮回模式允许更长，因为综合了多世信息）
        const maxLen = isReincarnationMode ? 700 : 400;
        if (hint.length > maxLen) {
            hint = hint.substring(0, maxLen - 3) + '…';
        }

        return hint;
    };


    /** 根据前世数据生成策略建议（优先读取LLM预生成的，fallback到硬编码） */
    proto._generateStrategyAdvice = function(lastLife) {
        // 优先使用LLM预生成的策略建议（在savePastLife时已生成并存入summary）
        if (lastLife.strategyAdvice) {
            return '前世策略:' + lastLife.strategyAdvice;
        }

        // fallback: 硬编码策略
        return this._generateStrategyAdviceFallback(lastLife);
    };


    /** 硬编码策略建议fallback */
    proto._generateStrategyAdviceFallback = function(lastLife) {
        let advice = '前世策略:';

        const rs = lastLife.resourceSnapshot;
        if (rs) {
            if (rs.woodFuel < 30) {
                const needed = Math.max(80, Math.round(rs.totalConsumed.woodFuel * 1.2));
                advice += `上世木柴消耗约${needed}单位;`;
            }
            if (rs.food < 15) {
                const needed = Math.max(50, Math.round(rs.totalConsumed.food * 1.1));
                advice += `上世食物消耗约${needed}单位;`;
            }
        }

        if (!lastLife.secondFurnaceBuilt) {
            advice += '上世Day3未能补足木材和电力;';
        }

        const frozenOutdoor = (lastLife.deathRecords || []).filter(d => d.cause === '冻死' && d.location === 'village');
        if (frozenOutdoor.length > 0) {
            advice += `上世第2天${frozenOutdoor.map(d => d.name).join('、')}在户外冻死;`;
        }

        return advice;
    };


    // ============ 前世记忆淡化处理 ============

    /**
    * 获取多世综合记忆（含淡化）
    * 最近1世详细，更早世代模糊，3世以上压缩为一句话
    */
    proto.getCompositePastLifeHint = function(forDialogue = true, isReincarnationMode = false) {
        if (this.pastLives.length === 0) return '';

        let hint = '';

        for (let i = this.pastLives.length - 1; i >= 0; i--) {
            const life = this.pastLives[i];
            const age = this.pastLives.length - i; // 1=最近，2=上上世...

            if (age === 1) {
                // 最近1世：详细记忆
                if (forDialogue) {
                    hint += this.getPastLifeHintForDialogue(isReincarnationMode);
                } else {
                    hint += this.getPastLifeHintForThinking(isReincarnationMode);
                }
            } else if (age === 2) {
                // 上上世：模糊概要
                const endingNames = { perfect: '成功了', normal: '勉强活下来', bleak: '很惨', extinction: '全灭了' };
                hint += `更早的记忆更模糊：似乎还有一世${endingNames[life.endingType] || '记不清了'}。`;
            } else {
                // 3世以上：一句话
                hint += '很久以前似乎经历过更惨烈的失败。';
                break; // 更早的不再添加
            }
        }

        return hint;
    };


    /**
     * 获取特定NPC的个性化前世记忆片段
     * 优先使用LLM生成的perNpc个性化总结，fallback到通用记忆
     * @param {string} npcId - NPC的ID
     * @param {boolean} isReincarnationMode - 是否轮回模式
     * @returns {string} 个性化的前世记忆片段
     */
    proto.getNpcPersonalizedHint = function(npcId, isReincarnationMode = false) {
        if (this.currentLifeNumber <= 1 || this.pastLives.length === 0) {
            return '';
        }

        const lastLife = this.pastLives[this.pastLives.length - 1];

        // 优先使用LLM生成的个性化记忆
        if (lastLife.lifeSummary && lastLife.lifeSummary.perNpc && lastLife.lifeSummary.perNpc[npcId]) {
            return lastLife.lifeSummary.perNpc[npcId];
        }

        // fallback: 从死亡记录和NPC状态中提取与该NPC相关的信息
        let personalHint = '';
        const npc = this.game.npcs.find(n => n.id === npcId);
        if (!npc) return '';

        // 检查该NPC上一世是否死亡
        const finalState = (lastLife.npcFinalStates || []).find(s => s.id === npcId);
        if (finalState && finalState.isDead) {
            const deathRecord = (lastLife.deathRecords || []).find(d => d.name === npc.name);
            if (deathRecord) {
                personalHint = `你上一世在第${deathRecord.day}天${deathRecord.cause}(${deathRecord.location || ''})，这次必须避免。`;
            } else {
                personalHint = '你上一世死了，这次要更加小心。';
            }
        } else if (finalState) {
            // 存活但状态不佳
            if (finalState.stamina < 20) {
                personalHint = `你上一世虽然活下来了，但体力只剩${finalState.stamina}，需要更合理分配精力。`;
            } else if (finalState.sanity < 20) {
                personalHint = `你上一世精神状态很差(San:${finalState.sanity})，需要更多休息和社交。`;
            }
        }

        return personalHint;
    };


    // ============ 查询接口 ============

    /** 获取上一世的数据（供其他系统读取） */
    proto.getLastLifeData = function() {
        if (this.pastLives.length === 0) return null;
        return this.pastLives[this.pastLives.length - 1];
    };


    /** 获取上一世的死亡记录 */
    proto.getLastLifeDeathRecords = function() {
        const last = this.getLastLifeData();
        if (!last) return [];
        return last.deathRecords || [];
    };


    /** 获取上一世的资源快照 */
    proto.getLastLifeResourceSnapshot = function() {
        const last = this.getLastLifeData();
        if (!last) return null;
        return last.resourceSnapshot || null;
    };


    /** 获取上一世的教训列表 */
    proto.getLastLifeLessons = function() {
        const last = this.getLastLifeData();
        if (!last) return [];
        return last.lessons || [];
    };


    /** 获取上一世的关键事件（冲突） */
    proto.getLastLifeConflictEvents = function() {
        const last = this.getLastLifeData();
        if (!last) return [];
        return (last.keyEvents || []).filter(e => e.type === 'conflict');
    };


    /** 获取上一世的存活数量 */
    proto.getLastLifeAliveCount = function() {
        const last = this.getLastLifeData();
        if (!last) return null;
        return last.aliveCount;
    };


    /** 获取上一世的结局类型 */
    proto.getLastLifeEndingType = function() {
        const last = this.getLastLifeData();
        if (!last) return null;
        return last.endingType;
    };


    /** 检查某个NPC在上一世是否死亡 */
    proto.wasNpcDeadLastLife = function(npcId) {
        const last = this.getLastLifeData();
        if (!last) return false;
        const finalState = (last.npcFinalStates || []).find(s => s.id === npcId);
        return finalState ? finalState.isDead : false;
    };


    /** 获取上一世NPC的死因 */
    proto.getNpcDeathCauseLastLife = function(npcId) {
        const deathRecords = this.getLastLifeDeathRecords();
        const record = deathRecords.find(r => {
            // deathRecords中存的是name不是id，需要通过game.npcs反查
            const npc = this.game.npcs.find(n => n.id === npcId);
            return npc && r.name === npc.name;
        });
        return record ? record.cause : null;
    };


    /** 硬编码教训fallback（LLM不可用时使用） */
    proto._generateLessonsFallback = function(deathRecords, resourceSnapshot, secondFurnaceBuilt, aliveCount) {
        const lessons = [];

        if (resourceSnapshot && resourceSnapshot.woodFuel < 20) {
            lessons.push('木柴储备严重不足，第1天应多安排人手砍柴，目标至少80单位');
        }
        if (resourceSnapshot && resourceSnapshot.food < 10) {
            lessons.push('食物储备不足，需更积极收集食物，目标至少50单位');
        }
        const frozenDeaths = deathRecords.filter(r => r.cause === '冻死');
        if (frozenDeaths.length > 0) {
            const outdoorDeaths = frozenDeaths.filter(r => r.location === 'village');
            if (outdoorDeaths.length > 0) {
                lessons.push(`${outdoorDeaths.map(r => r.name).join('、')}在户外冻死，尤其第2天户外连续工作超过2小时会严重冻伤`);
            }
            if (frozenDeaths.some(r => r.day >= 4)) {
                lessons.push('第4天有人冻死，集中供暖强度和木材/电力储备不够，需提前准备更多木柴并维持电力');
            }
        }
        const starvedDeaths = deathRecords.filter(r => r.cause === '饿死');
        if (starvedDeaths.length > 0) {
            lessons.push('有人饿死，食物收集严重不足，第1天食物采集量远低于消耗量');
        }
        const mentalDeaths = deathRecords.filter(r => r.cause === '精神崩溃致死');
        if (mentalDeaths.length > 0) {
            lessons.push('有人精神崩溃致死，需更重视San值维护，多安排鼓舞和心理疏导');
        }
        if (!secondFurnaceBuilt) {
            lessons.push('供暖准备不足，Day3木材和电力储备未达到第4天集中供暖所需的最低量');
        }
        if (aliveCount >= 8) {
            lessons.push('策略成功！保持当前分配方案，关注资源节约');
        }
        if (resourceSnapshot && resourceSnapshot.power < 10) {
            lessons.push('电力不足，需安排人手维护发电机');
        }

        return lessons;
    };

})();
