/**
 * Gospel Snow Town - English Prompt Templates
 * All English role cards, address maps, fallback lines, and prompt builders
 * Routed by council-prompt-builder.js
 */
(function() {
    'use strict';
    const GST = window.GST;

    // taskType → English display labels (fallback)
    const TASK_TYPE_LABELS = {
        'COLLECT_WOOD': 'Chop Wood', 'COLLECT_FOOD': 'Gather Food', 'MAINTAIN_POWER': 'Manual Power',
        'MINE_POWER': 'Mine Power', 'COLLECT_MATERIAL': 'Explore Ruins', 'BUILD_GENERATOR': 'Build Generator',
        'BUILD_LUMBER_MILL': 'Build Lumber Mill', 'BUILD_FOOD_COLLECTOR': 'Build Food Collector', 'REPAIR_GENERATOR': 'Repair Generator', 'REPAIR_LUMBER_MILL': 'Repair Lumber Mill',
        'REPAIR_FOOD_COLLECTOR': 'Repair Food Collector',
        'DISTRIBUTE_FOOD': 'Cook', 'PREPARE_MEDICAL': 'Treat Wounded', 'PSYCHOLOGY': 'Counseling',
        'WAREHOUSE': 'Inventory', 'BOOST_MORALE': 'Boost Morale', 'MAINTAIN_ORDER': 'Patrol', 'REST': 'Rest',
        'TREATMENT': 'Treatment',
    };
    const getTaskLabel = (t) => (GST.i18n && GST.i18n.translateTaskLabel ? GST.i18n.translateTaskLabel(t) : null) || TASK_TYPE_LABELS[String(t || '').trim().toUpperCase()] || t;

    // ============ Role Cards ============
    const ROLE_CARDS = {
        'old_qian': {
            bio: 'Retired mayor, 60 years old, Qing Xuan\'s grandfather. Spiritual leader of the town.',
            style: 'Speaks slowly but every word carries weight. Uses "we", "everyone", "kids" often. Draws on past experiences. Slams the table in critical moments to silence the room.',
            maxWords: '2-4 sentences',
            examples: [
                'Everyone, calm down... Back during the mine collapse, things were even worse, and we pulled through, didn\'t we? Listen, let\'s sort things out one by one.',
                'Here\'s what I think — Tiezhu, take Lu Chen to chop wood. Aunt Li, keep an eye on the food. Dr. Su, check if anyone\'s still suffering from the cold. Let\'s split up and get it done before dark.',
                'Xuan\'er... don\'t be scared, grandpa\'s here. (Sighs) ...Alright, everyone, chin up.'
            ]
        },
        'li_shen': {
            bio: '42-year-old supply manager, Lu Chen\'s mother. Loud voice, soft heart.',
            style: 'Blunt and direct, scolds without thinking. Knows supply numbers by heart. Fires off rapid complaints when stressed, but worries about everyone the most. Tough talk, soft heart.',
            maxWords: '2-4 sentences',
            examples: [
                'Listen up, the warehouse has barely enough food for three days, and you\'re all just standing around!',
                'Tiezhu, help me move that bag of rice — Chen\'er, stop running outside! You want to freeze to death?',
                'Enough, enough, stop arguing! Eat first, talk later — what can you do on an empty stomach?'
            ]
        },
        'zhao_chef': {
            bio: '38-year-old lumberjack/boiler operator. Strongest in town. Man of few words.',
            style: 'Barely speaks. Others say ten sentences, he grunts once. When he does speak, it\'s pure substance. One sentence max. Occasionally drops a truth bomb that silences the room.',
            maxWords: 'Only 1 sentence, 2 at most. Never more than 15 words.',
            examples: [
                'Not enough firewood.',
                'I\'ll go chop.',
                '...Furnace won\'t last till morning.',
                'Less talk, more work.',
                'Mm. (Stands up and walks out)'
            ]
        },
        'su_doctor': {
            bio: '35-year-old medic. The town\'s only medical resource. Calm and professional.',
            style: 'Organized and steady. Analyzes from a medical/data perspective. Occasionally pushes glasses up and sighs. Anxious about medicine supplies.',
            maxWords: '2-3 sentences',
            examples: [
                'Old Qian\'s temperature is 35.2°C — any lower and we risk hypothermia. I suggest he stays near the furnace tonight.',
                'At the current consumption rate, we only have two fever shots left... once they\'re gone, that\'s it.',
                'Listen, frostbite is serious — Xin Yue, your fingers are turning white, let me take a look.'
            ]
        },
        'wang_teacher': {
            bio: '32-year-old technician/planner, former philosophy teacher. Rational to the point of coldness.',
            style: 'Always speaks with evidence and conclusions. Occasionally quotes philosophy but immediately translates it. Can propose harsh plans without flinching. Pushing glasses is his signature move.',
            maxWords: '2-3 sentences',
            examples: [
                'Logically speaking, at the current firewood consumption rate, the furnace lasts 18 hours max. I suggest we use half the supplies to reinforce the second one.',
                '(Pushes glasses) As Kant would say... never mind, point is — we have no choice. Either we push tonight, or we all freeze tomorrow.',
                'The optimal plan is to send the fittest — that\'s Tiezhu and Lu Chen. This isn\'t anyone\'s choice, it\'s a probability issue.'
            ]
        },
        'lu_chen': {
            bio: '18-year-old gatherer, Aunt Li\'s son. Youngest and toughest against cold. Reckless.',
            style: 'Mouth faster than brain, body faster than mouth. "Stop talking, just do it!" Low EQ but no bad intentions. Mumbles "yeah yeah" when mom nags.',
            maxWords: '1-2 sentences, fast pace, short bursts',
            examples: [
                'I\'ll go! What are we waiting for! Not enough wood? I\'m heading out right now!',
                'Mom, stop worrying, I got this! — Yeah yeah, I\'ll dress warm, okay?',
                'Stop dawdling, I can handle the cold, let me go!'
            ]
        },
        'ling_yue': {
            bio: '22-year-old scout. The team\'s emotional stabilizer. Gentle outside, steel inside.',
            style: 'Seems carefree but is actually the most perceptive. Finds silver linings even in despair. Keenly notices when others are down and proactively encourages them. Rubs fingers when nervous.',
            maxWords: '2-3 sentences',
            examples: [
                'Hey, don\'t look so gloomy — at least the furnace is still burning, right? We can get through this.',
                'Everyone, I\'ve got good news — found a box of canned food in the ruins today! Not much, but enough for two meals.',
                '(Rubs fingers) ...Dr. Su, Old Qian doesn\'t look right, could you check on him?'
            ]
        },
        'qing_xuan': {
            bio: '16-year-old pharmacist apprentice, Old Qian\'s granddaughter. Quiet voice but sharpest mind.',
            style: 'Soft-spoken but well-organized. Can propose solutions from a chemistry angle. Hides behind grandpa when scared. Often speaks last but hits the nail on the head. Bites lip.',
            maxWords: '1-2 sentences, soft voice',
            examples: [
                'Grandpa... your hands are so cold, come closer to the fire.',
                'Um... I\'ve read that if you boil willow bark, you can make a painkiller.',
                '(Bites lip) ...Everyone, don\'t panic, let me think of something.'
            ]
        },
    };

    // ============ Address Map ============
    const ADDRESS_MAP = {
        'lu_chen': {
            'li_shen': 'Mom', 'old_qian': 'Uncle Qian', 'zhao_chef': 'Brother Zhao',
            'su_doctor': 'Dr. Su', 'wang_teacher': 'Mr. Wang', 'ling_yue': 'Xin Yue', 'qing_xuan': 'Qing Xuan',
        },
        'li_shen': {
            'lu_chen': 'Chen\'er/son', 'old_qian': 'Old Qian', 'zhao_chef': 'Tiezhu',
            'su_doctor': 'Dr. Su', 'wang_teacher': 'Mr. Wang', 'ling_yue': 'Xin Yue', 'qing_xuan': 'Qing Xuan',
        },
        'zhao_chef': {
            'li_shen': 'Aunt Li', 'lu_chen': 'kid/Lu Chen', 'old_qian': 'Mayor Qian',
            'su_doctor': 'Dr. Su', 'wang_teacher': 'Mr. Wang', 'ling_yue': 'Xin Yue', 'qing_xuan': 'Qing Xuan',
        },
        'old_qian': {
            'qing_xuan': 'Xuan\'er/granddaughter', 'li_shen': 'Aunt Li', 'zhao_chef': 'Tiezhu',
            'su_doctor': 'Dr. Su', 'wang_teacher': 'young Wang', 'lu_chen': 'Lu Chen', 'ling_yue': 'Xin Yue',
        },
        'qing_xuan': {
            'old_qian': 'Grandpa', 'li_shen': 'Aunt Li', 'zhao_chef': 'Uncle Zhao',
            'su_doctor': 'Dr. Su', 'wang_teacher': 'Mr. Wang', 'lu_chen': 'Lu Chen', 'ling_yue': 'Xin Yue',
        },
        'su_doctor': {
            'li_shen': 'Aunt Li', 'zhao_chef': 'Tiezhu', 'old_qian': 'Mayor Qian',
            'lu_chen': 'Lu Chen', 'wang_teacher': 'Wang Ce', 'ling_yue': 'Xin Yue', 'qing_xuan': 'Qing Xuan',
        },
        'wang_teacher': {
            'li_shen': 'Aunt Li', 'zhao_chef': 'Tiezhu', 'old_qian': 'Old Qian',
            'lu_chen': 'Lu Chen', 'su_doctor': 'Dr. Su', 'ling_yue': 'Xin Yue', 'qing_xuan': 'Qing Xuan',
        },
        'ling_yue': {
            'li_shen': 'Aunt Li', 'zhao_chef': 'Brother Zhao', 'old_qian': 'Uncle Qian',
            'lu_chen': 'Lu Chen', 'su_doctor': 'Dr. Su', 'wang_teacher': 'Mr. Wang', 'qing_xuan': 'Qing Xuan',
        },
    };

    // ============ Token Limits ============
    const TOKEN_LIMITS = {
        'zhao_chef': 80, 'lu_chen': 120, 'qing_xuan': 120,
        'old_qian': 200, 'li_shen': 200, 'su_doctor': 180,
        'wang_teacher': 180, 'ling_yue': 160,
    };

    // ============ Offline Fallback Lines ============
    const FALLBACKS = {
        'old_qian':     ['Everyone, don\'t panic. Let\'s think this through.', 'How about this... let\'s each share our situation first.', 'Stay calm. There\'s always a way.'],
        'li_shen':      ['I\'ve got the food situation under control, don\'t worry.', 'Alright, alright, stop arguing! Let\'s get to the point.', 'I\'m telling you, the warehouse supplies won\'t last long.'],
        'zhao_chef':    ['Firewood\'s still enough.', '...I\'ll check the furnace.', 'Less talk. Work.'],
        'su_doctor':    ['From what I can see... everyone needs to stay warm.', 'I\'ve been monitoring Old Qian\'s temperature.', 'Medicine is running low. Let\'s hope no more frostbite cases.'],
        'wang_teacher': ['Logically, our top priority right now is...', 'I\'ve done some calculations — at the current consumption rate...', 'I suggest we prioritize.'],
        'lu_chen':      ['I\'ll go chop wood! What are we waiting for!', 'Stop dawdling, just do it already.', 'Mom, don\'t worry, I got this.'],
        'ling_yue':     ['Hey, cheer up — we found some stuff in the ruins today.', 'Come on everyone, we can get through this!', 'I think we should...'],
        'qing_xuan':    ['Grandpa... your hands are so cold, come sit by the furnace.', 'I... I\'ve read about this, we should...', 'Let me try, maybe I can help.'],
    };

    // ============ Summary Speaker Traits ============
    const NPC_TRAITS = {
        'old_qian': '60-year-old retired mayor, spiritual leader of the town. Speaks slowly but every word carries weight.',
        'li_shen': '50-year-old Aunt Li, kitchen manager, loud but warm-hearted.',
        'wang_teacher': '32-year-old technician, calm and rational. Speaks concisely.',
        'su_doctor': '35-year-old doctor, gentle and professional. Speaks steadily.',
        'zhao_chef': '38-year-old lumberjack, tough and straightforward. Man of few words.',
        'ling_yue': '22-year-old scout, cheerful and optimistic. Energetic speaker.',
        'qing_xuan': '16-year-old pharmacist apprentice, quiet but determined.',
        'lu_chen': '18-year-old gatherer, young and energetic. Speaks bluntly.',
    };

    // ============ Prompt Builders ============
    const EN = {
        ROLE_CARDS,
        ADDRESS_MAP,
        TOKEN_LIMITS,
        FALLBACKS,
        NPC_TRAITS,
        getTaskLabel,

        /** Build situation description */
        buildSituation(game, alive, dead) {
            const rs = game.resourceSystem;
            const ws = game.weatherSystem;

            let ctx = `Currently Day ${game.dayCount} ${game.getTimeStr()}.`;

            if (ws) {
                ctx += `\nWeather: ${game.weather}, Temperature ${ws.getEffectiveTemp ? ws.getEffectiveTemp().toFixed(0) : '?'}°C.`;
                const _d = GST.promptDataEN || {};
                const blizzard = _d.getBlizzardUrgencyForPromptEN ? _d.getBlizzardUrgencyForPromptEN(game) : (ws.getBlizzardUrgencyForPrompt ? ws.getBlizzardUrgencyForPrompt() : '');
                if (blizzard) ctx += '\n' + blizzard;
            }

            if (rs) {
                const _d2 = GST.promptDataEN || {};
                ctx += '\n' + (_d2.getResourceStatusForPromptEN ? _d2.getResourceStatusForPromptEN(game) : rs.getResourceStatusForPrompt());
                const forecast = _d2.getResourceForecastForPromptEN ? _d2.getResourceForecastForPromptEN(game) : (rs.getResourceForecastForPrompt ? rs.getResourceForecastForPrompt() : '');
                if (forecast) ctx += forecast;
            }

            if (dead.length > 0) {
                const _dn = (n) => n.displayName || n.name;
                ctx += `\nDeceased: ${dead.map(n => `${_dn(n)}(${n._deathCause || 'unknown cause'})`).join(', ')}`;
                ctx += `\n⚠️ The above characters are DEAD and not present. Do NOT speak to the dead or assign them tasks. Only assign work to living characters.`;
            }

            ctx += `\n\n[Survivor Details] ${alive.length} people:`;
            for (const n of alive) {
                const cfg = (GST.NPC_CONFIGS || []).find(c => c.id === n.id) || {};
                const _dn = n.displayName || n.name;
                const tags = [];
                if (n.isCrazy) tags.push('🤯Crazy');
                if (n._isDying) tags.push('🚨Dying');
                if (n.isSick) tags.push('🤒Sick');
                if (n.isSleeping) tags.push('💤Sleeping');
                if (n.stamina <= 0) tags.push('STA=0');
                else if (n.stamina < 20) tags.push('STA low');
                if (n.sanity <= 0) tags.push('San=0');
                else if (n.sanity < 20) tags.push('San low');
                if (n.health < 10) tags.push('HP critical');
                else if (n.health < 30) tags.push('HP low');
                if ((n.hunger || 50) < 20) tags.push('Hungry');
                const tagStr = tags.length > 0 ? ` [${tags.join(', ')}]` : '';
                const scene = n.currentScene || 'unknown';
                const action = n.stateDesc || n.state || 'idle';
                ctx += `\n  ${_dn}(${cfg.occupation || ''}): 💪STA${Math.round(n.stamina)} 🧠San${Math.round(n.sanity)} 🫀HP${Math.round(n.health)} 🍖Hunger${Math.round(n.hunger || 50)} 🌡️${n.bodyTemp.toFixed(1)}°C${tagStr} | Location:${scene} | Doing:${action}`;
            }

            if (game.taskSystem) {
                const taskSummary = alive.map(n => {
                    const _dn = n.displayName || n.name;
                    const _d3 = GST.promptDataEN || {};
                    const desc = _d3.getNpcTaskDescForPromptEN ? _d3.getNpcTaskDescForPromptEN(game, n.id) : game.taskSystem.getNpcTaskDescForPrompt(n.id);
                    return `${_dn}→${desc}`;
                }).join(', ');
                ctx += `\nCurrent assignments: ${taskSummary}`;
            }

            if (game.deathSystem) {
                const _d4 = GST.promptDataEN || {};
                const deathSummary = _d4.getDeathSummaryForPromptEN ? _d4.getDeathSummaryForPromptEN(game) : game.deathSystem.getDeathSummaryForPrompt();
                if (deathSummary) ctx += '\n' + deathSummary;
            }

            if (game.machineSystem) {
                const ms = game.machineSystem;
                const _bkPct = Math.round((game.getDifficultyMult ? game.getDifficultyMult('machineBreakdownChance') : 0.10) * 100);
                let machineCtx = '';
                const MC = GST.MACHINE_CONFIG || {};
                const _genCfg = MC.generator || {};
                const _lumCfg = MC.lumberMill || {};
                const _fcCfg = MC.foodCollector || {};
                const _buildHours = (sec) => Math.round((sec || 14400) / 3600);

                if (ms.generator.built) {
                    machineCtx += `\nAuto Generator: ${ms.generator.running ? 'Running' : ms.generator.broken ? '⚠️Broken' : 'Stopped'}(Output ⚡${_genCfg.powerOutputPerHour || 20}/h, Consumes 🪵${_genCfg.woodConsumptionPerHour || 3}/h, ${_bkPct}%/h breakdown chance)`;
                } else if (ms.generator.building) {
                    machineCtx += `\nAuto Generator: Building ${Math.round(ms.generator.buildProgress * 100)}%`;
                } else if (ms.canUnlockGenerator()) {
                    machineCtx += `\n⚡ Can build Auto Generator! (Cost: ⚡${_genCfg.buildMaterialCost || 10}+🪵${_genCfg.buildWoodCost || 12}, ${_buildHours(_genCfg.buildTimeSeconds)}h to build, then auto ⚡+${_genCfg.powerOutputPerHour || 20}/h consuming 🪵${_genCfg.woodConsumptionPerHour || 3}/h, ${_bkPct}%/h breakdown)`;
                } else {
                    machineCtx += `\nAuto Generator: 🔒Locked (Need ⚡>${_genCfg.buildUnlockPower || 10}, current ${Math.round(rs ? rs.power : 0)})`;
                }

                if (ms.lumberMill.built) {
                    machineCtx += `\nAuto Lumber Mill: ${ms.lumberMill.running ? 'Running' : ms.lumberMill.broken ? '⚠️Broken' : 'Stopped'}(Output 🪵${_lumCfg.woodOutputPerHour || 24}/h, Consumes ⚡${_lumCfg.powerConsumptionPerHour || 4}/h, ${_bkPct}%/h breakdown)`;
                } else if (ms.lumberMill.building) {
                    machineCtx += `\nAuto Lumber Mill: Building ${Math.round(ms.lumberMill.buildProgress * 100)}%`;
                } else if (ms.canUnlockLumberMill()) {
                    machineCtx += `\n🪵 Can build Auto Lumber Mill! (Cost: ⚡${_lumCfg.buildMaterialCost || 12}+🪵${_lumCfg.buildWoodCost || 15}, ${_buildHours(_lumCfg.buildTimeSeconds)}h to build, then auto 🪵+${_lumCfg.woodOutputPerHour || 24}/h consuming ⚡${_lumCfg.powerConsumptionPerHour || 4}/h, ${_bkPct}%/h breakdown)`;
                } else {
                    machineCtx += `\nAuto Lumber Mill: 🔒Locked (Need 🪵>${_lumCfg.buildUnlockWood || 18}, current ${Math.round(rs ? rs.woodFuel : 0)})`;
                }

                if (ms.foodCollector.built) {
                    machineCtx += `\nAuto Food Collector: ${ms.foodCollector.running ? 'Running' : ms.foodCollector.broken ? '⚠️Broken' : 'Stopped'}(Output 🍞${_fcCfg.foodOutputPerHour || 12}/h, Consumes ⚡${_fcCfg.powerConsumptionPerHour || 3}/h, ${_bkPct}%/h breakdown)`;
                } else if (ms.foodCollector.building) {
                    machineCtx += `\nAuto Food Collector: Building ${Math.round(ms.foodCollector.buildProgress * 100)}%`;
                } else if (ms.canUnlockFoodCollector && ms.canUnlockFoodCollector()) {
                    machineCtx += `\n🍞 Can build Auto Food Collector! (Cost: ⚡${_fcCfg.buildMaterialCost || 10}+🪵${_fcCfg.buildWoodCost || 12}, ${_buildHours(_fcCfg.buildTimeSeconds)}h to build, then auto 🍞+${_fcCfg.foodOutputPerHour || 12}/h consuming ⚡${_fcCfg.powerConsumptionPerHour || 3}/h, ${_bkPct}%/h breakdown)`;
                } else {
                    machineCtx += `\nAuto Food Collector: 🔒Locked (Need 🍞>${_fcCfg.buildUnlockFood || 25}, current ${Math.round(rs ? rs.food : 0)})`;
                }

                if (ms.generator.built || ms.lumberMill.built || ms.foodCollector.built) {
                    const net = ms.getNetOutputPerHour();
                    machineCtx += `\nAutomation net output: 🪵${net.wood >= 0 ? '+' : ''}${net.wood.toFixed(1)}/h, ⚡${net.power >= 0 ? '+' : ''}${net.power.toFixed(1)}/h, 🍞${net.food >= 0 ? '+' : ''}${net.food.toFixed(1)}/h`;
                }
                if (machineCtx) ctx += '\n[Automation Facilities]' + machineCtx;
            }

            if (game.furnaceSystem) {
                const fs = game.furnaceSystem;
                const _d5 = GST.promptDataEN || {};
                ctx += `\n[Heating] ${_d5.getHeatingSummaryEN ? _d5.getHeatingSummaryEN(game) : fs.getHeatingSummary()}, Indoor temp ${fs.indoorTemp ? fs.indoorTemp.toFixed(1) : '?'}°C`;
            }

            if (game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1) {
                const _d9 = GST.promptDataEN || {}; const hint = _d9.getPastLifeHintForDialogueEN ? _d9.getPastLifeHintForDialogueEN(game, game.mode === 'reincarnation') : game.reincarnationSystem.getPastLifeHintForDialogue(game.mode === 'reincarnation');
                if (hint) ctx += '\n' + hint;
            }

            ctx += '\n[Common Sense] Chopping wood→produces 🪵wood; Manual power→produces ⚡power; Generator(auto): consumes 🪵→produces ⚡; Lumber Mill(auto): consumes ⚡→produces 🪵; Food Collector(auto): consumes ⚡→produces 🍞.';

            return ctx;
        },

        /** Build character card */
        buildCharacterCard(npc, deadNames) {
            const role = ROLE_CARDS[npc.id];
            if (!role) {
                const cfg = (GST.NPC_CONFIGS || []).find(c => c.id === npc.id) || {};
                return `You are ${npc.displayName || npc.name}, ${npc.age} years old, ${cfg.occupation || npc.occupation}.`;
            }

            let bio = role.bio;
            let validExamples = role.examples;
            if (deadNames.length > 0) {
                validExamples = role.examples.filter(ex =>
                    !deadNames.some(dn => ex.includes(dn))
                );
                if (validExamples.length === 0) validExamples = role.examples.slice(0, 1);
            }

            const shuffled = [...validExamples].sort(() => Math.random() - 0.5);
            const examplesText = shuffled.slice(0, 2).map((e, i) => `  Example ${i+1}: ${e}`).join('\n');

            return `You are ${bio}
Speaking style: ${role.style}
Word limit: ${role.maxWords}

Examples of how you speak (mimic this tone and length):
${examplesText}`;
        },

        /** Build address rules */
        buildAddressRules(npc, deadIds) {
            const myMap = ADDRESS_MAP[npc.id] || {};
            const entries = Object.entries(myMap).filter(([id]) => !deadIds.has(id));
            if (entries.length === 0) {
                return '[Address Rules] Call each other by name or respectful titles. Never call anyone "Mom" or "Dad".';
            }

            const addrList = entries.map(([id, addr]) => {
                const cfg = (GST.NPC_CONFIGS || []).find(c => c.id === id);
                return cfg ? `${cfg.displayName || cfg.name}→call "${addr}"` : '';
            }).filter(Boolean).join(', ');

            let rule = `[Address Rules] ${addrList}.`;
            if (npc.id !== 'lu_chen') {
                rule += ' Never call anyone "Mom" or "Dad"!';
            }
            return rule;
        },

        /** Capture NPC state */
        captureNpcState(npc, game, aliveNpcs, deadNames) {
            let stateHints = '';

            if (npc.sanity < 15) {
                stateHints += `\n[Mental State] You're on the verge of breakdown (San:${Math.round(npc.sanity)}) — speak aggressively, darkly. You might lash out, mock others, say hopeless things. You think nobody will survive tomorrow.`;
            } else if (npc.sanity < 30) {
                stateHints += `\n[Mental State] Very poor (San:${Math.round(npc.sanity)}) — anxious, impatient, sharp-tongued, easily triggered.`;
            } else if (npc.sanity < 50) {
                stateHints += `\n[Mental State] Tired and anxious (San:${Math.round(npc.sanity)}) — somewhat irritable but can still discuss rationally.`;
            } else if (npc.sanity < 70) {
                stateHints += `\n[Mental State] Okay (San:${Math.round(npc.sanity)}) — can stay calm and analytical.`;
            } else {
                stateHints += `\n[Mental State] Stable (San:${Math.round(npc.sanity)}) — relatively positive, can encourage others.`;
            }

            if (npc.stamina < 20) {
                stateHints += `\n[Stamina] Extremely exhausted (${Math.round(npc.stamina)}) — your voice is weak, speaking feebly.`;
            } else if (npc.stamina < 40) {
                stateHints += `\n[Stamina] Very tired (${Math.round(npc.stamina)}).`;
            }
            if (npc.bodyTemp < 35) {
                stateHints += `\n[Body Temp] ${npc.bodyTemp.toFixed(1)}°C — you're shivering, hunching your shoulders, voice trembling.`;
            }
            if (npc.mood) {
                stateHints += `\n[Mood] ${npc.mood}`;
            }

            if (game.deathSystem && game.deathSystem.isNpcGrieving(npc.id)) {
                const griefEffects = game.deathSystem._griefEffects.filter(g => g.npcId === npc.id);
                const griefNames = griefEffects.map(g => g.deadNpcName).join(', ');
                stateHints += `\n[Grief] ${griefNames} is dead and not present. You're grieving — you may mourn and reminisce, but NEVER speak to the dead or call their name to assign tasks.`;
            }

            let relationContext = '';
            const others = aliveNpcs.filter(n => n.id !== npc.id);
            const notableRelations = [];
            for (const other of others) {
                const _dn = other.displayName || other.name;
                const aff = npc.getAffinity ? npc.getAffinity(other.id) : 50;
                if (aff >= 80) notableRelations.push(`Close with ${_dn} (${aff}), speak warmly`);
                else if (aff <= 25) notableRelations.push(`Bad terms with ${_dn} (${aff}), cold or hostile`);
                if (npc._affinityCooldown && npc._affinityCooldown[other.id] > 0) {
                    notableRelations.push(`Just had a fight with ${_dn}, still angry, don't want to talk to them`);
                }
            }
            if (notableRelations.length > 0) {
                relationContext = `\n[Relationships] ${notableRelations.join('; ')}`;
            }

            let memoryHint = '';
            if (npc.memory && npc.memory.getRecent) {
                const recentMems = npc.memory.getRecent(3);
                const memTexts = recentMems.map(m => {
                    let desc = m.text || m.type;
                    if (m.lines && m.lines.length > 0) {
                        const lastLine = m.lines[m.lines.length - 1];
                        desc += ` (${lastLine.speaker} said: ${lastLine.text.substring(0, 30)})`;
                    }
                    return desc;
                }).join('; ');
                memoryHint = `\n[Recent Events] ${memTexts}`;
            }

            let blizzardHint = '';
            if (game.weatherSystem) {
                const _d6 = GST.promptDataEN || {};
                const urgency = _d6.getBlizzardUrgencyForPromptEN ? _d6.getBlizzardUrgencyForPromptEN(game) : (game.weatherSystem.getBlizzardUrgencyForPrompt ? game.weatherSystem.getBlizzardUrgencyForPrompt() : '');
                if (urgency) blizzardHint = `\n[Urgent Warning] ${urgency}`;
            }

            let pastLifeHint = '';
            if (game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1) {
                const _d8 = GST.promptDataEN || {};
                const hint = _d8.getPastLifeHintForDialogueEN ? _d8.getPastLifeHintForDialogueEN(game, game.mode === 'reincarnation') : game.reincarnationSystem.getPastLifeHintForDialogue(game.mode === 'reincarnation');
                if (hint) pastLifeHint = `\n[Past Life Memory] ${hint} — Use this as background reference. You may naturally cite past life lessons during discussion, or not — base decisions on current reality. NEVER state past life events as currently happening facts.`;
            }

            return { stateHints, relationContext, memoryHint, blizzardHint, pastLifeHint };
        },

        /** Build reality guard */
        buildDiscussionRealityGuard(snapshot, npc) {
            const sit = snapshot.situation || '';
            const isFirstLife = !sit.includes('前世记忆') && !sit.includes('已轮回') && !sit.includes('首次轮回重生') && !sit.includes('Past Life') && !sit.includes('reincarnated') && !sit.includes('Reincarnation');

            const rules = isFirstLife ? [
                '[Facts First] Current situation always takes priority over speculation and emotions. Only discuss what is actually happening right now.',
                '[No Fabricated History] This is your FIRST time facing this disaster — you have never experienced anything like this before. Do NOT fabricate any "last time we..." or "back when we..." experiences, because there is no "last time".',
            ] : [
                '[Facts First] Current situation always takes priority over past life memories, speculation, and emotions. Past lives are only experience — never state them as current facts.',
                '[No Cross-contamination] Do NOT restate "past life problems" as "current reality". Only reference past lessons when explicitly prefixed with "in my past life".',
            ];

            // Machine state facts — use Chinese keywords to match situation string (which is generated in ZH internally)
            if (sit.includes('自动发电机：运行中') || sit.includes('Auto Generator: Running')) {
                rules.push('[Machine Fact] The auto generator is built and running. Do NOT say "we haven\'t built the generator yet" or "hurry up and fix the generator". You may discuss its wood consumption, breakdown risk, or what resources to stockpile next.');
            } else if (sit.includes('自动发电机：⚠️故障中') || sit.includes('自动发电机：故障中') || sit.includes('Auto Generator: ⚠️Broken')) {
                rules.push('[Machine Fact] The auto generator is built but currently broken. Discuss repairs and emergency power, but do NOT say "we haven\'t built the generator".');
            } else if (sit.includes('自动发电机：停机') || sit.includes('Auto Generator: Stopped')) {
                rules.push('[Machine Fact] The auto generator is built but stopped. Discuss why it stopped and what to do, but do NOT say "we haven\'t built the generator".');
            } else if (sit.includes('自动发电机：建造中') || sit.includes('Auto Generator: Building')) {
                rules.push('[Machine Fact] The auto generator is currently being built. Do NOT say it\'s already running or that it hasn\'t been started.');
            } else if (sit.includes('可以建造自动发电机') || sit.includes('Can build Auto Generator')) {
                rules.push('[Machine Fact] The auto generator can be built but hasn\'t been built yet.');
            }

            if (sit.includes('自动伐木机：运行中') || sit.includes('Auto Lumber Mill: Running')) {
                rules.push('[Machine Fact] The auto lumber mill is built and running. Do NOT say it hasn\'t been built.');
            } else if (sit.includes('自动伐木机：建造中') || sit.includes('Auto Lumber Mill: Building')) {
                rules.push('[Machine Fact] The auto lumber mill is being built. Do NOT say it\'s already running.');
            }
            if (sit.includes('自动捕猎机：运行中') || sit.includes('Auto Food Collector: Running')) {
                rules.push('[Machine Fact] The auto food collector is built and running. Do NOT say it hasn\'t been built.');
            } else if (sit.includes('自动捕猎机：建造中') || sit.includes('Auto Food Collector: Building')) {
                rules.push('[Machine Fact] The auto food collector is being built. Do NOT say it\'s already running.');
            }

            if (npc.id === 'li_shen' && snapshot.aliveNpcs.some(n => n.id === 'lu_chen')) {
                rules.push('[Relationship] When Lu Chen is present, you call him "Chen\'er/son" — speak like a worried mother.');
            }
            if (npc.id === 'lu_chen' && snapshot.aliveNpcs.some(n => n.id === 'li_shen')) {
                rules.push('[Relationship] When Aunt Li is present, you call her "Mom" — you complain about her nagging but clearly care.');
            }

            return rules.join('\n');
        },

        /** Build discussion prompt */
        buildDiscussionPrompt(snapshot, npc, chatHistory, discussionContext) {
            const card = snapshot.characterCards[npc.id];
            const addr = snapshot.addressRules[npc.id];
            const state = snapshot.npcStates[npc.id];
            const realityGuard = this.buildDiscussionRealityGuard(snapshot, npc);
            const ctx = discussionContext || {};
            const _dn = npc.displayName || npc.name;

            const isFirstLifeForPrompt = !snapshot.situation.includes('前世记忆') && !snapshot.situation.includes('已轮回') && !snapshot.situation.includes('首次轮回重生');
            const isFirstReincarnation = snapshot.situation.includes('首次轮回重生');

            const worldLock = isFirstLifeForPrompt
                ? '\n[World Setting] You are survivors trapped in a snow town by a sudden blizzard. This is your FIRST time facing such a crisis — you have never experienced anything like this before.'
                : '';

            const systemPrompt = `[Identity Lock] You ARE "${_dn}" — no one else. You can ONLY speak as ${_dn}.
Never imitate other characters' tone or say things outside your personality. Never refer to yourself in third person.${worldLock}

${card}
${addr}`;

            // Anti-repeat detection
            let antiRepeatHint = '';
            if (chatHistory.length >= 4) {
                const recentTexts = chatHistory.slice(-4).join('');
                const allWords = recentTexts.toLowerCase().match(/\b\w{4,}\b/g) || [];
                const freq = {};
                for (const w of allWords) { freq[w] = (freq[w] || 0) + 1; }
                const repeatedWords = Object.keys(freq).filter(w => freq[w] >= 3);
                if (repeatedWords.length > 0) {
                    antiRepeatHint = `\n⚠️ Note: Words like "${repeatedWords.slice(0, 3).join('", "')}" have been used too many times. Please respond from a different angle or topic. Do not repeat.`;
                }
            }

            // Discussion focus
            let discussionFocus = '';
            if (ctx.isDeathTrigger && ctx.deadNpcName) {
                discussionFocus = `\n\n---⚠️ Discussion Focus ⚠️---
This is an EMERGENCY DISCUSSION after a companion's death. ${ctx.deadNpcName} has died.
Trigger: ${ctx.triggerReason}

[Discussion Pace — MUST follow this order, do NOT skip steps!]
Step 1: Emotional reaction (first 1-2 rounds)
- Express shock, grief, anger, or guilt about ${ctx.deadNpcName}'s death
- Recall moments with ${ctx.deadNpcName}, describe what kind of person they were
- If you were close to ${ctx.deadNpcName}, show deeper grief

Step 2: Analyze causes (middle 1-2 rounds)
- Discuss how ${ctx.deadNpcName} died — froze? starved? other causes?
- Reflect on what we did wrong — bad task assignments? poor resource allocation?
- Exchange information: what do you know that others don't?

Step 3: Plan next steps (final 1-2 rounds)
- With one fewer person, how do we redistribute tasks?
- Who takes over ${ctx.deadNpcName}'s responsibilities?
- How do we prevent this from happening again?

[FORBIDDEN] Do NOT start assigning tasks immediately! Grieve first, analyze, THEN decide!
[FORBIDDEN] Do NOT act like ${ctx.deadNpcName}'s death doesn't matter and jump straight to "let's get to work"!
---End Focus---`;
            } else if (ctx.isNpcCrisis && ctx.triggerReason) {
                discussionFocus = `\n\n---⚠️ Discussion Focus ⚠️---
This is a PERSONAL CRISIS discussion, NOT a general situation review!
Trigger: ${ctx.triggerReason}
[Core Requirement] Your speech MUST focus on this person's condition:
- Show concern for how they're doing, whether they can hold on
- Discuss how to help (who takes care of them, treatment, resources needed)
- If YOU are the person in crisis, express your feelings and needs
- You may briefly mention related resources/situation, but don't derail into pure situation analysis
[FORBIDDEN] Do NOT ignore the person's crisis to talk about weather, power, or wood! This discussion is about SAVING someone!
---End Focus---`;
            } else if (!ctx.isOpeningCouncil && ctx.triggerReason) {
                discussionFocus = `\n\n---Discussion Focus---
Trigger: ${ctx.triggerReason}
Please discuss around this issue.
---End Focus---`;
            }

            let userPrompt = `---Current Situation---
${snapshot.situation}
${state.stateHints}${state.relationContext}${state.memoryHint}${state.blizzardHint}${state.pastLifeHint}
---End Situation---
${discussionFocus}
---Fact Constraints---
${realityGuard}
---End Constraints---

`;

            if (chatHistory.length > 0) {
                userPrompt += `---Previous speakers (these are NOT your words! You are ${_dn}!)---\n`;
                userPrompt += chatHistory.map(line => line.replace(/^(.+?): /, '[$1]: ')).join('\n');
                userPrompt += `\n---End of previous speeches---\n\n`;
            }

            if (ctx.isDeathTrigger && chatHistory.length === 0) {
                userPrompt += `You are the first to speak. ${ctx.deadNpcName} just died. You are shocked and grieving. First express your emotional reaction to ${ctx.deadNpcName}'s death (grief, shock, guilt, etc.), recall your time with them. Do NOT jump straight to assigning tasks!`;
            } else if (ctx.isDeathTrigger && chatHistory.length > 0) {
                userPrompt += `Respond to what others said above. If everyone is still grieving and analyzing causes, join the discussion about how ${ctx.deadNpcName} died and what we did wrong. If they've moved on to planning next steps, then share your suggestions. Don't skip emotions and analysis to jump straight to task assignments.`;
            } else if (ctx.isNpcCrisis && chatHistory.length === 0) {
                userPrompt += `You are the first to speak. This discussion was triggered because a companion is in trouble (${ctx.triggerReason}). First show concern for their condition, then discuss how to help.`;
            } else if (chatHistory.length === 0) {
                if (isFirstReincarnation) {
                    userPrompt += `You are the first to speak. You just experienced death or disaster in your previous life and suddenly find yourself back at the start — you can express shock and confusion about being reborn, or directly discuss the current situation. It's your call.`;
                } else {
                    userPrompt += `You are the first to speak. Comment on the current situation and bring up a topic.`;
                }
            } else {
                if (isFirstReincarnation) {
                    userPrompt += `Respond to what others said above — agree, disagree, ask questions, or add information. If someone mentioned rebirth or past lives, you can share your own feelings about it.`;
                } else {
                    userPrompt += `Respond to what others said above — agree, disagree, ask questions, or add information.`;
                }
            }
            userPrompt += `\nRules: Speak directly, no name prefix, no JSON, no quotes. Natural and emotional. Follow your word count and speaking style.${antiRepeatHint}${isFirstLifeForPrompt ? '\n⚠️ You have never experienced anything like this before. Do not fabricate any past experiences.' : ''}\n⚠️ Reminder: You are "${_dn}", speak in your own voice! ALL dialogue MUST be in English!\n\n${_dn}: `;

            return {
                systemPrompt,
                userPrompt,
                maxTokens: TOKEN_LIMITS[npc.id] || 150,
            };
        },

        /** Build proposal prompt */
        buildProposalPrompt(snapshot, chatHistory, triageParticipants) {
            const assignTargets = triageParticipants || snapshot.aliveNpcs;

            const participantInfo = assignTargets.map(n => {
                const cfg = (GST.NPC_CONFIGS || []).find(c => c.id === n.id) || {};
                const _dn = n.displayName || n.name;
                const tags = [];
                if (n.isCrazy) tags.push('🤯Crazy');
                if (n._isDying) tags.push('🚨Dying');
                if (n.isSick) tags.push('🤒Sick');
                if (n.stamina <= 0) tags.push('STA=0');
                else if (n.stamina < 20) tags.push('STA low');
                if (n.sanity <= 0) tags.push('San=0');
                else if (n.sanity < 20) tags.push('San low');
                if (n.health < 10) tags.push('HP critical');
                else if (n.health < 30) tags.push('HP low');
                const statusStr = tags.length > 0 ? ` ⚠️${tags.join('+')}` : '';
                return `${_dn}(${cfg.occupation || ''}, STA${Math.round(n.stamina)}/San${Math.round(n.sanity)}/HP${Math.round(n.health)}${statusStr})`;
            }).join('\n  ');

            const systemPrompt = `You are a game AI system. Based on the characters' discussion, propose 2-3 concrete action plans.

Each plan must:
1. Have a short, punchy name (max 4 words)
2. Assign specific tasks to every surviving character (⚠️ MUST assign ALL survivors, miss no one!)
3. Have clear expected benefits

⚠️ [CRITICAL] Each person's value in assignments MUST be a standard taskType key (UPPERCASE English) from the list below. Do NOT use Chinese!

[Available taskType List] (choose ONLY from these):
- COLLECT_WOOD → Chop wood at lumber yard, output 🪵+10/h
- COLLECT_FOOD → Gather food at frozen lake, output 🍞+8/h
- MAINTAIN_POWER → Manual power at workshop, output ⚡+8/h (emergency)
- MINE_POWER → Mine at slag heap, output ⚡+12/h (highest power but outdoor freezing)
- COLLECT_MATERIAL → Explore ruins (3x/day limit, chance for first aid kits/canned food)
- BUILD_GENERATOR → Build auto generator at workshop, costs ⚡10+🪵12, 4h build, then auto ⚡+20/h consuming 🪵3/h
- BUILD_LUMBER_MILL → Build auto lumber mill, costs ⚡12+🪵15, 5h build, then auto 🪵+24/h consuming ⚡4/h
- BUILD_FOOD_COLLECTOR → Build auto food collector, costs ⚡10+🪵12, 5h build, then auto 🍞+12/h consuming ⚡3/h
- REPAIR_GENERATOR / REPAIR_LUMBER_MILL / REPAIR_FOOD_COLLECTOR → Repair broken machines
- DISTRIBUTE_FOOD → Cook at kitchen, reduces food waste -20%
- PREPARE_MEDICAL → Treat wounded at medical station, HP+18/h, San+18/h
- WAREHOUSE → Inventory at warehouse, food waste -20% + wood waste -10%
- BOOST_MORALE → Boost morale, nearby NPC San+10.8/h
- MAINTAIN_ORDER → Patrol at dormitory
- PSYCHOLOGY → Counseling at medical station, restores San
- REST → Rest at home, restores stamina and body temp (assign when STA<30)

⚠️ [Personnel Constraints — HIGHEST PRIORITY]:
- STA≤0 or San≤0 or HP≤0 → ONLY assign REST or PREPARE_MEDICAL! Cannot work!
- 🤯Crazy → ONLY REST, others should BOOST_MORALE or PREPARE_MEDICAL
- 🚨Dying → MUST REST, assign doctor PREPARE_MEDICAL
- 🤒Sick → Prefer light work or REST
- Assigning heavy labor to someone with zero STA/San is UNREASONABLE!

Output format MUST be JSON:
{
  "proposals": [
    {
      "name": "Plan name (English, max 4 words)",
      "description": "One sentence description (English)",
      "assignments": {"NPC Name": "TASK_TYPE_KEY"},
      "reasoning": "Reason for recommendation (English)"
    }
  ]
}

Example:
{"proposals":[{"name":"Resource Priority","description":"Focus on replenishing critical resources","assignments":{"Old Qian":"BOOST_MORALE","Aunt Li":"DISTRIBUTE_FOOD","Zhao Tiezhu":"COLLECT_WOOD","Dr. Su":"PREPARE_MEDICAL","Wang Ce":"MAINTAIN_POWER","Lu Chen":"COLLECT_WOOD","Qing Xuan":"COLLECT_FOOD","Xin Yue":"COLLECT_MATERIAL"},"reasoning":"Address resource shortage first"}]}

⚠️ ALL text in name, description, and reasoning fields MUST be in English!`;

            let userPrompt = `---Current Situation---\n${snapshot.situation}\n---End Situation---\n\n`;
            if (chatHistory.length > 0) {
                userPrompt += `---Discussion Record---\n${chatHistory.join('\n')}\n---End Discussion---\n\n`;
            }
            userPrompt += `Surviving members status (⚠️ MUST consider when assigning tasks! Those in critical condition can only be assigned REST/PREPARE_MEDICAL):\n  ${participantInfo}\n\n`;

            let machineHint = '';
            if (snapshot._game && snapshot._game.machineSystem) {
                const ms = snapshot._game.machineSystem;
                if (ms.generator.broken) machineHint += '⚠️ Auto Generator BROKEN! Assign someone to REPAIR_GENERATOR!\n';
                if (ms.lumberMill.broken) machineHint += '⚠️ Auto Lumber Mill BROKEN! Assign someone to REPAIR_LUMBER_MILL!\n';
                if (ms.foodCollector.broken) machineHint += '⚠️ Auto Food Collector BROKEN! Assign someone to REPAIR_FOOD_COLLECTOR!\n';
                if (ms.canUnlockGenerator() && !ms.generator.built && !ms.generator.building) {
                    machineHint += '💡 Can build Auto Generator (BUILD_GENERATOR) — permanent auto power!\n';
                }
                if (ms.canUnlockLumberMill() && !ms.lumberMill.built && !ms.lumberMill.building) {
                    machineHint += '💡 Can build Auto Lumber Mill (BUILD_LUMBER_MILL) — permanent auto wood!\n';
                }
                if (ms.canUnlockFoodCollector && ms.canUnlockFoodCollector() && !ms.foodCollector.built && !ms.foodCollector.building) {
                    machineHint += '💡 Can build Auto Food Collector (BUILD_FOOD_COLLECTOR) — permanent auto food!\n';
                }
            }
            if (machineHint) {
                userPrompt += `---Automation Facility Status---\n${machineHint}---End Facility Status---\n\n`;
            }

            userPrompt += `Based on the above, propose 2-3 most feasible action plans with clear personnel assignments.\n⚠️ Each person's value in assignments MUST be a standard taskType key (e.g. COLLECT_WOOD, MAINTAIN_POWER, BUILD_GENERATOR)!\n⚠️ MAINTAIN_POWER=manual power, BUILD_GENERATOR=build auto machine, REPAIR_GENERATOR=repair broken generator — they are DIFFERENT!\n⚠️ You MUST assign tasks to ALL listed personnel! Do not miss anyone!${triageParticipants ? '\n⚠️ Only assign tasks to the listed participants. Others continue their current work.' : ''}\nOutput in JSON format.`;

            return { systemPrompt, userPrompt, maxTokens: 800 };
        },

        /** Build vote prompt */
        buildVotePrompt(snapshot, npc, proposalSummary) {
            const card = snapshot.characterCards[npc.id];
            const _dn = npc.displayName || npc.name;
            const otherNames = snapshot.aliveNpcs.filter(n => n.id !== npc.id).map(n => n.displayName || n.name);
            const numProposals = (proposalSummary.match(/方案\d+|Plan \d+/g) || []).length || 3;
            const npcState = snapshot.npcStates[npc.id] || {};

            const staminaVal = Math.round(npc.stamina);
            const sanityVal = Math.round(npc.sanity);
            const healthVal = Math.round(npc.health);
            const hungerVal = Math.round(npc.hunger || 50);
            const tempVal = npc.bodyTemp ? npc.bodyTemp.toFixed(1) : '36.5';

            let myStatusBlock = `\n\n---Your Current Status---`;
            myStatusBlock += `\n💪STA:${staminaVal}/100 🧠San:${sanityVal}/100 🫀HP:${healthVal}/100 🍖Hunger:${hungerVal}/100 🌡️Temp:${tempVal}°C`;
            if (npc.isCrazy) myStatusBlock += `\n🤯 You are having a mental breakdown! You CANNOT work!`;
            if (npc.isSick) myStatusBlock += `\n🤒 You are sick!`;
            if (npc._isDying) myStatusBlock += `\n🚨 You are DYING!`;
            if (npcState.stateHints) myStatusBlock += npcState.stateHints;
            if (staminaVal <= 0 || sanityVal <= 0 || healthVal <= 0) {
                myStatusBlock += `\n⚠️ Your condition is critical! When voting, prioritize your own survival! You cannot do labor — you need REST/treatment/comfort!`;
            }
            myStatusBlock += `\n---End Status---`;

            let teamStatusBlock = '\n\n---Team Member Status---';
            for (const n of snapshot.aliveNpcs) {
                const _ndn = n.displayName || n.name;
                const tags = [];
                if (n.isCrazy) tags.push('🤯Crazy');
                if (n._isDying) tags.push('🚨Dying');
                if (n.isSick) tags.push('🤒Sick');
                if (n.stamina <= 0) tags.push('STA=0');
                if (n.sanity <= 0) tags.push('San=0');
                if (n.health < 10) tags.push('HP critical');
                else if (n.stamina < 20) tags.push('STA low');
                if (n.sanity < 20 && !n.isCrazy) tags.push('San low');
                const tagStr = tags.length > 0 ? ` [${tags.join(', ')}]` : ' [OK]';
                teamStatusBlock += `\n${_ndn}: STA${Math.round(n.stamina)} San${Math.round(n.sanity)} HP${Math.round(n.health)}${tagStr}`;
            }
            teamStatusBlock += '\n---End Team Status---';

            const systemPrompt = `[Identity Lock] You ARE "${_dn}".
Use "I" to refer to yourself, NEVER use third person. ${otherNames.join(', ')} are other people, not you.
${card}

You are voting on action plans. From your character's perspective and expertise, choose the plan you support most.
Give a one-sentence reason (use "I" to refer to yourself). Decide independently based on your personality.

⚠️ When voting, you MUST consider your own and teammates' physical condition!
- People with STA/San/HP at zero CANNOT do labor — they must rest or receive treatment
- Crazy/dying people need comfort/treatment/rest as top priority
- Assigning labor to a dying person is UNREASONABLE!

⚠️ Common sense reminders:
- "Chopping wood" produces 🪵wood, NOT power
- "Manual power" generates ⚡power at the workshop
- "Build generator" creates an auto-generator that produces ⚡power (consumes 🪵wood)
- "Build lumber mill" creates an auto-mill that produces 🪵wood (consumes ⚡power)
- Lumber mill CANNOT generate power! Generator CANNOT produce wood! Don't confuse them!

Output format MUST be JSON:
{
  "vote": 1,
  "reason": "One sentence reason in English, use I to refer to yourself"
}

vote field = plan number (1~${numProposals}), reason field = your reason.
⚠️ The reason field MUST be in English! Do not use Chinese!`;

            let userPrompt = `---Situation Summary---\n${snapshot.situation}\n---End Situation---\n\n`;
            userPrompt += `---Plans to Vote On---\n${proposalSummary}\n---End Plans---\n\n`;
            userPrompt += myStatusBlock + teamStatusBlock + '\n\n';
            userPrompt += `[You are ${_dn}, use "I" to refer to yourself. Consider your physical condition and vote for your preferred plan. Output JSON. ALL text MUST be in English!]`;

            return { systemPrompt, userPrompt, maxTokens: 150 };
        },

        /** Build summary prompt */
        buildSummaryPrompt(snapshot, winnerProposal, summaryNpc) {
            const speaker = summaryNpc || { id: 'old_qian', name: 'Old Qian' };
            const trait = NPC_TRAITS[speaker.id] || 'Camp member.';

            const deadNames = snapshot.deadNames || [];
            let deadContext = '';
            if (deadNames.length > 0) {
                deadContext = `\n⚠️ ${deadNames.length} people have died (${deadNames.join(', ')}). Please express condolences and encourage the survivors.`;
            }

            const speakerName = speaker.displayName || speaker.name;
            const systemPrompt = `You are "${speakerName}", ${trait} You just finished a voting meeting and now give a summary speech.\nUse "I" to refer to yourself. Never use third person.${deadContext}\n\n[LANGUAGE] You MUST respond entirely in English. Do not use any Chinese characters.`;

            const assignText = winnerProposal.assignments
                ? Object.entries(winnerProposal.assignments).map(([n, t]) => `${n} → ${getTaskLabel(t)}`).join(', ')
                : '';

            const userPrompt = `Vote result: Everyone chose "${winnerProposal.name}" — ${winnerProposal.description}\n${assignText ? 'Assignments: ' + assignText : ''}\n\nGive a brief and powerful summary speech (2-3 sentences), announce the decision, boost morale. Speak naturally and in character. ALL in English.`;

            return { systemPrompt, userPrompt, maxTokens: 200 };
        },

        /** Build triage prompt */
        buildTriagePrompt(snapshot, triggerReason) {
            const alive = snapshot.aliveNpcs;
            let npcStatusList = '';
            for (const n of alive) {
                const cfg = (GST.NPC_CONFIGS || []).find(c => c.id === n.id) || {};
                const _dn = n.displayName || n.name;
                const tags = [];
                if (n.isCrazy) tags.push('🤯Crazy');
                if (n._isDying) tags.push('🚨Dying');
                if (n.isSick) tags.push('🤒Sick');
                if (n.stamina <= 0) tags.push('STA=0');
                else if (n.stamina < 20) tags.push('STA low');
                if (n.sanity <= 0) tags.push('San=0');
                else if (n.sanity < 20) tags.push('San low');
                if (n.health < 10) tags.push('HP critical');
                if (n.isSleeping) tags.push('💤Sleeping');
                const tagStr = tags.length > 0 ? ` [${tags.join(', ')}]` : ' [OK]';
                const currentAction = n.stateDesc || n.state || 'idle';
                npcStatusList += `  ${_dn}(${cfg.occupation || ''}): STA${Math.round(n.stamina)}/San${Math.round(n.sanity)}/HP${Math.round(n.health)}${tagStr} Doing:${currentAction}\n`;
            }

            const systemPrompt = `You are a game AI system. An emergency has occurred. From the crisis person's perspective, determine: who should they ask for help? Or can they handle it alone?

Rules:
1. The crisis person is always the first participant (even if crazy/dying, they express their state)
2. The crisis person decides whether to seek help:
   - If they can handle it alone (e.g. just tired, needs rest), they can be the only participant
   - If they need professional help (e.g. sick → find Dr. Su), they'll seek the right person
   - If it's severe (e.g. dying), nearby people will come help automatically
3. Don't call too many people — everyone has their own tasks:
   - People doing important unrelated tasks don't need to come
   - Sleeping people don't need to come (unless they're the only one who can help)
   - People in bad shape themselves don't need to come (unless they're specialists)
4. Minimum 1 person (the crisis person), maximum 4
5. If the crisis person is crazy/dying and can't think clearly, the system auto-includes nearby people

Output format MUST be JSON:
{
  "participants": ["Name1"],
  "reason": "One sentence (from crisis person's perspective, e.g. 'I'm just tired, I'll rest' or 'I need to find Dr. Su')",
  "selfResolve": true/false,
  "otherOrders": {"Name": "continue current task"}
}`;

            let userPrompt = `---Emergency---\n${triggerReason}\n---End Emergency---\n\n`;
            userPrompt += `---Current Situation---\n${snapshot.situation}\n---End Situation---\n\n`;
            userPrompt += `---All Surviving NPC Status---\n${npcStatusList}---End Status---\n\n`;
            userPrompt += `Determine which people need to participate in this emergency meeting. Output JSON.`;

            return { systemPrompt, userPrompt, maxTokens: 300 };
        },

        /** Get offline fallback line */
        getFallback(npcId) {
            const pool = FALLBACKS[npcId] || ['...(silence)'];
            return pool[Math.floor(Math.random() * pool.length)];
        },
    };

    GST._councilPromptsEn = EN;
})();
