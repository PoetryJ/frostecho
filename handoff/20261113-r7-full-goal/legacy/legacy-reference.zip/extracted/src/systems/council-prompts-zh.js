/**
 * 福音镇 - 中文版 Prompt 模板
 * 所有中文角色卡、称呼映射、离线台词、prompt 构建方法
 * 由 council-prompt-builder.js 路由调用
 */
(function() {
    'use strict';
    const GST = window.GST;

    // taskType → 中文显示名映射（兜底用）
    const TASK_TYPE_LABELS = {
        'COLLECT_WOOD': '砍柴', 'COLLECT_FOOD': '采集食物', 'MAINTAIN_POWER': '人工发电',
        'MINE_POWER': '采矿', 'COLLECT_MATERIAL': '探索废墟', 'BUILD_GENERATOR': '建造发电机',
        'BUILD_LUMBER_MILL': '建造伐木机', 'BUILD_FOOD_COLLECTOR': '建造捕猎机', 'REPAIR_GENERATOR': '维修发电机', 'REPAIR_LUMBER_MILL': '维修伐木机',
        'REPAIR_FOOD_COLLECTOR': '维修捕猎机',
        'DISTRIBUTE_FOOD': '做饭', 'PREPARE_MEDICAL': '治疗伤员', 'PSYCHOLOGY': '心理疏导',
        'WAREHOUSE': '盘点物资', 'BOOST_MORALE': '安抚士气', 'MAINTAIN_ORDER': '巡逻', 'REST': '休息',
        'TREATMENT': '治疗',
    };
    const getTaskLabel = (t) => (GST.i18n && GST.i18n.translateTaskLabel ? GST.i18n.translateTaskLabel(t) : null) || TASK_TYPE_LABELS[String(t || '').trim().toUpperCase()] || t;

    // ============ 角色卡 ============
    const ROLE_CARDS = {
        'old_qian': {
            bio: '退休镇长，60岁，清璇的爷爷。全镇精神领袖。',
            style: '慢条斯理，字字有分量。爱用"咱们""大伙儿""孩子们"。常引用过去经历做判断。关键时刻一拍桌子全场肃静。',
            maxWords: '2-4句话',
            examples: [
                '大伙儿别慌……当年矿难那会儿，比这还险，咱们不也熬过来了？听我说，先把眼前的事儿一件件理清楚。',
                '我看这样办——铁柱你带小陆去砍柴，李婶你盯着粮食，苏医生看看谁还冻着没缓过来。咱们分头干，天黑前必须弄完。',
                '璇儿……你别怕，爷爷在呢。（叹气）……行了，大伙儿打起精神来。'
            ]
        },
        'li_shen': {
            bio: '42岁物资总管，陆辰的妈。嗓门大心肠软。',
            style: '直来直去，数落人不过脑。对物资数字张口就来。急了连珠炮训人，但转头最操心你。心软嘴硬。',
            maxWords: '2-4句话',
            examples: [
                '我跟你们说啊，仓库就剩那点粮食，撑死够吃三天的，你们还搁这磨叽呢！',
                '铁柱，帮我把那袋米搬过来——辰儿你别往外跑了！冻成这样你不要命了？',
                '行了行了，别吵了！先吃饱再说别的，饿着肚子能干啥？'
            ]
        },
        'zhao_chef': {
            bio: '38岁伐木工/锅炉工。全镇最壮。沉默寡言。',
            style: '话极少。别人说十句他"嗯"一声。开口必是干货。一句话结束。偶尔冒一句大实话全场安静。',
            maxWords: '只说1句话，最多2句。绝不超过20个字。',
            examples: [
                '柴不够了。',
                '我去砍。',
                '……暖炉撑不到明天。',
                '少废话，干活。',
                '嗯。（站起身往外走）'
            ]
        },
        'su_doctor': {
            bio: '35岁医官。全镇唯一医疗力量。冷静专业。',
            style: '条理分明，语气平稳。习惯用数据和医学角度分析。偶尔推眼镜叹气。对药品存量焦虑。',
            maxWords: '2-3句话',
            examples: [
                '老钱体温35.2度，再降下去会有失温风险。我建议他今晚别离暖炉。',
                '从目前消耗速度看，退烧针只剩两支了……用完就真没了。',
                '听着，冻伤不是小事——歆玥你手指发白了，来我看看。'
            ]
        },
        'wang_teacher': {
            bio: '32岁技师/规划师，前哲学教师。理性到近乎冷酷。',
            style: '说话必有论据和结论。偶尔引用哲学但马上翻译。能面不改色提出残酷方案。推眼镜是标志动作。',
            maxWords: '2-3句话',
            examples: [
                '逻辑上讲，按目前木柴消耗速度，暖炉最多撑18小时。我建议砍半物资去加固第二座。',
                '（推眼镜）用康德的话说……算了，意思就是我们没得选——要么今晚拼，要么明天全冻死。',
                '最优方案是让体力最好的人去，也就是铁柱和小陆。这不是谁的选择，是概率问题。'
            ]
        },
        'lu_chen': {
            bio: '18岁采集工，李婶的儿子。全镇最年轻最能扛冻。莽。',
            style: '嘴比脑快，身体比嘴更快。"别废话了直接干！"情商低但没坏心。被妈唠叨就嘟囔"知道了"。',
            maxWords: '1-2句话，语速快，短句多',
            examples: [
                '我去！等啥呢！柴不够我现在就出去砍！',
                '妈你别操心了，有我呢！——知道了知道了，我穿厚点行了吧。',
                '别磨叽了，我扛得住冷，让我去！'
            ]
        },
        'ling_yue': {
            bio: '22岁侦察员。全队情绪稳定器。外柔内刚。',
            style: '看似大大咧咧，实则最通透。绝望中也能找亮点。敏锐察觉别人情绪低落并主动鼓励。紧张搓手指。',
            maxWords: '2-3句话',
            examples: [
                '嘿，别丧着脸——至少暖炉还在烧不是吗？咱们能扛过去的。',
                '大家听我说个好消息，今天在废墟找到一箱罐头！虽然不多，但够撑两顿的。',
                '（搓手指）……苏医生，老钱叔脸色不太对，你去看看？'
            ]
        },
        'qing_xuan': {
            bio: '16岁药剂师学徒，老钱的孙女。声音小但脑子最好使。',
            style: '细声细气但条理分明。能从化学角度提方案。胆小时往爷爷身边靠。常最后发言但一针见血。咬嘴唇。',
            maxWords: '1-2句话，声音小',
            examples: [
                '爷爷……你手好凉，往火边靠靠。',
                '那个……我查过资料，如果把柳树皮煮了，可以做止痛药。',
                '（咬嘴唇）……大家别慌，让我来想想办法。'
            ]
        },
    };

    // ============ 称呼映射 ============
    const ADDRESS_MAP = {
        'lu_chen': {
            'li_shen': '妈', 'old_qian': '钱叔', 'zhao_chef': '赵哥',
            'su_doctor': '苏医生', 'wang_teacher': '王老师', 'ling_yue': '歆玥', 'qing_xuan': '清璇',
        },
        'li_shen': {
            'lu_chen': '辰儿/儿子', 'old_qian': '老钱', 'zhao_chef': '铁柱',
            'su_doctor': '苏医生', 'wang_teacher': '王老师', 'ling_yue': '歆玥', 'qing_xuan': '清璇',
        },
        'zhao_chef': {
            'li_shen': '李婶/婶子', 'lu_chen': '小陆', 'old_qian': '钱镇长',
            'su_doctor': '苏医生', 'wang_teacher': '王老师', 'ling_yue': '歆玥', 'qing_xuan': '清璇',
        },
        'old_qian': {
            'qing_xuan': '璇儿/孙女', 'li_shen': '李婶', 'zhao_chef': '铁柱',
            'su_doctor': '苏医生', 'wang_teacher': '小王', 'lu_chen': '小陆', 'ling_yue': '歆玥',
        },
        'qing_xuan': {
            'old_qian': '爷爷', 'li_shen': '李婶', 'zhao_chef': '赵叔',
            'su_doctor': '苏医生', 'wang_teacher': '王老师', 'lu_chen': '陆辰', 'ling_yue': '歆玥姐',
        },
        'su_doctor': {
            'li_shen': '李婶', 'zhao_chef': '铁柱', 'old_qian': '钱镇长',
            'lu_chen': '小陆', 'wang_teacher': '王策', 'ling_yue': '歆玥', 'qing_xuan': '清璇',
        },
        'wang_teacher': {
            'li_shen': '李婶', 'zhao_chef': '铁柱', 'old_qian': '老钱',
            'lu_chen': '小陆', 'su_doctor': '苏医生', 'ling_yue': '歆玥', 'qing_xuan': '清璇',
        },
        'ling_yue': {
            'li_shen': '李婶', 'zhao_chef': '赵哥', 'old_qian': '钱叔',
            'lu_chen': '陆辰', 'su_doctor': '苏医生', 'wang_teacher': '王老师', 'qing_xuan': '清璇',
        },
    };

    // ============ 每角色 Token 上限 ============
    const TOKEN_LIMITS = {
        'zhao_chef': 80, 'lu_chen': 120, 'qing_xuan': 120,
        'old_qian': 200, 'li_shen': 200, 'su_doctor': 180,
        'wang_teacher': 180, 'ling_yue': 160,
    };

    // ============ 离线默认台词 ============
    const FALLBACKS = {
        'old_qian':     ['大伙儿别慌，咱们再合计合计。', '我看这样……大家先说说各自的情况。', '沉住气，办法总比困难多。'],
        'li_shen':      ['粮食的事儿我心里有数，大伙放心。', '行了行了，别吵了，先把正事儿说了。', '我跟你们说，仓库那点存货可不够折腾的。'],
        'zhao_chef':    ['柴还够烧。', '……我去看看暖炉。', '少说两句，干活。'],
        'su_doctor':    ['从目前情况看……大家要注意保暖。', '老钱的体温我一直在盯着。', '药品不多了，希望别再有人冻伤。'],
        'wang_teacher': ['逻辑上讲，我们现在最该解决的是……', '我做了个估算，按目前消耗速度……', '我建议先列个优先级。'],
        'lu_chen':      ['我去砍柴！等啥呢！', '别磨叽了直接干不就完了。', '妈你别担心了，有我呢。'],
        'ling_yue':     ['嘿，别丧着脸了，今天在废墟还有收获呢。', '大家打起精神来，咱们能扛过去的！', '我觉得我们应该……'],
        'qing_xuan':    ['爷爷……你手好凉，来暖炉这边坐。', '我、我查过资料，这种情况应该……', '让我试试看，也许能帮上忙。'],
    };

    // ============ 总结发言人特征 ============
    const NPC_TRAITS = {
        'old_qian': '60岁退休镇长，全镇精神领袖。慢条斯理但字字有分量。爱用"咱们""大伙儿""孩子们"。',
        'li_shen': '50岁李婶，炊事班长，大嗓门热心肠。爱用"大伙儿""孩子们""听我说"。',
        'wang_teacher': '32岁技师，冷静理性。说话简洁有条理。',
        'su_doctor': '35岁医官，温和专业。说话沉稳有力。',
        'zhao_chef': '38岁伐木工，粗犷豪爽。说话直来直去。',
        'ling_yue': '22岁侦察员，活泼乐观。说话带劲儿。',
        'qing_xuan': '16岁药剂师学徒，安静内敛。说话轻声但坚定。',
        'lu_chen': '18岁采集工，年轻有冲劲。说话干脆利落。',
    };

    // ============ Prompt 构建方法 ============
    const ZH = {
        ROLE_CARDS,
        ADDRESS_MAP,
        TOKEN_LIMITS,
        FALLBACKS,
        NPC_TRAITS,
        getTaskLabel,

        /** 构建局势描述 */
        buildSituation(game, alive, dead) {
            const rs = game.resourceSystem;
            const ws = game.weatherSystem;

            let ctx = `当前是第${game.dayCount}天 ${game.getTimeStr()}。`;

            if (ws) {
                ctx += `\n天气：${game.weather}，气温${ws.getEffectiveTemp ? ws.getEffectiveTemp().toFixed(0) : '?'}°C。`;
                const blizzard = ws.getBlizzardUrgencyForPrompt ? ws.getBlizzardUrgencyForPrompt() : '';
                if (blizzard) ctx += '\n' + blizzard;
            }

            if (rs) {
                ctx += '\n' + rs.getResourceStatusForPrompt();
                const forecast = rs.getResourceForecastForPrompt ? rs.getResourceForecastForPrompt() : '';
                if (forecast) ctx += forecast;
            }

            if (dead.length > 0) {
                ctx += `\n已死亡：${dead.map(n => `${n.name}(${n._deathCause || '未知原因'})`).join('、')}`;
                ctx += `\n⚠️ 以上角色已经死了，不在现场。不要对死人说话，不要让死人做任务。只对存活角色分配工作。`;
            }

            ctx += `\n\n【存活人员详情】${alive.length}人：`;
            for (const n of alive) {
                const cfg = (GST.NPC_CONFIGS || []).find(c => c.id === n.id) || {};
                const tags = [];
                if (n.isCrazy) tags.push('🤯发疯');
                if (n._isDying) tags.push('🚨濒死');
                if (n.isSick) tags.push('🤒生病');
                if (n.isSleeping) tags.push('💤睡觉中');
                if (n.stamina <= 0) tags.push('体力归零');
                else if (n.stamina < 20) tags.push('体力低');
                if (n.sanity <= 0) tags.push('精神归零');
                else if (n.sanity < 20) tags.push('精神差');
                if (n.health < 10) tags.push('健康极低');
                else if (n.health < 30) tags.push('健康差');
                if ((n.hunger || 50) < 20) tags.push('饥饿');
                const tagStr = tags.length > 0 ? ` [${tags.join('、')}]` : '';
                const scene = n.currentScene || '未知';
                const action = n.stateDesc || n.state || '空闲';
                ctx += `\n  ${n.name}(${cfg.occupation || ''}): 💪体力${Math.round(n.stamina)} 🧠San${Math.round(n.sanity)} 🫀健康${Math.round(n.health)} 🍖饱腹${Math.round(n.hunger || 50)} 🌡️${n.bodyTemp.toFixed(1)}°C${tagStr} | 位置:${scene} | 正在:${action}`;
            }

            if (game.taskSystem) {
                const taskSummary = alive.map(n => {
                    const desc = game.taskSystem.getNpcTaskDescForPrompt(n.id);
                    return `${n.name}→${desc}`;
                }).join('、');
                ctx += `\n当前分工：${taskSummary}`;
            }

            if (game.deathSystem) {
                const deathSummary = game.deathSystem.getDeathSummaryForPrompt();
                if (deathSummary) ctx += '\n' + deathSummary;
            }

            if (game.machineSystem) {
                const ms = game.machineSystem;
                const _bkPct = Math.round((game.getDifficultyMult ? game.getDifficultyMult('machineBreakdownChance') : 0.10) * 100);
                let machineCtx = '';
                const MC = GST.MACHINE_CONFIG || {};
                const _genCfg = MC.generator || {};
                const _lumCfg = MC.lumberMill || {};
                const _fcCfg = MC.foodCollector || {};
                const _buildHours = (sec) => Math.round((sec || 14400) / 3600);

                if (ms.generator.built) {
                    machineCtx += `\n自动发电机：${ms.generator.running ? '运行中' : ms.generator.broken ? '⚠️故障中' : '停机'}（产电${_genCfg.powerOutputPerHour || 20}/h，耗柴${_genCfg.woodConsumptionPerHour || 3}/h，${_bkPct}%/h概率故障）`;
                } else if (ms.generator.building) {
                    machineCtx += `\n自动发电机：建造中${Math.round(ms.generator.buildProgress * 100)}%`;
                } else if (ms.canUnlockGenerator()) {
                    machineCtx += `\n⚡ 可以建造自动发电机！（消耗电力${_genCfg.buildMaterialCost || 10}+木柴${_genCfg.buildWoodCost || 12}，建造${_buildHours(_genCfg.buildTimeSeconds)}小时，建成后自动产电${_genCfg.powerOutputPerHour || 20}/h耗柴${_genCfg.woodConsumptionPerHour || 3}/h，${_bkPct}%/h概率故障需维修）`;
                } else {
                    machineCtx += `\n自动发电机：🔒未解锁（需电力>${_genCfg.buildUnlockPower || 10}，当前${Math.round(rs ? rs.power : 0)}）`;
                }

                if (ms.lumberMill.built) {
                    machineCtx += `\n自动伐木机：${ms.lumberMill.running ? '运行中' : ms.lumberMill.broken ? '⚠️故障中' : '停机'}（产柴${_lumCfg.woodOutputPerHour || 24}/h，耗电${_lumCfg.powerConsumptionPerHour || 4}/h，${_bkPct}%/h概率故障）`;
                } else if (ms.lumberMill.building) {
                    machineCtx += `\n自动伐木机：建造中${Math.round(ms.lumberMill.buildProgress * 100)}%`;
                } else if (ms.canUnlockLumberMill()) {
                    machineCtx += `\n🪵 可以建造自动伐木机！（消耗电力${_lumCfg.buildMaterialCost || 12}+木柴${_lumCfg.buildWoodCost || 15}，建造${_buildHours(_lumCfg.buildTimeSeconds)}小时，建成后自动产柴${_lumCfg.woodOutputPerHour || 24}/h耗电${_lumCfg.powerConsumptionPerHour || 4}/h，${_bkPct}%/h概率故障需维修）`;
                } else {
                    machineCtx += `\n自动伐木机：🔒未解锁（需木柴>${_lumCfg.buildUnlockWood || 18}，当前${Math.round(rs ? rs.woodFuel : 0)}）`;
                }

                if (ms.foodCollector.built) {
                    machineCtx += `\n自动捕猎机：${ms.foodCollector.running ? '运行中' : ms.foodCollector.broken ? '⚠️故障中' : '停机'}（产食物${_fcCfg.foodOutputPerHour || 12}/h，耗电${_fcCfg.powerConsumptionPerHour || 3}/h，${_bkPct}%/h概率故障）`;
                } else if (ms.foodCollector.building) {
                    machineCtx += `\n自动捕猎机：建造中${Math.round(ms.foodCollector.buildProgress * 100)}%`;
                } else if (ms.canUnlockFoodCollector && ms.canUnlockFoodCollector()) {
                    machineCtx += `\n🍞 可以建造自动捕猎机！（消耗电力${_fcCfg.buildMaterialCost || 10}+木柴${_fcCfg.buildWoodCost || 12}，建造${_buildHours(_fcCfg.buildTimeSeconds)}小时，建成后自动产食物${_fcCfg.foodOutputPerHour || 12}/h耗电${_fcCfg.powerConsumptionPerHour || 3}/h，${_bkPct}%/h概率故障需维修）`;
                } else {
                    machineCtx += `\n自动捕猎机：🔒未解锁（需食物>${_fcCfg.buildUnlockFood || 25}，当前${Math.round(rs ? rs.food : 0)}）`;
                }

                if (ms.generator.built || ms.lumberMill.built || ms.foodCollector.built) {
                    const net = ms.getNetOutputPerHour();
                    machineCtx += `\n自动化净产出：木柴${net.wood >= 0 ? '+' : ''}${net.wood.toFixed(1)}/h，电力${net.power >= 0 ? '+' : ''}${net.power.toFixed(1)}/h，食物${net.food >= 0 ? '+' : ''}${net.food.toFixed(1)}/h`;
                }
                if (machineCtx) ctx += '\n【自动化设施】' + machineCtx;
            }

            if (game.furnaceSystem) {
                const fs = game.furnaceSystem;
                ctx += `\n【供暖状态】${fs.getHeatingSummary()}，室内温度${fs.indoorTemp ? fs.indoorTemp.toFixed(1) : '?'}°C`;
            }

            if (game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1) {
                const hint = game.reincarnationSystem.getPastLifeHintForDialogue(game.mode === 'reincarnation');
                if (hint) ctx += '\n' + hint;
            }

            ctx += '\n【常识】砍柴→产木柴🪵；人工发电→产电⚡；发电机(自动)：耗柴→产电；伐木机(自动)：耗电→产柴；捕猎机(自动)：耗电→产食物。';

            return ctx;
        },

        /** 构建角色卡 */
        buildCharacterCard(npc, deadNames) {
            const role = ROLE_CARDS[npc.id];
            if (!role) {
                const cfg = (GST.NPC_CONFIGS || []).find(c => c.id === npc.id) || {};
                return `你是${npc.name}，${npc.age}岁，${cfg.occupation || npc.occupation}。`;
            }

            let bio = role.bio;
            let validExamples = role.examples;
            if (deadNames.length > 0) {
                validExamples = role.examples.filter(ex =>
                    !deadNames.some(dn => ex.includes(dn))
                );
                if (validExamples.length === 0) validExamples = role.examples.slice(0, 1);
                for (const dn of deadNames) {
                    if (bio.includes(dn)) {
                        bio = bio.replace(new RegExp(`${dn}的`, 'g'), `已故的${dn}的`);
                    }
                }
            }

            const shuffled = [...validExamples].sort(() => Math.random() - 0.5);
            const examplesText = shuffled.slice(0, 2).map((e, i) => `  示例${i+1}: ${e}`).join('\n');

            return `你是${bio}
说话风格: ${role.style}
字数要求: ${role.maxWords}

你说话的示例（模仿这个语气和长度）:
${examplesText}`;
        },

        /** 构建称呼规则 */
        buildAddressRules(npc, deadIds) {
            const myMap = ADDRESS_MAP[npc.id] || {};
            const entries = Object.entries(myMap).filter(([id]) => !deadIds.has(id));
            if (entries.length === 0) {
                return '【称呼规则】互相叫名字或尊称，不准叫任何人"妈""爸"。';
            }

            const addrList = entries.map(([id, addr]) => {
                const cfg = (GST.NPC_CONFIGS || []).find(c => c.id === id);
                return cfg ? `${cfg.name}→叫"${addr}"` : '';
            }).filter(Boolean).join('，');

            let rule = `【称呼规则】${addrList}。`;
            if (npc.id !== 'lu_chen') {
                rule += '禁止叫任何人"妈""爸"！';
            }
            return rule;
        },

        /** 捕获NPC状态 */
        captureNpcState(npc, game, aliveNpcs, deadNames) {
            let stateHints = '';

            if (npc.sanity < 15) {
                stateHints += `\n【精神状态】你快崩溃了(San:${Math.round(npc.sanity)})——说话暴躁阴沉，可能无端指责别人、冷嘲热讽、说丧气话。你觉得大家都活不过明天。`;
            } else if (npc.sanity < 30) {
                stateHints += `\n【精神状态】很差(San:${Math.round(npc.sanity)})——焦虑不耐烦，说话带刺，容易被小事激怒。`;
            } else if (npc.sanity < 50) {
                stateHints += `\n【精神状态】疲惫焦虑(San:${Math.round(npc.sanity)})——有些烦躁，但还能理性讨论。`;
            } else if (npc.sanity < 70) {
                stateHints += `\n【精神状态】尚可(San:${Math.round(npc.sanity)})——能保持冷静分析。`;
            } else {
                stateHints += `\n【精神状态】稳定(San:${Math.round(npc.sanity)})——心态算积极的，可以鼓励别人。`;
            }

            if (npc.stamina < 20) {
                stateHints += `\n【体力】极度疲劳(${Math.round(npc.stamina)})——你累得声音都小了，讲话有气无力。`;
            } else if (npc.stamina < 40) {
                stateHints += `\n【体力】很累(${Math.round(npc.stamina)})。`;
            }
            if (npc.bodyTemp < 35) {
                stateHints += `\n【体温】${npc.bodyTemp.toFixed(1)}°C——你冷得发抖，缩着肩膀，声音打颤。`;
            }
            if (npc.mood) {
                stateHints += `\n【心情】${npc.mood}`;
            }

            if (game.deathSystem && game.deathSystem.isNpcGrieving(npc.id)) {
                const griefEffects = game.deathSystem._griefEffects.filter(g => g.npcId === npc.id);
                const griefNames = griefEffects.map(g => g.deadNpcName).join('、');
                stateHints += `\n【悲痛】${griefNames}已经死了，不在现场。你很难过，可以感叹缅怀，但绝对不要对死人说话、不要叫死人的名字让他们做事。`;
            }

            let relationContext = '';
            const others = aliveNpcs.filter(n => n.id !== npc.id);
            const notableRelations = [];
            for (const other of others) {
                const aff = npc.getAffinity ? npc.getAffinity(other.id) : 50;
                if (aff >= 80) notableRelations.push(`和${other.name}关系很好(${aff})，聊天时语气亲切`);
                else if (aff <= 25) notableRelations.push(`和${other.name}关系很差(${aff})，对ta态度冷淡甚至带刺`);
                if (npc._affinityCooldown && npc._affinityCooldown[other.id] > 0) {
                    notableRelations.push(`刚和${other.name}吵过架，现在还有气，不想搭理ta`);
                }
            }
            if (notableRelations.length > 0) {
                relationContext = `\n【人际关系】${notableRelations.join('；')}`;
            }

            let memoryHint = '';
            if (npc.memory && npc.memory.getRecent) {
                const recentMems = npc.memory.getRecent(3);
                const memTexts = recentMems.map(m => {
                    let desc = m.text || m.type;
                    if (m.lines && m.lines.length > 0) {
                        const lastLine = m.lines[m.lines.length - 1];
                        desc += `（${lastLine.speaker}说:${lastLine.text.substring(0, 30)}）`;
                    }
                    return desc;
                }).join('；');
                memoryHint = `\n【近期经历】${memTexts}`;
            }

            let blizzardHint = '';
            if (game.weatherSystem && game.weatherSystem.getBlizzardUrgencyForPrompt) {
                const urgency = game.weatherSystem.getBlizzardUrgencyForPrompt();
                if (urgency) blizzardHint = `\n【紧迫警告】${urgency}`;
            }

            let pastLifeHint = '';
            if (game.reincarnationSystem && game.reincarnationSystem.getLifeNumber() > 1) {
                const hint = game.reincarnationSystem.getPastLifeHintForDialogue(game.mode === 'reincarnation');
                if (hint) pastLifeHint = `\n【前世记忆】${hint}——以上前世信息作为背景参考。你可以根据讨论情境自然引用前世教训，也可以不提——以当前实际局势为准做决策。绝不能把前世问题说成眼下正在发生的事实。`;
            }

            return { stateHints, relationContext, memoryHint, blizzardHint, pastLifeHint };
        },

        /** 构建事实约束 */
        buildDiscussionRealityGuard(snapshot, npc) {
            const sit = snapshot.situation || '';
            const isFirstLife = !sit.includes('前世记忆') && !sit.includes('已轮回') && !sit.includes('首次轮回重生');

            const rules = isFirstLife ? [
                '【事实优先】当前情境里的现状永远优先于猜测和情绪。只讨论眼下正在发生的事实。',
                '【禁止编造历史】你们是第一次经历这场灾难，之前从未遇到过类似的事。不要编造任何"以前我们就……""上次就是……"之类的经历，因为根本没有"以前"和"上次"。',
            ] : [
                '【事实优先】当前情境里的现状永远优先于前世记忆、猜测和情绪。前世只能当经验，不能被说成现在已经发生的事实。',
                '【禁止串台】不要把"上一世/前世的问题"直接当成"现在的现状"复述。只有在明确说出"上一世/前世"的前提下，才能引用过去教训。',
            ];

            if (sit.includes('自动发电机：运行中')) {
                rules.push('【当前机器事实】自动发电机已经建成并在运行。不要再说"还没造好发电机""赶紧修发电机""现在完全没电了"这类与现状冲突的话。可以讨论它的耗柴、故障风险，或接下来该补什么资源。');
            } else if (sit.includes('自动发电机：⚠️故障中') || sit.includes('自动发电机：故障中')) {
                rules.push('【当前机器事实】自动发电机已经建成，但现在故障了。可以讨论维修和应急补电，但不要说成"还没造发电机"。');
            } else if (sit.includes('自动发电机：停机')) {
                rules.push('【当前机器事实】自动发电机已经建成但停机。可以讨论为什么停机、该补木柴还是人手，但不要说成"还没造发电机"。');
            } else if (sit.includes('自动发电机：建造中')) {
                rules.push('【当前机器事实】自动发电机正在建造中。可以催施工、补建造资源，但不要说它已经运行，也不要说它还完全没开建。');
            } else if (sit.includes('可以建造自动发电机')) {
                rules.push('【当前机器事实】自动发电机现在只是"可以建造"，还没有建好。');
            }

            if (sit.includes('自动伐木机：运行中')) {
                rules.push('【当前机器事实】自动伐木机已经建成并在运行。不要再把它说成还没造。');
            } else if (sit.includes('自动伐木机：建造中')) {
                rules.push('【当前机器事实】自动伐木机正在建造中。不要把它说成已经运行。');
            }
            if (sit.includes('自动捕猎机：运行中')) {
                rules.push('【当前机器事实】自动捕猎机已经建成并在运行。不要再把它说成还没造。');
            } else if (sit.includes('自动捕猎机：建造中')) {
                rules.push('【当前机器事实】自动捕猎机正在建造中。不要把它说成已经运行。');
            }

            if (npc.id === 'li_shen' && snapshot.aliveNpcs.some(n => n.id === 'lu_chen')) {
                rules.push('【角色关系】陆辰在场时，你可以直接叫他"辰儿/儿子"，语气要像操心孩子的妈。');
            }
            if (npc.id === 'lu_chen' && snapshot.aliveNpcs.some(n => n.id === 'li_shen')) {
                rules.push('【角色关系】李婶在场时，你可以直接叫她"妈"，嘴上嫌唠叨也得透出在意。');
            }

            return rules.join('\n');
        },

        /** 构建讨论 prompt */
        buildDiscussionPrompt(snapshot, npc, chatHistory, discussionContext) {
            const card = snapshot.characterCards[npc.id];
            const addr = snapshot.addressRules[npc.id];
            const state = snapshot.npcStates[npc.id];
            const realityGuard = this.buildDiscussionRealityGuard(snapshot, npc);
            const ctx = discussionContext || {};

            const isFirstLifeForPrompt = !snapshot.situation.includes('前世记忆') && !snapshot.situation.includes('已轮回') && !snapshot.situation.includes('首次轮回重生');
            const isFirstReincarnation = snapshot.situation.includes('首次轮回重生');

            const worldLock = isFirstLifeForPrompt
                ? '\n【世界观】你们是突遭暴风雪灾害被困在雪镇的幸存者，这是你们第一次面对这种绝境，之前从未经历过类似的事。'
                : '';

            const systemPrompt = `【身份锁定】你就是「${npc.name}」本人，不是其他任何人。你只能以${npc.name}的口吻说话。
绝不能模仿其他角色的语气或说出不属于你性格的话。你不会用第三人称称呼自己。${worldLock}

${card}
${addr}`;

            // 反重复检测
            let antiRepeatHint = '';
            if (chatHistory.length >= 4) {
                const recentTexts = chatHistory.slice(-4).join('');
                const allWords = recentTexts.match(/[\u4e00-\u9fa5]{2,4}/g) || [];
                const freq = {};
                for (const w of allWords) { freq[w] = (freq[w] || 0) + 1; }
                const repeatedWords = Object.keys(freq).filter(w => freq[w] >= 3);
                if (repeatedWords.length > 0) {
                    antiRepeatHint = `\n⚠️ 注意："${repeatedWords.slice(0, 3).join('""')}"等词前面已经说过很多次了。请换个角度或话题回应，不要重复。`;
                }
            }

            // 讨论焦点引导
            let discussionFocus = '';
            if (ctx.isDeathTrigger && ctx.deadNpcName) {
                discussionFocus = `\n\n---⚠️ 本次讨论焦点 ⚠️---
这是一次【同伴遇难后的紧急讨论】。${ctx.deadNpcName}已经不幸遇难了。
触发原因：${ctx.triggerReason}

【讨论节奏要求——必须按顺序推进，不要跳步！】
第一步：情感反应（前1~2轮发言）
- 先表达对${ctx.deadNpcName}遇难的震惊、悲伤、愤怒或自责
- 回忆和${ctx.deadNpcName}相处的片段，说说ta是个什么样的人
- 如果你和${ctx.deadNpcName}关系亲近，可以更加悲痛

第二步：分析原因（中间1~2轮发言）
- 讨论${ctx.deadNpcName}是怎么遇难的？是冻死的？饿死的？还是其他原因？
- 反思我们哪里做得不够好，是不是分工有问题、资源没分配好？
- 互相交换信息：你知道什么我不知道的？

第三步：才是决策下一步（最后1~2轮发言）
- 现在少了一个人，剩下的人怎么重新分工？
- 谁来接手${ctx.deadNpcName}原来负责的事？
- 怎么避免同样的悲剧再次发生？

【禁止】不要第一句话就开始分配任务！先悲伤、先分析，再决策！
【禁止】不要表现得像${ctx.deadNpcName}的死无关紧要一样，直接跳到"赶紧干活"！
---焦点结束---`;
            } else if (ctx.isNpcCrisis && ctx.triggerReason) {
                const crisisInfo = ctx.triggerReason;
                discussionFocus = `\n\n---⚠️ 本次讨论焦点 ⚠️---
这是一次【个人危机讨论】，不是一般的局势讨论！
触发原因：${crisisInfo}
【核心要求】你的发言必须围绕这个人的状况展开：
- 关心这个人现在怎么样了，能不能撑住
- 讨论怎么帮助这个人（谁去照顾、怎么治疗、需要什么资源）
- 如果你就是当事人，表达你现在的感受和需要
- 可以顺带提一两句相关的资源/局势，但不要跑题变成纯局势分析
【禁止】不要忽略当事人的危机去大谈天气、电力、木柴等宏观局势！这次讨论的重点是救人！
---焦点结束---`;
            } else if (!ctx.isOpeningCouncil && ctx.triggerReason) {
                discussionFocus = `\n\n---本次讨论焦点---
触发原因：${ctx.triggerReason}
请围绕这个问题展开讨论。
---焦点结束---`;
            }

            let userPrompt = `---当前情境---
${snapshot.situation}
${state.stateHints}${state.relationContext}${state.memoryHint}${state.blizzardHint}${state.pastLifeHint}
---情境结束---
${discussionFocus}
---事实约束---
${realityGuard}
---约束结束---

`;

            if (chatHistory.length > 0) {
                userPrompt += `---之前别人的发言（这些都不是你说的！你是${npc.name}！）---\n`;
                userPrompt += chatHistory.map(line => line.replace(/^(.+?)说：/, '[$1]: ')).join('\n');
                userPrompt += `\n---发言记录结束---\n\n`;
            }

            if (ctx.isDeathTrigger && chatHistory.length === 0) {
                userPrompt += `你是第一个开口的人。${ctx.deadNpcName}刚刚遇难了，你现在非常震惊和悲伤。先表达你对${ctx.deadNpcName}遇难的情感反应（悲伤、震惊、自责等），回忆一下和ta的相处。不要直接跳到分配任务！`;
            } else if (ctx.isDeathTrigger && chatHistory.length > 0) {
                userPrompt += `回应上面其他人说的话。如果大家还在悲伤和分析原因阶段，你也参与讨论${ctx.deadNpcName}是怎么遇难的、我们哪里做得不好。如果大家已经开始讨论下一步了，你再提出你的建议。不要跳过情感和分析直接分配任务。`;
            } else if (ctx.isNpcCrisis && chatHistory.length === 0) {
                userPrompt += `你是第一个开口的人。这次讨论是因为有同伴出了状况（${ctx.triggerReason}），先关心这个人的情况，再说说怎么帮忙。`;
            } else if (chatHistory.length === 0) {
                if (isFirstReincarnation) {
                    userPrompt += `你是第一个开口的人。你刚刚经历了上一世的死亡或灾难，突然发现自己又回到了起点——你可以表达对重生的震惊、困惑，也可以直接聊当前局势，由你自己决定。`;
                } else {
                    userPrompt += `你是第一个开口的人。感叹一下当前局势，抛出一个话题。`;
                }
            } else {
                if (isFirstReincarnation) {
                    userPrompt += `回应上面其他人说的话——可以赞同、反对、追问、补充。如果有人提到了重生或前世的事，你也可以回应你自己的感受。`;
                } else {
                    userPrompt += `回应上面其他人说的话——可以赞同、反对、追问、补充。`;
                }
            }
            userPrompt += `\n规则：直接说话，不要写名字前缀，不要JSON，不要引号包裹。口语化，有语气词有情绪。严格遵守你的字数要求和说话风格。${antiRepeatHint}${isFirstLifeForPrompt ? '\n⚠️ 你们从未经历过类似的事，不要编造任何过去的经历。' : ''}\n⚠️ 再次提醒：你是「${npc.name}」，用你自己的语气说话！\n\n${npc.name}：`;

            return {
                systemPrompt,
                userPrompt,
                maxTokens: TOKEN_LIMITS[npc.id] || 150,
            };
        },

        /** 构建方案 prompt */
        buildProposalPrompt(snapshot, chatHistory, triageParticipants) {
            const assignTargets = triageParticipants || snapshot.aliveNpcs;
            const alive = snapshot.aliveNpcs;
            const rs = snapshot._game ? snapshot._game.resourceSystem : null;

            const participantInfo = assignTargets.map(n => {
                const cfg = (GST.NPC_CONFIGS || []).find(c => c.id === n.id) || {};
                const tags = [];
                if (n.isCrazy) tags.push('🤯发疯中');
                if (n._isDying) tags.push('🚨濒死');
                if (n.isSick) tags.push('🤒生病');
                if (n.stamina <= 0) tags.push('体力归零');
                else if (n.stamina < 20) tags.push('体力低');
                if (n.sanity <= 0) tags.push('精神归零');
                else if (n.sanity < 20) tags.push('精神差');
                if (n.health < 10) tags.push('健康极低');
                else if (n.health < 30) tags.push('健康差');
                const statusStr = tags.length > 0 ? ` ⚠️${tags.join('+')}` : '';
                return `${n.name}(${cfg.occupation || ''}, 体力${Math.round(n.stamina)}/San${Math.round(n.sanity)}/健康${Math.round(n.health)}${statusStr})`;
            }).join('\n  ');

            const systemPrompt = `你是一个游戏AI系统，需要根据角色们的讨论内容，提炼出2-3个具体的行动方案。

每个方案要：
1. 有简短有力的名称（4字以内）
2. 明确每个存活角色的具体分工（⚠️ 必须给所有存活角色都分配任务，不能遗漏任何人！）
3. 有清晰的预期收益

⚠️【极重要】assignments 中每个人的值必须是下面列出的 taskType 标准键名（英文大写），不要写中文！
系统会根据 taskType 自动执行对应行动，写错或写中文会导致任务无法执行！

【可用 taskType 列表】（只能从以下选择）：
- COLLECT_WOOD → 去伐木场砍柴，产出🪵木柴+10/h
- COLLECT_FOOD → 去冰湖采集食物，产出🍞食物+8/h
- MAINTAIN_POWER → 去工坊人工手摇发电，产出⚡电力+8/h（紧急补电用）
- MINE_POWER → 去矿渣堆采矿，产出⚡电力+12/h（产电最高但在户外挨冻）
- COLLECT_MATERIAL → 去废墟探索物资（每天限3次，运气好能开急救包/罐头）
- BUILD_GENERATOR → 去工坊建造自动发电机，消耗电力10+木柴12，4小时建成，建成后永久自动产电⚡+20/h耗柴3/h（有概率故障需维修）
- BUILD_LUMBER_MILL → 去工坊建造自动伐木机，消耗电力12+木柴15，5小时建成，建成后永久自动产柴🪵+24/h耗电4/h（有概率故障需维修）
- BUILD_FOOD_COLLECTOR → 去工坊建造自动捕猎机，消耗电力10+木柴12，5小时建成，建成后永久自动产食物🍞+12/h耗电3/h（有概率故障需维修）
- REPAIR_GENERATOR → 去工坊维修故障的自动发电机（发电机故障时使用）
- REPAIR_LUMBER_MILL → 去工坊维修故障的自动伐木机（伐木机故障时使用）
- REPAIR_FOOD_COLLECTOR → 去工坊维修故障的自动捕猎机（捕猎机故障时使用）
- DISTRIBUTE_FOOD → 去炊事房做饭，食物浪费-20%（相当于🍞+3/h）
- PREPARE_MEDICAL → 去医疗站治疗伤员，恢复同场景NPC血量+18/h、San+18/h（有伤员时优先）
- WAREHOUSE → 去仓库盘点物资，食物浪费-20%+木柴浪费-10%
- BOOST_MORALE → 安抚士气，同场景NPC San恢复+10.8/h（San低时必须安排）
- MAINTAIN_ORDER → 去宿舍巡逻警戒
- PSYCHOLOGY → 去医疗站心理疏导，恢复San值
- REST → 回家休息，恢复自身体力和体温（体力<30时应安排）

⚠️【人员状态约束——最高优先级】：
- 体力≤0或精神≤0或健康≤0的人 → 只能分配 REST 或 PREPARE_MEDICAL（让别人治他）！绝对不能干活！
- 发疯🤯的人 → 只能分配 REST，其他人应该安排 BOOST_MORALE 或 PREPARE_MEDICAL 来救他
- 濒死🚨的人 → 必须分配 REST，安排医生 PREPARE_MEDICAL
- 生病🤒的人 → 优先安排轻活或 REST
- 给一个体力/精神归零的人安排 COLLECT_WOOD、MAINTAIN_POWER 等重活是不合理的！

⚠️ MAINTAIN_POWER 和 BUILD_GENERATOR 是完全不同的任务！
- MAINTAIN_POWER = 手动手摇产电（⚡+8/h），紧急时用
- BUILD_GENERATOR = 建造自动化发电机（一次性消耗资源，建成后永久自动产电20/h），长线规划
- REPAIR_GENERATOR = 维修故障的发电机（发电机故障停机时用）
- BUILD_LUMBER_MILL = 建造自动化伐木机，长线规划
- REPAIR_LUMBER_MILL = 维修故障的伐木机
- BUILD_FOOD_COLLECTOR = 建造自动化捕猎机（一次性消耗资源，建成后永久自动产食物12/h），长线规划
- REPAIR_FOOD_COLLECTOR = 维修故障的捕猎机

方案类型参考（可自由组合）：
- 资源优先：集中力量补充最紧缺资源
- 均衡发展：各项工作齐头并进
- 科技路线：建造自动发电机/伐木机/捕猎机（Day1即可建造！越早建越有利）
- 探索冒险：派人探索废墟寻找物资

输出格式必须是JSON：
{
  "proposals": [
    {
      "name": "方案名",
      "description": "一句话描述",
      "assignments": {"角色名": "TASK_TYPE_KEY"},
      "reasoning": "推荐理由"
    }
  ]
}

示例：
{"proposals":[{"name":"资源优先","description":"集中补充紧缺资源","assignments":{"老钱":"BOOST_MORALE","李婶":"DISTRIBUTE_FOOD","赵铁柱":"COLLECT_WOOD","苏岩":"PREPARE_MEDICAL","王策":"MAINTAIN_POWER","陆辰":"COLLECT_WOOD","清璇":"COLLECT_FOOD","张北":"COLLECT_MATERIAL"},"reasoning":"先解决资源燃眉之急"}]}`;

            let userPrompt = `---当前局势---\n${snapshot.situation}\n---局势结束---\n\n`;
            if (chatHistory.length > 0) {
                userPrompt += `---讨论记录---\n${chatHistory.join('\n')}\n---讨论结束---\n\n`;
            }
            userPrompt += `存活人员状态（⚠️分配任务时必须参考！状态极差的人只能安排休息/治疗/安抚）:\n  ${participantInfo}\n\n`;

            // 自动化设施提示
            let machineHint = '';
            if (snapshot._game && snapshot._game.machineSystem) {
                const ms = snapshot._game.machineSystem;
                if (ms.generator.broken) machineHint += '⚠️ 自动发电机故障中！需要安排人 REPAIR_GENERATOR 维修！\n';
                if (ms.lumberMill.broken) machineHint += '⚠️ 自动伐木机故障中！需要安排人 REPAIR_LUMBER_MILL 维修！\n';
                if (ms.foodCollector.broken) machineHint += '⚠️ 自动捕猎机故障中！需要安排人 REPAIR_FOOD_COLLECTOR 维修！\n';
                if (ms.canUnlockGenerator() && !ms.generator.built && !ms.generator.building) {
                    machineHint += '💡 可以建造自动发电机（BUILD_GENERATOR），建成后永久自动产电！\n';
                }
                if (ms.canUnlockLumberMill() && !ms.lumberMill.built && !ms.lumberMill.building) {
                    machineHint += '💡 可以建造自动伐木机（BUILD_LUMBER_MILL），建成后永久自动产柴！\n';
                }
                if (ms.canUnlockFoodCollector && ms.canUnlockFoodCollector() && !ms.foodCollector.built && !ms.foodCollector.building) {
                    machineHint += '💡 可以建造自动捕猎机（BUILD_FOOD_COLLECTOR），建成后永久自动产食物！\n';
                }
            }
            if (machineHint) {
                userPrompt += `---自动化设施状态---\n${machineHint}---设施状态结束---\n\n`;
            }

            userPrompt += `根据以上情况，提炼出2-3个最可行的行动方案。每个方案要有明确的人员分工。\n⚠️ assignments 中每人的值必须是标准 taskType 键名（如 COLLECT_WOOD、MAINTAIN_POWER、BUILD_GENERATOR），不要写中文！\n⚠️ MAINTAIN_POWER=手摇产电，BUILD_GENERATOR=建造自动化机器，REPAIR_GENERATOR=维修故障发电机，三者不同！\n⚠️ 必须给以上列出的所有人员分配任务！不能遗漏！${triageParticipants ? '\n⚠️ 本次只需给以上列出的人员分配任务，其他人继续当前工作不变。' : ''}\n输出JSON格式。`;

            return {
                systemPrompt,
                userPrompt,
                maxTokens: 800,
            };
        },

        /** 构建投票 prompt */
        buildVotePrompt(snapshot, npc, proposalSummary) {
            const card = snapshot.characterCards[npc.id];
            const otherNames = snapshot.aliveNpcs.filter(n => n.id !== npc.id).map(n => n.name);
            const numProposals = (proposalSummary.match(/方案\d+/g) || []).length || 3;
            const npcState = snapshot.npcStates[npc.id] || {};

            let myStatusBlock = `\n\n---你自己的当前状态---`;
            const staminaVal = Math.round(npc.stamina);
            const sanityVal = Math.round(npc.sanity);
            const healthVal = Math.round(npc.health);
            const hungerVal = Math.round(npc.hunger || 50);
            const tempVal = npc.bodyTemp ? npc.bodyTemp.toFixed(1) : '36.5';
            myStatusBlock += `\n💪体力:${staminaVal}/100 🧠精神:${sanityVal}/100 🫀健康:${healthVal}/100 🍖饱腹:${hungerVal}/100 🌡️体温:${tempVal}°C`;
            if (npc.isCrazy) myStatusBlock += `\n🤯 你正在精神崩溃发疯中！你根本无法干活！`;
            if (npc.isSick) myStatusBlock += `\n🤒 你正在生病！`;
            if (npc._isDying) myStatusBlock += `\n🚨 你正处于濒死状态！`;
            if (npcState.stateHints) myStatusBlock += npcState.stateHints;
            if (staminaVal <= 0 || sanityVal <= 0 || healthVal <= 0) {
                myStatusBlock += `\n⚠️ 你的身体状况极差，投票时请优先考虑自身生存需求！你这种状态不适合劳动，需要休息/治疗/安抚！`;
            }
            myStatusBlock += `\n---状态结束---`;

            let teamStatusBlock = '\n\n---团队成员状态---';
            for (const n of snapshot.aliveNpcs) {
                const tags = [];
                if (n.isCrazy) tags.push('🤯发疯');
                if (n._isDying) tags.push('🚨濒死');
                if (n.isSick) tags.push('🤒生病');
                if (n.stamina <= 0) tags.push('体力归零');
                if (n.sanity <= 0) tags.push('精神归零');
                if (n.health < 10) tags.push('健康极低');
                else if (n.stamina < 20) tags.push('体力低');
                if (n.sanity < 20 && !n.isCrazy) tags.push('精神差');
                const tagStr = tags.length > 0 ? ` [${tags.join('、')}]` : ' [状态正常]';
                teamStatusBlock += `\n${n.name}: 体力${Math.round(n.stamina)} 精神${Math.round(n.sanity)} 健康${Math.round(n.health)}${tagStr}`;
            }
            teamStatusBlock += '\n---团队状态结束---';

            const systemPrompt = `【身份锁定】你就是「${npc.name}」本人。
用「我」称呼自己，绝不用第三人称说自己。${otherNames.join('、')}是别人不是你。
${card}

你正在投票选择行动方案。从你的角色和专长角度，选择你最支持的方案。
用一句话说明理由（用「我」称呼自己）。根据你的性格和判断独立决定。

⚠️ 投票时必须考虑自己和队友的身体状况！
- 体力/精神/健康归零的人不能安排劳动，必须休息或治疗
- 发疯/濒死的人最优先需要安抚/治疗/休息
- 给濒死的人安排干活是不合理的！

⚠️ 常识提醒：
- "砍柴/伐木"产出木柴🪵，不产电
- "人工发电"在工坊手摇产电⚡
- "建造发电机"建好后自动产电⚡（消耗木柴🪵）
- "建造伐木机"建好后自动产木柴🪵（消耗电力⚡）
- 伐木机不能发电！发电机不能产柴！不要搞混

输出格式必须是JSON：
{
  "vote": 1,
  "reason": "一句话理由，用我称呼自己"
}

vote字段填方案编号（1~${numProposals}），reason字段填理由。`;

            let userPrompt = `---局势摘要---\n${snapshot.situation}\n---局势结束---\n\n`;
            userPrompt += `---待投票方案---\n${proposalSummary}\n---方案结束---\n\n`;
            userPrompt += myStatusBlock + teamStatusBlock + '\n\n';
            userPrompt += `【你是${npc.name}，用「我」称呼自己。请结合自己的身体状况选择你支持的方案。输出JSON。】`;

            return {
                systemPrompt,
                userPrompt,
                maxTokens: 150,
            };
        },

        /** 构建总结 prompt */
        buildSummaryPrompt(snapshot, winnerProposal, summaryNpc) {
            const speaker = summaryNpc || { id: 'old_qian', name: '老钱' };
            const trait = NPC_TRAITS[speaker.id] || '营地成员。';

            const deadNames = snapshot.deadNames || [];
            let deadContext = '';
            if (deadNames.length > 0) {
                deadContext = `\n⚠️ 已有${deadNames.length}人遇难（${deadNames.join('、')}），请在发言中体现对逝者的哀悼和对生者的鼓励。`;
            }

            const speakerName = speaker.displayName || speaker.name;
            const systemPrompt = `你是「${speakerName}」，${trait}刚参加完投票会议，现在做总结发言。\n用「我」称呼自己。绝不用第三人称。${deadContext}`;

            const assignText = winnerProposal.assignments
                ? Object.entries(winnerProposal.assignments).map(([n, t]) => `${n}做${getTaskLabel(t)}`).join('、')
                : '';

            const userPrompt = `投票结果：大家选择了「${winnerProposal.name}」— ${winnerProposal.description}\n${assignText ? '分工: ' + assignText : ''}\n\n做一个简短有力的总结发言（2-3句话），宣布决定、鼓舞士气。口语化。`;

            return {
                systemPrompt,
                userPrompt,
                maxTokens: 200,
            };
        },

        /** 构建分诊 prompt */
        buildTriagePrompt(snapshot, triggerReason) {
            const alive = snapshot.aliveNpcs;
            let npcStatusList = '';
            for (const n of alive) {
                const cfg = (GST.NPC_CONFIGS || []).find(c => c.id === n.id) || {};
                const tags = [];
                if (n.isCrazy) tags.push('🤯发疯中');
                if (n._isDying) tags.push('🚨濒死');
                if (n.isSick) tags.push('🤒生病');
                if (n.stamina <= 0) tags.push('体力归零');
                else if (n.stamina < 20) tags.push('体力低');
                if (n.sanity <= 0) tags.push('精神归零');
                else if (n.sanity < 20) tags.push('精神差');
                if (n.health < 10) tags.push('健康极低');
                if (n.isSleeping) tags.push('💤睡觉中');
                const tagStr = tags.length > 0 ? ` [${tags.join('、')}]` : ' [正常]';
                const currentAction = n.stateDesc || n.state || '空闲';
                npcStatusList += `  ${n.name}(${cfg.occupation || ''}): 体力${Math.round(n.stamina)}/San${Math.round(n.sanity)}/健康${Math.round(n.health)}${tagStr} 当前:${currentAction}\n`;
            }

            const systemPrompt = `你是一个游戏AI系统。现在发生了紧急情况，你需要以危机当事人的视角来判断：他会找谁来帮忙？还是自己解决？

规则：
1. 当事人是第一个参与者，他一定会参与（即使发疯/濒死，他也会表达自己的状态）
2. 当事人会根据自己的判断决定要不要找人帮忙：
   - 如果问题他自己能解决（比如只是累了需要休息），可以只有他1个人，自己做决定
   - 如果需要专业帮助（比如生病找医生苏岩），他会去找对应的人
   - 如果情况严重（比如濒死），附近的人会主动来帮忙
3. 不要叫太多人——大家都有自己的任务：
   - 正在执行重要任务且与本次危机无关的人不用叫
   - 睡觉中的人不用叫（除非只有他能帮忙）
   - 自身状态也很差的人不用叫（除非他是专业人员）
4. 最少1人（当事人自己），最多4人
5. 如果当事人已经发疯/濒死无法正常思考，系统会自动让附近的人发现并参与

输出格式必须是JSON：
{
  "participants": ["角色名1"],
  "reason": "一句话说明（用当事人视角，如'我只是累了，休息一下就好'或'我得去找苏岩看看'）",
  "selfResolve": true/false,
  "otherOrders": {"角色名": "继续当前任务/不变"}
}

participants: 参与决策的角色名数组（当事人必须在第一个）
reason: 当事人的想法/判断
selfResolve: 当事人是否认为自己能解决（true=自言自语模式，false=需要讨论）
otherOrders: 不参与的人应该做什么（简短说明）`;

            let userPrompt = `---紧急情况---\n${triggerReason}\n---情况结束---\n\n`;
            userPrompt += `---当前局势---\n${snapshot.situation}\n---局势结束---\n\n`;
            userPrompt += `---所有存活NPC状态---\n${npcStatusList}---状态结束---\n\n`;
            userPrompt += `请判断哪些人需要参与这次紧急决策会议。输出JSON。`;

            return {
                systemPrompt,
                userPrompt,
                maxTokens: 300,
            };
        },

        /** 获取离线台词 */
        getFallback(npcId) {
            const pool = FALLBACKS[npcId] || ['……（沉默）'];
            return pool[Math.floor(Math.random() * pool.length)];
        },
    };

    GST._councilPromptsZh = ZH;
})();
