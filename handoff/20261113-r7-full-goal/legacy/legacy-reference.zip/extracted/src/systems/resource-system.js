/**
 * 福音镇 - ResourceSystem
 * 挂载到 GST.ResourceSystem
 */
(function() {
    'use strict';
    const GST = window.GST;

/**
 * 资源系统 - 全镇共享物资管理
 * 管理木柴、食物、电力三种核心资源
 * 依赖: game.js, weather-system.js
 */

// ============ 资源初始值配置（3资源制：木柴/食物/电力） ============
const RESOURCE_DEFAULTS = {
    woodFuel: 30,    // 木柴 — 初始30单位，Day1够烧但需采集为Day2囤
    food: 130,       // 食物 — 初始130单位（v4.38微调：从120→130，简单难度Day1不至于断粮）
                     // 计算：8人×2餐×1.8/餐=28.8/天，130÷28.8≈4.5天（简单难度宽裕）
    power: 30,       // 电力 — 初始30单位（v4.38微调：从25→30，简单难度够用约15h）
};

// ============ 废墟探索奖池（每天限3次，每次1游戏小时） ============
const RUINS_EXPLORE_POOL = [
    { name: '🥫 发现罐头', type: 'food', amount: 15, weight: 30 },
    { name: '💊 发现药品', type: 'medkit', amount: 1, weight: 20 },
    { name: '🔧 发现零件', type: 'power', amount: 10, weight: 15 },
    { name: '🪵 发现木材', type: 'woodFuel', amount: 10, weight: 15 },
    { name: '📔 发现日记', type: 'sanBoost', amount: 5, weight: 10 },
    { name: '❌ 一无所获', type: 'nothing', amount: 0, weight: 10 },
];
const RUINS_MAX_EXPLORES_PER_DAY = 3;

// ============ 资源消耗速率配置（每游戏小时） ============
const RESOURCE_CONSUMPTION = {
    heatingWoodPerHour: 1.0,      // 集中供暖每小时基础消耗木柴（v4.38微调：1.2→1.0，简单难度不至于Day1断柴）
    powerPerHour: 2.0,            // 全镇基础电力维持消耗【v4.38回调：2.5→2.0，简单难度电力不至于秒空】
    foodPerMealPerPerson: 1.8,    // 每人每餐消耗食物（v4.37上调：1.5→1.8，末日环境需要更多热量）
    mealsPerDay: 2,               // 每天2餐（8:00早餐, 18:00晚餐）【v4.38回调：3→2餐，简单难度食物压力适中】
};

// 用餐时间（小时）
const MEAL_HOURS = [8, 18];  // 【v4.38回调】恢复2餐制，食物压力通过难度倍率控制而非基础餐数

// ============ 【v4.24】NaN哨兵防护 ============
// JavaScript的undefined不报错特性是定时炸弹。关键数值计算必须有NaN检查。
// 如果计算结果是NaN，说明上游数据有问题，必须立即报错而不是静默传播。
function _safeNum(value, fallback, label) {
    if (typeof value !== 'number' || isNaN(value) || !isFinite(value)) {
        console.error(`[ResourceSystem] ⚠️ NaN哨兵触发: ${label} = ${value}，使用安全默认值 ${fallback}`);
        return fallback;
    }
    return value;
}

class ResourceSystem {
    constructor(game) {
        this.game = game;

        // 三种核心资源池（难度系数 + 总量守恒随机分配）
        const diff = (game && game.difficulty) ? game.difficulty : GST.getDifficulty();
        const initMult = diff.initialResources || { woodFuel: 1, food: 1, power: 1 };

        // 【总量守恒随机分配】
        // 设计思路：总预算由难度决定，但三种资源的分配比例每局随机
        // "此消彼长" —— 这世木柴多食物少，下世可能食物多电力少
        //
        // 算法：
        // 1. 算出难度下每种资源的标准值
        // 2. 转化为统一"预算点"（按标准值归一化）
        // 3. 生成3个随机偏移（和为0），让资源在标准值±30%间浮动
        // 4. 保证每种资源不低于标准值的50%（极端保底）

        const stdWood = RESOURCE_DEFAULTS.woodFuel * (initMult.woodFuel || 1);
        const stdFood = RESOURCE_DEFAULTS.food * (initMult.food || 1);
        const stdPower = RESOURCE_DEFAULTS.power * (initMult.power || 1);
        const totalBudget = stdWood + stdFood + stdPower; // 难度决定的总预算

        // 生成3个随机权重，归一化后乘以总预算
        // 权重以标准值为中心，加入随机扰动
        const jitter = () => 0.7 + Math.random() * 0.6; // [0.7, 1.3]
        let wW = stdWood * jitter();
        let wF = stdFood * jitter();
        let wP = stdPower * jitter();
        const wSum = wW + wF + wP;

        // 按权重比例分配总预算
        let allocWood = totalBudget * (wW / wSum);
        let allocFood = totalBudget * (wF / wSum);
        let allocPower = totalBudget * (wP / wSum);

        // 保底：每种资源不低于标准值的50%
        const floorWood = stdWood * 0.5;
        const floorFood = stdFood * 0.5;
        const floorPower = stdPower * 0.5;
        allocWood = Math.max(allocWood, floorWood);
        allocFood = Math.max(allocFood, floorFood);
        allocPower = Math.max(allocPower, floorPower);

        // 保底后重新按比例缩放回总预算（确保总量不变）
        const allocSum = allocWood + allocFood + allocPower;
        const scale = totalBudget / allocSum;
        allocWood *= scale;
        allocFood *= scale;
        allocPower *= scale;

        this.woodFuel = Math.round(allocWood);
        this.food = Math.round(allocFood);
        this.power = Math.round(allocPower);

        // 保存分配信息用于UI和日志
        this._initStandard = { woodFuel: stdWood, food: stdFood, power: stdPower };
        this._initRandomFactors = {
            woodFuel: this.woodFuel / stdWood,
            food: this.food / stdFood,
            power: this.power / stdPower
        };
        console.log(`[ResourceSystem] 难度=${diff.name}, 总预算=${Math.round(totalBudget)}`);
        console.log(`[ResourceSystem] 标准值: 木柴${Math.round(stdWood)} 食物${Math.round(stdFood)} 电力${Math.round(stdPower)}`);
        console.log(`[ResourceSystem] 随机分配: 木柴${this.woodFuel}(×${(this.woodFuel/stdWood).toFixed(2)}) 食物${this.food}(×${(this.food/stdFood).toFixed(2)}) 电力${this.power}(×${(this.power/stdPower).toFixed(2)})`);

        // 【v2.0】天气消耗乘数缓存
        this._weatherConsumptionMult = { wood: 1.0, power: 1.0, food: 1.0 };
        this._lastWeatherMultDay = 0;

        // 消耗统计（每日重置）
        this.dailyConsumed = { woodFuel: 0, food: 0, power: 0 };
        this.dailyCollected = { woodFuel: 0, food: 0, power: 0 };

        // 历史统计（全局）
        this.totalConsumed = { woodFuel: 0, food: 0, power: 0 };
        this.totalCollected = { woodFuel: 0, food: 0, power: 0 };

        // 废墟探索状态
        this.ruinsExploresToday = 0;  // 今天已探索次数
        this._ruinsExploreDay = 0;    // 上次重置的天数

        // 断电惩罚系数（默认1.0，断电时1.5）
        this._noPowerFuelPenalty = 1.0;

        // 资源消耗tick计时
        this._consumptionTick = 0;
        this._mealServed = {}; // { dayX_hourY: true } 防止重复发放餐食

        // 危机状态标记
        this.crisisFlags = {
            noFood: false,       // 食物耗尽
            noPower: false,      // 电力耗尽
            noWoodFuel: false,   // 木柴耗尽
            hungerCrisis: false, // 饥饿危机进行中
        };

        // 饥饿危机持续时间追踪（秒）
        this._hungerCrisisDuration = 0;

        // 日结算报告数据
        this.lastDayReport = null;

        console.log('[ResourceSystem] 初始化完成:', this.getResourceSummary());
    }

    // ============ 资源增减接口 ============

    /** 增加资源（NPC采集完成时调用） */
    addResource(type, amount, source = '') {
        // 【v4.45修复】防止NaN/undefined/非数字值污染资源状态
        if (!Number.isFinite(amount) || amount <= 0) return;
        switch (type) {
            case 'woodFuel':
                this.woodFuel += amount;
                break;
            case 'food':
                this.food += amount;
                break;
            case 'power':
                {
                    const oldPower = this.power;
                    this.power += amount;
                    this._checkPowerRecovery(oldPower, this.power);
                }
                break;

            default:
                console.warn(`[ResourceSystem] 未知资源类型: ${type}`);
                return;
        }
        this.dailyCollected[type] = (this.dailyCollected[type] || 0) + amount;
        this.totalCollected[type] = (this.totalCollected[type] || 0) + amount;

        if (this.game.addEvent && amount >= 1) {
            const icons = { woodFuel: '🪵', food: '🍞', power: '⚡' };
            const resName = GST.t('resource.res_' + ({woodFuel:'wood', food:'food', power:'power'}[type]));
            if (source) {
                this.game.addEvent(GST.t('resource.collected', { icon: icons[type], source, name: resName, amount: Math.round(amount), remaining: Math.round(this[type]) }));
            } else {
                this.game.addEvent(GST.t('resource.collected_no_source', { icon: icons[type], name: resName, amount: Math.round(amount), remaining: Math.round(this[type]) }));
            }
        }

        // 只有较大数量的资源变化才输出日志，避免机器每帧微量产出刷屏
        if (amount >= 0.5) {
            console.log(`[ResourceSystem] +${type}: ${amount.toFixed(1)} (${source}), 当前: ${Math.round(this[type])}`);
        }
    }

    /** 消耗资源（返回实际消耗量，可能不足） */
    consumeResource(type, amount, reason = '') {
        // 【v4.45修复】防止NaN/undefined/非数字值污染资源状态
        if (!Number.isFinite(amount) || amount <= 0) return 0;
        const current = this[type] || 0;
        const actual = Math.min(current, amount);
        this[type] = Math.max(0, current - amount);
        this.dailyConsumed[type] = (this.dailyConsumed[type] || 0) + actual;
        this.totalConsumed[type] = (this.totalConsumed[type] || 0) + actual;
        return actual;
    }

    /** 直接设置资源值（存档恢复用） */
    setResource(type, value) {
        if (this[type] !== undefined) {
            this[type] = Math.max(0, value);
        }
    }
    // [已拆分到 resource-consumption.js] npcEatAtKitchen
    // ============ 主更新循环 ============

    /** 在game.update()中调用 */
    update(gameDt) {
        // 【修复】累积游戏秒而非实际秒，确保资源消耗与游戏时间同步
        const gameSeconds = gameDt * (this.game.timeSpeed || 60);
        this._consumptionTick += gameSeconds;

        // 每游戏秒执行一次消耗
        if (this._consumptionTick >= 1.0) {
            const elapsed = this._consumptionTick;
            this._consumptionTick = 0;
            this._tickConsumption(elapsed);
        }

        // 用餐时间检测
        this._checkMealTime();

        // 危机状态更新
        this._updateCrisisFlags(gameDt);
    }
    // [已拆分到 resource-report.js] generateDayReport
    // [已拆分到 resource-report.js] formatDayReport
    // [已拆分到 resource-report.js] getResourceSummary
    /** 获取某种资源当前值 */
    getResource(type) {
        return this[type] || 0;
    }

    /** 食物是否够全员吃一顿 */
    hasFoodForOneMeal() {
        const aliveCount = this.game.npcs.filter(n => !n.isDead).length;
        return this.food >= aliveCount * RESOURCE_CONSUMPTION.foodPerMealPerPerson;
    }

    /** 获取食物够吃几餐 【v4.24】添加NaN哨兵 */
    getFoodMealsRemaining() {
        const aliveCount = this.game.npcs.filter(n => !n.isDead).length;
        if (aliveCount === 0) return Infinity;
        const result = Math.floor(this.food / (aliveCount * RESOURCE_CONSUMPTION.foodPerMealPerPerson));
        return _safeNum(result, 0, 'getFoodMealsRemaining');
    }

    /** 获取木柴够暖炉烧几小时 【v4.24】添加NaN哨兵 */
    getWoodFuelHoursRemaining() {
        const furnaceCount = this.game.furnaceSystem ? this.game.furnaceSystem.getActiveFurnaceCount() : 1;
        if (furnaceCount === 0) return Infinity;
        const hourly = RESOURCE_CONSUMPTION.heatingWoodPerHour * furnaceCount * this.getPopulationRatio();
        const result = hourly > 0 ? this.woodFuel / hourly : 999;
        return _safeNum(result, 0, 'getWoodFuelHoursRemaining');
    }

    /** 获取电力剩余小时 【v4.24】添加NaN哨兵 */
    getPowerHoursRemaining() {
        const hourly = RESOURCE_CONSUMPTION.powerPerHour * this.getPopulationRatio();
        const result = hourly > 0 ? this.power / hourly : 999;
        return _safeNum(result, 0, 'getPowerHoursRemaining');
    }

    /** 是否有任何资源危机 */
    hasAnyCrisis() {
        return this.crisisFlags.noFood || this.crisisFlags.noPower || this.crisisFlags.noWoodFuel;
    }
    // [已拆分到 resource-report.js] getResourceTension
    // [已拆分到 resource-report.js] getResourceStatusForPrompt
    // [已拆分到 resource-report.js] getResourceSituationBrief
    // [已拆分到 resource-report.js] getPopulationRatio
    // [已拆分到 resource-report.js] getResourceUrgency
    // [已拆分到 resource-report.js] getUrgencyPrompt
    // [已拆分到 resource-report.js] getResourceForecastForPrompt
    // [已拆分到 resource-report.js] getSupplyRecommendationPrompt
    // ============ 电力效率加成系统 ============

    /**
     * 【v2.1重构】获取电力对设施工作效率的加成系数
     * @param {string} scene - NPC所在场景（workshop / medical）
     * @returns {number} 效率系数
     *   电力正常：workshop=1.2(+20%), medical=1.2(+20%)
     *   电力耗尽：workshop=0.7(-30%), medical=0.5(-50%，医疗设备停电)
     *   其他场景：1.0
     */
    getPowerEfficiencyBonus(scene) {
        // 只有工坊和医疗站受电力影响
        if (scene !== 'workshop' && scene !== 'medical') return 1.0;
        if (this.power <= 0) {
            // 【v2.1】无电时医疗效率减半（医疗设备需要电力）
            return scene === 'medical' ? 0.5 : 0.7;
        }
        if (this.power > 0) return 1.2;   // 电力正常：+20%加成
        return 1.0;
    }

    /**
     * 检测电力从耗尽恢复，触发事件通知
     * 在 addResource 中调用
     */
    _checkPowerRecovery(oldPower, newPower) {
        // 【修复】不再在addResource中重复触发恢复事件
        // 电力恢复事件统一由 _updateCrisisFlags 中的滞后阈值逻辑处理
        // 避免与crisisFlags检测形成 耗尽→恢复→耗尽 的死循环
    }

    // ============ 序列化 ============

    // ============ 废墟探索系统 ============

    /** 获取废墟今日剩余探索次数 */
    getRuinsExploresRemaining() {
        // 每天重置
        const day = this.game.dayCount || 1;
        if (this._ruinsExploreDay !== day) {
            this.ruinsExploresToday = 0;
            this._ruinsExploreDay = day;
        }
        return RUINS_MAX_EXPLORES_PER_DAY - this.ruinsExploresToday;
    }

    /** NPC执行废墟探索（由action-effects的explore_ruins调用） */
    performRuinsExploration(npc) {
        if (!npc || npc.isDead) return null;
        // 每天重置
        const day = this.game.dayCount || 1;
        if (this._ruinsExploreDay !== day) {
            this.ruinsExploresToday = 0;
            this._ruinsExploreDay = day;
        }
        if (this.ruinsExploresToday >= RUINS_MAX_EXPLORES_PER_DAY) {
            return { type: 'exhausted', name: '废墟已搜刮干净', amount: 0 };
        }

        // 加权随机抽取
        const totalWeight = RUINS_EXPLORE_POOL.reduce((s, r) => s + r.weight, 0);
        let roll = Math.random() * totalWeight;
        let result = RUINS_EXPLORE_POOL[RUINS_EXPLORE_POOL.length - 1]; // 默认最后一项
        for (const item of RUINS_EXPLORE_POOL) {
            roll -= item.weight;
            if (roll <= 0) {
                result = item;
                break;
            }
        }

        this.ruinsExploresToday++;
        const remaining = RUINS_MAX_EXPLORES_PER_DAY - this.ruinsExploresToday;

        // 应用探索结果
        switch (result.type) {
            case 'food':
            case 'woodFuel':
            case 'power':
                this.addResource(result.type, result.amount, `${npc.name}在废墟发现`);
                break;
            case 'medkit':
                this.game._medkitCount = (this.game._medkitCount || 0) + result.amount;
                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('resource.ruin_medkit', { name: npc.name, amount: result.amount, count: this.game._medkitCount }));
                }                break;
            case 'sanBoost':
                for (const n of this.game.npcs) {
                    if (!n.isDead) n.sanity = Math.min(100, n.sanity + result.amount);
                }
                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('resource.ruin_diary', { name: npc.name, amount: result.amount }));
                }                break;
            case 'nothing':
                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('resource.ruin_nothing', { name: npc.name, remaining }));
                }                break;
        }

        // AI模式日志（包含具体数值，方便复盘）
        if (this.game.aiModeLogger) {
            const typeNames = { food: GST.t('res_type.food'), woodFuel: GST.t('res_type.woodFuel'), power: GST.t('res_type.power'), medkit: GST.t('res_type.medkit'), sanBoost: GST.t('res_type.sanBoost'), nothing: GST.t('res_type.nothing') };
            const amountStr = result.amount > 0 ? ` → ${typeNames[result.type] || result.type}+${result.amount}` : '';
            this.game.aiModeLogger.log('EXPLORE', `${npc.name} 探索废墟: ${result.name}${amountStr} (今日${this.ruinsExploresToday}/${RUINS_MAX_EXPLORES_PER_DAY}, 剩余${remaining}次)`);
        }

        console.log(`[ResourceSystem-废墟] ${npc.name} 探索结果: ${result.name}, 今日${this.ruinsExploresToday}/${RUINS_MAX_EXPLORES_PER_DAY}`);
        return result;
    }

    // ============ 序列化 ============

    serialize() {
        return {
            woodFuel: this.woodFuel,
            food: this.food,
            power: this.power,
            dailyConsumed: { ...this.dailyConsumed },
            dailyCollected: { ...this.dailyCollected },
            totalConsumed: { ...this.totalConsumed },
            totalCollected: { ...this.totalCollected },
            hungerCrisisDuration: this._hungerCrisisDuration,
            ruinsExploresToday: this.ruinsExploresToday,
        };
    }

    deserialize(data) {
        if (!data) return;
        this.woodFuel = data.woodFuel ?? RESOURCE_DEFAULTS.woodFuel;
        this.food = data.food ?? RESOURCE_DEFAULTS.food;
        this.power = data.power ?? RESOURCE_DEFAULTS.power;
        if (data.dailyConsumed) this.dailyConsumed = data.dailyConsumed;
        if (data.dailyCollected) this.dailyCollected = data.dailyCollected;
        if (data.totalConsumed) this.totalConsumed = data.totalConsumed;
        if (data.totalCollected) this.totalCollected = data.totalCollected;
        this._hungerCrisisDuration = data.hungerCrisisDuration || 0;
        this.ruinsExploresToday = data.ruinsExploresToday || 0;
    }
}
    // ============ 导出常量供拆分文件使用 ============
GST._resource_system_RESOURCE_DEFAULTS = RESOURCE_DEFAULTS;
GST._resource_system_RESOURCE_CONSUMPTION = RESOURCE_CONSUMPTION;
GST._resource_system_MEAL_HOURS = MEAL_HOURS;
GST._resource_system_RUINS_EXPLORE_POOL = RUINS_EXPLORE_POOL;
GST._resource_system_RUINS_MAX_EXPLORES_PER_DAY = RUINS_MAX_EXPLORES_PER_DAY;
GST._resource_system_safeNum = _safeNum;


    GST.ResourceSystem = ResourceSystem;
})();
