/**
 * 福音镇 - TaskSystem
 * 挂载到 GST.TaskSystem
 */
(function() {
    'use strict';
    const GST = window.GST;

/**
 * 任务分配系统 - NPC专长与每日任务管理
 * 管理NPC专长、每日任务生成、任务分配、完成度追踪
 * 依赖: game.js, npc.js, resource-system.js, furnace-system.js, weather-system.js
 */

// ============ 任务类型枚举 ============
const TASK_TYPES = {
    COLLECT_WOOD:     'COLLECT_WOOD',      // 收集木柴
    COLLECT_FOOD:     'COLLECT_FOOD',      // 收集食物
    MAINTAIN_POWER:   'MAINTAIN_POWER',    // 维护电力
    COLLECT_MATERIAL: 'COLLECT_MATERIAL',  // 探索废墟
    PREPARE_WARMTH:   'PREPARE_WARMTH',    // 准备御寒物资
    PREPARE_MEDICAL:  'PREPARE_MEDICAL',   // 准备医疗物资
    BOOST_MORALE:     'BOOST_MORALE',      // 鼓舞士气
    COORDINATE:       'COORDINATE',        // 统筹协调
    DISTRIBUTE_FOOD:  'DISTRIBUTE_FOOD',   // 分配食物
    MAINTAIN_ORDER:   'MAINTAIN_ORDER',    // 维持秩序
    REST_RECOVER:     'REST_RECOVER',      // 休息恢复
    // ---- 新增特殊角色任务 ----
    SCOUT_RUINS:      'SCOUT_RUINS',       // 废墟侦察（歆玥）
    // CRAFT_MEDICINE已合并到PREPARE_MEDICAL
    // SET_TRAP已移除（v4.6: 效果太弱不值得浪费人力）
    // REPAIR_RADIO已移除（v4.5: 性价比太低，浪费资源）
    BUILD_GENERATOR:  'BUILD_GENERATOR',   // 建造自动发电机
    BUILD_LUMBER_MILL:'BUILD_LUMBER_MILL',  // 建造自动伐木机
    BUILD_FOOD_COLLECTOR:'BUILD_FOOD_COLLECTOR',  // 建造自动捕猎机
};

// ============ 任务详情配置 ============
const TASK_DETAILS = {
    [TASK_TYPES.COLLECT_WOOD]: {
        name: '🪵 收集木柴',
        desc: '前往伐木场砍伐枯树收集木柴',
        isOutdoor: true,
        baseYield: 10,
        baseDuration: 1800,
        staminaCost: 15,
        targetLocation: 'lumber_camp',
        resourceType: 'woodFuel',
    },
    [TASK_TYPES.COLLECT_FOOD]: {
        name: '🍞 收集食物',
        desc: '前往冰湖捕鱼或从废墟中搜索罐头',
        isOutdoor: true,
        baseYield: 8,
        baseDuration: 1800,
        staminaCost: 12,
        targetLocation: 'frozen_lake',
        resourceType: 'food',
    },
    [TASK_TYPES.MAINTAIN_POWER]: {
        name: '⚡ 维护电力',
        desc: '在工坊检修发电机、储备燃油，维持电力供应',
        isOutdoor: false,
        baseYield: 15,
        baseDuration: 2400,
        staminaCost: 10,
        targetLocation: 'workshop_door',
        resourceType: 'power',
    },
    [TASK_TYPES.COLLECT_MATERIAL]: {
        name: '🔍 探索废墟',
        desc: '前往废墟探索，可能发现食物、药品、零件等物资（每天限3次）',
        isOutdoor: true,
        baseYield: 1,
        baseDuration: 3600,
        staminaCost: 18,
        targetLocation: 'ruins_site',
        resourceType: 'explore',
    },
    [TASK_TYPES.PREPARE_WARMTH]: {
        name: '🧥 准备御寒物资',
        desc: '在仓库准备毛毯、厚衣服等御寒物资',
        isOutdoor: false,
        baseYield: 0,
        baseDuration: 1800,
        staminaCost: 8,
        targetLocation: 'warehouse_door',
        resourceType: null,
    },
    [TASK_TYPES.PREPARE_MEDICAL]: {
        name: '💊 医疗救治',
        desc: '在医疗站治疗伤患、制作急救包',
        isOutdoor: false,
        baseYield: 0,
        baseDuration: 1800,
        staminaCost: 5,
        targetLocation: 'medical_door',
        resourceType: null,
    },
    [TASK_TYPES.BOOST_MORALE]: {
        name: '🎵 鼓舞士气',
        desc: '在宿舍或公共室内区域通过唱歌、鼓励来提振全员士气',
        isOutdoor: false,
        baseYield: 0,
        baseDuration: 1800,
        staminaCost: 8,
        targetLocation: 'dorm_a_door',
        resourceType: null,
    },
    [TASK_TYPES.COORDINATE]: {
        name: '📢 统筹协调',
        desc: '在宿舍或公共室内区域安抚居民情绪、监督任务进度、制定计划',
        isOutdoor: false,
        baseYield: 0,
        baseDuration: 3600,
        staminaCost: 5,
        targetLocation: 'dorm_a_door',
        resourceType: null,
    },
    // MAINTAIN_FURNACE已移除（v4.6: 暖炉自动燃烧消耗木柴，无需人工维护）
    [TASK_TYPES.DISTRIBUTE_FOOD]: {
        name: '🍲 分配食物',
        desc: '在炊事房合理加工分配食物给全员',
        isOutdoor: false,
        baseYield: 0,
        baseDuration: 1200,
        staminaCost: 3,
        targetLocation: 'kitchen_door',
        resourceType: null,
    },
    [TASK_TYPES.MAINTAIN_ORDER]: {
        name: '🛡️ 维持秩序',
        desc: '在宿舍和公共室内区域安抚情绪、调解冲突、维持团队秩序',
        isOutdoor: false,
        baseYield: 0,
        baseDuration: 3600,
        staminaCost: 5,
        targetLocation: 'dorm_a_door',
        resourceType: null,
    },
    [TASK_TYPES.REST_RECOVER]: {
        name: '🛏️ 休息恢复',
        desc: '在室内休息恢复体力和健康',
        isOutdoor: false,
        baseYield: 0,
        baseDuration: 3600,
        staminaCost: 0,
        targetLocation: 'dorm_a_door',
        resourceType: null,
    },
    // ---- 新增特殊任务 ----
    [TASK_TYPES.SCOUT_RUINS]: {
        name: '🔍 废墟侦察',
        desc: '歆玥深入废墟区域侦察搜索稀有物资',
        isOutdoor: true,
        baseYield: 5,
        baseDuration: 2400,
        staminaCost: 20,
        targetLocation: 'ruins_site',
        resourceType: null, // 特殊产出在_applyTaskEffect中处理
    },

    // SET_TRAP已移除（v4.6: 效果太弱不值得浪费人力）
    // REPAIR_RADIO已移除（v4.5）
    [TASK_TYPES.BUILD_GENERATOR]: {
        name: '⚡ 建造自动发电机',
        desc: '在工坊建造自动发电机，建成后自动产电24/h（消耗木柴2/h，有概率故障需维修）',
        isOutdoor: false,
        baseYield: 0,
        baseDuration: 14400,
        staminaCost: 20,
        targetLocation: 'workshop_door',
        resourceType: null,
    },
    [TASK_TYPES.BUILD_LUMBER_MILL]: {
        name: '🪵 建造自动伐木机',
        desc: '在工坊建造自动伐木机，建成后自动产柴30/h（消耗电力3/h，有概率故障需维修）',
        isOutdoor: false,
        baseYield: 0,
        baseDuration: 21600,
        staminaCost: 25,
        targetLocation: 'workshop_door',
        resourceType: null,
    },
    [TASK_TYPES.BUILD_FOOD_COLLECTOR]: {
        name: '🍞 建造自动捕猎机',
        desc: '在工坊建造自动捕猎机，建成后自动产食物15/h（消耗电力2/h，有概率故障需维修）',
        isOutdoor: false,
        baseYield: 0,
        baseDuration: 14400,
        staminaCost: 20,
        targetLocation: 'workshop_door',
        resourceType: null,
    },
};

// ============ NPC专长配置（末日生存） ============
const NPC_SPECIALTIES = {
    'zhao_chef': {
        name: '伐木/搬运专长',
        desc: '砍柴×1.5、搬运×1.5、食物采集×1.3、机器建造×1.3',
        bonuses: {
            [TASK_TYPES.COLLECT_WOOD]: 1.5,
            [TASK_TYPES.COLLECT_MATERIAL]: 1.3,
            [TASK_TYPES.BUILD_GENERATOR]: 1.3,
            [TASK_TYPES.BUILD_LUMBER_MILL]: 1.3,
            [TASK_TYPES.BUILD_FOOD_COLLECTOR]: 1.3,
            [TASK_TYPES.COLLECT_FOOD]: 1.3,
        },
    },
    'lu_chen': {
        name: '采集/建造专长',
        desc: '采集×1.3、食物采集×1.3、建造×1.3、耐寒体温下降×0.7',
        bonuses: {
            [TASK_TYPES.COLLECT_MATERIAL]: 1.5,
            [TASK_TYPES.COLLECT_FOOD]: 1.3,
            [TASK_TYPES.BUILD_GENERATOR]: 1.2,
            [TASK_TYPES.BUILD_LUMBER_MILL]: 1.2,
            [TASK_TYPES.BUILD_FOOD_COLLECTOR]: 1.2,
            [TASK_TYPES.COLLECT_WOOD]: 1.3,
        },
    },
    'li_shen': {
        name: '物资管理/炊事专长',
        desc: '食物加工×2、物资盘点减浪费-20%、分配公平',
        bonuses: {
            [TASK_TYPES.DISTRIBUTE_FOOD]: 2.0,
            [TASK_TYPES.COLLECT_FOOD]: 1.5,
            [TASK_TYPES.PREPARE_WARMTH]: 1.5,
            [TASK_TYPES.PREPARE_MEDICAL]: 1.2,
        },
        wasteReduction: 0.20,
    },
    'wang_teacher': {
        name: '技师/规划专长',
        desc: '发电机维修×2、暖炉扩建×1.5、机器建造×1.5、全队规划+10%',
        bonuses: {
            [TASK_TYPES.MAINTAIN_POWER]: 2.0,
            [TASK_TYPES.BUILD_GENERATOR]: 1.5,
            [TASK_TYPES.BUILD_LUMBER_MILL]: 1.5,
            [TASK_TYPES.BUILD_FOOD_COLLECTOR]: 1.5,
            [TASK_TYPES.COORDINATE]: 1.5,
        },
        teamBonus: 0.1,
    },
    'old_qian': {
        name: '领导力/精神支柱专长',
        desc: '调解冲突×2、安抚效果×2、经验判断预警',
        bonuses: {
            [TASK_TYPES.MAINTAIN_ORDER]: 2.0,
            [TASK_TYPES.COORDINATE]: 2.0,
            [TASK_TYPES.BOOST_MORALE]: 1.5,
        },
    },
    'su_doctor': {
        name: '医疗专长',
        desc: '治疗冻伤×2、失温救治+50%、心理疏导San恢复×1.5',
        bonuses: {
            [TASK_TYPES.PREPARE_MEDICAL]: 2.0,
            [TASK_TYPES.REST_RECOVER]: 1.5,
            [TASK_TYPES.BOOST_MORALE]: 1.2,
        },
    },
    'ling_yue': {
        name: '侦察/急救/士气专长',
        desc: '废墟侦察稀有物资×2、急救×1.5、士气恢复×1.3',
        bonuses: {
            [TASK_TYPES.SCOUT_RUINS]: 2.0,
            [TASK_TYPES.PREPARE_MEDICAL]: 1.5,
            [TASK_TYPES.BOOST_MORALE]: 1.3,
            [TASK_TYPES.COLLECT_MATERIAL]: 1.3,
        },
    },
    'qing_xuan': {
        name: '药剂/急救专长',
        desc: '医疗救治×1.5、草药制剂×1.3、学习他人技能×0.7',
        bonuses: {
            [TASK_TYPES.PREPARE_MEDICAL]: 1.5,
            [TASK_TYPES.BOOST_MORALE]: 1.1,
        },
        learnMultiplier: 0.7,
    },
};

// ============ 统一场景Key常量表 ============
const SCENE_KEYS = {
    // 主地图
    VILLAGE: 'village',
    // 室内场景（与 game.maps 中的 key 一致）
    DORM_A: 'dorm_a',
    DORM_B: 'dorm_b',
    MEDICAL: 'medical',
    WAREHOUSE: 'warehouse',
    WORKSHOP: 'workshop',
    KITCHEN: 'kitchen',
    // 户外采集区域ID（用于坐标区域判定，非 currentScene 值）
    LUMBER_CAMP: 'lumber_camp',
    FROZEN_LAKE: 'frozen_lake',
    RUINS_SITE: 'ruins_site',
    ORE_PILE: 'ore_pile',
    // 特殊位置
    FURNACE_PLAZA: 'furnace_plaza',
    NORTH_GATE: 'north_gate',
    SOUTH_GATE: 'south_gate',
};

// ============ 采集速率常量表（每游戏小时产出量）============
// 【v2.0重新平衡】基于需求文档数值推演：
//   木柴：2人×8单位/h×8h=128单位 > 第1天1暖炉60单位消耗 ✓
//   食物：2人×5单位/h×6h=60单位 > 24单位/天消耗 ✓
//   电力：1人×12单位/h×6h=72单位 ≈ 72单位/天消耗 ✓
//   废墟：探索（随机奖励，每天限3次） ✓
const GATHER_RATES = {
    woodFuel: 8,     // 木柴：8单位/小时，伐木场
    food: 5,         // 食物：5单位/小时，冰湖
    power: 12,       // 电力：12单位/小时，工坊/矿渣堆
};

// 户外采集区域坐标范围定义（与 VillageMap.resourceAreas 一致）
const GATHER_OUTDOOR_AREAS = [
    { id: SCENE_KEYS.LUMBER_CAMP, resourceType: 'woodFuel', x: 2, y: 2, w: 8, h: 6 },   // 伐木场
    { id: SCENE_KEYS.FROZEN_LAKE, resourceType: 'food',     x: 2, y: 32, w: 8, h: 6 },  // 冰湖
    { id: SCENE_KEYS.RUINS_SITE,  resourceType: 'explore',   x: 38, y: 2, w: 10, h: 6 }, // 废墟探索点
    { id: SCENE_KEYS.ORE_PILE,    resourceType: 'power',     x: 38, y: 32, w: 10, h: 6 },// 矿渣堆
];

// 室内采集区域映射（currentScene直接匹配）
const GATHER_INDOOR_MAP = {
    [SCENE_KEYS.WORKSHOP]: 'power',      // 工坊 -> 电力
};

// 【兼容】旧的 GATHER_LOCATION_MAP（保留给外部引用）
const GATHER_LOCATION_MAP = {
    'lumber_camp': 'woodFuel',
    'frozen_lake': 'food',
    'ruins_site': 'explore',
    'ore_pile': 'power',
    'workshop': 'power',
};

// 采集所需最低体力
const GATHER_MIN_STAMINA = {
    woodFuel: 20,
    food: 15,
    explore: 20,
    power: 10,
};

// 资源类型Emoji映射
const RESOURCE_EMOJI = {
    woodFuel: '🪵',
    food: '🍞',
    explore: '🔍',
    power: '⚡',
};

class TaskSystem {
    constructor(game) {
        this.game = game;

        // 当前天的任务清单
        this.dailyTasks = [];      // [{id, type, name, desc, target(目标量), progress, assignedNpcId, status, priority}]
        this.taskIdCounter = 0;

        // NPC任务分配映射 { npcId: taskId }
        this.npcAssignments = {};

        // NPC当前任务执行状态 { npcId: { taskId, startTime, workTime, paused, pauseReason } }
        this.npcTaskState = {};

        // 任务完成历史
        this.completedTasks = [];

        // 未完成任务日志
        this.unfinishedTaskLog = [];

        // 系统tick计时
        this._tick = 0;

        // 当天是否已生成任务
        this._taskGeneratedForDay = -1;

        // 全队效率加成（由王老师统筹专长提供）
        this._teamEfficiencyBonus = 0;

        console.log('[TaskSystem] 初始化完成');
    }

    // ============ 每日任务生成 ============

    /** 当天数切换时调用 */
    onDayChange(day) {
        // 记录上一天未完成任务
        this._logUnfinishedTasks(day - 1);

        // 生成新一天的任务
        this._generateDailyTasks(day);
    }
    // [已拆分到 task-generator.js] _generateDailyTasks
    /** 第1天（0°C准备日）任务 */
    _generateDay1Tasks(rs, fs, npcs) {
        // 大量收集木柴 — 赵铁柱
        this._addTask(TASK_TYPES.COLLECT_WOOD, 50, 'urgent', 'zhao_chef');
        // 砍柴 — 陆辰（年轻力壮）
        this._addTask(TASK_TYPES.COLLECT_WOOD, 40, 'urgent', 'lu_chen');
        // 采集食物 — 陆辰(次要轮换)
        this._addTask(TASK_TYPES.COLLECT_FOOD, 30, 'high', 'lu_chen');
        // 物资管理+分配食物 — 李婶
        this._addTask(TASK_TYPES.COLLECT_FOOD, 40, 'urgent', 'li_shen');
        this._addTask(TASK_TYPES.DISTRIBUTE_FOOD, 1, 'high', 'li_shen');
        // 建造自动发电机 — 王策（工程师优先建设自动化设施）
        this._addTask(TASK_TYPES.BUILD_GENERATOR, 1, 'urgent', 'wang_teacher');
        // 维护电力+暖炉方案 — 王策（建完发电机后维护）
        this._addTask(TASK_TYPES.MAINTAIN_POWER, 30, 'high', 'wang_teacher');
        // 准备医疗物资 — 苏岩
        this._addTask(TASK_TYPES.PREPARE_MEDICAL, 1, 'high', 'su_doctor');
        // 统筹协调 — 老钱
        this._addTask(TASK_TYPES.COORDINATE, 1, 'normal', 'old_qian');
        this._addTask(TASK_TYPES.MAINTAIN_ORDER, 1, 'normal', 'old_qian');
        // 废墟侦察 — 歆玥
        this._addTask(TASK_TYPES.SCOUT_RUINS, 1, 'high', 'ling_yue');
        this._addTask(TASK_TYPES.BOOST_MORALE, 1, 'normal', 'ling_yue');
        // 建造自动伐木机 — 清璇（发电机就绪后尽快建设伐木机形成循环）
        this._addTask(TASK_TYPES.BUILD_LUMBER_MILL, 1, 'high', 'qing_xuan');
        // 医疗 — 清璇
        this._addTask(TASK_TYPES.PREPARE_MEDICAL, 1, 'high', 'qing_xuan');
        // 准备御寒
        this._addTask(TASK_TYPES.PREPARE_WARMTH, 1, 'normal', 'li_shen');
    }

    /** 第2天（-30°C大雪天）任务 — 户外限制2小时 */
    _generateDay2Tasks(rs, fs, npcs) {
        const woodNeeded = Math.max(0, 80 - (rs ? rs.woodFuel : 0));
        const foodNeeded = Math.max(0, 40 - (rs ? rs.food : 0));

        // 冒险外出砍柴 — 赵铁柱
        if (woodNeeded > 10) {
            this._addTask(TASK_TYPES.COLLECT_WOOD, Math.min(30, woodNeeded), 'urgent', 'zhao_chef');
        }
        // 冒险外出采集 — 陆辰
        if (foodNeeded > 8) {
            this._addTask(TASK_TYPES.COLLECT_FOOD, Math.min(20, foodNeeded), 'high', 'lu_chen');
        }

        // 室内搬运木柴 — 赵铁柱(室内协助)
        this._addTask(TASK_TYPES.PREPARE_WARMTH, 1, 'urgent', 'zhao_chef');
        // 维护电力 — 王策
        this._addTask(TASK_TYPES.MAINTAIN_POWER, 20, 'high', 'wang_teacher');
        // 分配食物 — 李婶
        this._addTask(TASK_TYPES.DISTRIBUTE_FOOD, 1, 'urgent', 'li_shen');
        this._addTask(TASK_TYPES.PREPARE_WARMTH, 1, 'high', 'li_shen');
        // 医疗待命 — 苏岩
        this._addTask(TASK_TYPES.PREPARE_MEDICAL, 1, 'urgent', 'su_doctor');
        // 安抚情绪 — 老钱
        this._addTask(TASK_TYPES.MAINTAIN_ORDER, 1, 'urgent', 'old_qian');
        // 侦察+鼓舞 — 歆玥（短时外出侦察后鼓舞）
        this._addTask(TASK_TYPES.SCOUT_RUINS, 1, 'high', 'ling_yue');
        this._addTask(TASK_TYPES.BOOST_MORALE, 1, 'high', 'ling_yue');
        // 医疗+无线电 — 清璇
        this._addTask(TASK_TYPES.PREPARE_MEDICAL, 1, 'high', 'qing_xuan');
    }

    /** 第3天（0°C喘息日）任务 — 重点加固集中供暖保障 */
    _generateDay3Tasks(rs, fs, npcs) {
        // 【v2.0-需求10】第3天是为第4天做准备的关键日
        // 计算第4天所需物资（-60°C暴风雪，消耗×2.0）
        const day4WoodNeeded = Math.round(2.5 * 24 * 2.0); // 集中供暖木材需求
        const day4FoodNeeded = Math.round(npcs.length * 1.5 * 2); // 人数×1.5×2餐
        const day4PowerNeeded = Math.round(3 * 24 * 1.5); // 3/h × 24h × 1.5倍

        const woodDeficit = Math.max(0, day4WoodNeeded - (rs ? rs.woodFuel : 0));
        const foodDeficit = Math.max(0, day4FoodNeeded - (rs ? rs.food : 0));
        const powerDeficit = Math.max(0, day4PowerNeeded - (rs ? rs.power : 0));

        // 广播第4天准备清单
        if (this.game.addEvent) {
            this.game.addEvent(GST.t('task_prep.day3_prep_title'));
            this.game.addEvent(GST.t('task_prep.day3_prep_wood', { need: day4WoodNeeded, current: Math.round(rs ? rs.woodFuel : 0), status: woodDeficit > 0 ? GST.t('task_prep.deficit', { deficit: woodDeficit }) : GST.t('task_prep.sufficient') }));
            this.game.addEvent(GST.t('task_prep.day3_prep_food', { need: day4FoodNeeded, current: Math.round(rs ? rs.food : 0), status: foodDeficit > 0 ? GST.t('task_prep.deficit', { deficit: foodDeficit }) : GST.t('task_prep.sufficient') }));
            this.game.addEvent(GST.t('task_prep.day3_prep_power', { need: day4PowerNeeded, current: Math.round(rs ? rs.power : 0), status: powerDeficit > 0 ? GST.t('task_prep.deficit', { deficit: powerDeficit }) : GST.t('task_prep.sufficient') }));
        }

        // 第3天重点：补足木材和电力，确保第4天集中供暖强度足够
        this._addTask(TASK_TYPES.PREPARE_WARMTH, 1, 'high', 'li_shen');

        // 补充木柴 — 缺口越大优先级越高
        if (woodDeficit > 0) {
            const woodPriority = woodDeficit > 50 ? 'urgent' : 'high';
            this._addTask(TASK_TYPES.COLLECT_WOOD, Math.min(60, woodDeficit), woodPriority, 'zhao_chef');
            // 缺口大时增派陆辰也去砍柴
            if (woodDeficit > 30) {
                this._addTask(TASK_TYPES.COLLECT_WOOD, Math.min(30, woodDeficit - 30), woodPriority, 'lu_chen');
            }
        }

        // 补充食物
        if (foodDeficit > 0) {
            const foodPriority = foodDeficit > 15 ? 'urgent' : 'high';
            this._addTask(TASK_TYPES.COLLECT_FOOD, Math.min(30, foodDeficit), foodPriority, 'lu_chen');
        }

        // 维护电力 — 王策（缺口大时提升优先级）
        const powerPriority = powerDeficit > 30 ? 'urgent' : 'high';
        this._addTask(TASK_TYPES.MAINTAIN_POWER, Math.max(20, Math.min(40, powerDeficit)), powerPriority, 'wang_teacher');
        // 分配食物+物资整理 — 李婶
        this._addTask(TASK_TYPES.DISTRIBUTE_FOOD, 1, 'high', 'li_shen');
        // 医疗 — 苏岩
        this._addTask(TASK_TYPES.PREPARE_MEDICAL, 1, 'high', 'su_doctor');
        // 统筹 — 老钱
        this._addTask(TASK_TYPES.COORDINATE, 1, 'normal', 'old_qian');
        // 最后一次侦察 — 歆玥
        this._addTask(TASK_TYPES.SCOUT_RUINS, 1, 'high', 'ling_yue');
        this._addTask(TASK_TYPES.BOOST_MORALE, 1, 'normal', 'ling_yue');
        // 医疗 — 清璇
        this._addTask(TASK_TYPES.PREPARE_MEDICAL, 1, 'urgent', 'qing_xuan');
    }

    /** 第4天（-60°C大极寒）任务 — 全部室内 */
    _generateDay4Tasks(rs, fs, npcs) {
        // 严禁外出！所有任务均为室内

        // 室内准备御寒 — 赵铁柱+陆辰
        this._addTask(TASK_TYPES.PREPARE_WARMTH, 1, 'urgent', 'zhao_chef');
        this._addTask(TASK_TYPES.PREPARE_WARMTH, 1, 'urgent', 'lu_chen');
        // 分配食物 — 李婶
        this._addTask(TASK_TYPES.DISTRIBUTE_FOOD, 1, 'urgent', 'li_shen');
        // 维护电力 — 王策
        this._addTask(TASK_TYPES.MAINTAIN_POWER, 1, 'urgent', 'wang_teacher');
        // 维持秩序 — 老钱
        this._addTask(TASK_TYPES.MAINTAIN_ORDER, 1, 'urgent', 'old_qian');
        // 医疗待命 — 苏岩
        this._addTask(TASK_TYPES.PREPARE_MEDICAL, 1, 'urgent', 'su_doctor');
        // 鼓舞士气 — 歆玥
        this._addTask(TASK_TYPES.BOOST_MORALE, 1, 'urgent', 'ling_yue');
        // 医疗+辅助 — 清璇
        this._addTask(TASK_TYPES.PREPARE_MEDICAL, 1, 'high', 'qing_xuan');
    }
    // [已拆分到 task-effects.js] reassignDeadNpcTasks
    // [已拆分到 task-effects.js] onWeatherEmergency
    // [已拆分到 task-generator.js] _addTask
    // ============ 任务分配 ============

    /** 分配任务给NPC */
    _assignTasks(aliveNpcs) {
        for (const task of this.dailyTasks) {
            if (task.assignedNpcId) {
                // 已有指定NPC，检查是否存活
                const npc = aliveNpcs.find(n => n.id === task.assignedNpcId);
                if (!npc) {
                    // NPC已死亡，重新分配
                    task.assignedNpcId = this._findBestNpc(task, aliveNpcs);
                }
                this.npcAssignments[task.assignedNpcId] = task.id;
            } else {
                task.assignedNpcId = this._findBestNpc(task, aliveNpcs);
                if (task.assignedNpcId) {
                    this.npcAssignments[task.assignedNpcId] = task.id;
                }
            }
        }
    }

    /**
     * 将每日任务分配作为情报提供给NPC，而不是强制导航。
     * NPC会在自己的prompt里看到任务与分工信息，再由LLM自行判断是否执行。
     */
    _activateDailyTaskNavigation(aliveNpcs) {
        for (const npc of aliveNpcs) {
            const taskId = this.npcAssignments[npc.id];
            if (!taskId) continue;
            const task = this.dailyTasks.find(t => t.id === taskId);
            if (!task || task.status === 'completed') continue;
            const detail = TASK_DETAILS[task.type];
            if (!detail || !detail.targetLocation) continue;

            npc._systemTaskHint = `今日分工情报：我被分配的任务是「${detail.name}」，目标地点是 ${detail.targetLocation}，优先级 ${task.priority || 'normal'}。这是团队计划，不是强制命令，我需要结合自己的体力、位置、天气和现场局势判断是否立即执行、调整顺序，还是暂缓。`;
            npc._systemTaskHintTime = Date.now();

            if (this.game.aiModeLogger && this.game.aiModeLogger.log) {
                this.game.aiModeLogger.log('TASK_GUIDE', `${npc.name} 收到分工情报: ${detail.name} → ${detail.targetLocation} (${task.priority || 'normal'})`);
            }
            console.log(`[TaskSystem] 每日任务情报：${npc.name} → ${detail.name} → ${detail.targetLocation}`);
        }
    }
    // [已拆分到 task-generator.js] _findBestNpc
    // ============ 主更新循环 ============

    /** 在game.update()中调用 */
    update(gameDt) {
        this._tick += gameDt;
        if (this._tick < 1.0) return;
        const dt = this._tick;
        this._tick = 0;

        // 【v5.2安全网】如果dailyTasks为空且游戏已运行，自动触发任务生成
        // 防止因晨会异常、读档异常等导致任务永远为空
        if (this.dailyTasks.length === 0 && this._taskGeneratedForDay !== this.game.dayCount) {
            console.warn(`[TaskSystem] ⚠️ 安全网触发：第${this.game.dayCount}天dailyTasks为空，自动生成任务`);
            this.onDayChange(this.game.dayCount);
        }

        // 更新每个NPC的任务执行
        for (const npc of this.game.npcs) {
            if (npc.isDead) continue;
            this._updateNpcTask(npc, dt);
            // 【新增】持续驻留产出系统
            this._updateGathering(npc, dt);
        }

        // 【任务8】资源紧急任务自动分配（每2秒检查一次）
        if (!this._urgencyCheckTick) this._urgencyCheckTick = 0;
        this._urgencyCheckTick += dt;
        if (this._urgencyCheckTick >= 2) {
            this._urgencyCheckTick = 0;
            this._checkResourceUrgency();
        }

        // 更新食物浪费减少标记计时
        if (this.game._foodWasteReductionTimer > 0) {
            this.game._foodWasteReductionTimer -= dt;
            if (this.game._foodWasteReductionTimer <= 0) {
                this.game._foodWasteReduction = false;
            }
        }

        // 更新巡逻加成标记计时
        if (this.game._patrolBonusTimer > 0) {
            this.game._patrolBonusTimer -= dt;
            if (this.game._patrolBonusTimer <= 0) {
                this.game._patrolBonus = false;
            }
        }
    }
    // [已拆分到 task-effects.js] _updateNpcTask
    // [已拆分到 task-effects.js] _applyTaskEffect
    // [已拆分到 task-effects.js] _detectGatherArea
    // [已拆分到 task-effects.js] _detectGatherAreaId
    // [已拆分到 task-effects.js] _updateGathering
    // ============ 效率计算 ============

    /** 获取NPC执行某类任务的效率倍率 */
    getTaskEfficiency(npcId, taskType) {
        let efficiency = 1.0;

        // 专长加成
        const spec = NPC_SPECIALTIES[npcId];
        if (spec && spec.bonuses && spec.bonuses[taskType]) {
            efficiency *= spec.bonuses[taskType];
        }

        // 王老师全队加成
        efficiency *= (1 + this._teamEfficiencyBonus);

        return efficiency;
    }

    // ============ 查询接口 ============

    /** 获取NPC的专长信息 */
    getSpecialty(npcId) {
        return NPC_SPECIALTIES[npcId] || null;
    }

    /** 获取NPC当前分配的任务 */
    getNpcTask(npcId) {
        const taskId = this.npcAssignments[npcId];
        if (!taskId) return null;
        return this.dailyTasks.find(t => t.id === taskId) || null;
    }

    /** 获取NPC的任务描述（供AI prompt注入） */
    getNpcTaskDescForPrompt(npcId) {
        const task = this.getNpcTask(npcId);
        if (!task) return '暂无分配任务';

        const state = this.npcTaskState[npcId];
        const detail = TASK_DETAILS[task.type];
        let desc = `当前任务: ${task.name}`;
        if (task.status === 'completed') {
            desc += '（已完成✅）';
        } else if (state && state.paused) {
            desc += `（已暂停⏸️: ${state.pauseReason}）`;
        } else {
            const progressPercent = task.target > 0 ? Math.round((task.progress / task.target) * 100) : 0;
            desc += `（进度: ${progressPercent}%）`;
            if (detail && detail.targetLocation) {
                desc += `（目标地点: ${detail.targetLocation}）`;
            }
        }
        return desc;
    }

    /** 获取今日任务完成度 */
    getDailyCompletionRate() {
        if (this.dailyTasks.length === 0) return 0;
        const completed = this.dailyTasks.filter(t => t.status === 'completed').length;
        return completed / this.dailyTasks.length;
    }

    /** 获取任务面板数据（给UI用） */
    getTaskPanelData() {
        return this.dailyTasks.map(task => {
            const npc = this.game.npcs.find(n => n.id === task.assignedNpcId);
            const state = this.npcTaskState[task.assignedNpcId];
            return {
                id: task.id,
                name: task.name,
                desc: task.desc,
                assignee: npc ? npc.name : '未分配',
                assigneeId: task.assignedNpcId,
                status: task.status,
                priority: task.priority,
                progress: task.target > 0 ? Math.min(1, task.progress / task.target) : (task.status === 'completed' ? 1 : 0),
                target: task.target,
                currentProgress: Math.round(task.progress * 10) / 10,
                paused: state ? state.paused : false,
                pauseReason: state ? state.pauseReason : null,
                isOutdoor: task.isOutdoor,
            };
        });
    }

    /** 获取任务摘要（给AI prompt用） */
    getTaskSummaryForPrompt() {
        const total = this.dailyTasks.length;
        const completed = this.dailyTasks.filter(t => t.status === 'completed').length;
        const inProgress = this.dailyTasks.filter(t => t.status === 'in_progress').length;
        const paused = Object.values(this.npcTaskState).filter(s => s.paused).length;
        return `任务${completed}/${total}完成 | ${inProgress}进行中 | ${paused}暂停`;
    }

    /** 获取任务摘要（给HUD显示用，支持i18n） */
    getTaskSummaryForHUD() {
        const total = this.dailyTasks.length;
        const completed = this.dailyTasks.filter(t => t.status === 'completed').length;
        const inProgress = this.dailyTasks.filter(t => t.status === 'in_progress').length;
        const paused = Object.values(this.npcTaskState).filter(s => s.paused).length;
        return GST.t('hud.task_summary', { completed, total, inProgress, paused });
    }

    /**
     * 获取指定NPC当前分配的未完成任务（供NPC._executeAction的case 'work'调用）
     * @param {string} npcId - NPC的id
     * @returns {{ type: string, desc: string, targetLocation: string } | null}
     */
    getCurrentTask(npcId) {
        if (!npcId) return null;
        // 优先查找该NPC被分配的任务ID
        const taskId = this.npcAssignments[npcId];
        if (taskId) {
            const task = this.dailyTasks.find(t => t.id === taskId && t.status !== 'completed');
            if (task) {
                const details = TASK_DETAILS[task.type];
                if (details) {
                    return {
                        type: task.type,
                        desc: details.desc || task.desc || task.name,
                        targetLocation: details.targetLocation || null,
                    };
                }
            }
        }
        // 没有通过npcAssignments分配的任务，遍历dailyTasks找assignedNpcId匹配的
        const assignedTask = this.dailyTasks.find(t =>
            t.assignedNpcId === npcId && t.status !== 'completed'
        );
        if (assignedTask) {
            const details = TASK_DETAILS[assignedTask.type];
            if (details) {
                return {
                    type: assignedTask.type,
                    desc: details.desc || assignedTask.desc || assignedTask.name,
                    targetLocation: details.targetLocation || null,
                };
            }
        }
        return null;
    }
    // [已拆分到 task-effects.js] applyCouncilAssignments
    // [已拆分到 task-effects.js] _resolveCouncilAssignment
    // ============ 序列化 ============

    serialize() {
        return {
            dailyTasks: this.dailyTasks,
            npcAssignments: { ...this.npcAssignments },
            npcTaskState: { ...this.npcTaskState },
            completedTasks: this.completedTasks,
            unfinishedTaskLog: this.unfinishedTaskLog,
            taskIdCounter: this.taskIdCounter,
            taskGeneratedForDay: this._taskGeneratedForDay,
        };
    }

    deserialize(data) {
        if (!data) return;
        this.dailyTasks = data.dailyTasks || [];
        this.npcAssignments = data.npcAssignments || {};
        this.npcTaskState = data.npcTaskState || {};
        this.completedTasks = data.completedTasks || [];
        this.unfinishedTaskLog = data.unfinishedTaskLog || [];
        this.taskIdCounter = data.taskIdCounter || 0;
        this._taskGeneratedForDay = data.taskGeneratedForDay || -1;
    }
}
    // ============ 导出常量供拆分文件使用 ============
    GST._task_system_TASK_TYPES = TASK_TYPES;
    GST._task_system_TASK_DETAILS = TASK_DETAILS;
    GST._task_system_NPC_SPECIALTIES = NPC_SPECIALTIES;
    GST._task_system_SCENE_KEYS = SCENE_KEYS;
    GST._task_system_GATHER_RATES = GATHER_RATES;
    GST._task_system_GATHER_OUTDOOR_AREAS = GATHER_OUTDOOR_AREAS;
    GST._task_system_GATHER_INDOOR_MAP = GATHER_INDOOR_MAP;
    GST._task_system_GATHER_LOCATION_MAP = GATHER_LOCATION_MAP;
    GST._task_system_GATHER_MIN_STAMINA = GATHER_MIN_STAMINA;
    GST._task_system_RESOURCE_EMOJI = RESOURCE_EMOJI;


    GST.TaskSystem = TaskSystem;
})();
