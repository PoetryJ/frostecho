/**
 * 福音镇 - 结局判定与渲染
 * 从 death-system.js 拆分，遵循SRP原则
 * 挂载到 GST.DeathSystem.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.DeathSystem.prototype;

    // 从原文件导入常量
    const ENDINGS = GST._death_system_ENDINGS;


    // ============ 全灭检测 ============

    proto._checkExtinction = function() {
        const aliveCount = this.game.npcs.filter(n => !n.isDead).length;
        if (aliveCount === 0) {
            console.log('[DeathSystem] 🚨 全灭！所有NPC已死亡');
            // AI模式日志：全灭汇总
            if (this.game.aiModeLogger) {
                const deathSummary = this.deathRecords.map(r => `${r.npcName}-${r.cause}(D${r.dayNum} ${r.time})`).join('; ');
                this.game.aiModeLogger.log('EXTINCTION', `全员死亡! 共${this.deathRecords.length}人 | 死亡记录: ${deathSummary}`);
            }
            this._addTimelineEvent('crisis', '🚨 全员死亡…小镇陷入了永恒的沉寂');
            this._triggerEnding();
        }
    };


    // ============ 结局判定 ============

    /** 检查结局触发条件：第4天日落(18:00) */
    proto._checkEndingCondition = function() {
        if (this.endingTriggered) return;

        const dayCount = this.game.dayCount;
        const hour = this.game.getHour();

        // 第4天18:00触发结局
        // 【修复】增加兜底：第5天及以后任何时刻都强制触发结局
        // 防止跳夜从第4天晚上直接跳到第5天早上，错过18:00检测窗口
        if ((dayCount === 4 && hour >= 18) || dayCount >= 5) {
            this._triggerEnding();
        }
    };


    /** 触发结局 */
    proto._triggerEnding = function() {
        if (this.endingTriggered) return;
        this.endingTriggered = true;

        const aliveCount = this.game.npcs.filter(n => !n.isDead).length;

        // 根据存活人数确定结局
        if (aliveCount >= ENDINGS.PERFECT.minSurvivors) {
            this.currentEnding = ENDINGS.PERFECT;
        } else if (aliveCount >= ENDINGS.NORMAL.minSurvivors) {
            this.currentEnding = ENDINGS.NORMAL;
        } else if (aliveCount >= ENDINGS.BLEAK.minSurvivors) {
            this.currentEnding = ENDINGS.BLEAK;
        } else {
            this.currentEnding = ENDINGS.EXTINCTION;
        }

        console.log(`[DeathSystem] 🏁 结局触发: ${this.currentEnding.title} (存活${aliveCount}人)`);

        // AI模式日志：结局汇总
        if (this.game.aiModeLogger) {
            let endingLog = `结局: ${this.currentEnding.title} | 存活${aliveCount}/8人\n`;
            // 死亡记录摘要
            if (this.deathRecords.length > 0) {
                endingLog += `  死亡记录(${this.deathRecords.length}人):\n`;
                for (const r of this.deathRecords) {
                    endingLog += `    ${r.npcName} - ${r.cause} - D${r.dayNum} ${r.time}${r.anomaly ? ' ' + r.anomaly : ''}\n`;
                }
            }
            // 最终资源储量
            const rs = this.game.resourceSystem;
            if (rs) {
                const tc = rs.totalConsumed || {};
                endingLog += `  最终资源: 木柴:${rs.woodFuel != null ? rs.woodFuel.toFixed(1) : '?'} 食物:${rs.food != null ? rs.food.toFixed(1) : '?'} 电力:${rs.power != null ? rs.power.toFixed(1) : '?'}\n`;
                endingLog += `  总消耗: 木柴:${(tc.woodFuel || 0).toFixed(1)} 食物:${(tc.food || 0).toFixed(1)} 电力:${(tc.power || 0).toFixed(1)}\n`;
            }
            // 关键事件时间线
            if (this.timeline && this.timeline.length > 0) {
                endingLog += `  关键事件时间线:\n`;
                for (const evt of this.timeline) {
                    endingLog += `    D${evt.dayNum || '?'} ${evt.time || '?'} [${evt.type}] ${evt.text}\n`;
                }
            }
            // 每个NPC最终属性
            endingLog += `  NPC最终状态:\n`;
            for (const npc of this.game.npcs) {
                const snap = GST.AIModeLogger.npcAttrSnapshot(npc);
                endingLog += `    ${npc.name} | ${npc.isDead ? '已故-' + (npc._deathCause || '?') : '存活'} | ${snap} | ${npc.currentScene || '?'}\n`;
            }
            this.game.aiModeLogger.log('ENDING', endingLog);
            this.game.aiModeLogger.forceFlush();
        }

        // 结局时自动保存完整debug log（用于复盘）
        if (this.game._saveDebugLogToServer) {
            this.game._saveDebugLogToServer(true);
        }

        // 暂停游戏
        this.game.paused = true;

        // 添加最终时间线事件
        this._addTimelineEvent('milestone', `🏁 ${this.currentEnding.title} — 存活${aliveCount}/8人`);

        // 渲染结局界面
        this._renderEndingScreen(aliveCount);
    };


    // ============ 结局界面渲染 ============

    proto._renderEndingScreen = function(aliveCount) {
        const ending = this.currentEnding;

        // 创建结局遮罩层
        const overlay = document.createElement('div');
        overlay.id = 'ending-overlay';
        overlay.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0, 0, 0, 0); z-index: 10000;
            display: flex; align-items: center; justify-content: center;
            transition: background 2s ease;
            overflow-y: auto;
        `;

        // 创建结局内容面板
        const panel = document.createElement('div');
        panel.id = 'ending-panel';
        panel.style.cssText = `
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            border: 2px solid ${ending.color}40;
            border-radius: 20px; padding: 40px; max-width: 800px; width: 90%;
            max-height: 85vh; overflow-y: auto;
            color: #e0e0e0; font-family: 'Microsoft YaHei', sans-serif;
            box-shadow: 0 0 60px ${ending.color}30;
            opacity: 0; transform: translateY(30px);
            transition: opacity 1.5s ease 1s, transform 1.5s ease 1s;
        `;

        // 轮回世数和对比信息
        const rs = this.game.reincarnationSystem;
        const lifeNumber = rs ? rs.getLifeNumber() : 1;
        const lastLifeAlive = rs ? rs.getLastLifeAliveCount() : null;
        let comparisonText = '';
        if (lastLifeAlive !== null) {
            const diff = aliveCount - lastLifeAlive;
            if (diff > 0) comparisonText = `<span style="color:#4ade80;">${GST.t('ending.compare_more', { n: diff })}</span>`;
            else if (diff < 0) comparisonText = `<span style="color:#ff6b6b;">${GST.t('ending.compare_less', { n: Math.abs(diff) })}</span>`;
            else comparisonText = `<span style="color:#888;">${GST.t('ending.compare_same')}</span>`;
        }

        // 标题
        let html = `
            <div style="text-align:center; margin-bottom:30px;">
                <div style="font-size:48px; margin-bottom:10px;">❄️</div>
                <h1 style="font-size:28px; color:${ending.color}; margin:0 0 10px 0; text-shadow: 0 0 20px ${ending.color}60;">
                    ${ending.title}
                </h1>
                <div style="font-size:14px; color:#888; margin-bottom:8px;">
                    ${lifeNumber > 1 ? `${GST.t('ending.life_n', { n: lifeNumber })} · ` : ''}${GST.t('ending.day_info', { alive: aliveCount })}
                </div>
                ${comparisonText ? `<div style="font-size:13px; margin-bottom:10px;">${comparisonText}</div>` : ''}
                <p style="font-size:15px; line-height:1.8; color:#bbb; max-width:600px; margin:0 auto;">
                    ${ending.desc}
                </p>
            </div>
        `;

        // 世代存活对比（第2世+才显示）
        if (rs && rs.pastLives && rs.pastLives.length > 0) {
            html += `
                <div style="margin-bottom:24px; background:rgba(155,89,182,0.08); border:1px solid rgba(155,89,182,0.2); border-radius:12px; padding:16px;">
                    <h3 style="font-size:15px; color:#c084fc; margin:0 0 12px 0;">${GST.t('ending.generation_progress')}</h3>
                    <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap; font-size:14px;">
            `;
            // 渲染历史世代
            for (let i = 0; i < rs.pastLives.length; i++) {
                const life = rs.pastLives[i];
                const alive = life.aliveCount;
                const barPct = Math.round((alive / 8) * 100);
                const barColor = alive >= 8 ? '#4ade80' : alive >= 5 ? '#facc15' : alive >= 2 ? '#fb923c' : '#ff6b6b';
                html += `
                    <div style="text-align:center; min-width:60px;">
                        <div style="font-size:11px; color:#888;">${GST.t('ending.life_n', { n: life.lifeNumber })}</div>
                        <div style="width:50px; height:6px; background:#2a2a3a; border-radius:3px; margin:4px auto; overflow:hidden;">
                            <div style="width:${barPct}%; height:100%; background:${barColor}; border-radius:3px;"></div>
                        </div>
                        <div style="font-size:13px; color:${barColor}; font-weight:bold;">${alive}/8</div>
                    </div>
                `;
                if (i < rs.pastLives.length - 1) {
                    html += `<span style="color:#555;">→</span>`;
                }
            }
            // 当前世
            const curBarPct = Math.round((aliveCount / 8) * 100);
            const curBarColor = aliveCount >= 8 ? '#4ade80' : aliveCount >= 5 ? '#facc15' : aliveCount >= 2 ? '#fb923c' : '#ff6b6b';
            html += `
                    <span style="color:#555;">→</span>
                    <div style="text-align:center; min-width:60px; border:1px solid ${curBarColor}40; border-radius:8px; padding:4px 6px; background:${curBarColor}10;">
                        <div style="font-size:11px; color:#c084fc; font-weight:bold;">${GST.t('ending.life_n', { n: lifeNumber })}</div>
                        <div style="width:50px; height:6px; background:#2a2a3a; border-radius:3px; margin:4px auto; overflow:hidden;">
                            <div style="width:${curBarPct}%; height:100%; background:${curBarColor}; border-radius:3px;"></div>
                        </div>
                        <div style="font-size:13px; color:${curBarColor}; font-weight:bold;">${aliveCount}/8</div>
                    </div>
                </div>
            `;
            // 简单对比文字
            const lastAlive = rs.pastLives[rs.pastLives.length - 1].aliveCount;
            const diff = aliveCount - lastAlive;
            if (diff > 0) {
                html += `<div style="font-size:13px; color:#4ade80; margin-top:8px;">${GST.t('ending.compare_more_hint', { n: diff })}</div>`;
            } else if (diff < 0) {
                html += `<div style="font-size:13px; color:#ff6b6b; margin-top:8px;">${GST.t('ending.compare_less_hint', { n: Math.abs(diff) })}</div>`;
            } else {
                html += `<div style="font-size:13px; color:#888; margin-top:8px;">${GST.t('ending.compare_same_hint')}</div>`;            }
            html += `</div>`;
        }

        // NPC 状态卡片
        html += `
            <div style="margin-bottom:30px;">
                    <h2 style="font-size:18px; color:#fff; border-bottom:1px solid #333; padding-bottom:8px; margin-bottom:15px;">
                        ${GST.t('ending.npc_final_status')}
                    </h2>
                <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap:12px;">
        `;

        for (const npc of this.game.npcs) {
            const alive = !npc.isDead;
            const deathRecord = this.deathRecords.find(r => r.npcId === npc.id);
            const statusColor = alive ? '#4ade80' : '#ff6b6b';
            const statusIcon = alive ? '✅' : '💀';
            const statusText = alive ? '存活' : `${deathRecord ? deathRecord.cause : '已故'}`;

            html += `
                <div style="
                    background: ${alive ? 'rgba(74, 222, 128, 0.08)' : 'rgba(255, 107, 107, 0.08)'};
                    border: 1px solid ${alive ? 'rgba(74, 222, 128, 0.2)' : 'rgba(255, 107, 107, 0.2)'};
                    border-radius: 12px; padding: 14px; display:flex; align-items:center; gap:12px;
                ">
                    <div style="
                        width:44px; height:44px; border-radius:50%;
                        background: ${npc.color || '#666'}30;
                        border: 2px solid ${statusColor};
                        display:flex; align-items:center; justify-content:center;
                        font-size:20px; flex-shrink:0;
                    ">${statusIcon}</div>
                    <div style="flex:1; min-width:0;">
                        <div style="font-size:15px; font-weight:bold; color:${statusColor};">
                            ${npc.name} <span style="font-size:12px; color:#888; font-weight:normal;">${GST.t('ending.age_n', { n: npc.age })} · ${npc.occupation}</span>
                        </div>
                        <div style="font-size:13px; color:#999; margin-top:3px;">
                            ${alive
                                ? `❤️${Math.round(npc.health)} 🌡️${npc.bodyTemp ? npc.bodyTemp.toFixed(1) : '36.5'}°C 🧠San:${Math.round(npc.sanity)}`
                                : `${deathRecord ? `${deathRecord.causeIcon} ${deathRecord.cause} · ${GST.t('hud.day_n', { n: deathRecord.dayNum })} ${deathRecord.time}` : GST.t('ending.status_dead')}`
                            }
                        </div>
                    </div>
                </div>
            `;
        }

        html += `</div></div>`;

        // 关键事件时间线
        if (this.timeline.length > 0) {
            html += `
                <div style="margin-bottom:30px;">
                    <h2 style="font-size:18px; color:#fff; border-bottom:1px solid #333; padding-bottom:8px; margin-bottom:15px;">
                        ${GST.t('ending.timeline_title')}
                    </h2>
                    <div style="position:relative; padding-left:24px;">
                        <div style="position:absolute; left:8px; top:0; bottom:0; width:2px; background:#333;"></div>
            `;

            for (const event of this.timeline) {
                const typeColors = {
                    death: '#ff6b6b',
                    crisis: '#ffa500',
                    milestone: '#4ade80',
                    conflict: '#ff4757',
                };
                const dotColor = typeColors[event.type] || '#666';

                html += `
                    <div style="position:relative; margin-bottom:12px; padding-left:16px;">
                        <div style="
                            position:absolute; left:-5px; top:6px; width:12px; height:12px;
                            border-radius:50%; background:${dotColor};
                            border: 2px solid #1a1a2e;
                        "></div>
                        <div style="font-size:12px; color:#666;">${GST.t('hud.day_n', { n: event.dayNum })} ${event.time}</div>
                        <div style="font-size:14px; color:#ccc; margin-top:2px;">${event.text}</div>
                    </div>
                `;
            }

            html += `</div></div>`;
        }

        // 资源统计
        const resSys = this.game.resourceSystem;
        if (resSys) {
            html += `
                <div style="margin-bottom:30px;">
                    <h2 style="font-size:18px; color:#fff; border-bottom:1px solid #333; padding-bottom:8px; margin-bottom:15px;">
                        ${GST.t('ending.resource_title')}
                    </h2>
                    <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:10px; text-align:center;">
                        <div style="background:rgba(255,255,255,0.05); border-radius:8px; padding:12px;">
                            <div style="font-size:24px;">🪵</div>
                            <div style="font-size:20px; color:#facc15; font-weight:bold;">${Math.round(resSys.woodFuel)}</div>
                            <div style="font-size:11px; color:#888;">${GST.t('ending.wood_remaining')}</div>
                            <div style="font-size:11px; color:#666;">${GST.t('ending.total_consumed', { n: Math.round(resSys.totalConsumed.woodFuel) })}</div>
                        </div>
                        <div style="background:rgba(255,255,255,0.05); border-radius:8px; padding:12px;">
                            <div style="font-size:24px;">🍞</div>
                            <div style="font-size:20px; color:#fb923c; font-weight:bold;">${Math.round(resSys.food)}</div>
                            <div style="font-size:11px; color:#888;">${GST.t('ending.food_remaining')}</div>
                            <div style="font-size:11px; color:#666;">${GST.t('ending.total_consumed', { n: Math.round(resSys.totalConsumed.food) })}</div>
                        </div>
                        <div style="background:rgba(255,255,255,0.05); border-radius:8px; padding:12px;">
                            <div style="font-size:24px;">⚡</div>
                            <div style="font-size:20px; color:#60a5fa; font-weight:bold;">${Math.round(resSys.power)}</div>
                            <div style="font-size:11px; color:#888;">${GST.t('ending.power_remaining')}</div>
                            <div style="font-size:11px; color:#666;">${GST.t('ending.total_consumed', { n: Math.round(resSys.totalConsumed.power) })}</div>
                        </div>
                        <div style="background:rgba(255,255,255,0.05); border-radius:8px; padding:12px;">
                            <div style="font-size:24px;">🔍</div>
                            <div style="font-size:20px; color:#a78bfa; font-weight:bold;">${resSys.ruinsExploresToday || 0}</div>
                            <div style="font-size:11px; color:#888;">${GST.t('ending.explore_today')}</div>
                            <div style="font-size:11px; color:#666;">${GST.t('ending.explore_limit')}</div>                        </div>
                    </div>
                </div>
            `;
        }

        // 底部按钮 — 根据模式显示不同按钮
        const isReincarnationMode = this.game.mode === 'reincarnation';
        const nextLifeNum = lifeNumber + 1;
        const isPerfectEnding = ending === ENDINGS.PERFECT;

        if (isReincarnationMode && isPerfectEnding) {
            // 轮回模式 + 完美结局：不再自动轮回，显示通关界面
            html += `
                <div style="text-align:center; margin-top:20px;">
                    <div style="font-size:18px; color:#ffd700; margin-bottom:14px;">${GST.t('ending.perfect_congrats')}</div>
                    <div style="font-size:13px; color:#888; margin-bottom:14px;">${GST.t('ending.perfect_lives_info', { n: lifeNumber })}</div>
                    <div style="display:flex; gap:12px; justify-content:center; flex-wrap:wrap;">
                        <button id="btn-ending-new-reincarnation" style="
                            background: linear-gradient(135deg, #9b59b660, #9b59b630);
                            border: 1px solid #9b59b660; color: #fff;
                            padding: 12px 36px; border-radius: 10px; font-size: 16px;
                            cursor: pointer; transition: all 0.3s;
                        ">${GST.t('ending.btn_new_reincarnation')}</button>
                        <button id="btn-ending-reset" style="
                            background: rgba(255,255,255,0.08);
                            border: 1px solid rgba(255,255,255,0.15); color: #aaa;
                            padding: 12px 28px; border-radius: 10px; font-size: 14px;
                            cursor: pointer; transition: all 0.3s;
                        ">${GST.t('ending.btn_reset')}</button>
                    </div>
                </div>
            `;
        } else if (isReincarnationMode) {
            // 轮回模式 + 非完美结局：自动倒计时 + 立即轮回 / 暂停轮回
            html += `
                <div id="ending-reincarnation-area" style="text-align:center; margin-top:20px;">
                    <div id="reincarnation-countdown-text" style="font-size:16px; color:#c084fc; margin-bottom:14px;">
                        ${GST.t('ending.countdown', { n: '<span id="reincarnation-countdown-num">10</span>', life: nextLifeNum })}
                    </div>
                    <div id="reincarnation-auto-btns">
                        <button id="btn-ending-instant-reincarnate" style="
                            background: linear-gradient(135deg, #9b59b660, #9b59b630);
                            border: 1px solid #9b59b660; color: #fff;
                            padding: 12px 36px; border-radius: 10px; font-size: 16px;
                            cursor: pointer; transition: all 0.3s;
                        ">${GST.t('ending.btn_instant')}</button>
                        <button id="btn-ending-pause-reincarnation" style="
                            background: rgba(255,255,255,0.08);
                            border: 1px solid rgba(255,255,255,0.15); color: #aaa;
                            padding: 12px 28px; border-radius: 10px; font-size: 14px;
                            cursor: pointer; margin-left: 12px; transition: all 0.3s;
                        ">${GST.t('ending.btn_pause')}</button>
                    </div>
                    <div id="reincarnation-manual-btns" style="display:none;">
                        <button id="btn-ending-resume-reincarnate" style="
                            background: linear-gradient(135deg, #9b59b660, #9b59b630);
                            border: 1px solid #9b59b660; color: #fff;
                            padding: 12px 36px; border-radius: 10px; font-size: 16px;
                            cursor: pointer; transition: all 0.3s;
                        ">${GST.t('ending.btn_resume')}</button>
                        <button id="btn-ending-reset" style="
                            background: rgba(255,255,255,0.08);
                            border: 1px solid rgba(255,255,255,0.15); color: #aaa;
                            padding: 12px 28px; border-radius: 10px; font-size: 14px;
                            cursor: pointer; margin-left: 12px; transition: all 0.3s;
                        ">${GST.t('ending.btn_reset')}</button>
                    </div>
                </div>
            `;
        } else {
            // 非轮回模式（agent）：不显示轮回按钮，仅显示"本局已结束"提示 + 彻底重来
            html += `
                <div style="text-align:center; margin-top:20px;">
                    <div style="font-size:15px; color:#888; margin-bottom:14px;">${GST.t('ending.game_over')}</div>
                    <button id="btn-ending-reset" style="
                        background: linear-gradient(135deg, ${ending.color}60, ${ending.color}30);
                        border: 1px solid ${ending.color}60; color: #fff;
                        padding: 12px 36px; border-radius: 10px; font-size: 16px;
                        cursor: pointer; transition: all 0.3s;
                    ">${GST.t('ending.btn_reset')}</button>
                </div>
            `;
        }

        panel.innerHTML = html;
        overlay.appendChild(panel);
        document.body.appendChild(overlay);

        // 动画淡入
        requestAnimationFrame(() => {
            overlay.style.background = 'rgba(0, 0, 0, 0.85)';
            panel.style.opacity = '1';
            panel.style.transform = 'translateY(0)';
        });

        // 绑定按钮事件
        setTimeout(() => {
            const self = this;
            const game = this.game;

            // 通用：执行轮回
            const doReincarnate = async () => {
                // 清除倒计时定时器
                if (game._reincarnationCountdownInterval) {
                    clearInterval(game._reincarnationCountdownInterval);
                    game._reincarnationCountdownInterval = null;
                }
                if (game._reincarnationCountdownTimer) {
                    clearTimeout(game._reincarnationCountdownTimer);
                    game._reincarnationCountdownTimer = null;
                }
                await game.reincarnate();
            };

            // 通用：彻底重来
            const doReset = () => {
                if (game._reincarnationCountdownInterval) {
                    clearInterval(game._reincarnationCountdownInterval);
                }
                if (game._reincarnationCountdownTimer) {
                    clearTimeout(game._reincarnationCountdownTimer);
                }
                if (game.reincarnationSystem) {
                    game.reincarnationSystem.clearAllMemories();
                }
                localStorage.removeItem('tihutown_save');
                location.reload();
            };



            if (isReincarnationMode && !isPerfectEnding) {
                // ====== 轮回模式（非完美结局）：自动倒计时 ======
                let countdown = 10;
                const countdownNumEl = document.getElementById('reincarnation-countdown-num');
                const countdownTextEl = document.getElementById('reincarnation-countdown-text');
                const autoBtns = document.getElementById('reincarnation-auto-btns');
                const manualBtns = document.getElementById('reincarnation-manual-btns');

                // 倒计时定时器
                game._reincarnationCountdownInterval = setInterval(() => {
                    countdown--;
                    if (countdownNumEl) countdownNumEl.textContent = countdown;
                    if (countdown <= 0) {
                        clearInterval(game._reincarnationCountdownInterval);
                        game._reincarnationCountdownInterval = null;
                        // 自动轮回
                        doReincarnate();
                    }
                }, 1000);

                // 立即轮回
                const btnInstant = document.getElementById('btn-ending-instant-reincarnate');
                if (btnInstant) btnInstant.addEventListener('click', doReincarnate);

                // 暂停轮回
                const btnPause = document.getElementById('btn-ending-pause-reincarnation');
                if (btnPause) {
                    btnPause.addEventListener('click', () => {
                        // 停止倒计时
                        if (game._reincarnationCountdownInterval) {
                            clearInterval(game._reincarnationCountdownInterval);
                            game._reincarnationCountdownInterval = null;
                        }
                        // 切换到手动按钮
                if (countdownTextEl) countdownTextEl.textContent = GST.t('ending.paused');
                        if (autoBtns) autoBtns.style.display = 'none';
                        if (manualBtns) manualBtns.style.display = '';
                    });
                }

                // 继续轮回（手动模式下）
                const btnResume = document.getElementById('btn-ending-resume-reincarnate');
                if (btnResume) btnResume.addEventListener('click', doReincarnate);

            } else {
                // ====== 非轮回模式：无轮回按钮，不绑定轮回事件 ======
            }

            // 通用按钮（两种模式都可能存在）
            const btnReset = document.getElementById('btn-ending-reset');
            if (btnReset) btnReset.addEventListener('click', doReset);

            // 【v5.8.15】完美结局后"开始新轮回"按钮（保留轮回记忆继续挑战）
            const btnNewReincarnation = document.getElementById('btn-ending-new-reincarnation');
            if (btnNewReincarnation) {
                btnNewReincarnation.addEventListener('click', async () => {
                    // 清除存档（结局已触发的存档不应保留）
                    localStorage.removeItem('tihutown_save');
                    // 保留轮回记忆，直接轮回
                    await doReincarnate();
                });
            }



        }, 2000);
    };


    // ============ 墓碑渲染 ============

    /** 在canvas上绘制死亡NPC的墓碑（在game的render中调用） */
    proto.renderGraves = function(ctx, offsetX, offsetY) {
        for (const record of this.deathRecords) {
            const npc = this.game.npcs.find(n => n.id === record.npcId);
            if (!npc) continue;

            // 使用冻结的死亡坐标（兼容旧存档：若无冻结坐标则回退到实时坐标）
            const graveScene = npc._deathScene !== undefined ? npc._deathScene : npc.currentScene;
            const graveX = npc._deathX !== undefined ? npc._deathX : npc.x;
            const graveY = npc._deathY !== undefined ? npc._deathY : npc.y;

            // 只在同一场景中绘制
            if (graveScene !== this.game.currentScene) continue;

            const x = graveX - offsetX;
            const y = graveY - offsetY;

            // 绘制墓碑
            ctx.save();

            // 墓碑底座
            ctx.fillStyle = '#555';
            ctx.fillRect(x - 8, y + 6, 16, 6);

            // 墓碑石头
            ctx.fillStyle = '#888';
            ctx.beginPath();
            ctx.moveTo(x - 7, y + 6);
            ctx.lineTo(x - 7, y - 8);
            ctx.quadraticCurveTo(x, y - 14, x + 7, y - 8);
            ctx.lineTo(x + 7, y + 6);
            ctx.closePath();
            ctx.fill();

            // 墓碑边框
            ctx.strokeStyle = '#666';
            ctx.lineWidth = 1;
            ctx.stroke();

            // 十字架
            ctx.strokeStyle = '#aaa';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(x, y - 10);
            ctx.lineTo(x, y - 2);
            ctx.moveTo(x - 4, y - 7);
            ctx.lineTo(x + 4, y - 7);
            ctx.stroke();

            // 名字标签
            ctx.font = '9px sans-serif';
            ctx.fillStyle = '#ccc';
            ctx.textAlign = 'center';
            ctx.fillText(npc.name, x, y - 16);

            // 死因图标
            ctx.font = '12px sans-serif';
            ctx.fillText(record.causeIcon, x, y - 24);

            ctx.restore();
        }
    };

})();
