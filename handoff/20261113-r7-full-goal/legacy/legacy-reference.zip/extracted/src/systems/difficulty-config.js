/**
 * 福音镇 - DifficultyConfig
 * 挂载到 GST.DifficultyConfig
 */
(function() {
    'use strict';
    const GST = window.GST;

/**
 * 难度配置模块 - 6个难度等级的完整参数表
 * 所有系统通过 getDifficulty() / game.difficulty 读取当前难度参数
 * 
 * 核心设计理念：所有难度都可通关，区别在于Agent需要更多轮回次数
 * 简单模式所有倍率为1.0，与当前版本行为完全一致
 */

// ============ 难度等级定义 ============
const DIFFICULTY_LEVELS = {
    easy: {
        key: 'easy',
        name: 'easy', // 通过 i18n 获取显示名称: GST.t('difficulty.easy')
        stars: '⭐',
        desc: 'easy_desc', // i18n key
        expectedLives: 'easy_lives', // i18n key

        // 初始资源系数（乘以 RESOURCE_DEFAULTS）
        initialResources: {
            woodFuel: 1.0,   // 30
            food: 1.0,       // 130
            power: 1.0,      // 30
        },

        // 资源消耗倍率
        consumptionMult: {
            wood: 1.0,
            power: 1.0,
            food: 1.0
        },

        // NPC属性衰减倍率
        hungerDecayMult: 1.0,
        staminaDrainMult: 1.0,
        sanDecayMult: 1.0,
        tempDropMult: 1.0,

        // 采集效率倍率（1.0 = 不变）
        gatherEfficiencyMult: 1.0,

        // 天气温度偏移（在基础温度上额外降低的度数）
        tempOffset: 0,
        // 户外时间限制缩减（秒）
        outdoorTimePenalty: 0,

        // 机器故障率（每游戏小时概率）& 维修时间（游戏秒）
        machineBreakdownChance: 0.08,
        machineRepairSeconds: 600,   // 10分钟（坏得少修得快）

        // 轮回Buff强度
        reincarnationBuffMult: 1.0,   // San加成倍率
        gatherExpBonus: 0,             // 每世采集经验加成（0表示无）
        aiIntervalReduction: 0.10      // AI思考间隔缩短比例
    },

    hard: {
        key: 'hard',
        name: 'hard', // 通过 i18n 获取显示名称: GST.t('difficulty.hard')
        stars: '⭐⭐⭐⭐',
        desc: 'hard_desc', // i18n key
        expectedLives: 'hard_lives', // i18n key

        initialResources: {
            woodFuel: 0.65,  // 19.5
            food: 0.65,      // 84.5
            power: 0.65,     // 19.5
        },

        consumptionMult: {
            wood: 2.2,
            power: 2.0,
            food: 2.0
        },

        hungerDecayMult: 1.5,
        staminaDrainMult: 1.35,
        sanDecayMult: 1.3,
        tempDropMult: 1.3,

        gatherEfficiencyMult: 0.7,

        tempOffset: 15,
        outdoorTimePenalty: 30 * 60,  // -30分钟（秒）

        machineBreakdownChance: 0.25,
        machineRepairSeconds: 1800,  // 30分钟（半小时）

        reincarnationBuffMult: 1.6,
        gatherExpBonus: 0.04,
        aiIntervalReduction: 0.14
    }
};

// ============ 全局工具函数 ============

/**
 * 从 localStorage 读取当前难度key并返回配置对象
 * @returns {Object} 当前难度配置对象，默认返回 easy
 */
function getDifficulty() {
    let key = localStorage.getItem('gospel_difficulty') || 'easy';
    // 【v5.5】兼容旧难度key：normal/harder/arctic/hell 映射到新的 easy/hard
    if (key === 'normal') key = 'easy';
    if (key === 'harder' || key === 'arctic' || key === 'hell') key = 'hard';
    return DIFFICULTY_LEVELS[key] || DIFFICULTY_LEVELS.easy;
}

/**
 * 保存难度key到 localStorage
 * @param {string} key - 难度等级key（easy/hard）
 */
function setDifficulty(key) {
    if (DIFFICULTY_LEVELS[key]) {
        localStorage.setItem('gospel_difficulty', key);
        console.log(`[难度系统] 难度已设置为: ${DIFFICULTY_LEVELS[key].stars} ${DIFFICULTY_LEVELS[key].name}`);
    } else {
        console.warn(`[难度系统] 无效的难度key: ${key}，使用默认easy`);
        localStorage.setItem('gospel_difficulty', 'easy');
    }
}

/**
 * 清除已保存的难度设置（用于"从第1世重新开始"时）
 */
function clearDifficulty() {
    localStorage.removeItem('gospel_difficulty');
    console.log('[难度系统] 已清除难度设置');
}

/**
 * 获取所有难度等级列表（用于UI渲染）
 * @returns {Array} 难度配置数组
 */
function getDifficultyList() {
    return Object.values(DIFFICULTY_LEVELS);
}

console.log('[难度系统] difficulty-config.js 已加载');

// 挂载到 GST 命名空间，供外部模块调用
GST.getDifficulty = getDifficulty;
GST.setDifficulty = setDifficulty;
GST.clearDifficulty = clearDifficulty;
GST.getDifficultyList = getDifficultyList;

})();
