/**
 * 福音镇 - CouncilPromptBuilder (路由层)
 * 
 * 架构说明：
 * - 本文件只保留通用逻辑骨架和语言路由
 * - 中文 prompt 模板 → council-prompts-zh.js (GST._councilPromptsZh)
 * - 英文 prompt 模板 → council-prompts-en.js (GST._councilPromptsEn)
 * - 切换语言时自动切换文件，彻底解耦
 */
(function() {
    'use strict';
    const GST = window.GST;

    // ============ 语言路由 ============
    function _getLang() {
        const isEn = GST.i18n && GST.i18n.isEn && GST.i18n.isEn();
        return isEn ? GST._councilPromptsEn : GST._councilPromptsZh;
    }

    // ============ 静态类 ============
    class CouncilPromptBuilder {

        /**
         * 创建世界状态快照 — 唯一的 isDead 过滤点
         * 调用语言文件的方法生成文本
         */
        static createSnapshot(game) {
            const lang = _getLang();
            const allNpcs = game.npcs || [];
            const alive = allNpcs.filter(n => !n.isDead);
            const dead  = allNpcs.filter(n => n.isDead);
            const deadIds = new Set(dead.map(n => n.id));
            const deadNames = dead.map(n => n.name);

            const situation = lang.buildSituation(game, alive, dead);

            const characterCards = {};
            const addressRules = {};
            const npcStates = {};
            for (const npc of alive) {
                characterCards[npc.id] = lang.buildCharacterCard(npc, deadNames);
                addressRules[npc.id]  = lang.buildAddressRules(npc, deadIds);
                npcStates[npc.id]     = lang.captureNpcState(npc, game, alive, deadNames);
            }

            return {
                situation,
                characterCards,
                addressRules,
                npcStates,
                aliveNpcs: alive,
                deadNames,
                _game: game,
            };
        }

        // ============ Prompt 构建 — 委托给语言文件 ============

        static buildDiscussionPrompt(snapshot, npc, chatHistory, discussionContext) {
            return _getLang().buildDiscussionPrompt(snapshot, npc, chatHistory, discussionContext);
        }

        static buildProposalPrompt(snapshot, chatHistory, triageParticipants) {
            return _getLang().buildProposalPrompt(snapshot, chatHistory, triageParticipants);
        }

        static buildVotePrompt(snapshot, npc, proposalSummary) {
            return _getLang().buildVotePrompt(snapshot, npc, proposalSummary);
        }

        static buildSummaryPrompt(snapshot, winnerProposal, summaryNpc) {
            return _getLang().buildSummaryPrompt(snapshot, winnerProposal, summaryNpc);
        }

        static buildTriagePrompt(snapshot, triggerReason) {
            return _getLang().buildTriagePrompt(snapshot, triggerReason);
        }

        static getFallback(npcId) {
            return _getLang().getFallback(npcId);
        }

        // ============ 内部方法 — 供外部直接调用（如 council-system.js） ============

        static _buildDiscussionRealityGuard(snapshot, npc) {
            return _getLang().buildDiscussionRealityGuard(snapshot, npc);
        }

        // ============ 纯逻辑方法 — 不涉及语言 ============

        /**
         * 检测 LLM 回复是否与快照矛盾
         * 注意：situation 字符串可能是中文或英文，需要双语匹配
         */
        static isReplyContradictingSnapshot(snapshot, reply) {
            if (!reply) return false;
            const sit = snapshot.situation || '';
            const text = String(reply);

            // 发电机相关矛盾检测
            if (sit.includes('自动发电机：运行中') || sit.includes('Auto Generator: Running')) {
                if (/修发电机|修电机|还没造好发电机|赶紧造发电机|全得黑屏冻死|电不够全得|haven't built the generator|hurry.*build.*generator/i.test(text)) {
                    return true;
                }
            }

            if ((sit.includes('自动发电机：停机') || sit.includes('自动发电机：⚠️故障中') || sit.includes('自动发电机：故障中')
                || sit.includes('Auto Generator: Stopped') || sit.includes('Auto Generator: ⚠️Broken'))
                && /还没造好发电机|赶紧造发电机|haven't built the generator/i.test(text)) {
                return true;
            }

            if ((sit.includes('自动发电机：建造中') || sit.includes('Auto Generator: Building'))
                && /已经转起来|已经开始供电|already running|already generating/i.test(text)) {
                return true;
            }

            return false;
        }

        /**
         * 获取基于事实的兜底回复
         */
        static getGroundedFallback(npcId, snapshot) {
            const lang = _getLang();
            const isEn = GST.i18n && GST.i18n.isEn && GST.i18n.isEn();
            const sit = snapshot.situation || '';

            // 根据当前局势生成有意义的兜底
            if (sit.includes('自动发电机：运行中') || sit.includes('Auto Generator: Running')) {
                const responses = isEn ? {
                    'zhao_chef': 'Generator\'s running. Good.',
                    'wang_teacher': 'The generator is operational. We should focus on wood supply now.',
                    'su_doctor': 'With the generator running, at least we won\'t freeze tonight.',
                    'default': 'At least the generator is working...'
                } : {
                    'zhao_chef': '发电机转着呢。行。',
                    'wang_teacher': '发电机已经在运行了，现在该关注木柴供应。',
                    'su_doctor': '发电机运转着，至少今晚不会冻着了。',
                    'default': '至少发电机在转……'
                };
                return responses[npcId] || responses['default'];
            }

            return lang.getFallback(npcId);
        }

        /** 统一清理 LLM 回复 */
        static cleanReply(reply, allNpcNames) {
            if (!reply) return null;
            // 清理 <think> 标签和 [END] 标记
            reply = reply.replace(/<think>[\s\S]*?<\/think>/g, '').replace(/\[END\]/g, '').trim();
            // 移除 LLM 可能重复的角色名前缀
            if (allNpcNames && allNpcNames.length > 0) {
                const namePattern = allNpcNames.join('|');
                const namePrefix = new RegExp(`^[「【]?(${namePattern})[」】]?[：:]\\s*`, '');
                reply = reply.replace(namePrefix, '').trim();
            }
            // 移除引号包裹
            if ((reply.startsWith('"') && reply.endsWith('"')) || (reply.startsWith('\u201c') && reply.endsWith('\u201d'))) {
                reply = reply.slice(1, -1);
            }
            return reply.substring(0, 500);
        }
    }

    // ============ 兼容性：暴露 TOKEN_LIMITS 供外部使用 ============
    Object.defineProperty(CouncilPromptBuilder, 'TOKEN_LIMITS', {
        get() { return _getLang().TOKEN_LIMITS; }
    });

    GST.CouncilPromptBuilder = CouncilPromptBuilder;
})();
