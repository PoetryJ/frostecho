/**
 * 福音镇 - 任务生成器
 * 从 task-system.js 拆分，遵循SRP原则
 * 挂载到 GST.TaskSystem.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.TaskSystem.prototype;

    // 从原文件导入常量
    const TASK_TYPES = GST._task_system_TASK_TYPES;
    const TASK_DETAILS = GST._task_system_TASK_DETAILS;
    const NPC_SPECIALTIES = GST._task_system_NPC_SPECIALTIES;
    const SCENE_KEYS = GST._task_system_SCENE_KEYS;


    /** 根据当天配置生成任务清单 */
    proto._generateDailyTasks = function(day) {
        if (this._taskGeneratedForDay === day) return;
        this._taskGeneratedForDay = day;

        this.dailyTasks = [];
        this.npcAssignments = {};
        this.npcTaskState = {};

        const rs = this.game.resourceSystem;
        const fs = this.game.furnaceSystem;
        const ws = this.game.weatherSystem;
        const aliveNpcs = this.game.npcs.filter(n => !n.isDead);

        // 计算王老师统筹加成
        this._teamEfficiencyBonus = 0;
        const wangTeacher = aliveNpcs.find(n => n.id === 'wang_teacher');
        if (wangTeacher && NPC_SPECIALTIES['wang_teacher'].teamBonus) {
            this._teamEfficiencyBonus = NPC_SPECIALTIES['wang_teacher'].teamBonus;
        }

        // 【智能分工系统】优先使用workPlan，否则走硬编码路径
        let usedWorkPlan = false;
        if (this.game.reincarnationSystem) {
            const holder = this.game.reincarnationSystem.getWorkPlanHolder();
            if (holder && holder.workPlan && holder.workPlan.dayPlans && holder.workPlan.dayPlans[day]) {
                this._generateTasksFromWorkPlan(holder.workPlan, day, rs, fs, aliveNpcs);
                usedWorkPlan = true;
                console.log(`[TaskSystem] 第${day}天使用workPlan生成任务(策略:${holder.workPlan.strategy})`);
            }
        }
        if (!usedWorkPlan) {
            switch (day) {
                case 1: this._generateDay1Tasks(rs, fs, aliveNpcs); break;
                case 2: this._generateDay2Tasks(rs, fs, aliveNpcs); break;
                case 3: this._generateDay3Tasks(rs, fs, aliveNpcs); break;
                case 4: this._generateDay4Tasks(rs, fs, aliveNpcs); break;
            }
        }

        // 分配任务给NPC
        this._assignTasks(aliveNpcs);
        this._activateDailyTaskNavigation(aliveNpcs);  // 驱动NPC走向任务目标

        // 【轮回系统】未使用workPlan时才走旧的优化路径
        if (!usedWorkPlan) {
            this._applyReincarnationTaskBoost(day);
        }

        // 广播任务清单 — 详细显示分工方案，让玩家看到决策协调过程
        if (this.game.addEvent) {
            const strategyLabel = usedWorkPlan ? `策略:${this.game.reincarnationSystem && this.game.reincarnationSystem.getWorkPlanHolder() && this.game.reincarnationSystem.getWorkPlanHolder().workPlan ? this.game.reincarnationSystem.getWorkPlanHolder().workPlan.strategy || '轮回优化' : '默认'}` : '默认分工';
            this.game.addEvent(GST.t('task_gen.plan_header', { day, strategy: strategyLabel }));
            
            // 按NPC分组显示任务
            const tasksByNpc = {};
            for (const task of this.dailyTasks) {
                const npcId = task.assignedNpcId || 'unassigned';
                if (!tasksByNpc[npcId]) tasksByNpc[npcId] = [];
                tasksByNpc[npcId].push(task);
            }
            
            const nameMap = { zhao_chef: '赵铁柱', lu_chen: '陆辰', li_shen: '李婶', wang_teacher: '王策', old_qian: '老钱', su_doctor: '苏岩', ling_yue: '歆玥', qing_xuan: '清璇' };
            const roleEmoji = { zhao_chef: '👨‍🍳', lu_chen: '💪', li_shen: '👩‍🍳', wang_teacher: '👨‍🏫', old_qian: '👴', su_doctor: '👨‍⚕️', ling_yue: '🔍', qing_xuan: '🧪' };
            
            for (const [npcId, tasks] of Object.entries(tasksByNpc)) {
                if (npcId === 'unassigned') continue;
                const name = nameMap[npcId] || npcId;
                const emoji = roleEmoji[npcId] || '👤';
                const taskStr = tasks.map(t => `${t.name}(目标:${t.target})`).join(' + ');
                const npc = aliveNpcs.find(n => n.id === npcId);
                const staminaStr = npc ? `体力:${Math.round(npc.stamina)}` : '';
                this.game.addEvent(GST.t('task_gen.plan_npc_task', { emoji, name, task: taskStr, stamina: staminaStr }));
            }
            
            // 显示未分配任务
            if (tasksByNpc['unassigned']) {
                for (const task of tasksByNpc['unassigned']) {
                    this.game.addEvent(GST.t('task_gen.plan_unassigned', { task: task.name }));
                }
            }
            this.game.addEvent(GST.t('task_gen.plan_footer', { taskCount: this.dailyTasks.length, aliveCount: aliveNpcs.length }));

            // 【v4.16】分工方案已由右上角常驻面板(#work-plan-panel)实时显示，不再写入决策动态面板
        }

        console.log(`[TaskSystem] 第${day}天任务生成:`, this.dailyTasks.map(t => `${t.name}→${t.assignedNpcId}`));
    };


    // ============ 【智能分工系统】从workPlan生成任务 ============

    /** 根据workPlan的分工方案生成当天任务 */
    proto._generateTasksFromWorkPlan = function(workPlan, day, rs, fs, aliveNpcs) {
        const dayPlan = workPlan.dayPlans[day];
        if (!dayPlan || dayPlan.length === 0) return;

        const aliveIds = new Set(aliveNpcs.map(n => n.id));

        // 根据workPlan中每个NPC的分配生成任务
        for (const assignment of dayPlan) {
            const npcId = assignment.npcId;
            // 如果该NPC已死亡，跳过（后面由reassign处理）
            if (!aliveIds.has(npcId)) continue;

            const taskType = assignment.task;
            if (!TASK_DETAILS[taskType]) continue;

            // 确定任务目标量
            let target = assignment.target || 1;
            const detail = TASK_DETAILS[taskType];
            if (detail && detail.resourceType && target <= 1) {
                target = this._calcResourceTarget(taskType, rs, fs, day);
            }

            // 确定优先级
            let priority = assignment.priority || 'high';
            if (day === 4) priority = 'urgent';

            this._addTask(taskType, target, priority, npcId);
        }

        // 为已死亡NPC的任务重分配给存活NPC
        const deadAssignments = dayPlan.filter(a => !aliveIds.has(a.npcId));
        for (const deadA of deadAssignments) {
            const taskType = deadA.task;
            if (!TASK_DETAILS[taskType]) continue;

            const target = deadA.target || this._calcResourceTarget(taskType, rs, fs, day);
            const bestNpc = this._findBestNpcForTask(taskType, aliveNpcs);
            if (bestNpc) {
                this._addTask(taskType, target, 'high', bestNpc.id);
                console.log(`[TaskSystem-WorkPlan] 死者${deadA.npcId}的任务${taskType}重分配给${bestNpc.name}`);
            }
        }
    };


    /** 根据任务类型和当前资源计算合理的目标量 */
    proto._calcResourceTarget = function(taskType, rs, fs, day) {
        switch (taskType) {
            case TASK_TYPES.COLLECT_WOOD: {
                if (!rs) return 50;
                const needed = day === 1 ? 80 : day === 3 ? 60 : 30;
                return Math.max(10, needed - Math.round(rs.woodFuel * 0.3));
            }
            case TASK_TYPES.COLLECT_FOOD: {
                if (!rs) return 40;
                const needed = day === 1 ? 50 : 30;
                return Math.max(10, needed - Math.round(rs.food * 0.3));
            }
            case TASK_TYPES.COLLECT_MATERIAL: {
                // 废墟探索任务，固定优先级
                return 30;
            }
            case TASK_TYPES.MAINTAIN_POWER: {
                if (!rs) return 30;
                return Math.max(10, 30 - Math.round(rs.power * 0.2));
            }
            default: return 1;
        }
    };


    /** 为特定任务类型找到最佳NPC（按专长匹配+体力排序） */
    proto._findBestNpcForTask = function(taskType, aliveNpcs) {
        const urgentAssignedNpcIds = new Set(
            this.dailyTasks.filter(t => t.priority === 'urgent' && t.assignedNpcId)
                .map(t => t.assignedNpcId)
        );

        const candidates = aliveNpcs.filter(n =>
            !n.isDead && !urgentAssignedNpcIds.has(n.id)
        );

        if (candidates.length === 0) return aliveNpcs.find(n => !n.isDead) || null;

        candidates.sort((a, b) => {
            const specA = NPC_SPECIALTIES[a.id];
            const specB = NPC_SPECIALTIES[b.id];
            const multA = (specA && specA.bonuses && specA.bonuses[taskType]) || 1.0;
            const multB = (specB && specB.bonuses && specB.bonuses[taskType]) || 1.0;
            if (multA !== multB) return multB - multA;
            return b.stamina - a.stamina;
        });

        return candidates[0];
    };


    /** 添加任务到清单 */
    proto._addTask = function(type, target, priority, preferredNpcId) {
        const detail = TASK_DETAILS[type];
        if (!detail) return;

        const taskId = `task_${++this.taskIdCounter}`;
        this.dailyTasks.push({
            id: taskId,
            type: type,
            name: detail.name,
            desc: detail.desc,
            target: target,
            progress: 0,
            assignedNpcId: preferredNpcId || null,
            status: 'pending',  // pending | in_progress | completed | failed
            priority: priority, // urgent | high | normal | low
            isOutdoor: detail.isOutdoor,
            startTime: null,
            completedTime: null,
        });
        return taskId;
    };


    /** 为任务找到最佳NPC */
    proto._findBestNpc = function(task, aliveNpcs) {
        // 找还没被分配任务的NPC
        const unassigned = aliveNpcs.filter(n => !this.npcAssignments[n.id]);
        if (unassigned.length === 0) return null;

        // 按专长匹配度排序
        let best = null;
        let bestScore = -1;
        for (const npc of unassigned) {
            let score = 0;
            const spec = NPC_SPECIALTIES[npc.id];
            if (spec && spec.bonuses && spec.bonuses[task.type]) {
                score += spec.bonuses[task.type] * 10;
            }
            // 户外任务优先体力高的
            if (task.isOutdoor) {
                score += npc.stamina / 10;
                score += npc.health / 20;
            }
            if (score > bestScore) {
                bestScore = score;
                best = npc;
            }
        }
        return best ? best.id : unassigned[0].id;
    };


    // ============ 【任务8】资源紧急任务自动分配 & think→action桥接 ============

    /**
    * 检测资源紧急情况并自动分配NPC前往采集
    * 每2秒调用一次，检测木柴<6h消耗量 / 食物<1餐需求 / 电力<3h消耗时触发
    */
    proto._checkResourceUrgency = function() {
        const rs = this.game.resourceSystem;
        if (!rs) return;

        const ws = this.game.weatherSystem;
        const currentDay = ws ? ws.currentDay : 1;

        // 第4天禁止户外任务
        if (currentDay === 4) return;

        const urgency = rs.getResourceUrgency();
        const aliveNpcs = this.game.npcs.filter(n => !n.isDead);

        // 检测各资源是否有NPC正在采集（包括暂停中的任务，避免反复分配）
        const activeGatherers = {};
        for (const npc of aliveNpcs) {
            if (npc._taskOverride && npc._taskOverride.resourceType) {
                // 只要taskOverride有resourceType，无论isActive还是暂停中，都算已分配
                const rt = npc._taskOverride.resourceType;
                if (!activeGatherers[rt]) activeGatherers[rt] = [];
                activeGatherers[rt].push(npc.id);
            }
        }

        // 资源紧急分配逻辑
        const urgentNeeds = [];
        if (urgency.wood === 'critical') {
urgentNeeds.push({ resourceType: 'woodFuel', taskType: TASK_TYPES.COLLECT_WOOD, targetLocation: 'lumber_camp', maxWorkers: 2 });
        }
        if (urgency.food === 'critical') {
urgentNeeds.push({ resourceType: 'food', taskType: TASK_TYPES.COLLECT_FOOD, targetLocation: 'frozen_lake', maxWorkers: 2 });
        }
        if (urgency.power === 'critical') {
            urgentNeeds.push({ resourceType: 'power', taskType: TASK_TYPES.MAINTAIN_POWER, targetLocation: 'workshop_door', maxWorkers: 1 });
        }

        for (const need of urgentNeeds) {
            const currentGatherers = activeGatherers[need.resourceType] || [];
            if (currentGatherers.length >= need.maxWorkers) continue; // 已有足够人在采集

            // 筛选空闲 + 体力>30 的NPC
            const candidates = aliveNpcs.filter(npc => {
                if (npc.isDead || npc.isSleeping) return false;
                if (npc.stamina < 30 || npc.health < 30) return false;
                // 【v4.17修复】有taskOverride（无论active还是暂停）的NPC都不再分配
                if (npc._taskOverride && (npc._taskOverride.isActive || npc._taskOverride.taskId)) return false;
                if (npc._behaviorPriority === 'P0') return false;
                // 第2天户外限制
                if (currentDay === 2 && need.taskType !== TASK_TYPES.MAINTAIN_POWER && npc._outdoorTimer > 100) return false;
                return true;
            });

            if (candidates.length === 0) continue;

            // 【增强】按专长匹配度排序，排除老钱（优先安抚），相同专长按体力排序
            candidates.sort((a, b) => {
                // 老钱优先安抚，排到最后（除非没有其他人可用）
                const aIsQian = a.id === 'old_qian' ? 1 : 0;
                const bIsQian = b.id === 'old_qian' ? 1 : 0;
                if (aIsQian !== bIsQian) return aIsQian - bIsQian;

                const specA = NPC_SPECIALTIES[a.id];
                const specB = NPC_SPECIALTIES[b.id];
                const multA = (specA && specA.bonuses && specA.bonuses[need.taskType]) || 1.0;
                const multB = (specB && specB.bonuses && specB.bonuses[need.taskType]) || 1.0;
                // 优先选专长倍率高的
                if (multA !== multB) return multB - multA;
                // 相同专长倍率按体力排序
                return b.stamina - a.stamina;
            });

            // 向最合适的NPC广播紧急情报，但不再强制接管行动
            const assignCount = need.maxWorkers - currentGatherers.length;
            for (let i = 0; i < Math.min(assignCount, candidates.length); i++) {
                const npc = candidates[i];
                const resourceNames = { woodFuel: '砍柴', food: '采集食物', power: '维护电力' };
                const actionName = resourceNames[need.resourceType] || need.resourceType;
                const hint = `资源紧急：当前急需有人前往${need.targetLocation}执行${actionName}。这是一条高优先级生存情报，请你结合自己的体力、位置和团队状况自主判断是否接手。`;

                if (typeof npc._triggerEmergencyDecision === 'function') {
                    npc._triggerEmergencyDecision(hint, this.game);
                } else {
                    npc._emergencyHint = hint;
                    npc._actionDecisionCooldown = 0;
                }

                if (this.game.addEvent) {
                    if (!this._urgencyMsgCooldown) this._urgencyMsgCooldown = {};
                    const cooldownKey = `${npc.id}_${need.resourceType}`;
                    const now = Date.now();
                    if (!this._urgencyMsgCooldown[cooldownKey] || now - this._urgencyMsgCooldown[cooldownKey] > 60000) {
                        this._urgencyMsgCooldown[cooldownKey] = now;
                        const spec = NPC_SPECIALTIES[npc.id];
                        const mult = (spec && spec.bonuses && spec.bonuses[need.taskType]) || 1.0;
                        const multTag = mult > 1.0 ? `(专长×${mult})` : '';
                        this.game.addEvent(GST.t('task_gen.urgent_resource', { name: npc.name, tag: multTag, action: actionName }));
                    }
                }

                console.log(`[TaskSystem] 紧急情报 ${npc.name} → ${need.resourceType} (${need.targetLocation})`);
            }
        }

        // warning级别也分配，但只分配1人
        const warningNeeds = [];
        if (urgency.wood === 'warning' && !(activeGatherers['woodFuel']?.length > 0)) {
warningNeeds.push({ resourceType: 'woodFuel', taskType: TASK_TYPES.COLLECT_WOOD, targetLocation: 'lumber_camp' });
        }
        if (urgency.food === 'warning' && !(activeGatherers['food']?.length > 0)) {
warningNeeds.push({ resourceType: 'food', taskType: TASK_TYPES.COLLECT_FOOD, targetLocation: 'frozen_lake' });
        }
        if (urgency.power === 'warning' && !(activeGatherers['power']?.length > 0)) {
warningNeeds.push({ resourceType: 'power', taskType: TASK_TYPES.MAINTAIN_POWER, targetLocation: 'workshop_door' });
        }

        for (const need of warningNeeds) {
            const candidates = aliveNpcs.filter(npc => {
                if (npc.isDead || npc.isSleeping) return false;
                if (npc.stamina < 40 || npc.health < 40) return false;
                // 【v4.17修复】有taskOverride（无论active还是暂停）的NPC都不再分配
                if (npc._taskOverride && (npc._taskOverride.isActive || npc._taskOverride.taskId)) return false;
                if (npc._behaviorPriority === 'P0') return false;
                if (currentDay === 2 && npc._outdoorTimer > 80) return false;
                return true;
            });

            if (candidates.length === 0) continue;

            // 【增强】warning级别也使用增强排序：排除老钱，按专长+体力排序
            candidates.sort((a, b) => {
                const aIsQian = a.id === 'old_qian' ? 1 : 0;
                const bIsQian = b.id === 'old_qian' ? 1 : 0;
                if (aIsQian !== bIsQian) return aIsQian - bIsQian;

                const specA = NPC_SPECIALTIES[a.id];
                const specB = NPC_SPECIALTIES[b.id];
                const multA = (specA && specA.bonuses && specA.bonuses[need.taskType]) || 1.0;
                const multB = (specB && specB.bonuses && specB.bonuses[need.taskType]) || 1.0;
                if (multA !== multB) return multB - multA;
                return b.stamina - a.stamina;
            });

            const npc = candidates[0];
            const resourceNames = { woodFuel: '砍柴', food: '采集食物', power: '维护电力' };
            const actionName = resourceNames[need.resourceType] || need.resourceType;
            npc._systemTaskHint = `资源预警：当前${actionName}需求正在上升，建议尽快有人前往${need.targetLocation}处理。这是一条生存情报，请结合自己的体力、位置、天气、风险和团队分工，自主判断是否接手。`;
            npc._systemTaskHintTime = Date.now();
            npc._actionDecisionCooldown = 0;

            // 【v4.24自治化】warning级别只广播情报，不再直接激活taskOverride
            if (this.game.addEvent) {
                if (!this._warningMsgCooldown) this._warningMsgCooldown = {};
                const warnCooldownKey = `${npc.id}_${need.resourceType}`;
                const warnNow = Date.now();
                if (!this._warningMsgCooldown[warnCooldownKey] || warnNow - this._warningMsgCooldown[warnCooldownKey] > 120000) {
                    this._warningMsgCooldown[warnCooldownKey] = warnNow;
                    const spec = NPC_SPECIALTIES[npc.id];
                    const mult = (spec && spec.bonuses && spec.bonuses[need.taskType]) || 1.0;
                    const multTag = mult > 1.0 ? `(专长×${mult})` : '';
                    this.game.addEvent(GST.t('task_gen.low_resource', { name: npc.name, tag: multTag, action: actionName }));
                }
            }

            console.log(`[TaskSystem] 预警情报 ${npc.name} → ${need.resourceType} (${need.targetLocation})`);
        }
    };


    // ============ 【轮回系统】前世经验任务优化 ============

    /** 基于前世记忆优化当天任务分配 */
    proto._applyReincarnationTaskBoost = function(day) {
        if (!this.game || !this.game.reincarnationSystem) return;
        const rs = this.game.reincarnationSystem;
        if (rs.getLifeNumber() <= 1) return; // 第1世无优化

        const lastLife = rs.getLastLifeData();
        if (!lastLife) return;

        let optimized = false;

        // 1. 资源不足优化：增加收集目标量
        if (lastLife.resourceSnapshot) {
            const snap = lastLife.resourceSnapshot;

            // 木柴严重不足（<安全线50%，安全线约80单位）
            if (snap.woodFuel < 40) {
                for (const task of this.dailyTasks) {
                    if (task.type === 'COLLECT_WOOD') {
                        const oldTarget = task.target;
                        task.target = Math.round(task.target * 1.4); // 增加40%
                        console.log(`[TaskSystem-轮回] 木柴任务目标提升: ${oldTarget} → ${task.target}`);
                        optimized = true;
                    }
                }
            }

            // 食物严重不足
            if (snap.food < 20) {
                for (const task of this.dailyTasks) {
                    if (task.type === 'COLLECT_FOOD') {
                        const oldTarget = task.target;
                        task.target = Math.round(task.target * 1.3); // 增加30%
                        console.log(`[TaskSystem-轮回] 食物任务目标提升: ${oldTarget} → ${task.target}`);
                        optimized = true;
                    }
                }
            }
        }

        // 2. 上一世供暖准备不足：优先增加木材储备
        if (!lastLife.secondFurnaceBuilt) {
            if (day === 1 || day === 3) {
                for (const task of this.dailyTasks) {
                    if (task.type === 'COLLECT_WOOD') {
                        const oldTarget = task.target;
                        task.target = Math.round(task.target * 1.3);
                        console.log(`[TaskSystem-轮回] 木柴任务目标提升: ${oldTarget} → ${task.target}（上世供暖准备不足，增加木柴储备）`);
                        optimized = true;
                        break;
                    }
                }
            }
            for (const task of this.dailyTasks) {
                if (task.type === 'MAINTAIN_POWER' && task.priority !== 'urgent') {
                    task.priority = 'urgent';
                    optimized = true;
                }
            }
        }

        // 3. 户外冻死记录：降低第2天户外任务目标
        if (day === 2) {
            const frozenOutdoor = (lastLife.deathRecords || []).filter(
                d => d.cause === '冻死' && d.day <= 2
            );
            if (frozenOutdoor.length > 0) {
                for (const task of this.dailyTasks) {
                    if (task.type === 'COLLECT_WOOD' || task.type === 'COLLECT_FOOD' || task.type === 'SCOUT_RUINS') {
                        const oldTarget = task.target;
                        task.target = Math.max(5, Math.round(task.target * 0.7)); // 降低30%
                        console.log(`[TaskSystem-轮回] 第2天户外任务降低: ${oldTarget} → ${task.target}（上世有人户外冻死）`);
                        optimized = true;
                    }
                }
            }
        }

        // 4. 显示优化提示
        if (optimized && this.game.addEvent) {
            this.game.addEvent(GST.t('task_gen.reincarnation_optimize', { day }));
        }
    };


    // ============ 日志 ============

    /** 记录未完成任务 */
    proto._logUnfinishedTasks = function(day) {
        if (day < 1) return;
        const unfinished = this.dailyTasks.filter(t => t.status !== 'completed');
        if (unfinished.length > 0) {
            this.unfinishedTaskLog.push({
                day: day,
                tasks: unfinished.map(t => ({
                    name: t.name,
                    assignee: t.assignedNpcId,
                    progress: Math.round(t.progress * 10) / 10,
                    target: t.target,
                    reason: this.npcTaskState[t.assignedNpcId]?.pauseReason || '时间不足',
                })),
            });

            if (this.game.addEvent) {
                this.game.addEvent(GST.t('task_gen.unfinished_header', { day, count: unfinished.length }));
                for (const t of unfinished) {
                    const progressPercent = t.target > 0 ? Math.round((t.progress / t.target) * 100) : 0;
                    this.game.addEvent(GST.t('task_gen.unfinished_task', { task: t.name, pct: progressPercent }));
                }
            }
        }
    };

})();
