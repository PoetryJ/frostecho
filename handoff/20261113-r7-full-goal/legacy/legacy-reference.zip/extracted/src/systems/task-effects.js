/**
 * 福音镇 - 任务效果与执行
 * 从 task-system.js 拆分，遵循SRP原则
 * 挂载到 GST.TaskSystem.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.TaskSystem.prototype;

    // 从原文件导入常量
    const TASK_TYPES = GST._task_system_TASK_TYPES;
    const TASK_DETAILS = GST._task_system_TASK_DETAILS;
    const NPC_SPECIALTIES = GST._task_system_NPC_SPECIALTIES;
    const SCENE_KEYS = GST._task_system_SCENE_KEYS;
    const GATHER_RATES = GST._task_system_GATHER_RATES;
    const GATHER_OUTDOOR_AREAS = GST._task_system_GATHER_OUTDOOR_AREAS;
    const GATHER_INDOOR_MAP = GST._task_system_GATHER_INDOOR_MAP;
    const GATHER_LOCATION_MAP = GST._task_system_GATHER_LOCATION_MAP;
    const GATHER_MIN_STAMINA = GST._task_system_GATHER_MIN_STAMINA;
    const RESOURCE_EMOJI = GST._task_system_RESOURCE_EMOJI;


    /** 更新单个NPC的任务执行 */
    proto._updateNpcTask = function(npc, dt) {
        const taskId = this.npcAssignments[npc.id];
        if (!taskId) return;

        const task = this.dailyTasks.find(t => t.id === taskId);
        if (!task || task.status === 'completed' || task.status === 'failed') return;

        // 获取任务状态
        let state = this.npcTaskState[npc.id];
        if (!state) {
            state = { taskId, startTime: 0, workTime: 0, paused: false, pauseReason: null };
            this.npcTaskState[npc.id] = state;
        }

        // 体力/健康阈值自动暂停
        if (npc.stamina < 30 || npc.health < 30) {
            if (!state.paused) {
                state.paused = true;
                state.pauseReason = npc.stamina < 30 ? 'stamina' : 'health';
                if (this.game.addEvent) {
                    this.game.addEvent(GST.t(npc.stamina < 30 ? 'task_event.paused_stamina' : 'task_event.paused_health', { name: npc.name }));
                }
            }
            return;
        }

        // 第2天户外时间限制
        const ws = this.game.weatherSystem;
        if (ws && ws.currentDay === 2 && task.isOutdoor) {
            if (ws.isOutdoorTimeExceeded(npc.id)) {
                if (!state.paused) {
                    state.paused = true;
                    state.pauseReason = '户外时间超限';
                    if (this.game.addEvent) {
                        this.game.addEvent(GST.t('task_event.outdoor_limit', { name: npc.name }));
                    }
                }
                return;
            }
        }

        // 【v4.19】第4天不再强制暂停户外任务，NPC自主判断是否冒险外出
        // 户外任务在-60°C下会导致快速失温，但如果NPC决定冒险（如修发电机），允许执行

        // 恢复暂停状态
        if (state.paused && npc.stamina >= 40 && npc.health >= 40) {
            state.paused = false;
            state.pauseReason = null;
        }

        if (state.paused) return;

        // 任务执行中
        if (task.status === 'pending') {
            task.status = 'in_progress';
            task.startTime = Date.now();
        }

        // 【修复v4.4.2】任务效果位置校验：NPC必须在任务指定的正确场景才能产出
        // 【Bug修复】_door类型目标在SCHEDULE_LOCATIONS中scene='village'（门口坐标），
        // NPC导航到门口后在village场景，但之前的校验要求NPC在室内场景，导致
        // BUILD_FURNACE等_door类目标任务永远无法执行（NPC站门口但校验要求在室内）
        const taskDetail = TASK_DETAILS[task.type];
        if (taskDetail && taskDetail.targetLocation) {
            const doorToScene = {
                warehouse_door: 'warehouse', medical_door: 'medical',
                dorm_a_door: 'dorm_a', dorm_b_door: 'dorm_b',
                kitchen_door: 'kitchen', workshop_door: 'workshop',
            };
            const tLoc = taskDetail.targetLocation;
            const isDoor = tLoc.endsWith('_door');
            if (isDoor) {
                // _door类型任务：NPC在门口(village)或已进入对应室内场景都算到达
                const indoorScene = doorToScene[tLoc];
                if (npc.currentScene !== 'village' && npc.currentScene !== indoorScene) {
                    return;
                }
            } else {
                // 非_door类型（户外采集点等）：NPC必须在village场景
                if (npc.currentScene !== 'village') {
                    return;
                }
            }
        }

        state.workTime += dt;

        // 计算效率倍率
        const efficiency = this.getTaskEfficiency(npc.id, task.type);

        // 资源产出型任务
        const detail = TASK_DETAILS[task.type];
        if (detail && detail.resourceType && detail.baseYield > 0) {
            let yieldPerSecond = (detail.baseYield / detail.baseDuration) * efficiency;
            // 【难度系统】采集效率乘以难度倍率
            const _diffGatherMult = this.game.getDifficultyMult ? this.game.getDifficultyMult('gatherEfficiencyMult') : 1.0;
            yieldPerSecond *= _diffGatherMult;
            const produced = yieldPerSecond * dt;

            // 第2天户外冒险加成
            if (ws && ws.currentDay === 2 && task.isOutdoor) {
                const adventureBonus = 1.5;
                task.progress += produced * adventureBonus;
            } else {
                task.progress += produced;
            }

            // 周期性交付资源（每产出5单位交付一次）
            const delivered = Math.floor(task.progress / 5) * 5;
            const previousDelivered = Math.floor((task.progress - produced) / 5) * 5;
            if (delivered > previousDelivered) {
                const toDeliver = delivered - previousDelivered;
                const rs = this.game.resourceSystem;
                if (rs) {
                    rs.addResource(detail.resourceType, toDeliver, npc.name);
                }
            }

            // 消耗体力
            const staminaDrain = (detail.staminaCost / detail.baseDuration) * dt;
            npc.stamina = Math.max(0, npc.stamina - staminaDrain);

            // 任务完成检测
            if (task.progress >= task.target) {
                task.status = 'completed';
                task.completedTime = Date.now();
                this.completedTasks.push({ ...task });

                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('task_event.complete_resource', { name: npc.name, task: task.name, amount: Math.round(task.progress) }));
                }
                // 奖励San值
                npc.sanity = Math.min(100, npc.sanity + 5);
            }
        } else {
            // 非资源型任务（协调、鼓舞、医疗等）
            const progressRate = (1 / detail.baseDuration) * efficiency;
            task.progress += progressRate * dt;

            // 特殊任务效果
            this._applyTaskEffect(npc, task, dt, efficiency);

            // 消耗体力
            const staminaDrain = (detail.staminaCost / detail.baseDuration) * dt;
            npc.stamina = Math.max(0, npc.stamina - staminaDrain);

            // 完成检测
            if (task.progress >= task.target) {
                task.status = 'completed';
                task.completedTime = Date.now();
                this.completedTasks.push({ ...task });

                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('task_event.complete_general', { name: npc.name, task: task.name }));
                }
                npc.sanity = Math.min(100, npc.sanity + 5);
            }
        }
    };


    /** 特殊任务效果 */
    proto._applyTaskEffect = function(npc, task, dt, efficiency) {
        const aliveNpcs = this.game.npcs.filter(n => !n.isDead);

        switch (task.type) {
            case TASK_TYPES.BOOST_MORALE: {
                // 歆玥鼓舞：恢复同场景所有NPC的San值
                const sameScene = aliveNpcs.filter(n => n.currentScene === npc.currentScene && n.id !== npc.id);
                for (const other of sameScene) {
                    other.sanity = Math.min(100, other.sanity + 0.02 * efficiency * dt);
                }
                break;
            }
            case TASK_TYPES.COORDINATE: {
                // 统筹协调：提升同场景NPC工作效率（通过San值维持）
                const sameScene = aliveNpcs.filter(n => n.currentScene === npc.currentScene && n.id !== npc.id);
                for (const other of sameScene) {
                    other.sanity = Math.min(100, other.sanity + 0.01 * efficiency * dt);
                }
                break;
            }
            case TASK_TYPES.MAINTAIN_ORDER: {
                // 维持秩序：老钱安抚，恢复San值
                const sameScene = aliveNpcs.filter(n => n.currentScene === npc.currentScene && n.id !== npc.id);
                for (const other of sameScene) {
                    other.sanity = Math.min(100, other.sanity + 0.015 * efficiency * dt);
                }
                break;
            }
            case TASK_TYPES.PREPARE_MEDICAL: {
                // 医疗救治：治疗同场景中健康低的NPC + 制作急救包
                const sameScene = aliveNpcs.filter(n => n.currentScene === npc.currentScene && n.id !== npc.id && n.health < 60);
                for (const other of sameScene) {
                    other.health = Math.min(100, other.health + 0.03 * efficiency * dt);
                    // 治疗失温
                    if (other.bodyTemp < 35 && other.bodyTemp !== undefined) {
                        other.bodyTemp = Math.min(36.5, other.bodyTemp + 0.005 * efficiency * dt);
                    }
                }
                // 同时制作急救包（合并原CRAFT_MEDICINE功能）
                if (!this.game._medkitCraftProgress) this.game._medkitCraftProgress = 0;
                const craftRate = 0.5 * efficiency;
                this.game._medkitCraftProgress += (dt / 7200) * craftRate; // 7200秒(2游戏小时)产出1份
                if (this.game._medkitCraftProgress >= 1) {
                    this.game._medkitCraftProgress -= 1;
                    this.game._medkitCount = (this.game._medkitCount || 0) + 1;
                    if (this.game.addEvent) {
                        this.game.addEvent(GST.t('task_event.medkit_crafted', { name: npc.name, count: this.game._medkitCount }));
                    }
                }
                break;
            }

            // MAINTAIN_FURNACE已移除（v4.6）
            case TASK_TYPES.BUILD_GENERATOR:
            case TASK_TYPES.BUILD_LUMBER_MILL:
            case TASK_TYPES.BUILD_FOOD_COLLECTOR: {
                // 建造自动化机器：通知MachineSystem
                const ms = this.game.machineSystem;
                if (ms) {
                    const machineType = task.type === TASK_TYPES.BUILD_GENERATOR ? 'generator' : task.type === TASK_TYPES.BUILD_LUMBER_MILL ? 'lumberMill' : 'foodCollector';
                    const machine = ms[machineType];
                    if (machine && !machine.built) {
                        const builders = this.dailyTasks
                            .filter(t => t.type === task.type && t.assignedNpcId)
                            .map(t => t.assignedNpcId);
                        if (!machine.building) {
                            ms.startBuild(machineType, builders);
                        } else {
                            machine.buildWorkers = builders;
                        }
                    }
                }
                break;
            }
            case TASK_TYPES.MAINTAIN_POWER: {
                // 维护电力：产出电力
                const rs = this.game.resourceSystem;
                if (rs) {
                    const detail = TASK_DETAILS[task.type];
                    let yieldPerSecond = (detail.baseYield / detail.baseDuration) * efficiency;
                    // 【难度系统】采集效率乘以难度倍率
                    const _diffGatherMult2 = this.game.getDifficultyMult ? this.game.getDifficultyMult('gatherEfficiencyMult') : 1.0;
                    yieldPerSecond *= _diffGatherMult2;
                    rs.addResource('power', yieldPerSecond * dt);
                }
                break;
            }
            case TASK_TYPES.SCOUT_RUINS: {
                // 歆玥废墟侦察：有概率产出稀有物资
                const rs2 = this.game.resourceSystem;
                if (rs2 && Math.random() < 0.002 * efficiency * dt) {
                    const loot = ['medicine', 'canned_food', 'spare_parts'];
                    const item = loot[Math.floor(Math.random() * loot.length)];
                    const names = { medicine: 'task_event.ruins_item_medicine', canned_food: 'task_event.ruins_item_canned', spare_parts: 'task_event.ruins_item_parts' };
                    if (this.game.addEvent) {
                        this.game.addEvent(GST.t('task_event.ruins_found', { name: npc.name, item: GST.t(names[item]) }));
                    }
                    // 转为对应资源
                    if (item === 'medicine') rs2.addResource('medical', 5, npc.name);
                    else if (item === 'canned_food') rs2.addResource('food', 8, npc.name);
                    else if (item === 'spare_parts') rs2.addResource('power', 5, npc.name);
                }
                break;
            }
            // CRAFT_MEDICINE已合并到PREPARE_MEDICAL
            // SET_TRAP已移除（v4.6）
            // REPAIR_RADIO已移除（v4.5）
            case TASK_TYPES.DISTRIBUTE_FOOD: {
                // 李婶分配食物：完成后全员饱腹恢复+触发进餐事件
                if (task.progress >= task.target && !task._foodDistributed) {
                    task._foodDistributed = true;
                    const rs4 = this.game.resourceSystem;
                    const foodCost = aliveNpcs.length * 1.5; // 每人1.5单位食物
                    if (rs4 && rs4.food >= foodCost) {
                        rs4.consumeResource('food', foodCost, '分配食物');
                        for (const other of aliveNpcs) {
                            if (other.hunger !== undefined) {
                                other.hunger = Math.min(100, other.hunger + 25);
                            }
                            other.sanity = Math.min(100, other.sanity + 2);
                        }
                        if (this.game.addEvent) {
                            this.game.addEvent(GST.t('task_event.food_distributed', { name: npc.name, count: aliveNpcs.length, cost: Math.round(foodCost) }));
                        }
                    } else if (rs4) {
                        if (this.game.addEvent) {
                            this.game.addEvent(GST.t('task_event.food_insufficient', { name: npc.name, need: Math.round(foodCost), have: Math.round(rs4.food) }));
                        }
                    }
                }
                break;
            }
            case TASK_TYPES.PREPARE_WARMTH: {
                // 准备御寒物资：完成后全员体温恢复加成buff
                if (task.progress >= task.target && !task._warmthPrepared) {
                    task._warmthPrepared = true;
                    // 激活御寒buff，持续到下一天
                    this.game._warmthPrepBonus = true;
                    for (const other of aliveNpcs) {
                        if (other.bodyTemp !== undefined && other.bodyTemp < 36.5) {
                            other.bodyTemp = Math.min(36.5, other.bodyTemp + 0.5);
                        }
                        other.sanity = Math.min(100, other.sanity + 3);
                    }
                    if (this.game.addEvent) {
                        this.game.addEvent(GST.t('task_event.warmth_prepared', { name: npc.name }));
                    }
                }
                break;
            }
            case TASK_TYPES.REST_RECOVER: {
                // 休息恢复：在有效室内供暖环境中加速恢复体力和健康
                const hSys = this.game.furnaceSystem;
                if (hSys && hSys.isNearActiveFurnace(npc)) {
                    npc.stamina = Math.min(100, npc.stamina + 0.05 * efficiency * dt);
                    npc.health = Math.min(100, npc.health + 0.02 * efficiency * dt);
                }
                break;
            }
        }
    };


    /**
    * 检测NPC当前是否在采集区域，返回对应的资源类型
    * 户外区域用坐标范围判定（因为NPC在户外时currentScene都是'village'）
    * 室内区域用currentScene直接匹配
    * @returns {string|null} 资源类型(woodFuel/food/explore/power)或null
    */
    proto._detectGatherArea = function(npc) {
        const scene = npc.currentScene;

        // 1. 室内场景直接匹配
        if (GATHER_INDOOR_MAP[scene]) {
            return GATHER_INDOOR_MAP[scene];
        }

        // 2. 户外区域坐标范围检测
        if (scene === SCENE_KEYS.VILLAGE) {
            const gx = npc.x / 32; // GST.TILE = 32
            const gy = npc.y / 32;
            for (const area of GATHER_OUTDOOR_AREAS) {
                if (gx >= area.x && gx < area.x + area.w && gy >= area.y && gy < area.y + area.h) {
                    return area.resourceType;
                }
            }
        }

        return null;
    };


    /**
    * 获取NPC当前所在的采集区域ID
    * @returns {string|null} 区域ID如'lumber_camp'或null
    */
    proto._detectGatherAreaId = function(npc) {
        const scene = npc.currentScene;

        if (scene === SCENE_KEYS.VILLAGE) {
            const gx = npc.x / 32;
            const gy = npc.y / 32;
            for (const area of GATHER_OUTDOOR_AREAS) {
                if (gx >= area.x && gx < area.x + area.w && gy >= area.y && gy < area.y + area.h) {
                    return area.id;
                }
            }
        }

        // 室内
        if (GATHER_INDOOR_MAP[scene]) {
            return scene;
        }

        return null;
    };


    /** 检测NPC是否在采集区域，持续产出资源 */
    proto._updateGathering = function(npc, dt) {
        if (npc.isDead || npc.isSleeping) return;

        // 判断NPC当前所在区域对应的资源类型
        const resourceType = this._detectGatherArea(npc);
        if (!resourceType) {
            // 不在采集区域，重置状态
            if (npc._gatheringResource) {
                // NPC离开采集区域，输出总结日志
                const totalTime = npc._gatherTotalTime || 0;
                const totalYield = npc._gatherAccumulated || 0;
                if (totalYield > 0 && this.game.addEvent) {
                    const emoji = RESOURCE_EMOJI[npc._gatheringResource] || '📦';
                    const hours = (totalTime / 3600).toFixed(1);
                    this.game.addEvent(GST.t('task_event.gather_summary', { emoji, name: npc.name, hours, amount: Math.round(totalYield) }));
                }
                npc._gatheringResource = null;
                npc._gatherAccumulated = 0;
                npc._gatherTotalTime = 0;
                npc._gatherNotifyAccum = 0;
            }
            return;
        }

        // 体力检查：低于最低工作体力阈值时停止产出
        const minStamina = GATHER_MIN_STAMINA[resourceType] || 20;
        if (npc.stamina <= minStamina) {
            // 触发一次性提示
            if (!npc._gatherStaminaWarned) {
                npc._gatherStaminaWarned = true;
                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('task_event.stamina_low', { name: npc.name, stamina: Math.round(npc.stamina) }));
                }
            }
            return;
        }
        npc._gatherStaminaWarned = false;

        // 初始化采集状态
        if (!npc._gatheringResource || npc._gatheringResource !== resourceType) {
            // 【调试日志】NPC进入采集区
            const areaId = this._detectGatherAreaId(npc) || resourceType;
            console.log(`[采集] ${npc.name} 在 ${areaId} 采集 ${resourceType} (坐标: ${(npc.x/32).toFixed(1)},${(npc.y/32).toFixed(1)})`);
            if (this.game.addEvent) {
                const emoji = RESOURCE_EMOJI[resourceType] || '📦';
                const gatherStartKey = resourceType === 'woodFuel' ? 'task_event.gather_start_chop' : resourceType === 'food' ? 'task_event.gather_start_fish' : resourceType === 'explore' ? 'task_event.gather_start_explore' : 'task_event.gather_start_power';
                this.game.addEvent(GST.t(gatherStartKey, { emoji, name: npc.name }));
            }
            // 【任务8】更新NPC状态描述为具体的采集动作（走i18n翻译）
            const gatherActionNames = {
                woodFuel: '🪓 ' + GST.t('state_desc.chopping_wood'),
                food: '🎣 ' + GST.t('state_desc.fishing'),
                explore: '🔍 ' + GST.t('state_desc.exploring_ruins'),
                power: '🔧 ' + GST.t('state_desc.maintaining_power')
            };
            npc.stateDesc = gatherActionNames[resourceType] || GST.t('state_desc.gathering');
            npc._gatheringResource = resourceType;
            npc._gatherAccumulated = 0;
            npc._gatherTotalTime = 0;
            npc._gatherNotifyAccum = 0;
        }

        // 计算实际产出
        const baseRate = GATHER_RATES[resourceType] || 0;

        // 专长倍率
        let specialtyMult = 1.0;
        const spec = NPC_SPECIALTIES[npc.id];
        if (spec && spec.bonuses) {
            // 查找对应的任务类型
            const taskTypeMap = {
                woodFuel: TASK_TYPES.COLLECT_WOOD,
                food: TASK_TYPES.COLLECT_FOOD,
                explore: TASK_TYPES.COLLECT_MATERIAL,
                power: TASK_TYPES.MAINTAIN_POWER,
            };
            const taskType = taskTypeMap[resourceType];
            if (taskType && spec.bonuses[taskType]) {
                specialtyMult = spec.bonuses[taskType];
            }
        }

        // 体力效率系数【v2.0重新平衡：匹配需求文档体力修正表】
        let staminaEff = 1.0;
        if (npc.stamina >= 80) staminaEff = 1.2;       // 体力充沛，效率提升
        else if (npc.stamina >= 50) staminaEff = 1.0;  // 正常效率
        else if (npc.stamina >= 20) staminaEff = 0.6;  // 体力偏低，效率下降
        else staminaEff = 0.3;                          // 体力极低，几乎无法工作

        // 天气惩罚【v2.0重新平衡：匹配需求文档天气采集效率修正表】
        let weatherPenalty = 1.0;
        const ws = this.game.weatherSystem;
        if (ws) {
            // 户外判定：NPC在village场景且在采集区域坐标范围内
            const isOutdoor = (npc.currentScene === SCENE_KEYS.VILLAGE);
            if (isOutdoor) {
                if (ws.currentDay === 1) weatherPenalty = 0.9;       // 第1天-10°C轻雪
                else if (ws.currentDay === 2) weatherPenalty = 0.7;  // 第2天-25°C中雪
                else if (ws.currentDay === 3) weatherPenalty = 1.1;  // 第3天0°C喘息日
                else if (ws.currentDay === 4) weatherPenalty = 0;    // 第4天-60°C禁止外出
            }
        }

        // 是否有对应采集任务，无任务时50%速率产出
        let taskMult = 0.5; // 默认无任务50%
        const npcTask = this.getNpcTask(npc.id);
        if (npcTask) {
            const detail = TASK_DETAILS[npcTask.type];
            if (detail && detail.resourceType === resourceType) {
                taskMult = 1.0;
            }
        }

        // taskOverride 任务驱动的NPC也视为有任务
        if (npc._taskOverride && npc._taskOverride.isActive) {
            taskMult = 1.0;
        }

        // 实际产出 = 基础产出/小时 × 专长倍率 × 体力效率 × 天气惩罚 × 任务倍率 / 3600秒
        // 【难度系统】采集效率乘以难度倍率
        const _diffGatherMult3 = this.game.getDifficultyMult ? this.game.getDifficultyMult('gatherEfficiencyMult') : 1.0;
        const actualRatePerSec = (baseRate * specialtyMult * staminaEff * weatherPenalty * taskMult * _diffGatherMult3) / 3600;
        const produced = actualRatePerSec * dt;

        if (produced <= 0) return;

        // 累加产出
        npc._gatherAccumulated += produced;
        npc._gatherTotalTime += dt;
        npc._gatherNotifyAccum += produced;

        // 实际添加到资源系统
        const rs = this.game.resourceSystem;
        if (rs) {
            rs.addResource(resourceType, produced, npc.name);
        }

        // 每累计达到10单位时显示通知【v2.0调整：从5提升到10，减少刷屏】
        if (npc._gatherNotifyAccum >= 10) {
            npc._gatherNotifyAccum -= 10;
            if (this.game.addEvent) {
                const emoji = RESOURCE_EMOJI[resourceType] || '📦';
                const effText = specialtyMult > 1 ? ` (${specialtyMult}x)` : '';
                this.game.addEvent(GST.t('task_event.gather_progress', { emoji, name: npc.name, amount: Math.round(npc._gatherAccumulated), eff: effText }));
            }
        }
    };

    // [已拆分到 task-generator.js] _logUnfinishedTasks
    // [已拆分到 task-generator.js] _applyReincarnationTaskBoost
    // [已拆分到 task-generator.js] _checkResourceUrgency
    /** 将营地会议分工转成正式的当日任务表（用于首日晨会） */
    proto.applyCouncilAssignments = function(proposal, options) {
        if (!proposal || !proposal.assignments) return false;

        const day = (options && options.day) || this.game.dayCount || 1;
        const rs = this.game.resourceSystem;
        const fs = this.game.furnaceSystem;
        const aliveNpcs = this.game.npcs.filter(n => !n.isDead);
        const npcByName = new Map(aliveNpcs.map(n => [n.name, n]));

        this._taskGeneratedForDay = day;
        this.dailyTasks = [];
        this.npcAssignments = {};
        this.npcTaskState = {};

        for (const npc of aliveNpcs) {
            if (!npc._taskOverride) continue;
            npc._taskOverride.isActive = false;
            npc._taskOverride.taskId = null;
            npc._taskOverride.targetLocation = null;
            npc._taskOverride.resourceType = null;
            npc._taskOverride.stateDesc = null;
            npc._taskOverride.displayDesc = null;
            npc._taskOverride.effectKey = null;
            npc._taskOverride.intentId = null;
        }

        for (const [name, taskText] of Object.entries(proposal.assignments)) {
            const npc = npcByName.get(name);
            if (!npc) continue;

            const resolved = this._resolveCouncilAssignment(taskText, day, npc, rs, fs);
            const taskId = this._addTask(resolved.type, resolved.target, resolved.priority, npc.id);
            if (taskId) {
                this.npcAssignments[npc.id] = taskId;
            }
        }

        for (const npc of aliveNpcs) {
            if (this.npcAssignments[npc.id]) continue;
            const fallback = this._resolveCouncilAssignment('', day, npc, rs, fs);
            const taskId = this._addTask(fallback.type, fallback.target, fallback.priority, npc.id);
            if (taskId) {
                this.npcAssignments[npc.id] = taskId;
            }
        }

        this._assignTasks(aliveNpcs);
        this._activateDailyTaskNavigation(aliveNpcs);

        if (this.game.addEvent) {
            this.game.addEvent(GST.t('task_event.council_applied', { plan: proposal.name || 'Daily Plan', day }));

            const lines = aliveNpcs.map(npc => {
                const taskId = this.npcAssignments[npc.id];
                const task = this.dailyTasks.find(t => t.id === taskId);
                return task ? `  ${npc.name}: ${task.name}` : null;
            }).filter(Boolean);

            for (const line of lines) {
                this.game.addEvent(line);
            }
        }

        // 【v4.16】晨会定稿已由右上角常驻面板(#work-plan-panel)实时显示，不再写入决策动态面板

        console.log(`[TaskSystem] 晨会方案已转成第${day}天正式任务:`, this.dailyTasks.map(t => `${t.name}→${t.assignedNpcId}`));
        return true;
    };


    proto._resolveCouncilAssignment = function(taskText, day, npc, rs, fs) {
        const text = String(taskText || '').trim();
        const lowered = text.toLowerCase();
        const has = (...keywords) => keywords.some(kw => lowered.includes(String(kw).toLowerCase()));
        const calc = (type) => this._calcResourceTarget(type, rs, fs, day);

        if (has('建造发电机', '自动发电', '发电机')) {
            return { type: TASK_TYPES.BUILD_GENERATOR, target: 1, priority: 'urgent' };
        }
        if (has('建造伐木机', '自动伐木', '伐木机')) {
            return { type: TASK_TYPES.BUILD_LUMBER_MILL, target: 1, priority: 'high' };
        }
        if (has('建造捕猎机', '自动捕猎', '捕猎机', '建造捕猎机', '自动捕猎')) {
            return { type: TASK_TYPES.BUILD_FOOD_COLLECTOR, target: 1, priority: 'high' };
        }
        if (has('供暖', '保暖', '御寒', '加固供暖', '准备过冬')) {
            return { type: TASK_TYPES.PREPARE_WARMTH, target: 1, priority: 'urgent' };
        }
        if (has('人工发电', '手摇发电', '手动发电', '维护电力', '电力', '接线', '电路', '供电')) {
            return { type: TASK_TYPES.MAINTAIN_POWER, target: calc(TASK_TYPES.MAINTAIN_POWER), priority: 'high' };
        }
        if (has('砍柴', '伐木', '木柴', '柴火', '木头')) {
            return { type: TASK_TYPES.COLLECT_WOOD, target: calc(TASK_TYPES.COLLECT_WOOD), priority: 'urgent' };
        }
        if (has('做饭', '烹饪', '炊事', '分配食物', '分食', '准备早餐', '准备晚餐')) {
            return { type: TASK_TYPES.DISTRIBUTE_FOOD, target: 1, priority: 'high' };
        }
        if (has('采集食物', '食物', '捕鱼', '抓鱼', '钓鱼', '打鱼', '冰湖')) {
            return { type: TASK_TYPES.COLLECT_FOOD, target: calc(TASK_TYPES.COLLECT_FOOD), priority: 'high' };
        }
        if (has('医疗', '治疗', '急救', '包扎', '药', '伤员', '心理疏导')) {
            return { type: TASK_TYPES.PREPARE_MEDICAL, target: 1, priority: 'high' };
        }
        if (has('探索', '废墟', '搜索', '搜寻', '找零件', '材料', '物资')) {
            if (has('零件', '材料', '物资')) {
                return { type: TASK_TYPES.COLLECT_MATERIAL, target: calc(TASK_TYPES.COLLECT_MATERIAL), priority: 'high' };
            }
            return { type: TASK_TYPES.SCOUT_RUINS, target: 1, priority: 'high' };
        }
        if (has('侦察', '巡查')) {
            return { type: TASK_TYPES.SCOUT_RUINS, target: 1, priority: 'high' };
        }
        if (has('安抚', '鼓舞', '士气', '安慰', '谈心')) {
            return { type: TASK_TYPES.BOOST_MORALE, target: 1, priority: 'normal' };
        }
        if (has('巡逻', '守夜', '值班', '警戒', '秩序')) {
            return { type: TASK_TYPES.MAINTAIN_ORDER, target: 1, priority: 'normal' };
        }
        if (has('统筹', '协调', '组织', '指挥')) {
            return { type: TASK_TYPES.COORDINATE, target: 1, priority: 'normal' };
        }
        if (has('御寒', '保暖', '取暖', '准备御寒')) {
            return { type: TASK_TYPES.PREPARE_WARMTH, target: 1, priority: 'normal' };
        }
        if (has('休息', '恢复', '睡觉', '养伤')) {
            return { type: TASK_TYPES.REST_RECOVER, target: 1, priority: 'normal' };
        }

        if (npc.health < 40 || npc.stamina < 25) {
            return { type: TASK_TYPES.REST_RECOVER, target: 1, priority: 'normal' };
        }

        switch (npc.id) {
            case 'wang_teacher':
                return { type: TASK_TYPES.BUILD_GENERATOR, target: 1, priority: 'urgent' };
            case 'zhao_chef':
                return { type: TASK_TYPES.COLLECT_WOOD, target: calc(TASK_TYPES.COLLECT_WOOD), priority: 'urgent' };
            case 'lu_chen':
                return { type: TASK_TYPES.COLLECT_FOOD, target: calc(TASK_TYPES.COLLECT_FOOD), priority: 'high' };
            case 'li_shen':
                return { type: TASK_TYPES.DISTRIBUTE_FOOD, target: 1, priority: 'high' };
            case 'su_doctor':
            case 'qing_xuan':
                return { type: TASK_TYPES.PREPARE_MEDICAL, target: 1, priority: 'high' };
            case 'ling_yue':
                return { type: TASK_TYPES.SCOUT_RUINS, target: 1, priority: 'high' };
            case 'old_qian':
                return { type: TASK_TYPES.COORDINATE, target: 1, priority: 'normal' };
            default:
                return { type: TASK_TYPES.PREPARE_WARMTH, target: 1, priority: 'normal' };
        }
    };

    // [已拆分到 task-generator.js] _generateTasksFromWorkPlan
    // [已拆分到 task-generator.js] _calcResourceTarget
    // [已拆分到 task-generator.js] _findBestNpcForTask
    // ============ 【任务8】动态任务重分配 ============

    /** NPC死亡时重分配其未完成任务 */
    proto.reassignDeadNpcTasks = function(deadNpcId) {
        const aliveNpcs = this.game.npcs.filter(n => !n.isDead);
        if (aliveNpcs.length === 0) return;

        const deadTasks = this.dailyTasks.filter(
            t => t.assignedNpcId === deadNpcId && t.status !== 'completed'
        );
        if (deadTasks.length === 0) return;

        for (const task of deadTasks) {
            task.status = 'failed';
            const remaining = task.target - task.progress;
            if (remaining <= 0) continue;

            const bestNpc = this._findBestNpcForTask(task.type, aliveNpcs);
            if (bestNpc) {
                const newTaskId = this._addTask(task.type, Math.ceil(remaining), task.priority, bestNpc.id);
                this.npcAssignments[bestNpc.id] = newTaskId;

                if (this.game.addEvent) {
                    const nameMap = { zhao_chef: '赵铁柱', lu_chen: '陆辰', li_shen: '李婶', wang_teacher: '王策', old_qian: '老钱', su_doctor: '苏岩', ling_yue: '歆玥', qing_xuan: '清璇' };
                    this.game.addEvent(GST.t('task_event.task_reassigned', { dead: nameMap[deadNpcId] || deadNpcId, task: task.name, assignee: bestNpc.name }));
                }
                console.log(`[TaskSystem] 死者${deadNpcId}的任务${task.name}重分配给${bestNpc.name}`);
            }
        }

        delete this.npcAssignments[deadNpcId];
        delete this.npcTaskState[deadNpcId];
    };


    /** 天气变化时将户外NPC任务转为室内 */
    proto.onWeatherEmergency = function(weatherType) {
        if (weatherType !== 'blizzard') return;

        const aliveNpcs = this.game.npcs.filter(n => !n.isDead);
        for (const task of this.dailyTasks) {
            if (task.status === 'completed' || !task.isOutdoor) continue;

            const npc = aliveNpcs.find(n => n.id === task.assignedNpcId);
            if (!npc) continue;

            task.status = 'failed';
            const newTaskId = this._addTask(TASK_TYPES.PREPARE_WARMTH, 1, 'urgent', npc.id);
            this.npcAssignments[npc.id] = newTaskId;

            if (this.game.addEvent) {
                this.game.addEvent(GST.t('task_event.blizzard_cancel', { name: npc.name, task: task.name }));
            }
        }

        // 更新workPlan摘要
        if (this.game.reincarnationSystem) {
            const holder = this.game.reincarnationSystem.getWorkPlanHolder();
            if (holder && holder.workPlan) {
                holder.workPlan.workPlanSummary += '(暴风雪:户外→室内)';
            }
        }
    };

})();
