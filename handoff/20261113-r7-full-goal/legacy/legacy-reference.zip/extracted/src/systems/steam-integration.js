/**
 * 福音雪镇 - Steam SDK 前端集成模块
 * 
 * 通过 window.steamAPI（由 preload.js 注入）与 Electron 主进程通信
 * 提供成就、Rich Presence、云存档等功能
 * 挂载到 GST.Steam
 * 
 * @version 5.8.18
 */
(function() {
    'use strict';
    const GST = window.GST;

    // ============ Steam 成就定义 ============
    // TODO: 在 Steamworks 后台配置这些成就后，替换为正式的成就 API Name
    const ACHIEVEMENTS = {
        // 生存类
        FIRST_WINTER:      'FIRST_WINTER',       // 度过第一个冬天
        SURVIVE_10_DAYS:   'SURVIVE_10_DAYS',     // 存活10天
        SURVIVE_30_DAYS:   'SURVIVE_30_DAYS',     // 存活30天
        SURVIVE_100_DAYS:  'SURVIVE_100_DAYS',    // 存活100天
        // 转世类
        FIRST_REINCARNATION: 'FIRST_REINCARNATION', // 第一次转世
        REINCARNATION_5:     'REINCARNATION_5',     // 转世5次
        // 议会类
        FIRST_COUNCIL:     'FIRST_COUNCIL',       // 第一次议会讨论
        COUNCIL_EXILE:     'COUNCIL_EXILE',       // 议会投票驱逐
        // 社交类
        FIRST_DIALOGUE:    'FIRST_DIALOGUE',      // 第一次NPC对话
        ALL_NPC_TALKED:    'ALL_NPC_TALKED',      // 与所有NPC对话过
        // 特殊
        POWER_SAVE_MODE:   'POWER_SAVE_MODE',     // 开启节能模式
        ALL_DEAD:          'ALL_DEAD',            // 全员死亡
    };

    class SteamIntegration {
        constructor() {
            this.available = false;
            this.playerInfo = null;
            this._initDone = false;
        }

        /**
         * 初始化 Steam 集成
         * @returns {Promise<boolean>} 是否成功
         */
        async init() {
            if (this._initDone) return this.available;

            // 检查 steamAPI 是否可用（只在 Electron + Steam 环境下可用）
            if (typeof window.steamAPI === 'undefined') {
                console.log('[Steam] ⚠️ steamAPI 不可用（非 Electron 环境或未启用 preload）');
                this.available = false;
                this._initDone = true;
                return false;
            }

            try {
                const status = await window.steamAPI.getStatus();
                if (!status || !status.inited) {
                    console.log('[Steam] ⚠️ Steam SDK 未初始化（非 Steam 环境）');
                    this.available = false;
                    this._initDone = true;
                    return false;
                }

                this.available = true;
                this.playerInfo = await window.steamAPI.getPlayerInfo();
                console.log(`[Steam] ✅ 已连接！玩家: ${this.playerInfo?.name} (${this.playerInfo?.steamId64})`);

                // 设置初始 Rich Presence
                await this.updateRichPresence('正在加载福音雪镇...');

                this._initDone = true;
                return true;
            } catch (e) {
                console.warn('[Steam] 初始化异常:', e);
                this.available = false;
                this._initDone = true;
                return false;
            }
        }

        // ============ 成就系统 ============

        /**
         * 解锁成就
         * @param {string} achievementName - 成就 API Name
         */
        async unlockAchievement(achievementName) {
            if (!this.available) return false;
            try {
                // 先检查是否已解锁，避免重复触发
                const already = await window.steamAPI.isAchievementActivated(achievementName);
                if (already) return true;

                const result = await window.steamAPI.activateAchievement(achievementName);
                if (result) {
                    console.log(`[Steam] 🏆 成就解锁: ${achievementName}`);
                }
                return result;
            } catch (e) {
                console.warn(`[Steam] 成就解锁失败 (${achievementName}):`, e);
                return false;
            }
        }

        /**
         * 检查成就是否已解锁
         */
        async isAchievementUnlocked(achievementName) {
            if (!this.available) return false;
            try {
                return await window.steamAPI.isAchievementActivated(achievementName);
            } catch (e) { return false; }
        }

        // ============ Rich Presence ============

        /**
         * 更新 Steam 好友列表中显示的游戏状态
         * @param {string} status - 状态文本
         */
        async updateRichPresence(status) {
            if (!this.available) return;
            try {
                await window.steamAPI.setRichPresence('steam_display', '#StatusWithScore');
                await window.steamAPI.setRichPresence('status', status);
            } catch (e) { /* ignore */ }
        }

        /**
         * 根据游戏状态更新 Rich Presence
         */
        async updateGameStatus(day, alive, total, temperature) {
            if (!this.available) return;
            const status = `第${day}天 | 存活 ${alive}/${total} | ${temperature}°C`;
            await this.updateRichPresence(status);
        }

        // ============ Steam Overlay ============

        async openWebPage(url) {
            if (!this.available) return;
            try { await window.steamAPI.openOverlayToWebPage(url); } catch (e) {}
        }

        async openStore(appId) {
            if (!this.available) return;
            try { await window.steamAPI.openOverlayToStore(appId); } catch (e) {}
        }

        // ============ 云存档 ============

        /**
         * 保存数据到 Steam Cloud
         * @param {string} filename - 文件名
         * @param {object} data - 要保存的数据
         */
        async cloudSave(filename, data) {
            if (!this.available) return false;
            try {
                const content = JSON.stringify(data);
                const result = await window.steamAPI.cloudSave(filename, content);
                if (result) {
                    console.log(`[Steam] ☁️ 云存档保存成功: ${filename} (${content.length} bytes)`);
                }
                return result;
            } catch (e) {
                console.warn(`[Steam] 云存档保存失败 (${filename}):`, e);
                return false;
            }
        }

        /**
         * 从 Steam Cloud 加载数据
         * @param {string} filename - 文件名
         * @returns {object|null}
         */
        async cloudLoad(filename) {
            if (!this.available) return null;
            try {
                const content = await window.steamAPI.cloudLoad(filename);
                if (content) {
                    console.log(`[Steam] ☁️ 云存档加载成功: ${filename}`);
                    return JSON.parse(content);
                }
                return null;
            } catch (e) {
                console.warn(`[Steam] 云存档加载失败 (${filename}):`, e);
                return null;
            }
        }

        /**
         * 列出所有云存档文件
         */
        async cloudList() {
            if (!this.available) return [];
            try {
                return await window.steamAPI.cloudList();
            } catch (e) { return []; }
        }
    }

    // 挂载到 GST
    GST.Steam = new SteamIntegration();
    GST.STEAM_ACHIEVEMENTS = ACHIEVEMENTS;

})();