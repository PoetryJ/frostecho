/**
 * 福音镇 - 死亡连锁反应与悲伤效果
 * 从 death-system.js 拆分，遵循SRP原则
 * 挂载到 GST.DeathSystem.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.DeathSystem.prototype;

    // 从原文件导入常量
    const ENDINGS = GST._death_system_ENDINGS;


    // ============ 死亡连锁反应 ============

    /** 死亡连锁反应：对所有存活NPC施加San值打击 */
    proto._triggerDeathChainReaction = function(deadNpc, cause) {
        const aliveNPCs = this.game.npcs.filter(n => !n.isDead);
        if (aliveNPCs.length === 0) return;

        // 【恐慌叠加】根据已死亡人数计算基础San打击叠加系数
        // 【修复】加入时间冷却：1小时(3600s)内多人死亡时后续惩罚递减，避免连锁崩溃
        const deathCount = this.deathRecords.length;
        const recentDeaths = this.deathRecords.filter(r => {
            // 使用dayNum×86400+gameTimeSeconds计算绝对游戏时间
            const currentAbsTime = (this.game.dayCount || 1) * 86400 + (this.game.gameTimeSeconds || 0);
            const recordAbsTime = (r.dayNum || 1) * 86400 + (r.gameTime || 0);
            const elapsed = currentAbsTime - recordAbsTime;
            return elapsed >= 0 && elapsed < 3600; // 1游戏小时内的死亡
        }).length;
        // 短时间内连续死亡时，后续惩罚递减（第2人×0.7，第3人×0.5，第4人+×0.3）
        const recentDampen = recentDeaths <= 1 ? 1.0 : recentDeaths === 2 ? 0.7 : recentDeaths === 3 ? 0.5 : 0.3;
        const baseNonClosePenalty = Math.max(-20, Math.round((-10 - (deathCount - 1) * 2) * recentDampen)); // 降低叠加速率，上限-20
        const baseClosePenalty = Math.max(-30, Math.round((-20 - (deathCount - 1) * 2) * recentDampen));    // 亲密者叠加，上限-30

        // 【角色针对性】根据死者角色生成针对性事件文本
        let roleSpecificText = '';
        const deadId = deadNpc.id;
        if (deadId === 'su_yan') {
            roleSpecificText = GST.t('death.role_su_yan');
        } else if (deadId === 'ling_yue') {
            roleSpecificText = GST.t('death.role_ling_yue');
        } else if (deadId === 'wang_ce') {
            roleSpecificText = GST.t('death.role_wang_ce');
        } else if (deadId === 'lu_chen') {
            roleSpecificText = GST.t('death.role_lu_chen');
        } else if (deadId === 'li_shen') {
            roleSpecificText = GST.t('death.role_li_shen');
        } else if (deadId === 'old_qian') {
            roleSpecificText = GST.t('death.role_old_qian');
        } else if (deadId === 'qing_xuan') {
            roleSpecificText = GST.t('death.role_qing_xuan');
        } else if (deadId === 'fang_yu') {
            roleSpecificText = GST.t('death.role_fang_yu');
        }

        // 检查是否所有San恢复角色都已死亡
        const suYanDead = this.deathRecords.some(r => r.npcId === 'su_yan');
        const lingYueDead = this.deathRecords.some(r => r.npcId === 'ling_yue');
        if (suYanDead && lingYueDead) {
            roleSpecificText += GST.t('death.all_san_healers_dead');
        }

        if (roleSpecificText && this.game.addEvent) {
            this.game.addEvent(roleSpecificText);
        }

        for (const npc of aliveNPCs) {
            // 判断亲密程度
            const affinity = npc.getAffinity ? npc.getAffinity(deadNpc.id) : 50;
            const isClose = affinity >= 70; // 好感度≥70视为亲密

            // 特殊家庭关系判定
            const isFamilyRelation = this._isFamilyRelation(npc.id, deadNpc.id);

            // 【恐慌叠加】使用叠加后的惩罚值
            let sanPenalty = baseNonClosePenalty;

            if (isFamilyRelation || isClose) {
                // 亲密者/家人: 使用亲密叠加惩罚
                sanPenalty = baseClosePenalty;

                // 进入悲痛状态（效率×0.3，持续2小时=7200游戏秒）
                this._griefEffects.push({
                    npcId: npc.id,
                    deadNpcId: deadNpc.id,
                    deadNpcName: deadNpc.name,
                    startTime: 0,
                    duration: 7200, // 2小时
                    elapsed: 0,
                    efficiencyMult: 0.3,
                });

                npc.mood = GST.t('mood.grieving');
                npc.stateDesc = `因${deadNpc.name}的死亡陷入悲痛`; // translateStateDesc handles i18n
                // 【个性化悲痛文本】根据关系生成
                if (isFamilyRelation) {
                    npc.expression = GST.t('death.grief_family', { name: deadNpc.displayName || deadNpc.name });
                } else {
                    npc.expression = GST.t('death.grief_close', { name: deadNpc.displayName || deadNpc.name });
                }
                npc.expressionTimer = 15;

                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('death.grief_deep', { name: npc.name, dead: deadNpc.name, penalty: sanPenalty }));
                }
            } else {
                // 非亲密: 恐惧反应 + 个性化文本
                if (deathCount >= 3) {
                    npc.expression = GST.t('death.grief_despair');
                } else if (deathCount >= 2) {
                    npc.expression = GST.t('death.grief_another', { name: deadNpc.displayName || deadNpc.name });
                } else {
                    npc.expression = GST.t('death.grief_fear', { name: deadNpc.displayName || deadNpc.name });
                }
                npc.expressionTimer = 10;
            }

            // 施加San值打击
            npc.sanity = Math.max(0, npc.sanity + sanPenalty);

            // 好感度高的NPC额外健康影响（悲痛伤身）
            if (isClose || isFamilyRelation) {
                npc.health = Math.max(0, npc.health - 5);
            }
        }

        // 全体恐惧事件（包含恐慌叠加信息）
        const panicLevel = deathCount >= 3 ? '极度恐慌' : (deathCount >= 2 ? '恐慌蔓延' : '悲痛和恐惧');
        this._addTimelineEvent('crisis', `全镇因${deadNpc.name}的死亡陷入${panicLevel}（已${deathCount}人死亡）`);
    };


    /** 判断是否为家庭关系 */
    proto._isFamilyRelation = function(npcId1, npcId2) {
        // 家庭关系对：
        // 李婶 ↔ 陆辰 (母子)
        // 老钱 ↔ 清璇 (爷孙)
        const familyPairs = [
            ['li_shen', 'lu_chen'],
            ['old_qian', 'qing_xuan'],
        ];
        return familyPairs.some(pair =>
            (pair[0] === npcId1 && pair[1] === npcId2) ||
            (pair[0] === npcId2 && pair[1] === npcId1)
        );
    };


    // ============ 悲痛效果 ============

    /** 更新悲痛效果（降低工作效率） */
    proto._updateGriefEffects = function(gameDt) {
        // 【P0修复】gameDt是实际秒×播放倍速，需乘以timeSpeed转为游戏秒
        // grief.duration=7200是游戏秒（2游戏小时），所以elapsed也必须用游戏秒累计
        const _griefGameSec = gameDt * (this.game.timeSpeed || 60);
        for (let i = this._griefEffects.length - 1; i >= 0; i--) {
            const grief = this._griefEffects[i];
            grief.elapsed += _griefGameSec;

            if (grief.elapsed >= grief.duration) {
                // 悲痛结束
                const npc = this.game.npcs.find(n => n.id === grief.npcId);
                if (npc && !npc.isDead) {
                    npc.expression = GST.t('death.grief_recover_expression', { name: grief.deadNpcName });
                    npc.expressionTimer = 8;
                    if (npc.mood === GST.t('mood.grieving')) {
                        npc.mood = GST.t('mood.down');
                    }
                    if (this.game.addEvent) {
                        this.game.addEvent(GST.t('death.grief_recover', { name: npc.name }));
                    }
                }
                this._griefEffects.splice(i, 1);
            } else {
                // 悲痛期间持续轻微San值下降
                const npc = this.game.npcs.find(n => n.id === grief.npcId);
                if (npc && !npc.isDead) {
                    npc.sanity = Math.max(0, npc.sanity - 0.02 * gameDt);
                }
            }
        }
    };


    /** 检查NPC是否处于悲痛状态（供其他系统查询） */
    proto.isNpcGrieving = function(npcId) {
        return this._griefEffects.some(g => g.npcId === npcId);
    };


    /** 获取NPC悲痛效率倍率 */
    proto.getGriefEfficiency = function(npcId) {
        const grief = this._griefEffects.find(g => g.npcId === npcId);
        return grief ? grief.efficiencyMult : 1.0;
    };


    // ============ 【智能分工系统】workPlan转移 ============

    /** 当workPlan持有者死亡时，将workPlan转移给下一个继任者 */
    proto._handleWorkPlanTransfer = function(deadNpc) {
        if (!deadNpc.workPlan) return; // 死者不是workPlan持有者

        const rs = this.game.reincarnationSystem;
        if (!rs) return;

        // 找到下一个继任者
        const succession = ['old_qian', 'wang_teacher', 'li_shen', 'ling_yue'];
        let newHolder = null;
        for (const id of succession) {
            if (id === deadNpc.id) continue; // 跳过死者自己
            const npc = this.game.npcs.find(n => n.id === id && !n.isDead);
            if (npc) {
                newHolder = npc;
                break;
            }
        }

        // 如果所有继任者都死了，找任意存活NPC
        if (!newHolder) {
            newHolder = this.game.npcs.find(n => !n.isDead && n.id !== deadNpc.id);
        }

        if (newHolder) {
            newHolder.workPlan = deadNpc.workPlan;
            deadNpc.workPlan = null;

            if (this.game.addEvent) {
                this.game.addEvent(GST.t('death.work_plan_transfer', { dead: deadNpc.name, holder: newHolder.name }));
            }
            console.log(`[WorkPlan] ${deadNpc.name}死亡，workPlan转移给${newHolder.name}`);
        }
    };

    // [已拆分到 death-ending.js] _checkExtinction
    // [已拆分到 death-ending.js] _checkEndingCondition
    // [已拆分到 death-ending.js] _triggerEnding
    // [已拆分到 death-ending.js] _renderEndingScreen
    // [已拆分到 death-ending.js] renderGraves
    // ============ 时间线管理 ============

    /** 添加关键事件到时间线 */
    proto._addTimelineEvent = function(type, text) {
        this.timeline.push({
            time: this.game.getTimeStr(),
            dayNum: this.game.dayCount,
            text: text,
            type: type,
        });

        // 最多保留50条
        if (this.timeline.length > 50) {
            this.timeline.shift();
        }
    };


    /** 外部调用：添加里程碑事件 */
    proto.addMilestone = function(text) {
        this._addTimelineEvent('milestone', text);
    };


    /** 外部调用：添加危机事件 */
    proto.addCrisis = function(text) {
        this._addTimelineEvent('crisis', text);
    };


    /** 外部调用：添加冲突事件 */
    proto.addConflict = function(text) {
        this._addTimelineEvent('conflict', text);
    };


    /** 获取死亡摘要（给AI prompt用，控制在100字以内） */
    proto.getDeathSummaryForPrompt = function() {
        if (this.deathRecords.length === 0) return '';

        let summary = `已有${this.deathRecords.length}人死亡: `;
        summary += this.deathRecords.map(r => `${r.npcName}(${r.cause})`).join('、');

        // 标注不可替代能力的丧失
        const deadIds = this.deathRecords.map(r => r.npcId);
        const suyanDead = deadIds.includes('su_yan');
        const lingyueDead = deadIds.includes('ling_yue');

        if (suyanDead && lingyueDead) {
            summary += '。⚠️ 已无人能恢复精神状态';
        } else if (suyanDead) {
            summary += '。⚠️ 医生已死，心理治疗能力丧失，仅歆玥可弹吉他安抚';
        } else if (lingyueDead) {
            summary += '。⚠️ 唯一音乐安抚者已死，仅苏岩可心理治疗';
        }

        // 控制长度不超过100字
        if (summary.length > 100) {
            summary = summary.substring(0, 97) + '...';
        }
        return summary;
    };


    /** 获取当前结局预估（不触发结局，仅预估） */
    proto.getEndingForecast = function() {
        const alive = this.getAliveCount();
        if (alive >= 8) return ENDINGS.PERFECT;
        if (alive >= 5) return ENDINGS.NORMAL;
        if (alive >= 2) return ENDINGS.BLEAK;
        return ENDINGS.EXTINCTION;
    };

})();
