/**
 * 福音镇 - DeathSystem
 * 挂载到 GST.DeathSystem
 */
(function() {
    'use strict';
    const GST = window.GST;

/**
 * 死亡系统与结局判定 — DeathSystem
 * 统一管理NPC死亡判定、死亡连锁反应、结局判定与结局界面
 * 依赖: game.js, npc.js, weather-system.js, resource-system.js
 */

// ============ 结局配置 ============
const ENDINGS = {
    PERFECT: {
        id: 'perfect',
        titleKey: 'ending.perfect_title',
        get title() { return GST.t(this.titleKey); },
        minSurvivors: 8,
        descKey: 'ending.perfect_desc',
        get desc() { return GST.t(this.descKey); },
        color: '#ffd700',
    },
    NORMAL: {
        id: 'normal',
        titleKey: 'ending.normal_title',
        get title() { return GST.t(this.titleKey); },
        minSurvivors: 5,
        descKey: 'ending.normal_desc',
        get desc() { return GST.t(this.descKey); },
        color: '#87ceeb',
    },
    BLEAK: {
        id: 'bleak',
        titleKey: 'ending.bleak_title',
        get title() { return GST.t(this.titleKey); },
        minSurvivors: 2,
        descKey: 'ending.bleak_desc',
        get desc() { return GST.t(this.descKey); },
        color: '#ff6b6b',
    },
    EXTINCTION: {
        id: 'extinction',
        titleKey: 'ending.extinction_title',
        get title() { return GST.t(this.titleKey); },
        minSurvivors: 0,
        descKey: 'ending.extinction_desc',
        get desc() { return GST.t(this.descKey); },
        color: '#8b9dc3',
    },
};

// ============ 死亡原因配置 ============
const DEATH_CAUSES = {
    FROZEN: { id: '冻死', icon: '🧊', descKey: 'death_cause.frozen' },
    STARVED: { id: '饿死', icon: '💀', descKey: 'death_cause.starved' },
    STAMINA_EXHAUSTION: { id: '体力衰竭', icon: '💤', descKey: 'death_cause.stamina_exhaustion' },
    MENTAL_BREAKDOWN: { id: '精神崩溃致死', icon: '🌀', descKey: 'death_cause.mental_breakdown' },
    VIOLENCE: { id: '暴力致死', icon: '💢', descKey: 'death_cause.violence' },
};

class DeathSystem {
    constructor(game) {
        this.game = game;

        // 死亡记录列表
        this.deathRecords = [];
        // { npcId, npcName, cause, causeIcon, time, dayNum, bodyTemp, location }

        // 关键事件时间线
        this.timeline = [];
        // { time, dayNum, text, type: 'death'|'crisis'|'milestone'|'conflict' }

        // 结局状态
        this.endingTriggered = false;
        this.currentEnding = null;

        // 死亡检测tick
        this._deathCheckTimer = 0;
        this._deathCheckInterval = 1.0; // 每1秒检查一次

        // 悲痛效果追踪
        this._griefEffects = [];
        // { npcId, deadNpcId, startTime, duration, efficiencyMult }

        console.log('[DeathSystem] 初始化完成');
    }

    // ============ 主更新循环 ============

    /** 在game.update()中调用 */
    update(gameDt) {
        if (this.endingTriggered) return;

        this._deathCheckTimer += gameDt;
        if (this._deathCheckTimer >= this._deathCheckInterval) {
            this._deathCheckTimer = 0;
            this._checkDeaths();
        }

        // 更新悲痛效果
        this._updateGriefEffects(gameDt);

        // 检查结局条件（第4天日落18:00）
        this._checkEndingCondition();
    }

    // ============ 死亡判定 ============

    /** 每秒检测所有NPC的死亡条件 */
    _checkDeaths() {
        // 【P0修复】计算每次_checkDeaths调用间隔对应的游戏秒
        // _deathCheckInterval是gameDt单位，乘以timeSpeed得到游戏秒
        const _checkGameSec = this._deathCheckInterval * (this.game.timeSpeed || 60);

        for (const npc of this.game.npcs) {
            if (npc.isDead) continue;

            let deathCause = null;

            // 1. 健康值归零 → 死亡
            if (npc.health <= 0) {
                // 判定死因（优先使用NPC自身标记的死因）
                if (npc._deathCause) {
                    deathCause = npc._deathCause;
                } else if (npc.bodyTemp < 30) {
                    deathCause = '冻死';
                } else if (npc.hunger !== undefined && npc.hunger <= 0 && npc.stamina <= 0) {
                    deathCause = '饥饿与体力衰竭';
                } else if (npc.hunger !== undefined && npc.hunger <= 0) {
                    deathCause = '饿死';
                } else if (npc.stamina <= 0) {
                    deathCause = '体力衰竭';
                } else if (npc.isSick) {
                    deathCause = '疾病致死';
                } else if (npc.sanity <= 0 || npc.isCrazy) {
                    deathCause = '精神崩溃致死';
                } else {
                    deathCause = '冻死'; // 默认死因
                }

                this._processNpcDeath(npc, deathCause);
            }

            // 2. 体温致命判定（健康还没归零但体温已经极低）
            if (npc.bodyTemp <= 25 && !npc.isDead) {
                npc.health = 0;
                this._processNpcDeath(npc, '冻死');
            }

            // 3. San值归零 + 健康低于10 + 持续一段时间 → 精神崩溃致死
            // 【修复】物资充足时不应这么快精神崩溃致死，需要持续精神归零才致命
            if (npc.sanity <= 0 && !npc.isDead) {
                // 累计San=0持续时间（游戏秒）
                if (!npc._zeroSanityDuration) npc._zeroSanityDuration = 0;
                npc._zeroSanityDuration += _checkGameSec;
                // 持续3600游戏秒(1游戏小时)且健康<15才致死
                if (npc._zeroSanityDuration > 3600 && npc.health <= 15) {
                    npc.health = 0;
                    this._processNpcDeath(npc, '精神崩溃致死');
                }
            } else if (npc.sanity > 0) {
                npc._zeroSanityDuration = 0;
            }

            // 4. 【新增】体力衰竭致死：体力=0持续超过2小时(7200秒) + 健康<30
            if (!npc.isDead && npc._zeroStaminaDuration > 7200 && npc.health < 30) {
                npc.health = 0;
                this._processNpcDeath(npc, '体力衰竭');
            }

            // 5. 【v2.0】饥饿加速死亡：饱腹=0持续超过4小时(14400秒)，健康以高速率下降
            if (!npc.isDead && npc._zeroHungerDuration > 14400) {
                // 持续饥饿加速健康下降：0.15/秒 → 约11分钟从100降到0
                npc.health = Math.max(0, npc.health - 0.15 * this._deathCheckInterval);
                if (npc.health <= 0) {
                    npc._deathCause = '饿死';
                    // 【调试日志】食物充足但饿死的异常情况
                    const foodRemaining = this.game.resourceSystem ? this.game.resourceSystem.food : 0;
                    if (foodRemaining > 0) {
                        console.warn(`[DeathSystem] ⚠️ 异常：${npc.name} 饿死时食物储备仍有 ${Math.round(foodRemaining)}！hunger=${npc.hunger}, zeroHungerDuration=${npc._zeroHungerDuration}s`);
                    }
                    this._processNpcDeath(npc, '饿死');
                }
            }

            // 6. 【v2.0】严重失温加速死亡：体温<33°C持续超过30分钟(1800秒)，健康以0.2/秒速率下降
            if (!npc.isDead && npc.bodyTemp < 33 && npc._hypothermiaDuration > 1800) {
                npc.health = Math.max(0, npc.health - 0.2 * this._deathCheckInterval);
                if (npc.health <= 0) {
                    npc._deathCause = '冻死';
                    this._processNpcDeath(npc, '冻死');
                }
            }

            // 7. 【v2.0】濒死状态检测：饱腹=0 + 体力=0 + 健康<30 → 进入濒死
            if (!npc.isDead && !npc._isDying && npc.hunger <= 0 && npc.stamina <= 0 && npc.health < 30) {
                npc._isDying = true;
                npc._dyingTimer = 0;
                npc.state = 'IDLE';
                npc.currentPath = [];
                npc.isMoving = false;
                npc.expression = GST.t('death.dying_help');
                npc.expressionTimer = 15;
                npc.mood = GST.t('mood.dying');                npc.stateDesc = '⚠️ 濒死';
                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('death.dying_state', { name: npc.name }));
                }
                this._addTimelineEvent('crisis', `🚨 ${npc.name} 陷入濒死状态（饥饿+体力耗尽+健康极低）`);
                console.warn(`[DeathSystem] ${npc.name} 进入濒死状态! health:${npc.health.toFixed(1)}`);
                // AI模式日志：濒死状态
                if (this.game.aiModeLogger) {
                    const snap = GST.AIModeLogger.npcAttrSnapshot(npc);
                    this.game.aiModeLogger.log('DYING', `${npc.name} 进入濒死状态 | ${snap} | 位置:${npc.currentScene || '?'}`);
                    this.game.aiModeLogger.pushNpcEvent(npc.id, `🚨 进入濒死状态 | ${snap}`);
                }
                // 【v4.17】NPC濒死时触发紧急决策会议
                if (this.game.councilSystem) {
                    const aliveCount = this.game.npcs.filter(n => !n.isDead).length;
                    if (aliveCount >= 2) {
                        const npcName = npc.name;
                        const game = this.game;
                        setTimeout(() => {
                            const cs = game.councilSystem;
                            if (cs && !cs.isActive && !cs.isGenerating) {
                                console.log(`[DeathSystem] ${npcName} 濒死，触发紧急决策会议`);
                                cs._triggerReason = `🚨 ${npcName} 陷入濒死状态！必须紧急救助`;
                                cs._autoTriggered = true;
                                cs._isNpcCrisisTrigger = true; // 【v4.19】NPC危机走分诊流程
                                if (!game.paused) {
                                    game.paused = true;
                                    const btn = document.getElementById('btn-pause');
                                    if (btn) btn.textContent = '▶️';
                                }
                                game.addEvent(GST.t('death.dying_council', { name: npcName }));
                                cs.openVotingCouncil();
                            }
                        }, 3000);
                    }
                }
            }

            // 8. 【v2.0】濒死状态持续5分钟(300游戏秒)无救助则死亡
            if (!npc.isDead && npc._isDying) {
                npc._dyingTimer = (npc._dyingTimer || 0) + _checkGameSec;
                // 濒死期间持续扣血
                npc.health = Math.max(0, npc.health - 0.05 * this._deathCheckInterval);
                if (npc._dyingTimer >= 300 || npc.health <= 0) {
                    const cause = npc.hunger <= 0 ? '饿死' : (npc.bodyTemp < 33 ? '冻死' : '体力衰竭');
                    npc._deathCause = cause;
                    this._processNpcDeath(npc, cause);
                }
            }

            // 9. 精神崩溃加速死亡：San=0且发疯持续超过1小时(3600秒)，健康以2倍速率下降
            if (!npc.isDead && npc._zeroCrazyDuration > 3600) {
                npc.health = Math.max(0, npc.health - 0.06 * this._deathCheckInterval);
                if (npc.health <= 0) {
                    npc._deathCause = '精神崩溃致死';
                    this._processNpcDeath(npc, '精神崩溃致死');
                }
            }
        }
    }

    /** 处理NPC死亡 */
    _processNpcDeath(npc, cause) {
        if (npc.isDead) return; // 防重复

        // 标记死亡
        npc.isDead = true;
        npc._deathCause = cause;
        npc._deathTime = this.game.getTimeStr();

        // 冻结死亡坐标（坟墓渲染使用，确保坟墓位置固定不动）
        npc._deathX = npc.x;
        npc._deathY = npc.y;
        npc._deathScene = npc.currentScene;
        npc.isMoving = false;

        // 停止所有行动
        npc.state = 'IDLE';
        npc.currentPath = [];
        npc.pathIndex = 0;
        npc._pendingAction = null;
        npc._currentAction = null;
        npc._actionOverride = false;

        // 清除对话气泡和AI状态，防止死亡后继续说话/思考
        npc.expression = '';
        npc.expressionTimer = 0;
        npc.aiCooldown = Infinity;  // 永久禁止AI思考
        npc._actionDecisionCooldown = Infinity; // 永久禁止行动决策

        // 记录死亡信息
        const causeConfig = Object.values(DEATH_CAUSES).find(c => c.id === cause) || { icon: '💀', desc: cause };
        const record = {
            npcId: npc.id,
            npcName: npc.name,
            cause: cause,
            causeIcon: causeConfig.icon,
            causeDesc: causeConfig.desc,
            time: this.game.getTimeStr(),
            dayNum: this.game.dayCount,
            gameTime: this.game.gameTimeSeconds || 0, // 用于计算死亡间隔冷却
            bodyTemp: npc.bodyTemp ? npc.bodyTemp.toFixed(1) : 'N/A',
            location: npc.currentScene || 'unknown',
            sanity: Math.round(npc.sanity || 0),
            health: 0,
            hunger: Math.round(npc.hunger || 0),
        };

        // 【异常标注】食物充足但饿死
        const isHungerDeath = (cause === '饿死' || cause === '饥饿与体力衰竭');
        if (isHungerDeath && this.game.resourceSystem && this.game.resourceSystem.food > 0) {
            record.anomaly = `⚠️ 食物充足但未进食（剩余食物:${Math.round(this.game.resourceSystem.food)}）`;
            console.warn(`[DeathSystem] ⚠️ 异常死亡：${npc.name} ${cause}，但食物储备仍有 ${Math.round(this.game.resourceSystem.food)}`);
            if (this.game.addEvent) {
                this.game.addEvent(GST.t('death.anomaly_hunger', { name: npc.name, food: Math.round(this.game.resourceSystem.food) }));
            }
            // AI模式日志：异常死亡标注
            if (this.game.aiModeLogger) {
                this.game.aiModeLogger.log('ANOMALY', `${npc.name} ${cause}但食物储备:${Math.round(this.game.resourceSystem.food)} | 最近行为:${npc.stateDesc || '?'} | 状态:${npc.state || '?'}`);
            }
        }

        this.deathRecords.push(record);

        // 添加到时间线
        this._addTimelineEvent('death', `${causeConfig.icon} ${npc.name} ${cause}（体温:${record.bodyTemp}°C, 位置:${record.location}）`);

        // 全屏事件通知 【v2.0增强：添加死因详情和高亮标记】
        if (this.game.addEvent) {
            this.game.addEvent(GST.t('death.npc_died', { name: npc.name, cause, icon: causeConfig.icon, temp: record.bodyTemp, location: record.location }));
        }

        // 设置死亡视觉状态
        npc.mood = GST.t('mood.deceased');
        npc.stateDesc = `已故 — ${cause}`; // translateStateDesc handles i18n
        npc.expression = '';
        npc.expressionTimer = 0;

        console.log(`[DeathSystem] ${npc.name} 死亡！死因: ${cause}, 时间: ${record.time}, 体温: ${record.bodyTemp}°C`);

        // AI模式日志：记录死亡详情
        if (this.game.aiModeLogger) {
            const snap = GST.AIModeLogger.npcAttrSnapshot(npc);
            const durInfo = `饥饿持续:${(npc._zeroHungerDuration || 0).toFixed(0)}s 体力枯竭持续:${(npc._zeroStaminaDuration || 0).toFixed(0)}s 失温持续:${(npc._hypothermiaDuration || 0).toFixed(0)}s 精神崩溃持续:${(npc._zeroCrazyDuration || 0).toFixed(0)}s`;
            this.game.aiModeLogger.log('DEATH', `${npc.name}(ID:${npc.id}) 年龄:${npc.age || '?'} 职业:${npc.occupation || '?'} | 死因:${cause} | ${snap} | 位置:${npc.currentScene || '?'} | ${durInfo}`);
            // 【v2.0新增】输出死亡回溯链 + 惩罚累计
            this.game.aiModeLogger.flushDeathRetrospective(npc.id, npc.name);
        }

        // 触发死亡连锁反应
        this._triggerDeathChainReaction(npc, cause);

        // 【智能分工系统】workPlan持有者死亡时转移 + 任务重分配
        this._handleWorkPlanTransfer(npc);
        if (this.game.taskSystem && this.game.taskSystem.reassignDeadNpcTasks) {
            this.game.taskSystem.reassignDeadNpcTasks(npc.id);
        }

        // 【紧急决策】有人死亡时触发紧急 council 会议，让存活者重新分工
        if (this.game.councilSystem) {
            const aliveCount = this.game.npcs.filter(n => !n.isDead).length;
            if (aliveCount >= 2) {
                // 延迟5秒触发，给死亡动画和事件通知留时间
                setTimeout(() => {
                    const cs = this.game.councilSystem;
                    if (cs && !cs.isActive && !cs.isGenerating) {
                        console.log(`[DeathSystem] ${npc.name} 死亡，触发紧急决策会议`);
                        cs._triggerReason = `${npc.name} 不幸遇难，必须紧急重新分工`;
                        cs._isNpcCrisisTrigger = false; // 【v4.19】死亡重新分工需全员参与，不走分诊
                        cs._isDeathTrigger = true; // 【v5.5】标记为死亡触发，prompt引导先分析原因再决策
                        cs._deadNpcName = npc.name; // 记录死亡NPC名字
                        cs.openVotingCouncil();
                    }
                }, 5000);
            }
        }

        // 【事件驱动镜头】通知镜头系统：NPC死亡
        if (this.game.onNPCEvent) {
            this.game.onNPCEvent(npc, 'death');
        }

        // 【镜头切走】若当前跟随目标就是死亡NPC，3秒后自动切到其他存活NPC
        if (this.game.followTarget === npc && this.game.autoFollow) {
            const aliveCount = this.game.npcs.filter(n => !n.isDead).length;
            if (aliveCount > 0) {
                this.game._deathViewTimer = 3; // 3秒后由 update() 中的计时器触发 _autoSwitchFollow()
            }
            // 全灭时不触发切换，保持镜头在最后死亡位置
        }

        // 检查是否全灭
        this._checkExtinction();
    }
    // [已拆分到 death-effects.js] _triggerDeathChainReaction
    // [已拆分到 death-effects.js] _isFamilyRelation
    // [已拆分到 death-effects.js] _updateGriefEffects
    // [已拆分到 death-effects.js] isNpcGrieving
    // [已拆分到 death-effects.js] getGriefEfficiency
    // [已拆分到 death-effects.js] _addTimelineEvent
    // [已拆分到 death-effects.js] addMilestone
    // [已拆分到 death-effects.js] addCrisis
    // [已拆分到 death-effects.js] addConflict
    // ============ 查询接口 ============

    /** 获取存活NPC数量 */
    getAliveCount() {
        return this.game.npcs.filter(n => !n.isDead).length;
    }

    /** 获取死亡NPC数量 */
    getDeadCount() {
        return this.deathRecords.length;
    }

    /** 获取死亡记录列表 */
    getDeathRecords() {
        return [...this.deathRecords];
    }
    // [已拆分到 death-effects.js] getDeathSummaryForPrompt
    /** 获取特定NPC的死亡信息 */
    getDeathRecord(npcId) {
        return this.deathRecords.find(r => r.npcId === npcId) || null;
    }
    // [已拆分到 death-effects.js] getEndingForecast
    // [已拆分到 death-effects.js] _handleWorkPlanTransfer
    // ============ 序列化 ============

    serialize() {
        // 在死亡记录中额外保存冻结坐标
        const enrichedRecords = this.deathRecords.map(r => {
            const npc = this.game.npcs.find(n => n.id === r.npcId);
            return {
                ...r,
                _deathX: npc ? npc._deathX : undefined,
                _deathY: npc ? npc._deathY : undefined,
                _deathScene: npc ? npc._deathScene : undefined,
            };
        });
        return {
            deathRecords: enrichedRecords,
            timeline: [...this.timeline],
            endingTriggered: this.endingTriggered,
            currentEnding: this.currentEnding ? this.currentEnding.id : null,
            griefEffects: this._griefEffects.map(g => ({
                npcId: g.npcId,
                deadNpcId: g.deadNpcId,
                deadNpcName: g.deadNpcName,
                elapsed: g.elapsed,
                duration: g.duration,
                efficiencyMult: g.efficiencyMult,
            })),
        };
    }

    deserialize(data) {
        if (!data) return;
        this.deathRecords = data.deathRecords || [];
        this.timeline = data.timeline || [];
        this.endingTriggered = data.endingTriggered || false;
        if (data.currentEnding) {
            this.currentEnding = Object.values(ENDINGS).find(e => e.id === data.currentEnding) || null;
        }
        if (data.griefEffects) {
            this._griefEffects = data.griefEffects.map(g => ({
                ...g,
                startTime: 0,
            }));
        }

        // 恢复冻结坐标到对应NPC对象
        for (const record of this.deathRecords) {
            const npc = this.game.npcs.find(n => n.id === record.npcId);
            if (npc) {
                if (record._deathX !== undefined) npc._deathX = record._deathX;
                if (record._deathY !== undefined) npc._deathY = record._deathY;
                if (record._deathScene !== undefined) npc._deathScene = record._deathScene;
            }
        }
    }
}
    // ============ 导出常量供拆分文件使用 ============
    GST._death_system_ENDINGS = ENDINGS;
    GST._death_system_DEATH_CAUSES = DEATH_CAUSES;


    GST.DeathSystem = DeathSystem;
})();
