/**
 * 福音镇 - 资源消耗与危机检测
 * 从 resource-system.js 拆分，遵循SRP原则
 * 挂载到 GST.ResourceSystem.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.ResourceSystem.prototype;

    // 从原文件导入常量
    const RESOURCE_CONSUMPTION = GST._resource_system_RESOURCE_CONSUMPTION;
    const MEAL_HOURS = GST._resource_system_MEAL_HOURS;


    /** 每秒消耗tick */
    proto._tickConsumption = function(dt) {
        const hourFraction = dt / 3600; // 转为小时比例

        // 【v2.0】获取天气消耗乘数
        const weatherMult = this._getWeatherConsumptionMult();

        // 【v4.1】存活人数缩减系数：人少了，需要供暖/用电的区域缩小
        // 公式：max(0.3, aliveCount / totalCount)，最低保底30%（空房间仍有基础维护消耗）
        const totalNpcCount = this.game.npcs ? this.game.npcs.length : 8;
        const aliveNpcCount = this.game.npcs ? this.game.npcs.filter(n => !n.isDead).length : 8;
        const populationRatio = Math.max(0.3, aliveNpcCount / totalNpcCount);

        // 1) 集中供暖消耗木柴，应用天气乘数
        const heatingSystem = this.game.furnaceSystem;
        if (heatingSystem) {
            const baseWood = RESOURCE_CONSUMPTION.heatingWoodPerHour * hourFraction;
            // 【难度系统】木柴消耗乘以难度倍率
            const diffConsWood = this.game.getDifficultyMult ? this.game.getDifficultyMult('consumptionMult') : null;
            const diffWoodMult = (diffConsWood && diffConsWood.wood) ? diffConsWood.wood : 1.0;
            let woodNeeded = baseWood * weatherMult.wood * diffWoodMult * populationRatio;

            // 【仓库管理】有NPC在执行reduce_waste效果时，木柴浪费减少10%
            if (this.game._woodWasteReduction) {
                woodNeeded *= 0.9;
                this.game._woodWasteReduction = false;
            }

            // 电力会影响供暖效率：有电更省柴，无电则更费柴
            if (this.power > 0) {
                woodNeeded *= 0.8;
            } else {
                woodNeeded *= 1.3;
            }

            this.consumeResource('woodFuel', woodNeeded, '集中供暖');
            heatingSystem.onFuelDepleted();
        }

        // 2) 发电机消耗电力，应用天气乘数 + 人口缩减系数
        const basePower = RESOURCE_CONSUMPTION.powerPerHour * hourFraction;
        // 【难度系统】电力消耗乘以难度倍率
        const diffConsPower = this.game.getDifficultyMult ? this.game.getDifficultyMult('consumptionMult') : null;
        const diffPowerMult = (diffConsPower && diffConsPower.power) ? diffConsPower.power : 1.0;
        const powerNeeded = basePower * weatherMult.power * diffPowerMult * populationRatio; // 【v4.1】人少消耗降低
        this.consumeResource('power', powerNeeded, '发电机');
    };


    // ============ 【v2.0】天气消耗乘数系统 ============

    /**
    * 【v2.1重构】基于实时温度的连续消耗乘数
    * 不再按天硬编码，改为根据getEffectiveTemp()动态计算
    * 温度越低，木柴和电力消耗越高；食物消耗不受温度影响（寒冷天不需要多吃）
    * 计算公式：
    *   木柴乘数 = 1.0 + max(0, -temp) * 0.04 （0°C=1.0, -30°C=2.2, -60°C=3.4）
    *   电力乘数 = 1.0 + max(0, -temp) * 0.02 （0°C=1.0, -30°C=1.6, -60°C=2.2）
    *   食物乘数 = 1.0 （不受温度影响）
    */
    proto._getWeatherConsumptionMult = function() {
        // 【v2.1】每次都基于实时温度重新计算，不再按天缓存
        const ws = this.game.weatherSystem;
        let temp = 0;
        if (ws && ws.getEffectiveTemp) {
            temp = ws.getEffectiveTemp();
        }

        // 温度越低，消耗越高（连续函数，不再阶梯式）
        const coldFactor = Math.max(0, -temp); // 0°C以上为0
        const woodMult = Math.max(0.5, 1.0 + coldFactor * 0.05); // 【v4.37加强】-30°C→2.5, -60°C→4.0, 0°C以上最低0.5
        const powerMult = Math.max(0.7, 1.0 + coldFactor * 0.03); // 【v4.37加强】-30°C→1.9, -60°C→2.8
        const foodMult = Math.max(1.0, 1.0 + coldFactor * 0.01);  // 【v4.37新增】寒冷天需要更多热量：-30°C→1.3, -60°C→1.6

        this._weatherConsumptionMult = { wood: woodMult, power: powerMult, food: foodMult };

        // 每天只输出一次日志（避免刷屏）
        const day = this.game.dayCount || 1;
        if (this._lastWeatherMultDay !== day) {
            this._lastWeatherMultDay = day;
            console.log(`[ResourceSystem-天气乘数] 第${day}天 实时温度${temp}°C: 木柴消耗×${woodMult.toFixed(2)}, 电力消耗×${powerMult.toFixed(2)}, 食物消耗×${foodMult.toFixed(2)}`);
        }
        return this._weatherConsumptionMult;
    };


    /**
    * 【v2.0】天气变化时刷新消耗乘数并通知玩家
    * 在weather-system.js的onDayChange()中调用
    */
    proto.onWeatherChange = function(newDay) {
        // 强制刷新缓存
        this._lastWeatherMultDay = 0;
        const mult = this._getWeatherConsumptionMult();

        // 向事件日志发送天气消耗变化提示
        if (this.game.addEvent) {
            const baseWoodPerHour = RESOURCE_CONSUMPTION.heatingWoodPerHour;
            const actualWoodPerHour = baseWoodPerHour * mult.wood;
            const basePowerPerHour = RESOURCE_CONSUMPTION.powerPerHour;
            const actualPowerPerHour = basePowerPerHour * mult.power;

            const foodMultInfo = mult.food > 1.0 ? `，食物消耗×${mult.food}` : '';
            if (mult.wood > 1.0) {
                this.game.addEvent(GST.t('resource_event.heating_cold', { wood: actualWoodPerHour.toFixed(1), woodMult: mult.wood, power: actualPowerPerHour.toFixed(1), powerMult: mult.power, foodInfo: foodMultInfo }));
            } else if (mult.wood < 1.0) {
                this.game.addEvent(GST.t('resource_event.heating_warm', { wood: actualWoodPerHour.toFixed(1), woodMult: mult.wood, power: actualPowerPerHour.toFixed(1), powerMult: mult.power, foodInfo: foodMultInfo }));
            } else {
                this.game.addEvent(GST.t('resource_event.heating_change', { wood: actualWoodPerHour.toFixed(1), power: actualPowerPerHour.toFixed(1), foodInfo: foodMultInfo }));
            }
        }
    };


    /** 检测用餐时间，分配食物 */
    proto._checkMealTime = function() {
        const hour = this.game.getHour();
        const day = this.game.dayCount;
        const key = `d${day}_h${hour}`;

        // 是否到了用餐时间
        if (!MEAL_HOURS.includes(hour)) return;
        if (this._mealServed[key]) return;
        this._mealServed[key] = true;

        // 计算需要的食物
        const aliveNPCs = this.game.npcs.filter(n => !n.isDead);
        let totalNeeded = aliveNPCs.length * RESOURCE_CONSUMPTION.foodPerMealPerPerson;

        // 【难度系统】食物消耗乘以难度倍率
        const diffConsFood = this.game.getDifficultyMult ? this.game.getDifficultyMult('consumptionMult') : null;
        const diffFoodMult = (diffConsFood && diffConsFood.food) ? diffConsFood.food : 1.0;
        totalNeeded *= diffFoodMult;

        // 【v4.37】天气食物消耗乘数：寒冷天需要更多热量
        const weatherMult = this._getWeatherConsumptionMult();
        totalNeeded *= weatherMult.food;

        // 【任务7】食物浪费减少：有人管理仓库/做饭时消耗量×0.8
        if (this.game._foodWasteReduction) {
            totalNeeded *= 0.8;
        }

        const mealName = hour <= 12 ? '早餐' : '晚餐';

        if (this.food >= totalNeeded) {
            // 食物充足，全员用餐
            const consumed = this.consumeResource('food', totalNeeded, mealName);
            const now = Date.now();
            for (const npc of aliveNPCs) {
                npc.hunger = Math.min(100, (npc.hunger || 50) + 30);
                // 【P1修复】定时用餐也更新_lastEatTime，避免ANOMALY检测误报"未进食"
                if (!npc._lastMealGameTime) npc._lastMealGameTime = 0;
                npc._lastMealGameTime = this.game.gameTimeSeconds + (this.game.dayCount - 1) * 86400;
                // 更新目标追踪
                if (npc._goalTrackers) {
                    npc._goalTrackers.mealsToday = (npc._goalTrackers.mealsToday || 0) + 1;
                }
            }
            if (this.game.addEvent) {
                this.game.addEvent(GST.t('resource_event.meal_normal', { meal: mealName, amount: Math.round(consumed), remaining: Math.round(this.food) }));
            }
            // AI模式日志：全员用餐充足
            if (this.game.aiModeLogger) {
                this.game.aiModeLogger.log('EAT', `${mealName} 全员${aliveNPCs.length}人用餐: 消耗${Math.round(consumed)}, 人均饱腹+30, 剩余食物${Math.round(this.food)}`);
            }
        } else if (this.food > 0) {
            // 【任务7】食物不足时按比例分配
            const ratio = this.food / totalNeeded;
            const consumed = this.consumeResource('food', this.food, `${mealName}(不足)`);
            const hungerRecovery = Math.round(30 * ratio);
            for (const npc of aliveNPCs) {
                npc.hunger = Math.min(100, (npc.hunger || 50) + hungerRecovery);
                // 【P1修复】食物不足时也更新进食时间
                npc._lastMealGameTime = this.game.gameTimeSeconds + (this.game.dayCount - 1) * 86400;
                if (npc._goalTrackers) {
                    npc._goalTrackers.mealsToday = (npc._goalTrackers.mealsToday || 0) + 1;
                }
            }
            if (this.game.addEvent) {
                this.game.addEvent(GST.t('resource_event.meal_shortage', { meal: mealName, recovery: hungerRecovery }));
            }
            // AI模式日志：食物不足用餐
            if (this.game.aiModeLogger) {
                this.game.aiModeLogger.log('EAT', `${mealName} 食物不足! ${aliveNPCs.length}人按比例分配: 消耗${Math.round(consumed)}, 人均饱腹+${hungerRecovery}, 食物耗尽`);
            }
        } else {
            // 完全没有食物
            // 【v5.4修复】断粮惩罚从-15降为-5，因为noFoodCrisis已经使自然衰减翻倍
            // 之前-15 + 翻倍自然衰减 = 三重打击，导致全员饱腹极速归零
            for (const npc of aliveNPCs) {
                npc.hunger = Math.max(0, (npc.hunger || 50) - 5);
            }
            if (this.game.addEvent) {
                this.game.addEvent(GST.t('resource_event.food_depleted'));
            }
            // AI模式日志：断粮
            if (this.game.aiModeLogger) {
                this.game.aiModeLogger.log('EAT', `${mealName} 断粮! ${aliveNPCs.length}人无食物可吃, 全员饱腹-5`);
            }
        }
    };


    /** 更新危机状态 */
    proto._updateCrisisFlags = function(gameDt) {
        const oldFlags = { ...this.crisisFlags };
        // 【修复】将实际秒转换为游戏秒，用于危机持续时间和惩罚计算
        const gameSeconds = gameDt * (this.game.timeSpeed || 60);

        this.crisisFlags.noFood = this.food <= 0;
        // 【修复】电力状态使用滞后阈值，避免在0附近反复震荡触发耗尽/恢复事件
        // 耗尽条件：power <= 0；恢复条件：power > 2（需要积累一定余量才算恢复）
        if (this.power <= 0) {
            this.crisisFlags.noPower = true;
        } else if (this.power > 2) {
            this.crisisFlags.noPower = false;
        }
        // noPower 在 0~2 之间保持原状态不变（hysteresis）
        // 【修复】木柴同样使用滞后阈值，避免在0附近反复震荡触发"木柴耗尽"刷屏
        // 耗尽条件：woodFuel <= 0；恢复条件：woodFuel > 2（需要积累一定余量才算恢复）
        if (this.woodFuel <= 0) {
            this.crisisFlags.noWoodFuel = true;
        } else if (this.woodFuel > 2) {
            this.crisisFlags.noWoodFuel = false;
        }
        // noWoodFuel 在 0~2 之间保持原状态不变（hysteresis）

        // 食物危机：食物为0且有NPC在饥饿
        if (this.crisisFlags.noFood) {
            // AI模式日志：食物耗尽危机
            if (!oldFlags.noFood && this.game.aiModeLogger) {
                const aliveCount = this.game.npcs.filter(n => !n.isDead).length;
                this.game.aiModeLogger.log('RESOURCE_CRISIS', `食物耗尽! 存活${aliveCount}人面临饥饿危机`);
            }
            this._hungerCrisisDuration += gameSeconds;
            this.crisisFlags.hungerCrisis = true;

            // 饥饿伤害：无食物时NPC属性持续下降
            // 【P0修复】速率单位修正：之前用 rate * gameSeconds（游戏秒），导致惩罚是设计值的60倍
            // 修正为 rate * gameDt（与npc-attributes中的其他衰减速率单位一致）
            // 设计意图：食物耗尽后约2-3游戏小时体力归零，4-5游戏小时健康归零
            if (this._hungerCrisisDuration > 0) {
                for (const npc of this.game.npcs) {
                    if (npc.isDead) continue;
                    // 饥饿衰减（/gameDt单位，与npc-attributes一致）：
                    // 体力 -0.12/gameDt ≈ -7.2/游戏小时，约14游戏小时从100→0
                    // 健康 -0.06/gameDt ≈ -3.6/游戏小时，约28游戏小时从100→0
                    // San  -0.06/gameDt ≈ -3.6/游戏小时，约28游戏小时从100→0
                    // 【v5.4修复】去掉额外hunger扣减，因为npc-goals._updateHunger中noFoodCrisis已经翻倍衰减了
                    // 之前双重扣减导致全员饱腹极速归零
                    npc.stamina = Math.max(0, npc.stamina - 0.12 * gameDt);
                    npc.health = Math.max(0, npc.health - 0.06 * gameDt);
                    npc.sanity = Math.max(0, npc.sanity - 0.06 * gameDt);
                }
            }

            // 持续无食物超过6游戏小时（6*3600=21600游戏秒）→ NPC饿死
            if (this._hungerCrisisDuration >= 21600) {
                for (const npc of this.game.npcs) {
                    if (npc.isDead) continue;
                    if (npc.hunger <= 0 && npc.health <= 10) {
                        npc.health = 0;
                        // 标记死因（由死亡系统处理具体逻辑）
                        npc._deathCause = '饿死';
                        console.log(`[ResourceSystem] ${npc.name} 因长期饥饿而死亡`);
                    }
                }
            }
        } else {
            this._hungerCrisisDuration = 0;
            this.crisisFlags.hungerCrisis = false;
        }

        // 【v2.1】电力耗尽 → 暖炉耗柴+30%、医疗效率减半、夜间San下降×2
        // 【修复】加冷却时间（60秒真实时间），避免短时间内重复刷屏
        const now = Date.now();
        if (this.crisisFlags.noPower && !oldFlags.noPower) {
            if (!this._lastPowerOutTime || now - this._lastPowerOutTime > 60000) {
                this._lastPowerOutTime = now;
                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('resource_event.power_depleted'));
                }
                if (this.game.aiModeLogger) {
                    this.game.aiModeLogger.log('RESOURCE_CRISIS', `电力耗尽! 供暖耗柴+30%,医疗效率×0.5,夜间San×2`);
                }
            }
        }
        // 电力恢复通知
        if (!this.crisisFlags.noPower && oldFlags.noPower) {
            if (!this._lastPowerRestoreTime || now - this._lastPowerRestoreTime > 60000) {
                this._lastPowerRestoreTime = now;
                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('resource_event.power_restored'));
                }
            }
        }
        // 【v2.1】断电时夜间San加速下降×2（黑暗恐惧）
        if (this.crisisFlags.noPower) {
            const hour = this.game.getHour ? this.game.getHour() : 12;
            const isNight = hour < 6 || hour >= 16;
            if (isNight) {
                for (const npc of this.game.npcs) {
                    if (npc.isDead) continue;
                    // 【P0修复】速率单位修正：之前用 rate * gameSeconds（游戏秒），导致惩罚是设计值的60倍
                    // 修正为 rate * gameDt（与npc-attributes中的其他衰减速率单位一致）
                    // 断电夜间San下降 0.10/gameDt ≈ 6/游戏小时（比正常夜间0.15/gameDt略低，因为这是额外惩罚）
                    npc.sanity = Math.max(0, npc.sanity - 0.10 * gameDt);
                }
            }
        }

        // 木柴耗尽 → 集中供暖失效
        // 【v4.37修复】加冷却时间（60秒真实时间），避免短时间内重复刷屏
        // 根因：D4断点续玩时木柴=0，每分钟刷一条RESOURCE_CRISIS日志（80+条）
        if (this.crisisFlags.noWoodFuel && !oldFlags.noWoodFuel) {
            if (!this._lastWoodOutTime || now - this._lastWoodOutTime > 60000) {
                this._lastWoodOutTime = now;
                if (this.game.addEvent) {
                    this.game.addEvent(GST.t('resource_event.wood_depleted'));
                }
                // AI模式日志：木柴耗尽危机
                if (this.game.aiModeLogger) {
                    this.game.aiModeLogger.log('RESOURCE_CRISIS', `木柴耗尽,集中供暖失效! 当前食物:${this.food.toFixed(1)} 电力:${this.power.toFixed(1)}`);
                }
            }
        }
    };


    /**
    * 【v2.1】NPC进入食堂时触发的个人进食逻辑
    * 消耗食物并恢复饱腹值（食物消耗不受天气影响）
    * @param {object} npc - NPC对象
    * @returns {boolean} 是否成功进食
    */
    proto.npcEatAtKitchen = function(npc) {
        if (!npc || npc.isDead) return false;
        // 饱腹度>70时不需要额外进食
        if ((npc.hunger || 50) >= 70) return false;
        // 5分钟内同一NPC不能重复进食（防刷）
        const now = Date.now();
        if (!this._lastEatTime) this._lastEatTime = {};
        if (this._lastEatTime[npc.id] && (now - this._lastEatTime[npc.id]) < 300000) return false;

        const needed = RESOURCE_CONSUMPTION.foodPerMealPerPerson; // 1.5
        const hungerBefore = npc.hunger || 50;
        if (this.food >= needed) {
            const consumed = this.consumeResource('food', needed, `${npc.name}在食堂进食`);
            npc.hunger = Math.min(100, (npc.hunger || 50) + 25);
            this._lastEatTime[npc.id] = now;
            if (this.game.addEvent) {
                this.game.addEvent(GST.t('resource_event.kitchen_eat', { name: npc.name, cost: Math.round(consumed), hunger: Math.round(npc.hunger), remaining: Math.round(this.food) }));
            }
            if (this.game.aiModeLogger) {
                this.game.aiModeLogger.log('EAT', `${npc.name} 进食: hunger ${Math.round(hungerBefore)}→${Math.round(npc.hunger)}, -${Math.round(consumed)}食物, 剩余${Math.round(this.food)}`);
            }
            return true;
        } else if (this.food > 0) {
            const available = this.food;
            const ratio = available / needed;
            const consumed = this.consumeResource('food', available, `${npc.name}在食堂进食(不足)`);
            npc.hunger = Math.min(100, (npc.hunger || 50) + Math.round(25 * ratio));
            this._lastEatTime[npc.id] = now;
            if (this.game.addEvent) {
                this.game.addEvent(GST.t('resource_event.kitchen_shortage', { name: npc.name, cost: Math.round(consumed), recovery: Math.round(25 * ratio) }));
            }
            if (this.game.aiModeLogger) {
                this.game.aiModeLogger.log('EAT', `${npc.name} 进食(不足): hunger ${Math.round(hungerBefore)}→${Math.round(npc.hunger)}, -${Math.round(consumed)}食物, 食物耗尽`);
            }
            return true;
        }
        // 没有食物
        if (this.game.addEvent) {
            this.game.addEvent(GST.t('resource_event.kitchen_empty', { name: npc.name }));
        }
        if (this.game.aiModeLogger) {
            this.game.aiModeLogger.log('EAT', `${npc.name} 到食堂但无食物, hunger:${Math.round(npc.hunger)}`);
        }
        return false;
    };


    // ============ 物资消耗温度倍率计算 ============

    /**
    * 获取指定天数的木柴消耗倍率（温度越低消耗越高）
    * Day1(0°C): 1.0, Day2(-30°C): 1.8, Day3(0°C): 0.5, Day4(-60°C): 3.0
    * @param {number} dayNumber - 天数(1-4)
    * @returns {number} 木柴消耗倍率
    */
    proto._getWoodConsumptionMultiplier = function(dayNumber) {
        const multipliers = { 1: 1.0, 2: 1.8, 3: 0.5, 4: 3.0 };
        return multipliers[dayNumber] || 1.0;
    };


    /**
    * 获取指定天数的电力消耗倍率
    * Day1(0°C): 1.0, Day2(-30°C): 1.5, Day3(0°C): 0.7, Day4(-60°C): 2.0
    * @param {number} dayNumber - 天数(1-4)
    * @returns {number} 电力消耗倍率
    */
    proto._getPowerConsumptionMultiplier = function(dayNumber) {
        const multipliers = { 1: 1.0, 2: 1.5, 3: 0.7, 4: 2.0 };
        return multipliers[dayNumber] || 1.0;
    };

})();
