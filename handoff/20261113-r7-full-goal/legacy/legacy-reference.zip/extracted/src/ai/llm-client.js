/**
 * 福音镇 - LLM API 客户端
 * callLLM / GST.parseLLMJSON / 模型配置
 * 挂载到 GST.LLM
 */
(function() {
    'use strict';
    const GST = window.GST;

// ============ LLM API 配置 ============
// LLM 来源: 'local'(本地llama-server) 或 'external'(外部API) 或 'llama'(内嵌llama-server)
let LLM_SOURCE = 'local';
// --- llama-server 内嵌模式（优先，自动检测）---
const LLAMA_API_URL = '/llm/v1/chat/completions';  // llama-server OpenAI 兼容接口
let LLAMA_READY = false;  // llama-server 是否就绪（启动时自动检测）
// --- 本地模式配置 ---
let API_KEY = '';  // 本地模式不需要 API Key
let API_URL = '/llm/v1/chat/completions';  // 默认走 llama-server 代理
const OLLAMA_NATIVE_URL = '/ollama/api/chat';    // 保留 Ollama 原生接口（兼容）
let USE_OLLAMA_NATIVE = false;  // 默认不使用 Ollama 原生接口
let AI_MODEL = 'qwen3:8b';  // 本地模型默认使用 Qwen3-8B（启动界面可切换）
let FAST_MODEL = 'qwen3:0.6b'; // 快速小模型，用于简单任务（行动决策、think、打招呼等）
let FAST_MODEL_ENABLED = true;    // 是否启用快速小模型（qwen3:0.6b处理简单任务，qwen3:8b处理深度对话/讨论）
let POWER_SAVE_MODE = false;      // 【v5.8.17】节能模式：所有决策全部使用0.6B小模型，不调用大模型
// --- 外部API配置（由开始界面动态设置） ---
let EXTERNAL_API_URL = '';   // 外部API地址
let EXTERNAL_API_KEY = '';   // 外部API Key
let EXTERNAL_MODEL = '';     // 外部模型名称

// 【全局API状态跟踪】
const LLM_STATUS = {
    totalCalls: 0,
    successCalls: 0,
    failedCalls: 0,
    lastError: null,
    lastErrorTime: null,
    consecutiveFails: 0,  // 连续失败次数
    lastSuccessTime: null,
    isDown: false,         // API是否疑似宕机
    // 【v4.41】双模型统计
    fastCalls: 0,          // 快速小模型调用次数
    fastSuccess: 0,        // 快速小模型成功次数
    fastFallbacks: 0,      // 快速模型回退到主模型的次数
    mainCalls: 0,          // 主模型调用次数
    mainSuccess: 0,        // 主模型成功次数
    lastModelUsed: null,   // 最近一次使用的模型名
};

// 【自动检测 llama-server】启动时检查内嵌LLM引擎是否就绪
(async function detectLlamaServer() {
    try {
        const resp = await fetch('/api/llm-status');
        if (resp.ok) {
            const data = await resp.json();
            if (data.llamaReady) {
                LLAMA_READY = true;
                LLM_SOURCE = 'llama';
                // llama-server 只加载了一个模型，不区分快慢模型
                FAST_MODEL_ENABLED = false;
                console.log(`[LLM] 🧠 检测到内嵌 llama-server (${data.backend})，已切换到高质量推理模式`);
            } else {
                console.log('[LLM] ⚠️ llama-server 未就绪，等待启动...');
            }
        }
    } catch (e) {
        console.log('[LLM] llama-server 状态检测失败，等待启动...');
    }
})();

// 定期检测 llama-server 状态（模型加载可能需要时间）
let _llamaCheckInterval = setInterval(async () => {
    if (LLAMA_READY) { clearInterval(_llamaCheckInterval); return; }
    try {
        const resp = await fetch('/api/llm-status');
        if (resp.ok) {
            const data = await resp.json();
            if (data.llamaReady) {
                LLAMA_READY = true;
                LLM_SOURCE = 'llama';
                FAST_MODEL_ENABLED = false;
                console.log(`[LLM] 🧠 llama-server 已就绪！切换到高质量推理模式`);
                clearInterval(_llamaCheckInterval);
            }
        }
    } catch (e) { /* 忽略 */ }
}, 5000); // 每5秒检测一次

// 【LLM请求串行化队列】本地推理同一时间只能处理一个请求
// 多个NPC同时想聊天时，排队依次处理，避免并发导致超时失败
let _llmQueuePromise = Promise.resolve();

async function callLLM(systemPrompt, userPrompt, maxTokens = 500) {
    // 【v5.8.17】节能模式：强制使用小模型
    if (POWER_SAVE_MODE && FAST_MODEL_ENABLED && LLM_SOURCE === 'local') {
        console.log(`[LLM] 🔋 节能模式 → callLLM 降级为 callLLMFast`);
        return await callLLMFast(systemPrompt, userPrompt, maxTokens);
    }
    // 将请求排入队列，确保串行执行
    const result = await new Promise((resolve) => {
        _llmQueuePromise = _llmQueuePromise.then(async () => {
            const r = await _callLLMInternal(systemPrompt, userPrompt, maxTokens);
            resolve(r);
        }).catch((err) => {
            console.error('[LLM Queue] 队列异常:', err);
            resolve(null);
        });
    });
    return result;
}

/**
 * 快速调用LLM（使用0.6B小模型 + 串行队列）
 * 适用于简单任务：行动决策、think心情、打招呼、简单判断等
 * 大模型(8B)用于深度对话、讨论等需要高质量输出的场景
 */
async function callLLMFast(systemPrompt, userPrompt, maxTokens = 300) {
    if (!FAST_MODEL_ENABLED || LLM_SOURCE !== 'local') {
        // 未启用快速模型或非本地模式，回退到默认模型
        LLM_STATUS.fastFallbacks++;
        console.log(`[LLM] ⚡→🔵 callLLMFast回退到主模型(${FAST_MODEL_ENABLED ? '非本地模式' : '快速模型未启用'})`);
        return await callLLM(systemPrompt, userPrompt, maxTokens);
    }
    LLM_STATUS.fastCalls++;
    // 将请求排入队列，确保串行执行
    const result = await new Promise((resolve) => {
        _llmQueuePromise = _llmQueuePromise.then(async () => {
            const r = await _callLLMInternal(systemPrompt, userPrompt, maxTokens, FAST_MODEL);
            resolve(r);
        }).catch((err) => {
            console.error('[LLM Queue Fast] 队列异常:', err);
            resolve(null);
        });
    });
    if (result) LLM_STATUS.fastSuccess++;
    return result;
}

/**
 * 直接调用LLM（绕过串行队列）
 * 供讨论系统等高优先级场景使用——游戏暂停时NPC AI不再产生新请求，
 * 但已排入队列的请求会堵塞讨论系统。用这个函数可以立即发送请求。
 */
async function callLLMDirect(systemPrompt, userPrompt, maxTokens = 500) {
    // 【v5.8.17】节能模式：强制使用小模型（绕过队列版本）
    if (POWER_SAVE_MODE && FAST_MODEL_ENABLED && LLM_SOURCE === 'local') {
        console.log(`[LLM] 🔋 节能模式 → callLLMDirect 降级为小模型`);
        return await _callLLMInternal(systemPrompt, userPrompt, maxTokens, FAST_MODEL);
    }
    return await _callLLMInternal(systemPrompt, userPrompt, maxTokens);
}

async function _callLLMInternal(systemPrompt, userPrompt, maxTokens = 500, overrideModel = null) {
    const _modelTag = overrideModel || AI_MODEL;
    const _isFast = overrideModel === FAST_MODEL;
    const _modelIcon = _isFast ? '⚡' : '🔵';
    const _startTime = Date.now();
    LLM_STATUS.lastModelUsed = _modelTag;
    if (!_isFast) LLM_STATUS.mainCalls++;

    // 【v5.9】英文模式：将整个 prompt 翻译为英文
    // 小模型在全中文上下文中会忽略英文语言指令，必须把 prompt 本身翻译为英文
    let _systemPrompt = systemPrompt;
    if (GST.i18n && GST.i18n.isEn && GST.i18n.isEn()) {
        const enLangDirective = `[LANGUAGE DIRECTIVE] You MUST respond entirely in English. All your thoughts, dialogue, expressions, mood words, concerns, goals, analysis, and any other text output must be in English. Do not use any Chinese characters in your response.\n\n`;
        _systemPrompt = enLangDirective + (GST.i18n.translatePromptToEn ? GST.i18n.translatePromptToEn(systemPrompt) : systemPrompt);
    }

    // 【v5.8.11】可变 prompt，支持 context size 超限时截断重试
    let _userPrompt = userPrompt;
    // 【v5.9】英文模式：user prompt 也需要翻译
    if (GST.i18n && GST.i18n.isEn && GST.i18n.isEn() && GST.i18n.translatePromptToEn) {
        _userPrompt = GST.i18n.translatePromptToEn(userPrompt);
    }

    // 【保护】如果连续失败超过10次，暂停60秒避免无意义请求
    if (LLM_STATUS.consecutiveFails >= 10) {
        const elapsed = Date.now() - (LLM_STATUS.lastErrorTime || 0);
        if (elapsed < 60000) {
            console.warn(`[LLM] API连续失败${LLM_STATUS.consecutiveFails}次，暂停中(剩余${Math.round((60000 - elapsed) / 1000)}秒)`);
            LLM_STATUS.isDown = true;
            return null;
        }
        // 超过60秒，重置计数器，允许重试
        console.log('[LLM] 暂停结束，重新尝试API调用...');
        LLM_STATUS.consecutiveFails = 0;
        LLM_STATUS.isDown = false;
    }

    const MAX_RETRIES = 2; // 最多重试2次（共3次调用）
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
        LLM_STATUS.totalCalls++;
        try {
            const headers = { 'Content-Type': 'application/json' };
            if (API_KEY) headers['Authorization'] = `Bearer ${API_KEY}`;

            // 外部API模式：通过服务器代理转发，附带目标API信息
            if (LLM_SOURCE === 'external') {
                headers['X-External-API-URL'] = EXTERNAL_API_URL;
                headers['X-External-API-Key'] = EXTERNAL_API_KEY;
            }

            // 根据模式选择不同的URL和请求体
            const useModel = overrideModel || AI_MODEL;
            let requestUrl, requestBody;
            if (LLM_SOURCE === 'llama' && LLAMA_READY) {
                // llama-server OpenAI 兼容接口（内嵌高质量推理）
                requestUrl = LLAMA_API_URL;
                requestBody = JSON.stringify({
                    model: 'qwen3',  // llama-server 忽略 model 字段，但需要传
                    messages: [
                        { role: 'system', content: _systemPrompt },
                        { role: 'user', content: _userPrompt }
                    ],
                    max_tokens: maxTokens,
                    temperature: 0.85,
                    // 关闭思考模式，直接输出结果
                    chat_template_kwargs: { enable_thinking: false }
                });
            } else if (USE_OLLAMA_NATIVE && LLM_SOURCE === 'local') {
                // Ollama 原生接口：支持 think:false 关闭思考模式
                requestUrl = OLLAMA_NATIVE_URL;
                requestBody = JSON.stringify({
                    model: useModel,
                    messages: [
                        { role: 'system', content: _systemPrompt },
                        { role: 'user', content: _userPrompt }
                    ],
                    think: false,
                    stream: false,
                    options: {
                        num_predict: maxTokens,
                        temperature: 0.85
                    }
                });
            } else {
                // OpenAI 兼容接口（GLM-4等云端模型）
                requestUrl = API_URL;
                requestBody = JSON.stringify({
                    model: useModel,
                    messages: [
                        { role: 'system', content: _systemPrompt },
                        { role: 'user', content: _userPrompt }
                    ],
                    max_tokens: maxTokens,
                    temperature: 0.85
                });
            }

            // 【关键修复】添加90秒超时（14B模型推理较慢，且Ollama串行处理请求需要排队等待）
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 90000);
            let resp;
            try {
                resp = await fetch(requestUrl, {
                    method: 'POST',
                    headers,
                    body: requestBody,
                    signal: controller.signal
                });
            } finally {
                clearTimeout(timeoutId);
            }

            // 检查HTTP状态码
            if (!resp.ok) {
                const errorText = await resp.text().catch(() => '无法读取响应体');
                const errMsg = `HTTP ${resp.status} ${resp.statusText}: ${errorText.substring(0, 200)}`;
                console.error(`[LLM] API HTTP错误(第${attempt + 1}次): ${errMsg}`);
                LLM_STATUS.lastError = errMsg;
                LLM_STATUS.lastErrorTime = Date.now();
                LLM_STATUS.failedCalls++;
                LLM_STATUS.consecutiveFails++;

                // 【v5.8.11】Context size exceeded → 截断 prompt 后重试
                if (resp.status === 500 && errorText.includes('Context size has been exceeded')) {
                    console.warn(`[LLM] ⚠️ 上下文超限！尝试截断 prompt 后重试(原长${_userPrompt.length}字, 第${attempt + 1}次)...`);
                    // 截断 _userPrompt 到原来的 40%（更激进），保留开头和结尾
                    const truncLen = Math.floor(_userPrompt.length * 0.4);
                    const tailLen = Math.min(200, Math.floor(_userPrompt.length * 0.1));
                    _userPrompt = _userPrompt.substring(0, truncLen) + '\n...(content truncated due to context limit)\n' + _userPrompt.substring(_userPrompt.length - tailLen);
                    // 同时截断 system prompt（如果也很长的话）
                    if (_systemPrompt.length > 2000) {
                        const sysTruncLen = Math.floor(_systemPrompt.length * 0.6);
                        _systemPrompt = _systemPrompt.substring(0, sysTruncLen) + '\n...(system prompt truncated)\n';
                    }
                    if (attempt < MAX_RETRIES) {
                        continue;
                    }
                    return null;
                }

                // 429 Too Many Requests → 等待后重试
                if (resp.status === 429 && attempt < MAX_RETRIES) {
                    const waitMs = (attempt + 1) * 2000;
                    console.warn(`[LLM] 速率限制，等待${waitMs}ms后重试...`);
                    await new Promise(r => setTimeout(r, waitMs));
                    continue;
                }
                // 其他错误也重试
                if (attempt < MAX_RETRIES) {
                    await new Promise(r => setTimeout(r, 1000));
                    continue;
                }
                return null;
            }

            const data = await resp.json();

            // 统一提取content：兼容Ollama原生格式和OpenAI格式
            let content = null;
            if (USE_OLLAMA_NATIVE && data.message) {
                // Ollama 原生格式: { message: { role, content } }
                content = data.message.content;
            } else if (data.choices && data.choices[0] && data.choices[0].message) {
                // OpenAI 兼容格式: { choices: [{ message: { content } }] }
                content = data.choices[0].message.content;
                // 【Qwen3兼容】如果content为空但reasoning有内容，记录warning
                if ((!content || !content.trim()) && data.choices[0].message.reasoning) {
                    console.warn(`[LLM] content为空但reasoning有内容(第${attempt + 1}次)，建议开启USE_OLLAMA_NATIVE模式`);
                }
            }

            if (content && content.trim()) {
                // 【Qwen3兼容】清理 <think>...</think> 思考标签，只保留实际回复
                content = content.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
                if (!content) {
                    console.warn(`[LLM] ${_modelIcon}[${_modelTag}] 清理think标签后content为空(第${attempt + 1}次)`);
                    // 继续重试
                } else {
                    const _elapsed = Date.now() - _startTime;
                    LLM_STATUS.successCalls++;
                    LLM_STATUS.consecutiveFails = 0;
                    LLM_STATUS.lastSuccessTime = Date.now();
                    LLM_STATUS.isDown = false;
                    if (!_isFast) LLM_STATUS.mainSuccess++;
                    // 【v4.41日志】记录模型名+耗时+返回长度，方便debug追踪
                    console.log(`[LLM] ${_modelIcon}[${_modelTag}] ✅ ${_elapsed}ms | ${content.length}字 | tokens≤${maxTokens}`);
                    return content;
                }
            }

            if (data.error) {
                // API返回了错误对象
                const errMsg = `API Error: ${data.error.message || data.error.code || JSON.stringify(data.error).substring(0, 200)}`;
                console.error(`[LLM] ${_modelIcon}[${_modelTag}] ${errMsg}`);
                LLM_STATUS.lastError = errMsg;
                LLM_STATUS.lastErrorTime = Date.now();
                LLM_STATUS.failedCalls++;
                LLM_STATUS.consecutiveFails++;
                if (attempt < MAX_RETRIES) {
                    await new Promise(r => setTimeout(r, 1500));
                    continue;
                }
                return null;
            } else {
                console.warn(`[LLM] API返回异常格式(第${attempt + 1}次):`, JSON.stringify(data).substring(0, 300));
            }

            LLM_STATUS.failedCalls++;
            LLM_STATUS.consecutiveFails++;
            LLM_STATUS.lastError = '返回格式异常或content为空';
            LLM_STATUS.lastErrorTime = Date.now();

            if (attempt < MAX_RETRIES) {
                await new Promise(r => setTimeout(r, 1000));
                continue;
            }
            return null;

        } catch (err) {
            LLM_STATUS.failedCalls++;
            LLM_STATUS.consecutiveFails++;
            LLM_STATUS.lastError = err.message || String(err);
            LLM_STATUS.lastErrorTime = Date.now();

            // 【v5.10】区分超时 abort 和其他异常，超时不重试（避免浪费时间）
            if (err.name === 'AbortError') {
                const _elapsed = Date.now() - _startTime;
                console.warn(`[LLM] ${_modelIcon}[${_modelTag}] ⏱️ 请求超时(${Math.round(_elapsed / 1000)}秒)，第${attempt + 1}次`);
                // 超时说明模型推理太慢或服务端卡住，继续重试意义不大
                if (attempt < MAX_RETRIES) {
                    // 超时后缩短 prompt 再试一次
                    console.warn(`[LLM] ⚠️ 超时后尝试截断 prompt 重试(原长${_userPrompt.length}字)...`);
                    const truncLen = Math.floor(_userPrompt.length * 0.5);
                    _userPrompt = _userPrompt.substring(0, truncLen) + '\n...(content truncated due to timeout)\n' + _userPrompt.substring(_userPrompt.length - 150);
                    await new Promise(r => setTimeout(r, 500));
                    continue;
                }
                return null;
            }

            console.error(`[LLM] ${_modelIcon}[${_modelTag}] 调用异常(第${attempt + 1}次):`, err);
            if (attempt < MAX_RETRIES) {
                await new Promise(r => setTimeout(r, 1000));
                continue;
            }
            return null;
        }
    }
    return null;
}

function parseLLMJSON(text) {
    if (!text) return null;
    try {
        let s = text.replace(/```json|```/g, '').trim();
        const m = s.match(/\{[\s\S]*\}/);
        if (m) s = m[0];
        return JSON.parse(s);
    } catch (e) {
        // 【14B兼容】尝试修复被token截断的不完整JSON
        try {
            let s = text.replace(/```json|```/g, '').trim();
            // 提取从第一个 { 开始的内容
            const idx = s.indexOf('{');
            if (idx >= 0) {
                s = s.substring(idx);
                // 移除末尾不完整的value（可能在字符串中间被截断）
                // 先尝试补全：去掉最后一个不完整的key-value对，然后闭合
                // 策略1: 如果最后一个完整的引号对之后有未闭合的内容，截断到最后一个完整的value
                const lastCompleteComma = s.lastIndexOf('",');
                const lastCompleteQuote = s.lastIndexOf('"');
                if (lastCompleteComma > 0) {
                    // 截断到最后一个 ", 然后闭合
                    const truncated = s.substring(0, lastCompleteComma + 1) + '}';
                    const result = JSON.parse(truncated);
                    console.log('[GST.parseLLMJSON] 修复截断JSON成功(策略1-截断到最后完整值)');
                    return result;
                }
            }
        } catch (e2) {
            // 策略2: 更激进的修复——逐步去掉末尾字符直到能解析
            try {
                let s = text.replace(/```json|```/g, '').trim();
                const idx = s.indexOf('{');
                if (idx >= 0) {
                    s = s.substring(idx);
                    // 补全所有未闭合的引号和大括号
                    let fixed = s;
                    // 统计未闭合的引号
                    const quoteCount = (fixed.match(/"/g) || []).length;
                    if (quoteCount % 2 !== 0) fixed += '"';
                    // 确保以 } 结尾
                    if (!fixed.trimEnd().endsWith('}')) fixed += '}';
                    const result = JSON.parse(fixed);
                    console.log('[GST.parseLLMJSON] 修复截断JSON成功(策略2-补全引号和括号)');
                    return result;
                }
            } catch (e3) {
                // 所有修复尝试都失败了
            }
        }
        console.warn('JSON 解析失败(含修复尝试):', e.message, text?.substring(0, 200));
        return null;
    }
}




    // 导出到 GST
    GST.callLLM = callLLM;
    GST.callLLMFast = callLLMFast;      // 快速小模型调用（简单任务用）
    GST.callLLMDirect = callLLMDirect;  // 绕过队列的直接调用（讨论系统用）
    GST.parseLLMJSON = parseLLMJSON;
    GST.LLM_STATUS = LLM_STATUS;
    GST.LLM = {
        get source() { return LLM_SOURCE; },
        set source(v) { LLM_SOURCE = v; },
        get apiKey() { return API_KEY; },
        set apiKey(v) { API_KEY = v; },
        get apiUrl() { return API_URL; },
        set apiUrl(v) { API_URL = v; },
        get model() { return AI_MODEL; },
        set model(v) { AI_MODEL = v; },
        get fastModel() { return FAST_MODEL; },
        set fastModel(v) { FAST_MODEL = v; },
        get fastModelEnabled() { return FAST_MODEL_ENABLED; },
        set fastModelEnabled(v) { FAST_MODEL_ENABLED = v; },
        get useOllamaNative() { return USE_OLLAMA_NATIVE; },
        set useOllamaNative(v) { USE_OLLAMA_NATIVE = v; },
        get externalUrl() { return EXTERNAL_API_URL; },
        set externalUrl(v) { EXTERNAL_API_URL = v; },
        get externalKey() { return EXTERNAL_API_KEY; },
        set externalKey(v) { EXTERNAL_API_KEY = v; },
        get externalModel() { return EXTERNAL_MODEL; },
        set externalModel(v) { EXTERNAL_MODEL = v; },
        get llamaReady() { return LLAMA_READY; },
        get powerSaveMode() { return POWER_SAVE_MODE; },
        set powerSaveMode(v) { POWER_SAVE_MODE = !!v; console.log(`[LLM] 🔋 节能模式: ${POWER_SAVE_MODE ? '开启' : '关闭'}`); },
        OLLAMA_NATIVE_URL: OLLAMA_NATIVE_URL,
        LLAMA_API_URL: LLAMA_API_URL,
    };
})();
