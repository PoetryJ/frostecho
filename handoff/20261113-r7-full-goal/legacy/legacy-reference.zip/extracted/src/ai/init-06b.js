/**
 * 福音雪镇 — 0.6B 精简模式初始化
 * 
 * 专门为打包版本设计，强制所有配置使用 Qwen3-0.6B 小模型：
 * - 隐藏"外部 API"选项卡，只保留本地引擎
 * - 隐藏"性能/节能"模式选择器，强制节能模式
 * - 强制开启 POWER_SAVE_MODE（所有决策都用 0.6B）
 * - llama-server 只加载 0.6B 模型文件
 * - 修改模型信息展示为"0.6B 精简模式"
 * 
 * 注意：此脚本不修改任何原有代码，仅在运行时覆盖 UI 和配置
 * 
 * 使用方式：在 index.html 的 startup.js 之后引入此脚本
 *   <script src="src/ai/init-06b.js?v=63"></script>
 */
(function() {
    'use strict';

    // ============ 版本守卫：仅当 URL 包含 ?build=06b 时才激活 ============
    // 这样原版（npm start / build:win）不受影响，只有 06b 版本才执行
    var urlParams = new URLSearchParams(window.location.search);
    var is06bBuild = urlParams.get('build') === '06b';
    if (!is06bBuild) {
        console.log('[0.6B初始化] ⏭️ 非精简版构建，跳过初始化（build != 06b）');
        return;
    }

    // ============ 第一阶段：页面加载后立即修改 UI ============
    // 不依赖 GST.LLM，纯 DOM 操作
    window.addEventListener('DOMContentLoaded', function() {
        console.log('[0.6B初始化] 🧊 启动 Qwen3-0.6B 精简模式...');

        // 1. 隐藏"外部 API"选项卡
        var tabExternal = document.getElementById('tab-external');
        if (tabExternal) {
            tabExternal.style.display = 'none';
            console.log('[0.6B初始化] ✅ 已隐藏"外部 API"选项卡');
        }

        // 隐藏外部API的内容区域
        var sourceExternal = document.getElementById('source-external');
        if (sourceExternal) {
            sourceExternal.style.display = 'none';
        }

        // 确保本地选项卡处于激活状态
        var tabLocal = document.getElementById('tab-local');
        if (tabLocal) {
            tabLocal.classList.add('active');
        }
        var sourceLocal = document.getElementById('source-local');
        if (sourceLocal) {
            sourceLocal.style.display = '';
        }

        // 2. 隐藏"性能/节能"模式选择器
        var powersaveSelector = document.getElementById('powersave-selector');
        if (powersaveSelector) {
            powersaveSelector.style.display = 'none';
            console.log('[0.6B初始化] ✅ 已隐藏"性能/节能"模式选择器');
        }

        // 3. 修改模型信息展示为"0.6B 精简模式"
        var modelHybridInfo = document.getElementById('model-hybrid-info');
        if (modelHybridInfo) {
            modelHybridInfo.innerHTML = 
                '<div class="hybrid-model-row">' +
                    '<span class="hybrid-icon">🧊</span>' +
                    '<div class="hybrid-detail">' +
                        '<div class="hybrid-model-name">Qwen3-0.6B <span class="hybrid-tag tag-fast" style="background:rgba(100,180,255,0.3);color:#8cd4ff;">精简模式</span></div>' +
                        '<div class="hybrid-model-desc">全部决策均使用 0.6B 小模型，低显存友好</div>' +
                    '</div>' +
                '</div>' +
                '<div class="hybrid-summary" style="color:rgba(100,180,255,0.7);">🧊 精简模式 · 仅需约 1GB 显存 · 适合轻量运行</div>';
            console.log('[0.6B初始化] ✅ 已更新模型信息展示');
        }

        // 4. 隐藏本地模型区域（不需要展示8B+0.6B混合信息）
        var localModelSection = document.getElementById('local-model-section');
        if (localModelSection) {
            localModelSection.style.display = 'none';
        }

        // 5. 修改本地模式提示文字
        var localHint = document.querySelector('#source-local .llm-source-hint');
        if (localHint) {
            localHint.textContent = '🧊 精简模式：内嵌 AI 推理引擎，自动加载 Qwen3-0.6B 小模型';
        }

        // 6. 禁止 localStorage 恢复外部API配置
        try {
            localStorage.removeItem('gospel_llm_source');
            localStorage.removeItem('gospel_external_api_url');
            localStorage.removeItem('gospel_external_api_key');
            localStorage.removeItem('gospel_external_model');
            // 强制设置节能模式
            localStorage.setItem('gospel_power_save_mode', 'true');
        } catch (e) { /* ignore */ }

        // 7. 拦截 tab-external 点击，防止切换到外部API
        if (tabExternal) {
            tabExternal.addEventListener('click', function(e) {
                e.stopImmediatePropagation();
                e.preventDefault();
                console.warn('[0.6B初始化] 🚫 已阻止切换到外部API模式');
            }, true);
        }

        // 8. 修改副标题，标注精简版
        var subtitle = document.getElementById('mode-subtitle');
        if (subtitle) {
            subtitle.textContent = '8 位 AI 居民在极寒中挣扎求生（0.6B 精简版）';
        }

        console.log('[0.6B初始化] 🧊 第一阶段 UI 修改完成');
    });

    // ============ 第二阶段：window.load 后覆盖 GST.LLM 配置 ============
    // startup.js 在 window.load 中初始化 GST.LLM，我们用更高优先级覆盖
    window.addEventListener('load', function() {
        // 等一帧，确保 startup.js 的 load 回调先执行
        requestAnimationFrame(function() {
            var GST = window.GST;
            if (!GST || !GST.LLM) {
                console.warn('[0.6B初始化] GST.LLM 尚未就绪，延迟重试...');
                setTimeout(function() {
                    applyLLMConfig();
                }, 500);
                return;
            }
            applyLLMConfig();
        });
    });

    function applyLLMConfig() {
        var GST = window.GST;
        if (!GST || !GST.LLM) {
            console.error('[0.6B初始化] ❌ GST.LLM 始终未就绪，无法覆盖配置');
            return;
        }

        // 强制使用本地模式
        GST.LLM.source = 'local';
        // 强制开启节能模式（所有决策都用 0.6B 小模型）
        GST.LLM.powerSaveMode = true;
        // 主模型也设为 0.6B（防止任何非节能路径调用 8B）
        GST.LLM.model = 'qwen3:0.6b';
        // 快速模型设为 0.6B
        GST.LLM.fastModel = 'qwen3:0.6b';
        // 启用快速模型
        GST.LLM.fastModelEnabled = true;

        console.log('[0.6B初始化] ✅ LLM 配置已强制: source=local, model=qwen3:0.6b, powerSave=true');

        // 同步 HUD 上的节能按钮状态（锁定为开启）
        var btnPS = document.getElementById('btn-power-save');
        if (btnPS) {
            btnPS.classList.add('active');
            if (GST.t) {
                btnPS.textContent = GST.t('hud.power_save_on') || '🔋 节能';
                btnPS.title = '节能模式已锁定(0.6B精简版)';
            }
            // 阻止点击切换（精简版不允许关闭节能模式）
            btnPS.addEventListener('click', function(e) {
                e.stopImmediatePropagation();
                e.preventDefault();
                console.warn('[0.6B初始化] 🚫 精简版不允许关闭节能模式');
            }, true);
        }

        // 确保 localStorage 中也强制存储节能模式
        try {
            localStorage.setItem('gospel_power_save_mode', 'true');
            localStorage.setItem('gospel_llm_source', 'local');
        } catch (e) { /* ignore */ }

        console.log('[0.6B初始化] 🧊✅ Qwen3-0.6B 精简模式初始化完成');
    }
})();
