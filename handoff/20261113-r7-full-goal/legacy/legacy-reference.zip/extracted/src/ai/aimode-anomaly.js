/**
 * 福音镇 - AI模式异常检测与日报
 * 从 aimode-logger.js 拆分，遵循SRP原则
 * 挂载到 GST.AIModeLogger.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    // 延迟获取，避免加载顺序导致 undefined
    function getAIModeLogger() { return GST.AIModeLogger; }
    const proto = (GST.AIModeLogger || {}).prototype;
    if (!proto) { console.warn('[aimode-anomaly] GST.AIModeLogger 尚未定义，跳过挂载'); return; }


    // ========== 【v2.0新增】异常行为检测系统 ==========

    /**
    * 每帧更新异常追踪器（累积持续时间）
    */
    proto._updateAnomalyTrackers = function(gameDt) {
        const game = this.game;
        if (!game.npcs) return;

        for (const npc of game.npcs) {
            if (npc.isDead) continue;
            const id = npc.id;
            if (!this._anomalyTrackers[id]) {
                this._anomalyTrackers[id] = {
                    san0Duration: 0,      // San=0持续时间（游戏秒）
                    hp0Duration: 0,       // HP极低(<10)持续时间
                    sta0Duration: 0,      // 体力=0持续时间
                    hunger0Duration: 0,   // 饱腹=0持续时间
                    lastScene: npc.currentScene,
                    sceneStayDuration: 0, // 同场景停留时间
                    lastEatGameTime: this._getGameTimeSeconds(), // 上次吃饭的游戏时间
                    lastSleepGameTime: this._getGameTimeSeconds(), // 上次睡觉的游戏时间
                    isSleepingNow: false,
                    // 属性持续低值追踪（你提到的"一直0超过三个小时"）
                    sanLowDuration: 0,    // San<15持续时间
                    hpLowDuration: 0,     // HP<30持续时间
                    staLowDuration: 0,    // 体力<10持续时间
                    // 【决策-行动一致性监测】追踪NPC是否在执行决策
                    lastDecision: null,       // 上一次检测到的决策（priorityOverride/stateOverride/taskOverride）
                    decisionStartTime: 0,     // 决策开始时间
                    lastDecisionPos: null,    // 决策开始时的位置
                    decisionStallDuration: 0, // 有决策但没移动的持续时间
                    lastMovingState: false,   // 上一帧是否在移动
                };
            }
            const t = this._anomalyTrackers[id];

            // San=0持续追踪
            if (npc.sanity <= 0) {
                t.san0Duration += gameDt;
            } else {
                t.san0Duration = 0;
            }

            // San<15持续追踪
            if (npc.sanity < 15) {
                t.sanLowDuration += gameDt;
            } else {
                t.sanLowDuration = 0;
            }

            // HP极低持续追踪
            if (npc.health < 10) {
                t.hp0Duration += gameDt;
            } else {
                t.hp0Duration = 0;
            }

            // HP<30持续追踪
            if (npc.health < 30) {
                t.hpLowDuration += gameDt;
            } else {
                t.hpLowDuration = 0;
            }

            // 体力=0持续追踪
            if (npc.stamina <= 0) {
                t.sta0Duration += gameDt;
            } else {
                t.sta0Duration = 0;
            }

            // 体力<10持续追踪
            if (npc.stamina < 10) {
                t.staLowDuration += gameDt;
            } else {
                t.staLowDuration = 0;
            }

            // 饱腹=0持续追踪
            if (npc.hunger <= 0) {
                t.hunger0Duration += gameDt;
            } else {
                t.hunger0Duration = 0;
            }

            // 同场景停留追踪
            if (npc.currentScene === t.lastScene) {
                t.sceneStayDuration += gameDt;
            } else {
                t.lastScene = npc.currentScene;
                t.sceneStayDuration = 0;
            }

            // 吃饭/睡觉时间追踪
            if (npc.isEating) {
                t.lastEatGameTime = this._getGameTimeSeconds();
            }
            if (npc.isSleeping && !t.isSleepingNow) {
                t.lastSleepGameTime = this._getGameTimeSeconds();
            }
            t.isSleepingNow = npc.isSleeping;

            // 【决策-行动一致性监测】追踪NPC决策与行动是否匹配
            const currentDecision = npc._priorityOverride || npc._stateOverride || 
                (npc._taskOverride && npc._taskOverride.isActive ? npc._taskOverride.taskId : null) ||
                (npc._actionOverride ? 'action_override' : null);
            const npcPos = npc.getGridPos ? npc.getGridPos() : null;
            
            if (currentDecision) {
                if (t.lastDecision !== currentDecision) {
                    // 决策变更，重置追踪
                    t.lastDecision = currentDecision;
                    t.decisionStartTime = this._getGameTimeSeconds();
                    t.lastDecisionPos = npcPos ? { x: npcPos.x, y: npcPos.y } : null;
                    t.decisionStallDuration = 0;
                } else {
                    // 同一决策持续中，检测是否在移动
                    const isActuallyMoving = npc.isMoving || (npc.currentPath && npc.currentPath.length > 0);
                    const isResting = npc.isSleeping || npc.isEating || npc._isBeingTreated || 
                        (npc._restCooldownTimer && npc._restCooldownTimer > 0);
                    const posChanged = npcPos && t.lastDecisionPos && 
                        (Math.abs(npcPos.x - t.lastDecisionPos.x) > 2 || Math.abs(npcPos.y - t.lastDecisionPos.y) > 2);
                    
                    if (posChanged) {
                        // 位置有变化，重置滞留计时
                        t.lastDecisionPos = { x: npcPos.x, y: npcPos.y };
                        t.decisionStallDuration = 0;
                    } else if (!isActuallyMoving && !isResting && !npc.isCrazy) {
                        // 有决策、没移动、没在休息/吃饭/治疗、没发疯 → 可能卡住了
                        t.decisionStallDuration += gameDt;
                    } else {
                        // 在移动或在休息中，不算滞留
                        t.decisionStallDuration = 0;
                    }
                }
            } else {
                // 无决策，重置
                t.lastDecision = null;
                t.decisionStallDuration = 0;
            }
        }
    };


    /**
    * 定期检查异常行为并记录（每5游戏分钟调用一次）
    */
    proto._checkAnomalies = function() {
        const game = this.game;
        if (!game.npcs) return;
        const currentGameTime = this._getGameTimeSeconds();

        for (const npc of game.npcs) {
            if (npc.isDead) continue;
            const id = npc.id;
            const t = this._anomalyTrackers[id];
            if (!t) continue;
            const snap = getAIModeLogger().npcAttrSnapshot(npc);

            // ===== 属性持续为0检测（你提到的核心需求）=====

            // San=0持续超过10游戏分钟（600秒）→ 严重异常
            if (t.san0Duration >= 600) {
                this.logDeduped('ANOMALY', id, 'san0_persist',
                    `🚨 ${npc.name} San=0已持续${Math.round(t.san0Duration / 60)}分钟! 场景:${npc.currentScene} 状态:${npc.stateDesc || npc.state} 睡眠:${npc.isSleeping} | ${snap} | 可能原因:资源不足/惩罚过重/无法恢复`);
            }

            // San<15持续超过3游戏小时（10800秒）→ 长期低迷
            if (t.sanLowDuration >= 10800) {
                this.logDeduped('ANOMALY', id, 'san_low_persist',
                    `⚠️ ${npc.name} San<15已持续${(t.sanLowDuration / 3600).toFixed(1)}小时! 场景:${npc.currentScene} | ${snap} | 精神状态长期低迷，需要关注恢复途径`);
            }

            // HP<10持续超过5游戏分钟（300秒）→ 濒死未处理
            if (t.hp0Duration >= 300) {
                this.logDeduped('ANOMALY', id, 'hp0_persist',
                    `🚨 ${npc.name} HP<10已持续${Math.round(t.hp0Duration / 60)}分钟! 场景:${npc.currentScene} 状态:${npc.stateDesc || npc.state} | ${snap} | 濒死状态未得到救治`);
            }

            // HP<30持续超过3游戏小时 → 健康长期低迷
            if (t.hpLowDuration >= 10800) {
                this.logDeduped('ANOMALY', id, 'hp_low_persist',
                    `⚠️ ${npc.name} HP<30已持续${(t.hpLowDuration / 3600).toFixed(1)}小时! 场景:${npc.currentScene} | ${snap} | 健康长期低迷，可能是资源/治疗不足`);
            }

            // 体力=0持续超过10游戏分钟 → 体力耗尽未恢复
            if (t.sta0Duration >= 600) {
                this.logDeduped('ANOMALY', id, 'sta0_persist',
                    `🚨 ${npc.name} 体力=0已持续${Math.round(t.sta0Duration / 60)}分钟! 场景:${npc.currentScene} 状态:${npc.stateDesc || npc.state} 睡眠:${npc.isSleeping} | ${snap} | 体力耗尽未回家睡觉`);
            }

            // 体力<10持续超过3游戏小时 → 长期疲惫
            if (t.staLowDuration >= 10800) {
                this.logDeduped('ANOMALY', id, 'sta_low_persist',
                    `⚠️ ${npc.name} 体力<10已持续${(t.staLowDuration / 3600).toFixed(1)}小时! 场景:${npc.currentScene} | ${snap} | 长期疲惫，睡眠恢复可能不足`);
            }

            // 饱腹=0持续超过10游戏分钟 → 饥饿未处理
            if (t.hunger0Duration >= 600) {
                this.logDeduped('ANOMALY', id, 'hunger0_persist',
                    `🚨 ${npc.name} 饱腹=0已持续${Math.round(t.hunger0Duration / 60)}分钟! 场景:${npc.currentScene} | ${snap} | 可能是食物耗尽或进食系统故障`);
            }

            // ===== 行为异常检测 =====

            // 同场景停留超过3游戏小时且不在睡觉 → 可能卡住了
            if (t.sceneStayDuration >= 10800 && !npc.isSleeping) {
                this.logDeduped('ANOMALY', id, 'scene_stuck',
                    `⚠️ ${npc.name} 在${npc.currentScene}停留超过${(t.sceneStayDuration / 3600).toFixed(1)}小时且未睡觉! 状态:${npc.stateDesc || npc.state} | ${snap} | 可能卡住或行为循环`);
            }

            // 连续未进食检测
            // 【v2.3修复】同时检查时间间隔和饱腹度，避免大量误报
            // 根因：NPC睡觉期间饱腹消耗很慢，13小时不吃饭但饱腹仍>75是正常的
            // 修复：只有饱腹<40且超过8小时未进食才告警
            const lastMealTime = Math.max(t.lastEatGameTime, npc._lastMealGameTime || 0);
            const timeSinceEat = currentGameTime - lastMealTime;
            if (timeSinceEat >= 28800 && !npc.isSleeping && npc.hunger < 40) {
                this.logDeduped('ANOMALY', id, 'no_eat',
                    `⚠️ ${npc.name} 已${(timeSinceEat / 3600).toFixed(1)}小时未进食! 饱腹:${Math.round(npc.hunger)} 场景:${npc.currentScene} | ${snap} | 进食系统可能故障`);
            }

            // 连续未睡觉检测
            // 【v2.3修复】阈值从16h提升到20h，避免正常白天活动触发误报
            // 根因：NPC D2 06:00醒来到22:00就寝=16h，正常白天活动就会触发旧阈值
            // 修复：20h阈值 + 区分白天/夜间（夜间23:00-06:00不睡觉才是真正异常）
            const timeSinceSleep = currentGameTime - t.lastSleepGameTime;
            const currentHour = game.getHour ? game.getHour() : 0;
            const isNightTime = currentHour >= 23 || currentHour < 6;
            // 夜间不睡觉：12h就告警（说明睡眠系统真的有问题）
            // 白天不睡觉：20h才告警（正常白天活动不应触发）
            const sleepAlertThreshold = isNightTime ? 43200 : 72000;
            if (timeSinceSleep >= sleepAlertThreshold && !npc.isSleeping) {
                this.logDeduped('ANOMALY', id, 'no_sleep',
                    `⚠️ ${npc.name} 已${(timeSinceSleep / 3600).toFixed(1)}小时未睡觉! 体力:${Math.round(npc.stamina)} San:${Math.round(npc.sanity)} 场景:${npc.currentScene} | ${snap} | 睡眠系统可能故障`);
            }

            // ===== 【v2.2新增】决策-行动一致性检测 =====
            // 有决策但长时间没行动（滞留超过5游戏分钟=300秒）
            // 【v2.3修复】排除"NPC已在任务目标场景且正在工作"的情况
            // 根因：老钱在workshop执行"人工发电"任务，不移动是因为已经在目标位置工作
            // 修复：检查NPC是否已到达任务目标场景，如果是则不算滞留
            if (t.decisionStallDuration >= 300) {
                const decisionDesc = npc._priorityOverride ? `P0:${npc._priorityOverride}` :
                    npc._stateOverride ? `stateOverride:${npc._stateOverride}` :
                    (npc._taskOverride && npc._taskOverride.isActive) ? `task:${npc._taskOverride.taskId}` :
                    npc._actionOverride ? 'actionOverride' : '未知';
                // 检查是否已在任务目标场景工作（不算滞留）
                const isAtTaskTarget = npc._taskOverride && npc._taskOverride.isActive && npc._taskOverrideReached;
                // 检查是否有P0覆盖且在室内原地休息（stamina_critical/crazy_emergency等）
                // 【v4.37b修复】扩大检查范围：只要有P0覆盖且在室内，就不算"无行动"
                // 根因：_restCooldownTimer=60秒过后归零，但体力还没恢复到40（清除阈值），
                // NPC仍在室内原地休息但被误报为"决策后无行动"
                const isIndoorScene = npc.currentScene && npc.currentScene !== 'village';
                const isP0Resting = npc._priorityOverride && (npc._restCooldownTimer > 0 || 
                    (isIndoorScene && ['stamina_critical', 'crazy_emergency', 'sanity_critical', 'health_critical'].includes(npc._priorityOverride)));
                // 检查是否有actionOverride正在执行（如人工发电、制药等）
                const isWorkingAction = npc._actionOverride && npc.stateDesc && 
                    (npc.stateDesc.includes('中') || npc.stateDesc.includes('正在'));
                if (!isAtTaskTarget && !isP0Resting && !isWorkingAction) {
                    const stallMinutes = (t.decisionStallDuration / 60).toFixed(1);
                    this.logDeduped('ANOMALY', id, 'decision_no_action',
                        `🚨 ${npc.name} 决策后无行动! 决策=${decisionDesc} 但在${npc.currentScene}原地滞留${stallMinutes}分钟! ` +
                        `状态:${npc.stateDesc || npc.state} 移动:${npc.isMoving} 路径:${(npc.currentPath||[]).length} ` +
                        `发疯:${npc.isCrazy} 睡觉:${npc.isSleeping} | ${snap}`);
                }
            }

            // 发疯但没有P0紧急处理（不应该发生，但作为安全网检测）
            // 【v2.3增强】报告当前P0是什么，帮助定位互斥问题
            if (npc.isCrazy && !npc.isSleeping && !npc._isDying && npc._priorityOverride !== 'crazy_emergency') {
                const blockingP0 = npc._priorityOverride ? `被${npc._priorityOverride}阻塞` : '无P0覆盖';
                this.logDeduped('ANOMALY', id, 'crazy_no_p0',
                    `🚨 ${npc.name} 发疯中但没有P0紧急处理! priorityOverride=${npc._priorityOverride || 'null'}(${blockingP0}) ` +
                    `场景:${npc.currentScene} | ${snap} | P0-4a crazy_emergency 可能未触发`);
            }

            // 体力=0但没有P0处理且不在休息
            if (npc.stamina <= 0 && !npc.isSleeping && !npc._isDying && 
                npc._priorityOverride !== 'stamina_critical' && npc._priorityOverride !== 'crazy_emergency' &&
                !(npc._restCooldownTimer && npc._restCooldownTimer > 0)) {
                this.logDeduped('ANOMALY', id, 'stamina0_no_action',
                    `🚨 ${npc.name} 体力=0但没有紧急处理! priorityOverride=${npc._priorityOverride || 'null'} ` +
                    `场景:${npc.currentScene} 状态:${npc.stateDesc || npc.state} | ${snap}`);
            }

            // ===== 【v2.1新增】决策Bug检测（基于行为观察）=====

            // 6. NPC在做事但没有产出（无效劳动）
            // 检测：NPC的stateDesc包含工作关键词，但不在正确场景
            const desc = (npc.stateDesc || '').toLowerCase();
            const isWorkDesc = desc.includes('砍柴') || desc.includes('伐木') || desc.includes('捕鱼') || desc.includes('采集') || desc.includes('发电') || desc.includes('维修') || desc.includes('建造');
            const isOutdoorWork = desc.includes('砍柴') || desc.includes('伐木') || desc.includes('捕鱼') || desc.includes('采集食物');
            const isIndoorWork = desc.includes('发电') || desc.includes('维修') || desc.includes('建造') || desc.includes('制药');
            if (isWorkDesc) {
                const inVillage = npc.currentScene === 'village';
                const wrongScene = (isOutdoorWork && !inVillage) || (isIndoorWork && inVillage);
                if (wrongScene) {
                    this.logDeduped('DECISION_BUG', id, 'wrong_scene_work',
                        `🤔 ${npc.name} 在错误场景工作! 描述:"${npc.stateDesc}" 但在${npc.currentScene} | ${snap} | 行动无法产生效果`);
                }
            }

            // 7. 全员都在室内但没人去采集资源（集体决策失误）
            // 这个检测放在循环外面做
        }

        // ===== 【v2.1新增】集体决策Bug检测 =====
        this._checkCollectiveDecisionBugs();
    };


    /**
    * 【v2.1新增】集体决策Bug检测
    * 检测整个团队层面的决策问题
    */
    proto._checkCollectiveDecisionBugs = function() {
        const game = this.game;
        if (!game.npcs || !game.resourceSystem) return;
        const rs = game.resourceSystem;
        const hour = game.getHour ? game.getHour() : 0;
        const aliveNpcs = game.npcs.filter(n => !n.isDead && !n.isSleeping && !n.isCrazy);
        if (aliveNpcs.length < 2) return;

        // 只在白天检测（6:00~22:00），夜间NPC应该在睡觉
        if (hour < 6 || hour >= 22) return;

        // 1. 资源危机但没人去采集
        const outdoorWorkers = aliveNpcs.filter(n => n.currentScene === 'village' && !n.isEating);
        const indoorNpcs = aliveNpcs.filter(n => n.currentScene !== 'village');

        // 木柴危机但没人在砍柴
        if (rs.woodFuel < 10 && outdoorWorkers.length === 0) {
            const npcLocations = aliveNpcs.map(n => `${n.name}(${n.currentScene})`).join(', ');
            this.logDeduped('DECISION_BUG', 'team', 'no_woodcutter',
                `🚨 团队决策Bug: 木柴仅剩${rs.woodFuel.toFixed(1)}但没人在户外砍柴! | 全员位置: ${npcLocations}`);
        }

        // 食物危机但没人在采集
        if (rs.food < 10 && outdoorWorkers.length === 0) {
            this.logDeduped('DECISION_BUG', 'team', 'no_gatherer',
                `🚨 团队决策Bug: 食物仅剩${rs.food.toFixed(1)}但没人在户外采集! | 存活${aliveNpcs.length}人全在室内`);
        }

        // 2. 所有人都在做同一件事（资源偏科）
        const outdoorCount = outdoorWorkers.length;
        if (outdoorCount >= 4 && indoorNpcs.length === 0 && aliveNpcs.length >= 5) {
            this.logDeduped('DECISION_BUG', 'team', 'all_outdoor',
                `⚠️ 团队决策Bug: ${outdoorCount}人全在户外，无人维护室内设施(暖炉/发电/医疗)!`);
        }

        // 3. 有人濒死但苏医生不在医疗站
        const dyingNpcs = aliveNpcs.filter(n => n.health < 20);
        const suDoctor = game.npcs.find(n => n.id === 'su_doctor' && !n.isDead);
        if (dyingNpcs.length > 0 && suDoctor && suDoctor.currentScene !== 'medical' && !suDoctor.isSleeping) {
            const dyingNames = dyingNpcs.map(n => `${n.name}(HP:${Math.round(n.health)})`).join(', ');
            this.logDeduped('DECISION_BUG', 'team', 'doctor_absent',
                `⚠️ 团队决策Bug: ${dyingNames}濒死但苏医生在${suDoctor.currentScene}而非医疗站!`);
        }
    };


    // ========== 【v2.0新增】惩罚累计追踪系统 ==========

    /**
    * 每帧更新惩罚追踪器
    */
    proto._updatePenaltyTrackers = function(gameDt) {
        const game = this.game;
        if (!game.npcs) return;
        const hour = game.getHour ? game.getHour() : 0;

        for (const npc of game.npcs) {
            if (npc.isDead) continue;
            const id = npc.id;
            if (!this._penaltyTrackers[id]) {
                this._penaltyTrackers[id] = {
                    nightPenalty: { duration: 0, sanLost: 0 },
                    outdoorCold: { duration: 0, hpLost: 0 },
                    starvation: { duration: 0, hpLost: 0 },
                    exhaustion: { duration: 0, hpLost: 0 },
                    sanSpiral: { duration: 0, sanLost: 0 },
                };
            }
            const pt = this._penaltyTrackers[id];

            // 通宵惩罚追踪（23:00~05:00不睡觉）
            if ((hour >= 23 || hour < 5) && !npc.isSleeping) {
                pt.nightPenalty.duration += gameDt;
                pt.nightPenalty.sanLost += 0.15 * gameDt; // 与_updateAttributes中的通宵San扣减一致
            }

            // 户外寒冷惩罚追踪
            if (npc.currentScene === 'village' && npc.bodyTemp < 35) {
                pt.outdoorCold.duration += gameDt;
                pt.outdoorCold.hpLost += 0.05 * gameDt;
            }

            // 饥饿惩罚追踪（饱腹=0时扣HP）
            if (npc.hunger <= 0) {
                pt.starvation.duration += gameDt;
                pt.starvation.hpLost += 0.15 * gameDt;
            }

            // 体力耗尽惩罚追踪（体力=0时扣HP）
            if (npc.stamina <= 0 && !npc.isSleeping) {
                pt.exhaustion.duration += gameDt;
                pt.exhaustion.hpLost += 0.025 * gameDt;
            }

            // San恶性循环追踪（San<30时加速下降）
            if (npc.sanity < 30 && npc.sanity > 0 && !npc.isSleeping) {
                pt.sanSpiral.duration += gameDt;
                pt.sanSpiral.sanLost += 0.03 * gameDt;
            }
        }
    };


    // ========== 【v2.0新增】每日智能摘要 ==========

    /**
    * 生成前一天的智能摘要
    */
    proto._generateDailySummary = function(dayNum) {
        const game = this.game;
        if (!game.npcs) return;

        const aliveNpcs = game.npcs.filter(n => !n.isDead);
        const deadNpcs = game.npcs.filter(n => n.isDead);

        // 找出最危险的NPC（按综合危险度排序）
        const dangerScores = aliveNpcs.map(npc => {
            let score = 0;
            if (npc.sanity < 20) score += (20 - npc.sanity) * 3;
            if (npc.health < 30) score += (30 - npc.health) * 2;
            if (npc.stamina < 15) score += (15 - npc.stamina) * 1.5;
            if (npc.hunger < 20) score += (20 - npc.hunger) * 1;
            if (npc.bodyTemp < 35) score += (35 - npc.bodyTemp) * 5;
            if (npc.isSick) score += 20;
            if (npc.isCrazy) score += 40;
            return { npc, score };
        }).sort((a, b) => b.score - a.score);

        const lines = [];
        lines.push(`📊 第${dayNum}天结束摘要:`);
        lines.push(`  存活: ${aliveNpcs.length}/${game.npcs.length}人`);

        // 当天死亡的NPC
        if (game.deathSystem && game.deathSystem.deathRecords) {
            const todayDeaths = game.deathSystem.deathRecords.filter(r => r.day === dayNum);
            if (todayDeaths.length > 0) {
                lines.push(`  ☠️ 今日死亡: ${todayDeaths.map(r => `${r.name}(${r.cause})`).join(', ')}`);
            }
        }

        // 最危险的NPC（前3名）
        const topDanger = dangerScores.filter(d => d.score > 10).slice(0, 3);
        if (topDanger.length > 0) {
            lines.push(`  ⚠️ 最危险NPC:`);
            for (const d of topDanger) {
                const n = d.npc;
            const snap = getAIModeLogger().npcAttrSnapshot(n);
                const reasons = [];
                if (n.sanity < 20) reasons.push(`San极低(${Math.round(n.sanity)})`);
                if (n.health < 30) reasons.push(`HP低(${Math.round(n.health)})`);
                if (n.stamina < 15) reasons.push(`体力低(${Math.round(n.stamina)})`);
                if (n.bodyTemp < 35) reasons.push(`失温(${n.bodyTemp.toFixed(1)}°C)`);
                if (n.isSick) reasons.push('生病');
                if (n.isCrazy) reasons.push('发疯');
                lines.push(`    ${n.name}: ${snap} | 原因: ${reasons.join(', ')}`);

                // 输出该NPC的惩罚累计
                const pt = this._penaltyTrackers[n.id];
                if (pt) {
                    const pLines = [];
                    if (pt.nightPenalty.duration > 60) pLines.push(`通宵${Math.round(pt.nightPenalty.duration / 60)}分`);
                    if (pt.outdoorCold.duration > 60) pLines.push(`户外寒冷${Math.round(pt.outdoorCold.duration / 60)}分`);
                    if (pt.starvation.duration > 60) pLines.push(`饥饿${Math.round(pt.starvation.duration / 60)}分`);
                    if (pt.exhaustion.duration > 60) pLines.push(`体力耗尽${Math.round(pt.exhaustion.duration / 60)}分`);
                    if (pt.sanSpiral.duration > 60) pLines.push(`San恶性循环${Math.round(pt.sanSpiral.duration / 60)}分`);
                    if (pLines.length > 0) {
                        lines.push(`      惩罚累计: ${pLines.join(' | ')}`);
                    }
                }
            }
        }

        // 资源状况
        const rs = game.resourceSystem;
        if (rs) {
            const resLine = `  📦 资源: 木柴${rs.woodFuel != null ? rs.woodFuel.toFixed(1) : '?'} 食物${rs.food != null ? rs.food.toFixed(1) : '?'} 电力${rs.power != null ? rs.power.toFixed(1) : '?'}`;
            lines.push(resLine);
        }

        // ===== 【v2.1新增】决策审计摘要 =====
        const decisionLines = [];
        let totalDecisionCount = 0;
        let totalAutonomousCount = 0;
        let totalSystemDrivenCount = 0;
        let totalInterventionCount = 0;
        for (const npc of aliveNpcs.concat(deadNpcs)) {
            const dt = this._decisionTrackers[npc.id];
            if (!dt || dt.totalDecisions === 0) continue;
            totalDecisionCount += dt.totalDecisions;
            totalAutonomousCount += dt.autonomousDecisions || 0;
            totalSystemDrivenCount += dt.systemDrivenDecisions || 0;
            totalInterventionCount += dt.interventionCount || 0;

            const issues = [];
            if (dt.idleDecisions > 2) issues.push(`闲逛${dt.idleDecisions}次`);
            if (dt.contradictions > 0) issues.push(`矛盾决策${dt.contradictions}次`);
            if ((dt.interventionCount || 0) > 0) issues.push(`系统接管${dt.interventionCount}次`);
            if (issues.length > 0) {
                decisionLines.push(`    ${npc.name}: 总决策${dt.totalDecisions}次, 自主${dt.autonomousDecisions || 0}次, 系统驱动${dt.systemDrivenDecisions || 0}次, 问题: ${issues.join(', ')}`);
            }
        }
        if (totalDecisionCount > 0) {
            const autonomyRate = totalAutonomousCount / totalDecisionCount;
            lines.push(`  🧭 决策自治率: ${(autonomyRate * 100).toFixed(1)}% (自主${totalAutonomousCount} / 总决策${totalDecisionCount})`);
            if (totalSystemDrivenCount > 0 || totalInterventionCount > 0) {
                lines.push(`  🎛️ 系统介入: 系统驱动${totalSystemDrivenCount}次 | 显式接管${totalInterventionCount}次`);
            }
        }
        if (decisionLines.length > 0) {
            lines.push(`  🧠 决策审计(有问题的NPC):`);
            lines.push(...decisionLines);
        }

        // ===== 【v2.1新增】生态平衡检测 =====
        if (rs) {
            const ecoIssues = [];
            // 资源入不敷出检测
            const dc = rs.dailyConsumed || {};
            const dg = rs.dailyCollected || {};
            if ((dg.woodFuel || 0) < (dc.woodFuel || 0) * 0.7) ecoIssues.push(`木柴入不敷出(采${(dg.woodFuel||0).toFixed(0)}消${(dc.woodFuel||0).toFixed(0)})`);
            if ((dg.food || 0) < (dc.food || 0) * 0.7) ecoIssues.push(`食物入不敷出(采${(dg.food||0).toFixed(0)}消${(dc.food||0).toFixed(0)})`);
            // 资源偏科检测
            const totalCollected = (dg.woodFuel || 0) + (dg.food || 0) + (dg.power || 0);
            if (totalCollected > 10) {
                const woodRatio = (dg.woodFuel || 0) / totalCollected;
                const foodRatio = (dg.food || 0) / totalCollected;
                if (woodRatio > 0.8) ecoIssues.push(`采集严重偏科:木柴占${(woodRatio*100).toFixed(0)}%`);
                if (foodRatio > 0.8) ecoIssues.push(`采集严重偏科:食物占${(foodRatio*100).toFixed(0)}%`);
                if (woodRatio < 0.1 && rs.woodFuel < 20) ecoIssues.push(`几乎没人砍柴(仅占${(woodRatio*100).toFixed(0)}%)`);
                if (foodRatio < 0.1 && rs.food < 20) ecoIssues.push(`几乎没人采食物(仅占${(foodRatio*100).toFixed(0)}%)`);
            }
            if (ecoIssues.length > 0) {
                lines.push(`  ⚖️ 生态平衡问题: ${ecoIssues.join(' | ')}`);
            }
        }

        // ===== 【v2.1新增】轮回进化评估 =====
        const reincSys = game.reincarnationSystem;
        if (reincSys && reincSys.pastLives && reincSys.pastLives.length > 0) {
            const lifeNum = reincSys.getLifeNumber();
            const lastLife = reincSys.pastLives[reincSys.pastLives.length - 1];
            const lastAlive = lastLife.aliveCount || 0;
            const currentAlive = aliveNpcs.length;
            if (dayNum >= 2) { // 至少第2天才有意义比较
                if (currentAlive <= lastAlive && lastAlive < 8) {
                    lines.push(`  🔄 轮回进化: ⚠️ 第${lifeNum}世D${dayNum}存活${currentAlive}人 ≤ 上世最终${lastAlive}人，轮回可能没有进步!`);
                } else if (currentAlive > lastAlive) {
                    lines.push(`  🔄 轮回进化: ✅ 第${lifeNum}世D${dayNum}存活${currentAlive}人 > 上世最终${lastAlive}人，有进步!`);
                }
            }
        }

        this.log('DAY_REVIEW', lines.join('\n'));

        // 重置每日决策计数器
        for (const id in this._decisionTrackers) {
            const dt = this._decisionTrackers[id];
            dt.totalDecisions = 0;
            dt.autonomousDecisions = 0;
            dt.systemDrivenDecisions = 0;
            dt.interventionCount = 0;
            dt.idleDecisions = 0;
            dt.contradictions = 0;
        }
    };


    /**
    * 【v2.0重构】NPC属性定期快照 — 降频到6游戏小时，只记录有危险的NPC
    */
    proto._takeSnapshot = function() {
        const game = this.game;
        if (!game.npcs || game.npcs.length === 0) return;

        const aliveNpcs = game.npcs.filter(n => !n.isDead);
        if (aliveNpcs.length === 0) return;

        // 只记录有危险或状态异常的NPC（至少有一项属性低于阈值）
        const dangerNpcs = [];
        const safeNpcs = [];
        for (const npc of aliveNpcs) {
            const isDanger = (npc.health < 50 || npc.stamina < 20 || npc.hunger < 30 || npc.sanity < 40 || npc.bodyTemp < 35 || npc.isSick || npc.isCrazy);
            if (isDanger) {
                dangerNpcs.push(npc);
            } else {
                safeNpcs.push(npc);
            }
        }

        // 危险NPC详细记录
        const lines = [];
        if (dangerNpcs.length > 0) {
            for (const npc of dangerNpcs) {
                const hp = npc.health != null ? npc.health.toFixed(1) : '?';
                const sta = npc.stamina != null ? npc.stamina.toFixed(1) : '?';
                const hun = npc.hunger != null ? npc.hunger.toFixed(1) : '?';
                const san = npc.sanity != null ? npc.sanity.toFixed(1) : '?';
                const temp = npc.bodyTemp != null ? npc.bodyTemp.toFixed(1) : '?';
                const flags = [];
                if (npc.isSleeping) flags.push('睡眠');
                if (npc.isSick) flags.push('生病');
                if (npc.isCrazy) flags.push('发疯');
                if (npc._hungerOverride) flags.push('饥饿覆盖');
                if (npc._stateOverride) flags.push(`状态覆盖:${npc._stateOverride}`);
                lines.push(`  ⚠️ ${npc.name} | HP:${hp} STA:${sta} HUN:${hun} SAN:${san} TEMP:${temp} | ${npc.currentScene || '?'} | ${npc.stateDesc || npc.state || '?'} | ${flags.join(',') || '无特殊'}`);
            }
        }
        // 安全NPC只记录一行摘要
        if (safeNpcs.length > 0) {
            lines.push(`  ✅ 状态正常(${safeNpcs.length}人): ${safeNpcs.map(n => n.name).join(', ')}`);
        }

        this.log('SNAPSHOT', `存活${aliveNpcs.length}人(危险${dangerNpcs.length}/安全${safeNpcs.length}):\n${lines.join('\n')}`);
    };


    /**
    * 资源快照（与NPC快照同步）
    */
    proto._takeResourceSnapshot = function() {
        const game = this.game;
        const rs = game.resourceSystem;
        if (!rs) return;

        // 三项资源当前储量
        const woodFuel = rs.woodFuel != null ? rs.woodFuel.toFixed(1) : '?';
        const food = rs.food != null ? rs.food.toFixed(1) : '?';
        const power = rs.power != null ? rs.power.toFixed(1) : '?';

        // 本日累计消耗/采集
        const dc = rs.dailyConsumed || {};
        const dg = rs.dailyCollected || {};
        const consumedStr = `木柴:${(dc.woodFuel || 0).toFixed(1)} 食物:${(dc.food || 0).toFixed(1)} 电力:${(dc.power || 0).toFixed(1)}`;
        const collectedStr = `木柴:${(dg.woodFuel || 0).toFixed(1)} 食物:${(dg.food || 0).toFixed(1)} 电力:${(dg.power || 0).toFixed(1)}`;

        // 暖炉状态
        let furnaceInfo = '暖炉:N/A';
        const fs = game.furnaceSystem;
        if (fs && fs.furnaces) {
            const furnaceArr = Array.isArray(fs.furnaces) ? fs.furnaces : Object.values(fs.furnaces);
            if (furnaceArr.length > 0) {
                const f = furnaceArr[0];
                furnaceInfo = `暖炉火焰:${f.fireLevel != null ? f.fireLevel : '?'} 室温:${f.indoorTemp != null ? f.indoorTemp.toFixed(1) : (fs.indoorTemp != null ? fs.indoorTemp.toFixed(1) : '?')}`;
            }
        }

        // 资源危机检测
        const crisisFlags = [];
        if (rs.food <= 0) crisisFlags.push('🚨食物耗尽');
        else if (rs.getFoodMealsRemaining && rs.getFoodMealsRemaining() < 2) crisisFlags.push('⚠️食物不足2餐');
        if (rs.woodFuel <= 0) crisisFlags.push('🚨木柴耗尽');
        else if (rs.getWoodFuelHoursRemaining && rs.getWoodFuelHoursRemaining() < 2) crisisFlags.push('⚠️木柴不足2小时');
        if (rs.power <= 0) crisisFlags.push('🚨电力耗尽');
        const crisisStr = crisisFlags.length > 0 ? ` | ${crisisFlags.join(' ')}` : '';

        this.log('RESOURCE', `储量 木柴:${woodFuel} 食物:${food} 电力:${power} | 今日消耗[${consumedStr}] 采集[${collectedStr}] | ${furnaceInfo}${crisisStr}`);
    };

})();
