/**
 * 福音镇 - AI 模式日志记录器 v2.1
 * 挂载到 GST.AIModeLogger
 * 
 * 【使命】8个AI在末日自主决策生活，不断轮回修正决策直到全员存活
 * 日志系统的核心价值：自动检测一切阻碍AI走向全员存活的异常
 * 
 * 【Bug的三层定义】
 * 1. 系统Bug：程序卡死、弹弹乐、属性计算错误
 * 2. 决策Bug：NPC做出不合理决策（行动与状态矛盾、无效行动、忽视危机）
 * 3. 生态Bug：惩罚太狠、资源不够、恢复途径断裂、轮回没有进化
 * 
 * 【v2.0重构】去噪+异常检测+死亡回溯
 * 【v2.1新增】决策审计+生态平衡检测+轮回进化评估
 */
(function() {
    'use strict';
    const GST = window.GST;

/**
 * AI模式专用日志系统 v2.0
 * 仅在 agent / reincarnation 模式下工作，自动记录关键游戏事件到 /log/aimode_log/ 目录
 */
class AIModeLogger {
    constructor(game) {
        this.game = game;

        // 生成会话文件名：session_YYYYMMDD_HHmmss.log
        const now = new Date();
        const pad = (n, len = 2) => String(n).padStart(len, '0');
        const timestamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
        this.sessionFilename = `session_${timestamp}.log`;

        // 缓冲区
        this._buffer = [];
        this._lastFlushTime = Date.now();
        this._flushInterval = 5000; // 5秒（真实时间）
        this._flushThreshold = 10;  // 10条

        // 快照定时器（游戏时间秒累积）— 改为6游戏小时 = 21600游戏秒
        this._snapshotTimer = 0;
        this._snapshotInterval = 21600; // 每6游戏小时（06:00/12:00/18:00/00:00）

        // ========== 【v2.0新增】日志去重系统 ==========
        // 格式: { "npcId_category_subType": lastGameTime }
        this._dedupeMap = {};
        this._dedupeCooldown = 600; // 默认10游戏分钟 = 600游戏秒
        // 【v4.33修复】高频重复日志使用更长的冷却时间，避免刷屏
        this._longCooldownSubTypes = {
            'fallback_blocked': 3600,   // 默认行为被阻止：1游戏小时冷却
            'stamina_rest': 3600,       // 体力不足原地休息：1游戏小时冷却
            'health_rest': 3600,        // 健康不足原地休息：1游戏小时冷却
            'health_medical_rest': 3600,// 健康危急原地休息：1游戏小时冷却
            'crazy_indoor_rest': 1800,  // 发疯原地休息：30游戏分钟冷却
            'crazy_rest': 1800,         // 发疯宿舍休息：30游戏分钟冷却
            'emergency_decision': 1800, // 【v4.34】紧急决策：30游戏分钟冷却（D1刷了10+条同一原因）
        };

        // ========== 【v2.0新增】NPC事件环形缓冲区（死亡回溯链） ==========
        // 格式: { npcId: [ {time, event}, ... ] }，每个NPC最多保留最近50条关键事件
        this._npcEventBuffers = {};
        this._eventBufferMaxSize = 50;

        // ========== 【v2.0新增】异常行为检测追踪器 ==========
        // 格式: { npcId: { san0Duration, hp0Duration, sta0Duration, lastScene, sceneStayDuration, lastEatTime, lastSleepTime, ... } }
        this._anomalyTrackers = {};

        // ========== 【v2.0新增】惩罚累计追踪 ==========
        // 格式: { npcId: { nightPenalty: {duration, sanLost}, outdoorPenalty: {...}, hungerPenalty: {...}, ... } }
        this._penaltyTrackers = {};

        // ========== 【v2.0新增】DOOR弹弹乐检测 ==========
        // 格式: { npcId: [ {time, scene}, ... ] }
        this._doorHistory = {};

        // ========== 【v2.0新增】每日摘要追踪 ==========
        this._lastSummaryDay = 0;

        // 异常检测定时器（每300游戏秒检测一次 = 5游戏分钟）
        this._anomalyCheckTimer = 0;
        this._anomalyCheckInterval = 300;

        // ========== 【v2.2新增】异常日志内存缓冲区（供debug log提取） ==========
        // 最近的 ANOMALY/EMERGENCY 日志，供 _saveDebugLogToServer 读取
        this._recentAnomalies = [];  // 最多保留50条
        this._recentAnomaliesMax = 50;

        // ========== 【v2.1新增】决策审计系统 ==========
        // 格式: { npcId: { totalDecisions, idleDecisions, contradictions, ineffectiveActions, lastDecision, ... } }
        this._decisionTrackers = {};
        // 每日资源产出追踪（用于检测生态平衡）
        this._dailyProductionByNpc = {}; // { npcId: { woodFuel: 0, food: 0, power: 0 } }

        // 写入文件头
        this._writeHeader();
    }

    /**
     * 写入日志文件头信息
     */
    _writeHeader() {
        const now = new Date();
        const headerLines = [
            '========================================',
            `  AI模式运行日志 v2.0`,
            `  启动时间: ${now.toLocaleString('zh-CN')}`,
            `  游戏模式: ${this.game.mode}`,
            `  会话文件: ${this.sessionFilename}`,
            `  日志级别: CRITICAL(必看) > IMPORTANT(排查) > VERBOSE(调试,默认不记录)`,
        ];
        // 如果是断点续玩，追加恢复信息
        if (this.game._isContinueSession) {
            const dayNum = this.game.dayCount || 1;
            const timeStr = this.game.getTimeStr ? this.game.getTimeStr() : '??:??';
            const lifeNum = this.game.reincarnationSystem ? this.game.reincarnationSystem.getLifeNumber() : '?';
            headerLines.push(`  ⚠️ 断点续玩恢复：从 D${dayNum} ${timeStr} 继续（第${lifeNum}世）`);
        }
        headerLines.push('========================================', '');
        const header = headerLines.join('\n');

        fetch('/api/save-aimode-log', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: this.sessionFilename, content: header })
        }).catch(err => console.warn('[AIModeLogger] 写入文件头失败:', err));
    }

    /**
     * 记录一条日志
     * @param {string} category - 日志分类，如 DEATH, SNAPSHOT, ALERT 等
     * @param {string} message - 日志内容
     */
    log(category, message) {
        const game = this.game;
        // 游戏时间
        const dayNum = game.dayCount || 1;
        const gameTimeStr = game.getTimeStr ? game.getTimeStr() : '??:??';
        // 真实时间
        const now = new Date();
        const realTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

        const entry = `[D${dayNum} ${gameTimeStr}] [${realTime}] [${category}] ${message}`;
        this._buffer.push(entry);

        // 【v2.2】异常日志自动缓存到内存（供debug log提取）
        if (category === 'ANOMALY' || category === 'EMERGENCY' || category === 'DEATH') {
            this._recentAnomalies.push(entry);
            if (this._recentAnomalies.length > this._recentAnomaliesMax) {
                this._recentAnomalies.shift();
            }
        }

        // 检查是否需要自动刷新
        if (this._buffer.length >= this._flushThreshold) {
            this._flush();
        }
    }

    /**
     * 【v2.0新增】带去重的日志记录
     * 同一NPC同一类型的日志，在冷却时间内不重复记录
     * @param {string} category - 日志分类
     * @param {string} npcId - NPC ID
     * @param {string} subType - 子类型（用于区分同一category下的不同告警）
     * @param {string} message - 日志内容
     * @returns {boolean} 是否成功记录（false=被去重过滤）
     */
    logDeduped(category, npcId, subType, message) {
        const key = `${npcId}_${category}_${subType}`;
        const gameTime = this._getGameTimeSeconds();
        const lastTime = this._dedupeMap[key];
        // 【v4.33修复】按subType使用自定义冷却时间，高频重复日志用更长冷却
        const cooldown = (this._longCooldownSubTypes && this._longCooldownSubTypes[subType]) 
            || this._dedupeCooldown;
        if (lastTime !== undefined && (gameTime - lastTime) < cooldown) {
            return false; // 冷却中，跳过
        }
        this._dedupeMap[key] = gameTime;
        this.log(category, message);
        return true;
    }

    /**
     * 【v2.1新增】记录NPC决策（供AI决策系统调用）
     * 用于检测决策Bug：行动与状态矛盾、无效行动、忽视危机等
     * @param {string} npcId - NPC ID
     * @param {string} npcName - NPC名字
     * @param {object} decision - 决策对象 { action, target, reasoning, source, interventionType }
     * @param {object} npcState - NPC当前状态 { health, stamina, hunger, sanity, bodyTemp, scene }
     */
    logDecision(npcId, npcName, decision, npcState) {
        if (!this._decisionTrackers[npcId]) {
            this._decisionTrackers[npcId] = {
                totalDecisions: 0,
                autonomousDecisions: 0,
                systemDrivenDecisions: 0,
                interventionCount: 0,
                idleDecisions: 0,      // 无意义决策（wander/stay without purpose）
                contradictions: 0,     // 矛盾决策（状态差但不自救）
                ineffectiveTime: 0,    // 无效行动累计时间
                lastDecisionTime: this._getGameTimeSeconds(),
                lastAction: null,
                lastTarget: null,
            };
        }
        const dt = this._decisionTrackers[npcId];
        dt.totalDecisions++;
        dt.lastDecisionTime = this._getGameTimeSeconds();
        dt.lastAction = decision.action;
        dt.lastTarget = decision.target;

        const action = (decision.action || '').toLowerCase();
        const target = (decision.target || '').toLowerCase();
        const reasoning = decision.reasoning || '';
        const source = (decision.source || 'unknown').toLowerCase();
        const interventionType = decision.interventionType || '';

        if (source === 'llm') {
            dt.autonomousDecisions++;
        } else {
            dt.systemDrivenDecisions++;
        }

        if (interventionType) {
            dt.interventionCount++;
            this.logDeduped('SYSTEM_INTERVENTION', npcId, `${interventionType}_${action}_${target}`,
                `🎛️ ${npcName} 遭遇系统接管: ${interventionType} | 来源:${source} | 行动:${action} 目标:${target} | 理由:${reasoning.slice(0, 60)}`);
        }

        // ===== 决策Bug检测 =====

        // 1. 无意义决策：wander/闲逛，且不是状态良好的休闲
        if (action === 'wander' || action === 'stay') {
            const isHealthy = npcState.health > 60 && npcState.stamina > 40 && npcState.hunger > 40 && npcState.sanity > 40;
            if (!isHealthy) {
                dt.idleDecisions++;
                // 连续3次无意义决策才记录（避免偶尔的正常闲逛）
                if (dt.idleDecisions >= 3 && dt.idleDecisions % 3 === 0) {
                    this.logDeduped('DECISION_BUG', npcId, 'idle_while_danger',
                        `🤔 ${npcName} 状态差却在闲逛! 已连续${dt.idleDecisions}次无意义决策 | 行动:${action} 目标:${target} | HP:${Math.round(npcState.health)} STA:${Math.round(npcState.stamina)} HUN:${Math.round(npcState.hunger)} SAN:${Math.round(npcState.sanity)} | 理由:${reasoning.slice(0, 60)}`);
                    this.pushNpcEvent(npcId, `🤔 决策Bug:状态差却闲逛(第${dt.idleDecisions}次) | ${action}→${target}`);
                }
            } else {
                dt.idleDecisions = 0; // 状态好时重置
            }
        } else {
            dt.idleDecisions = 0; // 有目的行动时重置
        }

        // 2. 矛盾决策：体力极低但去户外工作
        const isOutdoorTarget = target.includes('lumber') || target.includes('frozen_lake') || target.includes('ruins') || target.includes('ore_pile') || target === 'furnace_plaza';
        if (npcState.stamina < 15 && target && isOutdoorTarget) {
            if (action === 'go_to' || action === 'work') {
                dt.contradictions++;
                this.logDeduped('DECISION_BUG', npcId, 'exhausted_outdoor',
                    `🤔 ${npcName} 体力${Math.round(npcState.stamina)}却决定去户外${target}! | 行动:${action} | 理由:${reasoning.slice(0, 60)}`);
                this.pushNpcEvent(npcId, `🤔 决策Bug:体力${Math.round(npcState.stamina)}却去户外${target}`);
            }
        }

        // 3. 矛盾决策：饱腹极低但不去吃饭
        if (npcState.hunger < 15 && action !== 'eat' && !target.includes('kitchen')) {
            this.logDeduped('DECISION_BUG', npcId, 'starving_no_eat',
                `🤔 ${npcName} 饱腹${Math.round(npcState.hunger)}却不去吃饭! | 行动:${action} 目标:${target} | 理由:${reasoning.slice(0, 60)}`);
        }

        // 4. 矛盾决策：San极低但不去休息/医疗
        // 【v2.3修复】分级检测：San<10=严重Bug，San 10-20=风险提示
        // 根因：San=18的NPC去执行职责内任务（如李婶去厨房分饭）是合理的角色行为
        // 修复：San<10才标记为Bug，10-20只在非职责行为时标记
        if (npcState.sanity < 10 && action !== 'rest' && !target.includes('dorm') && !target.includes('medical')) {
            this.logDeduped('DECISION_BUG', npcId, 'insane_no_rest',
                `🚨 ${npcName} San=${Math.round(npcState.sanity)}却不去休息/医疗! | 行动:${action} 目标:${target} | 理由:${reasoning.slice(0, 60)}`);
        }

        // 5. 矛盾决策：体温极低但去户外
        if (npcState.bodyTemp < 35 && action === 'go_to' && isOutdoorTarget) {
            this.logDeduped('DECISION_BUG', npcId, 'freezing_outdoor',
                `🤔 ${npcName} 体温${npcState.bodyTemp.toFixed(1)}°C却决定去户外${target}! | 理由:${reasoning.slice(0, 60)}`);
        }

        // 记录到回溯链（简洁版）
        this.pushNpcEvent(npcId, `🧠 决策:${action}→${target} | src:${source} | ${reasoning.slice(0, 30)}`);
    }

    /**
     * 【v2.0新增】记录NPC关键事件到环形缓冲区（用于死亡回溯）
     * @param {string} npcId - NPC ID
     * @param {string} event - 事件描述
     */
    pushNpcEvent(npcId, event) {
        if (!this._npcEventBuffers[npcId]) {
            this._npcEventBuffers[npcId] = [];
        }
        const buf = this._npcEventBuffers[npcId];
        const game = this.game;
        const dayNum = game.dayCount || 1;
        const gameTimeStr = game.getTimeStr ? game.getTimeStr() : '??:??';
        buf.push({ time: `D${dayNum} ${gameTimeStr}`, event });
        // 环形缓冲：超过上限时移除最旧的
        while (buf.length > this._eventBufferMaxSize) {
            buf.shift();
        }
    }

    /**
     * 【v2.0新增】输出NPC死亡回溯链
     * @param {string} npcId - NPC ID
     * @param {string} npcName - NPC名字
     */
    flushDeathRetrospective(npcId, npcName) {
        const buf = this._npcEventBuffers[npcId];
        if (!buf || buf.length === 0) {
            this.log('DEATH_RETRO', `${npcName} 死亡回溯链: (无记录)`);
            return;
        }
        // 【v2.4优化】去重：连续相同事件合并为"事件 ×N"
        // 第四世日志中DEATH_RETRO的50条全是重复的"[P0]第4天在室外,紧急返回室内"，浪费空间
        const deduped = [];
        let lastEvent = null;
        let lastTime = null;
        let repeatCount = 0;
        for (const e of buf) {
            if (e.event === lastEvent) {
                repeatCount++;
                lastTime = e.time; // 更新为最后一次的时间
            } else {
                if (lastEvent !== null) {
                    if (repeatCount > 1) {
                        deduped.push(`  [${lastTime}] ${lastEvent} ×${repeatCount}`);
                    } else {
                        deduped.push(`  [${lastTime}] ${lastEvent}`);
                    }
                }
                lastEvent = e.event;
                lastTime = e.time;
                repeatCount = 1;
            }
        }
        // 最后一组
        if (lastEvent !== null) {
            if (repeatCount > 1) {
                deduped.push(`  [${lastTime}] ${lastEvent} ×${repeatCount}`);
            } else {
                deduped.push(`  [${lastTime}] ${lastEvent}`);
            }
        }
        this.log('DEATH_RETRO', `${npcName} 死亡前关键事件回溯(${buf.length}条,去重后${deduped.length}条):\n${deduped.join('\n')}`);

        // 输出惩罚累计
        const pt = this._penaltyTrackers[npcId];
        if (pt) {
            const penaltyLines = [];
            if (pt.nightPenalty && pt.nightPenalty.duration > 0) {
                penaltyLines.push(`通宵惩罚: 累计${Math.round(pt.nightPenalty.duration / 60)}分钟, San累计-${pt.nightPenalty.sanLost.toFixed(1)}`);
            }
            if (pt.outdoorCold && pt.outdoorCold.duration > 0) {
                penaltyLines.push(`户外寒冷: 累计${Math.round(pt.outdoorCold.duration / 60)}分钟, HP累计-${pt.outdoorCold.hpLost.toFixed(1)}`);
            }
            if (pt.starvation && pt.starvation.duration > 0) {
                penaltyLines.push(`饥饿惩罚: 累计${Math.round(pt.starvation.duration / 60)}分钟, HP累计-${pt.starvation.hpLost.toFixed(1)}`);
            }
            if (pt.exhaustion && pt.exhaustion.duration > 0) {
                penaltyLines.push(`体力耗尽: 累计${Math.round(pt.exhaustion.duration / 60)}分钟, HP累计-${pt.exhaustion.hpLost.toFixed(1)}`);
            }
            if (pt.sanSpiral && pt.sanSpiral.duration > 0) {
                penaltyLines.push(`San恶性循环: 累计${Math.round(pt.sanSpiral.duration / 60)}分钟, San累计-${pt.sanSpiral.sanLost.toFixed(1)}`);
            }
            if (penaltyLines.length > 0) {
                this.log('DEATH_PENALTY', `${npcName} 惩罚累计:\n  ${penaltyLines.join('\n  ')}`);
            }
        }
    }

    /**
     * 【v2.0新增】DOOR日志 — 仅记录异常弹弹乐（5分钟内同一NPC进出同一门3次以上）
     * @param {string} npcId - NPC ID
     * @param {string} npcName - NPC名字
     * @param {string} scene - 场景名
     * @param {string} direction - 'in' 或 'out'
     * @param {string} fullMessage - 完整日志消息（仅在异常时记录）
     */
    logDoor(npcId, npcName, scene, direction, fullMessage) {
        const gameTime = this._getGameTimeSeconds();
        if (!this._doorHistory[npcId]) {
            this._doorHistory[npcId] = [];
        }
        const history = this._doorHistory[npcId];
        history.push({ time: gameTime, scene, direction });

        // 清理5分钟前的记录
        const cutoff = gameTime - 300;
        while (history.length > 0 && history[0].time < cutoff) {
            history.shift();
        }

        // 检测弹弹乐：5分钟内同一场景进出>=3次
        const sceneCount = history.filter(h => h.scene === scene).length;
        if (sceneCount >= 6) { // 进+出各算一次，所以6次=3个来回
            this.logDeduped('DOOR_ANOMALY', npcId, scene,
                `⚠️ ${npcName} 弹弹乐检测! 5分钟内进出${scene} ${sceneCount}次 | ${fullMessage}`);
        }

        // 记录到NPC事件缓冲区（用于死亡回溯，但不写入主日志）
        this.pushNpcEvent(npcId, `${direction === 'in' ? '进门→' : '出门←'}${scene}`);
    }

    /**
     * 批量发送缓冲区日志到服务端
     */
    _flush() {
        if (this._buffer.length === 0) return;

        const content = this._buffer.join('\n') + '\n';
        this._buffer = [];
        this._lastFlushTime = Date.now();

        fetch('/api/append-aimode-log', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: this.sessionFilename, content: content })
        }).catch(err => console.warn('[AIModeLogger] 日志写入失败:', err));
    }

    /**
     * 立即刷新缓冲区（结局时调用，确保数据完整性）
     */
    forceFlush() {
        this._flush();
    }

    /**
     * 记录断点续玩恢复信息（在load()成功后调用）
     */
    logContinueInfo() {
        const game = this.game;
        const dayNum = game.dayCount || 1;
        const timeStr = game.getTimeStr ? game.getTimeStr() : '??:??';
        const lifeNum = game.reincarnationSystem ? game.reincarnationSystem.getLifeNumber() : '?';
        const rs = game.resourceSystem;
        let resStr = '';
        if (rs) {
            resStr = ` | 资源:木柴${rs.woodFuel != null ? rs.woodFuel.toFixed(1) : '?'} 食物${rs.food != null ? rs.food.toFixed(1) : '?'} 电力${rs.power != null ? rs.power.toFixed(1) : '?'}`;
        }
        const alive = game.npcs ? game.npcs.filter(n => !n.isDead).length : '?';
        const total = game.npcs ? game.npcs.length : '?';
        this.log('CONTINUE', `💾 断点续玩恢复 | 第${lifeNum}世 D${dayNum} ${timeStr} | 存活${alive}/${total}${resStr}`);
    }

    /**
     * 获取当前游戏时间（秒，用于去重计算，跨天累积）
     */
    _getGameTimeSeconds() {
        const game = this.game;
        const day = game.dayCount || 1;
        const daySeconds = game.gameTimeSeconds || 0; // 当天内的秒数（0~86400）
        return (day - 1) * 86400 + daySeconds;
    }

    /**
     * 每帧更新，驱动缓冲区定时刷新、定期快照和异常检测
     * @param {number} gameDt - 游戏时间增量（秒）
     */
    update(gameDt) {
        // 1. 检查缓冲区定时刷新（基于真实时间）
        if (this._buffer.length > 0 && (Date.now() - this._lastFlushTime) >= this._flushInterval) {
            this._flush();
        }

        // 2. 快照定时器累积（基于游戏时间）— 每6游戏小时
        this._snapshotTimer += gameDt;
        if (this._snapshotTimer >= this._snapshotInterval) {
            this._snapshotTimer -= this._snapshotInterval;
            this._takeSnapshot();
            this._takeResourceSnapshot();
        }

        // 3. 【v2.0新增】异常行为检测（每5游戏分钟）
        this._anomalyCheckTimer += gameDt;
        if (this._anomalyCheckTimer >= this._anomalyCheckInterval) {
            this._anomalyCheckTimer -= this._anomalyCheckInterval;
            this._checkAnomalies(gameDt);
        }

        // 4. 【v2.0新增】更新异常追踪器（每帧累积）
        this._updateAnomalyTrackers(gameDt);

        // 5. 【v2.0新增】更新惩罚追踪器（每帧累积）
        this._updatePenaltyTrackers(gameDt);

        // 6. 【v2.0新增】每日摘要（新的一天开始时输出前一天摘要）
        const currentDay = this.game.dayCount || 1;
        if (currentDay > this._lastSummaryDay && this._lastSummaryDay > 0) {
            this._generateDailySummary(this._lastSummaryDay);
        }
        this._lastSummaryDay = currentDay;
    }
    // [已拆分到 aimode-anomaly.js] _takeSnapshot
    // [已拆分到 aimode-anomaly.js] _takeResourceSnapshot
    // [已拆分到 aimode-anomaly.js] _updateAnomalyTrackers
    // [已拆分到 aimode-anomaly.js] _checkAnomalies
    // [已拆分到 aimode-anomaly.js] _checkCollectiveDecisionBugs
    // [已拆分到 aimode-anomaly.js] _updatePenaltyTrackers
    // [已拆分到 aimode-anomaly.js] _generateDailySummary
    /**
     * 生成NPC属性快照字符串（供外部调用，如死亡日志、睡眠日志等）
     * @param {object} npc - NPC对象
     * @returns {string} 属性快照字符串
     */
    static npcAttrSnapshot(npc) {
        const hp = npc.health != null ? npc.health.toFixed(1) : '?';
        const sta = npc.stamina != null ? npc.stamina.toFixed(1) : '?';
        const hun = npc.hunger != null ? npc.hunger.toFixed(1) : '?';
        const san = npc.sanity != null ? npc.sanity.toFixed(1) : '?';
        const temp = npc.bodyTemp != null ? npc.bodyTemp.toFixed(1) : '?';
        return `HP:${hp} STA:${sta} HUN:${hun} SAN:${san} TEMP:${temp}`;
    }
}


    // 如果原代码定义了全局的 AIModeLogger 类，导出到 GST
    if (typeof AIModeLogger !== 'undefined') {
        GST.AIModeLogger = AIModeLogger;
    }
})();
