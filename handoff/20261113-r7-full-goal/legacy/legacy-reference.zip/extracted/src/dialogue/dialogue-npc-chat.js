/**
 * 福音镇 - NPC对话与聊天面板
 * 从 dialogue-manager.js 拆分，遵循SRP原则
 * 挂载到 GST.DialogueManager.prototype
 */
(function() {
    'use strict';
    const GST = window.GST;
    const proto = GST.DialogueManager.prototype;


    // ============ NPC ↔ NPC 对话 ============

    proto.startNPCChat = function(npc1, npc2) {
        // 【全局聊天开关】最终防线：开关关闭时所有NPC间聊天一律不执行
        if (!GST.CHAT_ENABLED) return;

        if (npc1.state === 'CHATTING' || npc2.state === 'CHATTING') return;

        // 【关键修复】任一NPC过了就寝时间就不发起新对话
        const chatHour = this.game.getHour();
        if (npc1._isBedtime(chatHour) || npc2._isBedtime(chatHour)) return;

        // 【关键修复】必须在同一场景才能发起对话，防止隔空聊天
        if (npc1.currentScene !== npc2.currentScene) {
            console.warn(`[对话阻止] ${npc1.name}(${npc1.currentScene}) 和 ${npc2.name}(${npc2.currentScene}) 不在同一场景，取消对话`);
            return;
        }

        // 【修复】下雨时禁止在户外发起对话，NPC应该先去避雨
        if (this.game.isRaining()) {
            const isOutdoor1 = npc1.currentScene === 'village';
            const isOutdoor2 = npc2.currentScene === 'village';
            if (isOutdoor1 || isOutdoor2) {
                console.log(`[对话阻止] 下雨天，${npc1.name}或${npc2.name}在户外，应先避雨，取消对话`);
                return;
            }
        }

        // 加入队列
        // 【Debug模式】对话轮数限制，加速测试
        const isDebugMode = this.game.mode === 'debug';
        this.npcChatQueue.push({
            npc1, npc2,
            messages: [],
            turn: 0,
            maxTurns: isDebugMode ? 6 : 10,  // debug=6轮，正常=10轮（14B模型每轮约30秒，10轮≈5分钟真实时间）
            startTime: Date.now() // 记录聊天开始时间，用于超时检测
        });

        npc1.state = 'CHATTING';
        npc2.state = 'CHATTING';

        // 【事件驱动镜头】通知镜头系统：对话开始
        if (this.game && this.game.onNPCEvent) {
            this.game.onNPCEvent(npc1, 'chat_start');
        }

        // 【关键修复】对话开始时立即清除双方的移动路径和相关状态
        // 防止NPC在等待LLM响应时继续沿路径走动、被传送到其他场景
        npc1.currentPath = [];
        npc1.pathIndex = 0;
        npc1.isMoving = false;
        npc1._pendingEnterScene = null;
        npc1._pendingEnterKey = null;
        npc1._chatWalkTarget = null;
        npc1._walkingToDoor = false;
        npc1._exitDoorCallback = null;
        npc2.currentPath = [];
        npc2.pathIndex = 0;
        npc2.isMoving = false;
        npc2._pendingEnterScene = null;
        npc2._pendingEnterKey = null;
        npc2._chatWalkTarget = null;
        npc2._walkingToDoor = false;
        npc2._exitDoorCallback = null;

        // 设置冷却
        const now = Date.now();
        npc1.chatCooldowns[npc2.id] = now;
        npc2.chatCooldowns[npc1.id] = now;
    };


    // ============ 聊天记录面板 ============

    /** 向聊天记录面板添加一条消息 */
    proto._addChatLogEntry = function(speakerName, text, type) {
        if (!this.chatLogContent) return;
        // 【v5.9】翻译NPC名字
        const translatedName = GST.i18n && GST.i18n.translateNpcNamesInText ? GST.i18n.translateNpcNamesInText(speakerName) : speakerName;
        const entry = document.createElement('div');
        // type: 'self' -> right(玩家/自己), 'other' -> left(NPC/对方)
        const align = type === 'self' ? 'right' : 'left';
        entry.className = `chat-log-msg ${align} new`;

        const time = this.game.getTimeStr();
        entry.innerHTML = `
            <span class="chat-log-speaker">${translatedName} <span class="chat-log-time">${time}</span></span>
            <div class="chat-log-text">${text}</div>
        `;

        this.chatLogContent.appendChild(entry);
        // 【v4.39】限制DOM节点数量，防止面板堆叠过多（从200降到30）
        while (this.chatLogContent.children.length > 30) {
            this.chatLogContent.removeChild(this.chatLogContent.firstChild);
        }
        // 自动滚动到底部
        this.chatLogContent.scrollTop = this.chatLogContent.scrollHeight;
    };


    /** 添加对话分隔标记 */
    proto._addChatLogDivider = function(label) {
        if (!this.chatLogContent) return;
        const divider = document.createElement('div');
        divider.className = 'chat-log-divider';
        divider.textContent = label;
        this.chatLogContent.appendChild(divider);
        // 【v4.39】限制DOM节点数量，防止面板堆叠过多（从200降到30）
        while (this.chatLogContent.children.length > 30) {
            this.chatLogContent.removeChild(this.chatLogContent.firstChild);
        }
        this.chatLogContent.scrollTop = this.chatLogContent.scrollHeight;
    };


    // ============ UI 管理 ============

    proto._showPanel = function(npc) {
        this.panel.style.display = 'block';
        this.portraitEl.src = npc.portrait.src || '';
        this.portraitEl.style.display = npc.portrait.src ? 'block' : 'none';
        this.nameEl.textContent = npc.name;
        this.textEl.textContent = '';
        this.inputRow.style.display = 'none';
    };


    proto.closeDialogue = function() {
        if (this.activeDialogue) {
            if (this.activeDialogue.npc) {
                this.activeDialogue.npc.state = 'IDLE';
            }
            this.activeDialogue = null;
        }
        this.panel.style.display = 'none';
        this.inputRow.style.display = 'none';
    };


    // ============ 深夜对话队列清理 ============

    /**
    * 深夜时清空排队中的对话，释放卡在CHATTING状态等待的NPC
    * 不会中断正在进行的对话（isProcessing的那个），只清理排队等待的
    */
    proto._clearChatQueueForNight = function() {
        if (this.npcChatQueue.length <= (this.isProcessing ? 1 : 0)) return; // 没有排队的

        // 保留正在处理的第一个（如果有），清除后面排队的
        const startIdx = this.isProcessing ? 1 : 0;
        const removed = this.npcChatQueue.splice(startIdx);
        for (const chat of removed) {
            // 释放排队中NPC的CHATTING状态
            if (chat.npc1 && chat.npc1.state === 'CHATTING') {
                chat.npc1.state = 'IDLE';
                chat.npc1._logDebug('chat', `深夜清理：对话队列中释放CHATTING状态`);
            }
            if (chat.npc2 && chat.npc2.state === 'CHATTING') {
                chat.npc2.state = 'IDLE';
                chat.npc2._logDebug('chat', `深夜清理：对话队列中释放CHATTING状态`);
            }
        }
        if (removed.length > 0) {
            console.log(`[深夜清理] 清除${removed.length}组排队对话，释放NPC回去睡觉`);
        }
    };

})();
