/**
 * 福音雪镇 - Electron Preload 脚本
 * 
 * 通过 contextBridge 安全地将 Steam SDK API 暴露给渲染进程
 * 渲染进程通过 window.steamAPI 访问
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('steamAPI', {
    // Steam 状态
    getStatus: () => ipcRenderer.invoke('steam:getStatus'),
    getPlayerInfo: () => ipcRenderer.invoke('steam:getPlayerInfo'),

    // 成就系统
    activateAchievement: (name) => ipcRenderer.invoke('steam:activateAchievement', name),
    isAchievementActivated: (name) => ipcRenderer.invoke('steam:isAchievementActivated', name),

    // Rich Presence（好友列表显示游戏状态）
    setRichPresence: (key, value) => ipcRenderer.invoke('steam:setRichPresence', key, value),

    // Steam Overlay
    openOverlayToWebPage: (url) => ipcRenderer.invoke('steam:openOverlayToWebPage', url),
    openOverlayToStore: (appId) => ipcRenderer.invoke('steam:openOverlayToStore', appId),

    // 云存档
    cloudSave: (name, content) => ipcRenderer.invoke('steam:cloudSave', name, content),
    cloudLoad: (name) => ipcRenderer.invoke('steam:cloudLoad', name),
    cloudList: () => ipcRenderer.invoke('steam:cloudList'),
});
