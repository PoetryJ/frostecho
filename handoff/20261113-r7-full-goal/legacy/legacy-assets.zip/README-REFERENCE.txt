FrostEcho original-game asset reference.
Source app.asar SHA256 ac7f45dd48be581dbc264dbcc795cbe4e5add0bc6678e6dafd2e6d08a4926005
85 extracted original assets; preserve asset/ and music/ relative paths.
Read-only reference. No model binaries, executables or credentials.
Verify with sha256sum -c SHA256SUMS.txt.
