const fs = require('node:fs');
const path = require('node:path');
const repo = path.resolve(process.argv[2]);
const out = path.resolve(process.argv[3]);
if (fs.existsSync(out)) throw new Error('fresh output required');
fs.mkdirSync(out, { recursive: true });
process.chdir(repo);
const {runStory} = require(path.join(repo, 'dist/scripts/verify-r6.js'));
runStory(out).then(result => {
  fs.writeFileSync(path.join(out, 'independent-story-result.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify({pass:result.pass, reason:result.reason,
    continuous:{minutes:result.continuous.simMinutes,meals:result.continuous.mealFulfilled,supply:result.continuous.supplyFulfilled},
    segmented:{minutes:result.segmented.simMinutes,meals:result.segmented.mealFulfilled,supply:result.segmented.supplyFulfilled}}));
  process.exitCode = result.pass ? 0 : 1;
}).catch(e => { console.error(e); process.exitCode = 2; });
