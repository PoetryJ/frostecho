import collections, hashlib, json, pathlib, re, subprocess, sys
repo=pathlib.Path(sys.argv[1]).resolve(); out=pathlib.Path(sys.argv[2]).resolve()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
changed=set(git('diff','--name-only','r6-taskpack-20261113','12cc208').decode().splitlines())
entries=[]
for record in git('ls-tree','-r','-l','-z','12cc208').split(b'\0'):
 if not record: continue
 meta,name=record.split(b'\t',1);mode,kind,oid,size=meta.split()
 if kind!=b'blob':continue
 name=name.decode();entries.append({'path':name,'bytes':int(size),'newInR6':name in changed})
groups=collections.defaultdict(lambda:{'files':0,'bytes':0})
for row in entries:
 key='/'.join(row['path'].split('/')[:2]);groups[key]['files']+=1;groups[key]['bytes']+=row['bytes']
patterns={
 'private_key':rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
 'github_token':rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{40,})',
 'aws_key':rb'\bAKIA[A-Z0-9]{16}\b',
 'provider_key':rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{30,}',
 'url_password':rb'https?://[^\s/:@]{2,}:[^\s/@]{8,}@'}
findings=[];count=0
for name in sorted(changed):
 p=repo/name
 if not p.is_file():continue
 data=p.read_bytes()
 if b'\0' in data[:8192]:continue
 count+=1
 for kind,pat in patterns.items():
  for m in re.finditer(pat,data):findings.append({'path':name,'line':data[:m.start()].count(b'\n')+1,'kind':kind})
suspects=[x for x in entries if re.search(r'(^|/)(node_modules|\.git|__pycache__|acceptance-clone|\.venv|dist)/|\.(pyc|safetensors|pt|pth|ckpt)$',x['path'])]
result={'head':git('rev-parse','HEAD').decode().strip(),'trackedFiles':len(entries),'trackedBytes':sum(x['bytes'] for x in entries),
 'r6ChangedFiles':len(changed),'r6ChangedBytesAtHead':sum(x['bytes'] for x in entries if x['newInR6']),
 'topFiles':sorted(entries,key=lambda x:x['bytes'],reverse=True)[:20],
 'groups':dict(sorted(groups.items(),key=lambda x:x[1]['bytes'],reverse=True)),
 'specialFiles':suspects,'secretPatternScan':{'textFiles':count,'findings':findings,'note':'Pattern check only; no matched values recorded, no credentials read.'}}
(out/'inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('trackedFiles','trackedBytes','r6ChangedFiles','r6ChangedBytesAtHead','topFiles','specialFiles','secretPatternScan')},indent=2))
