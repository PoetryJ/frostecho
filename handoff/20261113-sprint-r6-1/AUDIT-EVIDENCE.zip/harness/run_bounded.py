import argparse, datetime, json, os, pathlib, subprocess, sys, time
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--out',required=True);p.add_argument('--label',required=True);p.add_argument('--timeout',type=float,default=45);p.add_argument('argv',nargs=argparse.REMAINDER);a=p.parse_args()
out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
cmd=a.argv[1:] if a.argv and a.argv[0]=='--' else a.argv
env=os.environ.copy();env.update(FROSTECHO_LLM_URL='',FROSTECHO_LLM_MODEL='',CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
t=time.monotonic();at=datetime.datetime.now(datetime.timezone.utc).isoformat();timed=False
with (out/(a.label+'.stdout')).open('wb') as stdout,(out/(a.label+'.stderr')).open('wb') as stderr:
 proc=subprocess.Popen(cmd,cwd=a.repo,env=env,stdout=stdout,stderr=stderr)
 try:code=proc.wait(timeout=a.timeout)
 except subprocess.TimeoutExpired:
  timed=True
  kill=subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True,text=True)
  (out/(a.label+'.cleanup.txt')).write_text(kill.stdout+'\n'+kill.stderr,encoding='utf-8')
  code=proc.wait(timeout=10)
result={'argv':cmd,'cwd':a.repo,'pid':proc.pid,'at':at,'seconds':time.monotonic()-t,'timeoutSeconds':a.timeout,'timedOut':timed,'exit':code,'scope':'local CPU / loopback fake only'}
(out/(a.label+'.process.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result));sys.exit(124 if timed else code)
