"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * G04 workstream B — the lifecycle CLI as a real child process.
 *
 * Covers the contract points that only a subprocess can prove: one finalize
 * path that persists exactly once (quit / EOF / interrupted), exit 0 on a
 * normal end, 1 on HTTP failure or timeout, 2 on missing configuration, a
 * restock after idle re-pumping the scheduler, legacy never waking, and
 * `status` issuing no provider request at all.
 */
const strict_1 = __importDefault(require("node:assert/strict"));
const node_child_process_1 = require("node:child_process");
const node_http_1 = require("node:http");
const node_fs_1 = require("node:fs");
const node_os_1 = require("node:os");
const node_path_1 = require("node:path");
const node_test_1 = require("node:test");
const record_1 = require("../src/reactive/record");
const CLI = (0, node_path_1.resolve)('dist/scripts/play-g04.js');
async function runCli(args, input, env = {}) {
    return runCliSteps(args, [{ line: input }], env);
}
/**
 * Feed lines one at a time. When `until` is set, wait for that marker to appear
 * before writing the next line, so a test can observe "idle, then restock"
 * instead of racing an in-flight run (the CLI is meant to accept both).
 */
async function runCliSteps(args, steps, env = {}) {
    const outDir = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'g04-cli-'));
    const child = (0, node_child_process_1.spawn)(process.execPath, [CLI, '--out', outDir, '--episode', 'ep', ...args], {
        env: { ...process.env, ...env },
        stdio: ['pipe', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    let seen = 0;
    child.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
    child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
    const waitFor = async (marker) => {
        const deadline = Date.now() + 10_000;
        for (;;) {
            const next = stdout.indexOf(marker, seen);
            if (next >= 0) {
                seen = next + marker.length;
                return;
            }
            if (Date.now() > deadline)
                throw new Error(`timed out waiting for ${JSON.stringify(marker)}\n${stdout}`);
            await new Promise(r => setTimeout(r, 10));
        }
    };
    for (const step of steps) {
        child.stdin.write(step.line);
        if (step.until !== undefined)
            await waitFor(step.until);
    }
    child.stdin.end();
    const code = await new Promise(resolveExit => child.on('exit', c => resolveExit(c)));
    return { code, stdout, stderr, outDir };
}
const savedLines = (stdout) => stdout.split('\n').filter(line => line.includes('saved ') && !line.includes('[save]')).length;
function readSaved(outDir) {
    const episodeDir = (0, node_path_1.join)(outDir, 'ep', 'episodes', 'ep');
    const gameFile = (0, node_path_1.join)(episodeDir, 'game.json');
    strict_1.default.ok((0, node_fs_1.existsSync)(gameFile), `game.json must be saved under ${episodeDir}`);
    const record = JSON.parse((0, node_fs_1.readFileSync)(gameFile, 'utf8'));
    return { record, dir: episodeDir, verification: (0, record_1.verifyReactiveEpisode)(episodeDir) };
}
const totalCalls = (record) => Object.values(record.actors).reduce((sum, actor) => sum + actor.providerCalls, 0);
function chatServer(handler, counter) {
    const server = (0, node_http_1.createServer)((req, res) => {
        if (req.url === '/v1/models') {
            res.writeHead(200, { 'content-type': 'application/json' });
            res.end(JSON.stringify({ data: [{ id: 'qwen3.8-27b' }] }));
            return;
        }
        if (counter)
            counter.chats += 1;
        const answer = handler();
        if (answer === 'hang')
            return;
        res.writeHead(answer.status, { 'content-type': 'application/json' });
        res.end(answer.body);
    });
    return new Promise(resolveListen => {
        server.listen(0, '127.0.0.1', () => {
            const address = server.address();
            resolveListen({ server, url: `http://127.0.0.1:${address.port}/v1/chat/completions` });
        });
    });
}
(0, node_test_1.test)('missing live configuration exits 2 and names both environment variables', async () => {
    const run = await runCli(['--live'], 'quit\n', { FROSTECHO_LLM_URL: '', FROSTECHO_LLM_MODEL: '' });
    strict_1.default.equal(run.code, 2, run.stdout);
    strict_1.default.ok(run.stderr.includes('FROSTECHO_LLM_URL') && run.stderr.includes('FROSTECHO_LLM_MODEL'), run.stderr);
    strict_1.default.deepEqual((0, node_fs_1.readdirSync)(run.outDir), [], 'nothing to save without a game');
    (0, node_fs_1.rmSync)(run.outDir, { recursive: true, force: true });
});
(0, node_test_1.test)('reference event run saves once, exits 0, and both NPCs wait on an empty kitchen', async () => {
    // Wait for the run to drain before quitting: a quit that races an in-flight
    // run now closes the game synchronously (G04-R1-CLOSE) and would legitimately
    // stop the second NPC from ever starting.
    const run = await runCliSteps([], [
        { line: 'run\n', until: '[run idle]' },
        { line: 'quit\n' },
    ]);
    strict_1.default.equal(run.code, 0, `${run.stdout}\n${run.stderr}`);
    strict_1.default.equal(savedLines(run.stdout), 1, run.stdout);
    const { record, verification } = readSaved(run.outDir);
    strict_1.default.equal(record.wakePolicy, 'event');
    strict_1.default.equal(record.thinking, true);
    strict_1.default.equal(verification.ok, true, verification.issues.join('; '));
    strict_1.default.equal(totalCalls(record), 2);
    strict_1.default.equal(record.actors.npc_a.providerCalls, 1);
    strict_1.default.equal(record.actors.npc_c.providerCalls, 1);
    for (const id of ['npc_a', 'npc_c']) {
        strict_1.default.equal(record.actors[id].goalReached, false);
        strict_1.default.equal(record.finalState.npcs[id].hunger, 40);
        const transitions = record.transitions.filter(t => t.actorId === id);
        strict_1.default.equal(transitions.at(-1)?.to, 'waiting', `${id} must be waiting, not stopped`);
    }
    strict_1.default.equal(record.finalState.food.kitchen, 0);
    (0, node_fs_1.rmSync)(run.outDir, { recursive: true, force: true });
});
(0, node_test_1.test)('a restock after idle wakes both NPCs under the event policy', async () => {
    const run = await runCliSteps([], [
        { line: 'run\n', until: '[run idle]' },
        { line: 'world restock kitchen 2\n', until: '[world accepted]' },
        { line: 'run\n', until: '[run idle]' },
        { line: 'quit\n' },
    ]);
    strict_1.default.equal(run.code, 0, `${run.stdout}\n${run.stderr}`);
    strict_1.default.equal(savedLines(run.stdout), 1, run.stdout);
    const { record, verification } = readSaved(run.outDir);
    strict_1.default.equal(verification.ok, true, verification.issues.join('; '));
    strict_1.default.equal(totalCalls(record), 4);
    for (const id of ['npc_a', 'npc_c']) {
        strict_1.default.equal(record.finalState.npcs[id].hunger, 70);
        strict_1.default.equal(record.actors[id].state, 'satisfied');
        strict_1.default.equal(record.actors[id].cycles, 2, `${id} needs a second cycle`);
    }
    strict_1.default.equal(record.finalState.food.kitchen, 0);
    strict_1.default.equal(record.replayMatches, true);
    (0, node_fs_1.rmSync)(run.outDir, { recursive: true, force: true });
});
(0, node_test_1.test)('the legacy policy never wakes a stopped NPC after a restock', async () => {
    const run = await runCliSteps(['--policy', 'legacy'], [
        { line: 'run\n', until: '[run idle]' },
        { line: 'world restock kitchen 2\n', until: '[world accepted]' },
        { line: 'run\n', until: '[run idle]' },
        { line: 'quit\n' },
    ]);
    strict_1.default.equal(run.code, 0, `${run.stdout}\n${run.stderr}`);
    const { record, verification } = readSaved(run.outDir);
    strict_1.default.equal(verification.ok, true, verification.issues.join('; '));
    strict_1.default.equal(totalCalls(record), 2);
    for (const id of ['npc_a', 'npc_c']) {
        strict_1.default.equal(record.finalState.npcs[id].hunger, 40);
        strict_1.default.equal(record.actors[id].cycles, 1);
        strict_1.default.equal(record.actors[id].state, 'stopped');
    }
    strict_1.default.equal(record.finalState.food.kitchen, 2, 'the restock itself still lands');
    (0, node_fs_1.rmSync)(run.outDir, { recursive: true, force: true });
});
(0, node_test_1.test)('an out-of-range restock is rejected and leaves the world unchanged', async () => {
    const run = await runCliSteps([], [
        { line: 'run\n', until: '[run idle]' },
        { line: 'world restock kitchen 99\n', until: '[world rejected]' },
        { line: 'world restock dorm 0\n', until: '[world rejected]' },
        { line: 'quit\n' },
    ]);
    strict_1.default.equal(run.code, 0, `${run.stdout}\n${run.stderr}`);
    const { record } = readSaved(run.outDir);
    strict_1.default.equal(record.finalState.food.kitchen, 0);
    strict_1.default.equal(record.finalState.food.dorm, 0);
    // Rejected commands are still in the world ledger; none may be accepted.
    strict_1.default.equal(record.commands.some(entry => entry.command.type === 'restock' && entry.result.status === 'accepted'), false);
    strict_1.default.equal((run.stdout.match(/\[world rejected\]/g) ?? []).length, 2, run.stdout);
    (0, node_fs_1.rmSync)(run.outDir, { recursive: true, force: true });
});
(0, node_test_1.test)('EOF without quit still saves exactly once and exits 0', async () => {
    const run = await runCliSteps([], [{ line: 'run\n', until: '[run idle]' }]);
    strict_1.default.equal(run.code, 0, `${run.stdout}\n${run.stderr}`);
    strict_1.default.equal(savedLines(run.stdout), 1, run.stdout);
    const { record } = readSaved(run.outDir);
    strict_1.default.ok(['completed', 'user_closed'].includes(record.stopReason), record.stopReason);
    (0, node_fs_1.rmSync)(run.outDir, { recursive: true, force: true });
});
(0, node_test_1.test)('HTTP 500 exits 1 and still persists one interrupted record', async () => {
    const { server, url } = await chatServer(() => ({ status: 500, body: JSON.stringify({ error: 'boom' }) }));
    try {
        const run = await runCli(['--live'], 'run\nquit\n', { FROSTECHO_LLM_URL: url, FROSTECHO_LLM_MODEL: 'qwen3.8-27b' });
        strict_1.default.equal(run.code, 1, `${run.stdout}\n${run.stderr}`);
        strict_1.default.equal(savedLines(run.stdout), 1, run.stdout);
        const { record } = readSaved(run.outDir);
        strict_1.default.equal(record.stopReason, 'interrupted');
        strict_1.default.equal(record.mode, 'live');
        (0, node_fs_1.rmSync)(run.outDir, { recursive: true, force: true });
    }
    finally {
        server.close();
    }
});
(0, node_test_1.test)('HTTP timeout exits 1 and still persists one interrupted record', async () => {
    const { server, url } = await chatServer(() => 'hang');
    try {
        const run = await runCli(['--live', '--timeout', '300'], 'run\nquit\n', { FROSTECHO_LLM_URL: url, FROSTECHO_LLM_MODEL: 'qwen3.8-27b' });
        strict_1.default.equal(run.code, 1, `${run.stdout}\n${run.stderr}`);
        strict_1.default.equal(savedLines(run.stdout), 1, run.stdout);
        const { record } = readSaved(run.outDir);
        strict_1.default.equal(record.stopReason, 'interrupted');
        (0, node_fs_1.rmSync)(run.outDir, { recursive: true, force: true });
    }
    finally {
        server.close();
    }
});
(0, node_test_1.test)('status only reads: a live session issues no chat request for status, and quit saves', async () => {
    const counter = { chats: 0 };
    const { server, url } = await chatServer(() => ({ status: 200, body: JSON.stringify({ choices: [{ message: { content: '{"type":"stop"}' } }] }) }), counter);
    try {
        const run = await runCliSteps(['--live'], [
            { line: 'status\n', until: 'commands=' },
            { line: 'status\n', until: 'commands=' },
            { line: 'quit\n' },
        ], { FROSTECHO_LLM_URL: url, FROSTECHO_LLM_MODEL: 'qwen3.8-27b' });
        strict_1.default.equal(run.code, 0, `${run.stdout}\n${run.stderr}`);
        strict_1.default.equal(counter.chats, 0, 'status must not call the model');
        strict_1.default.equal(savedLines(run.stdout), 1, run.stdout);
        const { record } = readSaved(run.outDir);
        strict_1.default.equal(totalCalls(record), 0);
        strict_1.default.equal(record.stopReason, 'user_closed');
        (0, node_fs_1.rmSync)(run.outDir, { recursive: true, force: true });
    }
    finally {
        server.close();
    }
});
(0, node_test_1.test)('quit during an in-flight live request waits only the started request', async () => {
    // G04-R1-CLOSE at the CLI level: quit while npc_a's request is on the wire
    // must not start npc_c, must reject later input, and must save exactly once.
    let release;
    const gate = new Promise(resolve => { release = resolve; });
    const counter = { chats: 0 };
    const server = (0, node_http_1.createServer)((req, res) => {
        if (req.url === '/v1/models') {
            res.writeHead(200, { 'content-type': 'application/json' });
            res.end(JSON.stringify({ data: [{ id: 'qwen3.8-27b' }] }));
            return;
        }
        counter.chats += 1;
        void gate.then(() => {
            res.writeHead(200, { 'content-type': 'application/json' });
            res.end(JSON.stringify({ choices: [{ message: { content: '{"type":"stop"}' } }] }));
        });
    });
    await new Promise(resolveListen => { server.listen(0, '127.0.0.1', resolveListen); });
    const url = `http://127.0.0.1:${server.address().port}/v1/chat/completions`;
    try {
        const outDir = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'g04-cli-close-'));
        const child = (0, node_child_process_1.spawn)(process.execPath, [CLI, '--live', '--out', outDir, '--episode', 'ep'], {
            env: { ...process.env, FROSTECHO_LLM_URL: url, FROSTECHO_LLM_MODEL: 'qwen3.8-27b' },
            stdio: ['pipe', 'pipe', 'pipe'],
        });
        let stdout = '';
        child.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
        child.stderr.on('data', () => { });
        child.stdin.write('run\n');
        const deadline = Date.now() + 10_000;
        while (counter.chats < 1 && Date.now() < deadline)
            await new Promise(r => setTimeout(r, 10));
        strict_1.default.equal(counter.chats, 1, 'npc_a request must be in flight');
        child.stdin.write('quit\n');
        // While the started request is still on the wire, later input is refused.
        child.stdin.write('world restock kitchen 1\n');
        for (;;) {
            if (stdout.includes('[world rejected]'))
                break;
            if (Date.now() > deadline)
                throw new Error(`post-quit input not refused\n${stdout}`);
            await new Promise(r => setTimeout(r, 10));
        }
        // Only now does the in-flight request settle; finalize prints after close drains.
        release();
        for (;;) {
            if (stdout.includes('[finalize quit]'))
                break;
            if (Date.now() > deadline)
                throw new Error(`finalize not reached\n${stdout}`);
            await new Promise(r => setTimeout(r, 10));
        }
        // Audit-only scheduler-delay control; production source is unchanged.
        await new Promise(r => setTimeout(r, 100));
        const codeBeforeListener = child.exitCode;
        const observed = await Promise.race([
            new Promise(resolveExit => child.on('exit', c => resolveExit({eventReceived:true,code:c}))),
            new Promise(resolveWait => setTimeout(() => resolveWait({eventReceived:false,code:null}), 200)),
        ]);
        console.error('AUDIT_LATE_EXIT ' + JSON.stringify({codeBeforeListener,observed}));
        require('node:assert/strict').equal(observed.eventReceived, true, 'late exit listener misses an already exited child');
        const code = observed.code;
        strict_1.default.equal(code, 0, stdout);
        strict_1.default.equal(counter.chats, 1, 'no second request may start after quit');
        strict_1.default.equal(savedLines(stdout), 1, stdout);
        const { record, verification } = readSaved(outDir);
        strict_1.default.equal(verification.ok, true, verification.issues.join('; '));
        strict_1.default.equal(record.actors.npc_a.providerCalls, 1);
        strict_1.default.equal(record.actors.npc_c.providerCalls, 0);
        strict_1.default.equal(record.stopReason, 'user_closed');
        (0, node_fs_1.rmSync)(outDir, { recursive: true, force: true });
    }
    finally {
        server.close();
    }
});
(0, node_test_1.test)('live timeout precedence: --timeout beats env, env beats the 30s default', async () => {
    // No chat request at all: status/quit only. The effective value must still be
    // the one actually handed to the runner and recorded (G04-R1-TIMEOUT).
    const fakeEnv = (timeout) => ({
        FROSTECHO_LLM_URL: 'http://127.0.0.1:9/v1/chat/completions',
        FROSTECHO_LLM_MODEL: 'unused-no-request',
        ...(timeout === undefined ? { FROSTECHO_LIVE_TIMEOUT_MS: '' } : { FROSTECHO_LIVE_TIMEOUT_MS: timeout }),
    });
    const recorded = async (args, env) => {
        const run = await runCli(args, 'status\nquit\n', env);
        strict_1.default.equal(run.code, 0, `${run.stdout}\n${run.stderr}`);
        return readSaved(run.outDir).record.requestConfig.timeoutMs;
    };
    strict_1.default.equal(await recorded(['--live'], fakeEnv('120000')), 120_000, 'env override reaches the record');
    strict_1.default.equal(await recorded(['--live', '--timeout', '45000'], fakeEnv('120000')), 45_000, 'explicit --timeout beats env');
    strict_1.default.equal(await recorded(['--live'], fakeEnv()), 30_000, 'default is the 30s live decision timeout, not 15s');
    strict_1.default.equal(await recorded(['--live'], fakeEnv('not-a-number')), 30_000, 'invalid env falls back to the default');
    const invalid = await runCli(['--live', '--timeout', 'abc'], 'quit\n', fakeEnv());
    strict_1.default.equal(invalid.code, 2, `${invalid.stdout}\n${invalid.stderr}`);
    strict_1.default.ok(invalid.stderr.includes('--timeout'), invalid.stderr);
});
(0, node_test_1.test)('offline reference mode records the same effective timeout resolution', async () => {
    const run = await runCli([], 'status\nquit\n', { FROSTECHO_LIVE_TIMEOUT_MS: '120000' });
    strict_1.default.equal(run.code, 0, `${run.stdout}\n${run.stderr}`);
    strict_1.default.equal(readSaved(run.outDir).record.requestConfig.timeoutMs, 120_000);
});
